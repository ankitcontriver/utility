#!/usr/bin/env python3
"""
Sakura Performance Configuration

This module provides optimized configuration settings for high-load scenarios
and performance tuning for AsyncLoop workers, thread pools, Redis operations,
and utterance timing intervals.

Key Environment Variables:
- UTTERANCE_TIMER: Complete utterance processing timeout (ms, default: 500)
- INCOMP_UTTERANCE_TIMER: Incomplete utterance wait timeout (ms, default: 500)  
- SPEECH_WAIT_TIMER: Speech processing wait timeout (ms, default: 3000)
- ASYNC_NUM_LOOPS: Number of AsyncLoop workers
- ASYNC_MAX_WORKERS_PER_LOOP: Workers per AsyncLoop
"""

import os
from logger import get_logger

logger = get_logger(__name__)

class PerformanceConfig:
    """Centralized performance configuration management"""
    
    def __init__(self):
        # CPU detection for auto-scaling
        self.cpu_count = os.cpu_count() or 4
        
        # AsyncLoop configuration (main bottleneck fix) - using your existing variable names
        self.async_num_loops = int(os.getenv('ASYNC_NUM_LOOPS', self._calculate_optimal_loops()))
        self.async_workers_per_loop = int(os.getenv('ASYNC_MAX_WORKERS_PER_LOOP', self._calculate_optimal_workers_per_loop()))
        
        # Thread pool configuration - using your existing variable name
        self.thread_pool_workers = int(os.getenv('THREAD_POOL_MAX_WORKERS', self._calculate_thread_pool_workers()))
        
        # Redis configuration
        self.redis_connection_pool_size = int(os.getenv('SAKURA_REDIS_POOL_SIZE', 50))
        self.redis_max_connections = int(os.getenv('SAKURA_REDIS_MAX_CONNECTIONS', 100))
        
        # LLM API configuration
        self.llm_max_concurrent = int(os.getenv('SAKURA_LLM_MAX_CONCURRENT', 100))
        self.llm_timeout = int(os.getenv('SAKURA_LLM_TIMEOUT', 30))
        
        # Utterance timing configuration (memory cache expiry intervals in milliseconds)
        self.utterance_timer = int(os.getenv('UTTERANCE_TIMER', 500))  # Complete utterance processing timeout
        self.incomp_utterance_timer = int(os.getenv('INCOMP_UTTERANCE_TIMER', 500))  # Incomplete utterance wait timeout
        self.speech_utterance_timer = int(os.getenv('SPEECH_WAIT_TIMER', 3000))  # Speech processing wait timeout
        
        # Performance monitoring
        self.enable_performance_logging = os.getenv('SAKURA_PERF_LOGGING', 'true').lower() == 'true'
        self.queue_size_alert_threshold = int(os.getenv('SAKURA_QUEUE_ALERT_THRESHOLD', 20))
        
        self._log_configuration()
    
    def _calculate_optimal_loops(self) -> int:
        """Calculate optimal number of async loops - optimized for Redis burst handling"""
        # OPTIMIZED: More loops for better Redis message distribution and concurrency
        # Based on analysis showing Redis message processing delays with too few loops
        return min(48, max(24, self.cpu_count * 6))  # 24-48 loops for Redis burst handling
    
    def _calculate_optimal_workers_per_loop(self) -> int:
        """Calculate optimal workers per async loop - optimized for Redis concurrency"""
        # OPTIMIZED: Fewer workers per loop, more loops for better Redis message distribution
        # Target: distribute Redis processing across more loops rather than queue in fewer loops
        return 6  # Fewer workers per loop, more loops for better Redis concurrency
    
    def _calculate_thread_pool_workers(self) -> int:
        """Calculate optimal thread pool size"""
        # For general purpose thread pools
        return max(20, self.cpu_count * 4)
    
    def _log_configuration(self):
        """Log the current performance configuration"""
        total_async_workers = self.async_num_loops * self.async_workers_per_loop
        
        logger.info("Sakura Performance Configuration:")
        logger.info(f"   CPU Cores: {self.cpu_count}")
        logger.info(f"   AsyncLoop Configuration:")
        logger.info(f"     - Number of loops: {self.async_num_loops}")
        logger.info(f"     - Workers per loop: {self.async_workers_per_loop}")
        logger.info(f"     - Total async workers: {total_async_workers}")
        logger.info(f"   Thread Pool Workers: {self.thread_pool_workers}")
        logger.info(f"   Redis Pool Size: {self.redis_connection_pool_size}")
        logger.info(f"   LLM Max Concurrent: {self.llm_max_concurrent}")
        logger.info(f"   Performance Logging: {self.enable_performance_logging}")
        
        if total_async_workers < 100:
            logger.warning(f"Total async workers ({total_async_workers}) may be insufficient for Redis burst handling")
        elif total_async_workers > 400:
            logger.warning(f"Total async workers ({total_async_workers}) may be excessive - consider reducing")
        else:
            logger.info(f"Async worker configuration looks optimal for Redis burst handling")
    
    def get_env_vars(self) -> dict:
        """Get environment variables for this configuration"""
        return {
            # Using your existing variable names
            'ASYNC_NUM_LOOPS': str(self.async_num_loops),
            'ASYNC_MAX_WORKERS_PER_LOOP': str(self.async_workers_per_loop),
            'THREAD_POOL_MAX_WORKERS': str(self.thread_pool_workers),
            # Additional Sakura-specific variables
            'SAKURA_REDIS_POOL_SIZE': str(self.redis_connection_pool_size),
            'SAKURA_REDIS_MAX_CONNECTIONS': str(self.redis_max_connections),
            'SAKURA_LLM_MAX_CONCURRENT': str(self.llm_max_concurrent),
            'SAKURA_LLM_TIMEOUT': str(self.llm_timeout),
            'SAKURA_PERF_LOGGING': str(self.enable_performance_logging).lower(),
            'SAKURA_QUEUE_ALERT_THRESHOLD': str(self.queue_size_alert_threshold)
        }
    
    def apply_to_environment(self):
        """Apply configuration to environment variables"""
        env_vars = self.get_env_vars()
        for key, value in env_vars.items():
            os.environ[key] = value
            logger.debug(f"Set {key}={value}")
    
    @staticmethod
    def get_load_profile(concurrent_calls: int) -> str:
        """Get load profile description based on concurrent calls"""
        if concurrent_calls <= 20:
            return "Light (≤20 calls)"
        elif concurrent_calls <= 50:
            return "Medium (21-50 calls)"
        elif concurrent_calls <= 100:
            return "Heavy (51-100 calls)"
        elif concurrent_calls <= 200:
            return "Very Heavy (101-200 calls)"
        else:
            return "Extreme (>200 calls)"

# Global configuration instance
perf_config = PerformanceConfig()

def apply_high_performance_config():
    """Apply high-performance configuration for production environments"""
    logger.info("Applying high-performance configuration...")
    
    # Apply the configuration to environment
    perf_config.apply_to_environment()
    
    # Set additional performance environment variables
    additional_vars = {
        # Python optimizations
        'PYTHONUNBUFFERED': '1',
        'PYTHONDONTWRITEBYTECODE': '1',
        
        # AsyncIO optimizations  
        'PYTHONASYNCIODEBUG': '0',
        'PYTHONASYNCIO_LOG_THRESHOLD': '1.0',  # Reduce AsyncIO queue warnings
        
        # Logging optimizations
        'LOG_LEVEL': 'INFO',  # Reduce debug logging overhead
    }
    
    for key, value in additional_vars.items():
        os.environ[key] = value
        logger.debug(f"Set {key}={value}")
    
    logger.info("High-performance configuration applied")
    return perf_config

def get_performance_recommendations(current_load: int) -> list:
    """Get performance recommendations based on current load"""
    recommendations = []
    
    profile = PerformanceConfig.get_load_profile(current_load)
    
    if current_load > 100:
        recommendations.extend([
            "Consider horizontal scaling (multiple server instances)",
            "Monitor LLM API rate limits and response times",
            "Implement request queuing with priority",
            "Add load balancing across multiple instances"
        ])
    
    if current_load > 50:
        recommendations.extend([
            "Monitor async worker queue depths",
            "Consider increasing Redis connection pools",
            "Enable performance logging for detailed analysis"
        ])
    
    recommendations.extend([
        f"Current load profile: {profile}",
        f"Recommended async workers: {perf_config.async_num_loops * perf_config.async_workers_per_loop}",
        "Monitor response times and adjust configuration as needed"
    ])
    
    return recommendations

if __name__ == "__main__":
    # CLI tool for configuration testing
    import sys
    
    if len(sys.argv) > 1:
        concurrent_calls = int(sys.argv[1])
        print(f"Performance recommendations for {concurrent_calls} concurrent calls:")
        for rec in get_performance_recommendations(concurrent_calls):
            print(f"  • {rec}")
    else:
        print("Usage: python performance_config.py <concurrent_calls>")
        print(f"Current configuration supports up to ~{perf_config.async_num_loops * perf_config.async_workers_per_loop * 2} concurrent calls efficiently")

