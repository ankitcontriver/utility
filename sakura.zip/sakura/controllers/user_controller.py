import base64
from urllib import request

from response.GenericResponse import GenericResponse
from fastapi import APIRouter, Header
from typing import Optional
from logger import get_logger
from models.request_models import GetMenuRequest, LoginRequest, SignUpRequest, UidLoginRequest, ContactForm
from service.user_service import get_menu_service, login_service, sign_up_service, check_login_service, log_out_service, upsert_password_service, uid_login_service, url_tracer, send_login_cred_service, get_all_url_service, get_url_details_service, get_url_details_by_email_service, get_all_users_service, forgot_password_service, contact_service

logger = get_logger(__name__)

router = APIRouter()


@router.post("/get-menu", tags=["User Login and Other Details"])
def get_menu(request: GetMenuRequest):
    logger.info(f"get_menu controller hit for user type : {request.user_type}")
    return get_menu_service(request)


@router.post("/login", tags=["User Login and Other Details"])
def login(request: LoginRequest):
    logger.info(f"login controller hit for email : {request.email}")
    return login_service(request)


@router.post("/signup", tags=["User Login and Other Details"])
def sign_up(request: SignUpRequest):
    logger.info(f"sign_up controller hit for email : {request.email}")
    return sign_up_service(request)


@router.get("/check-login", tags=["User Login and Other Details"])
def check_login(user_id: int):
    logger.info(f"check_login controller hit for user_id: {user_id}")
    return check_login_service(user_id)


@router.post("/logout", tags=["User Login and Other Details"])
def logout(user_id: int):
    logger.info(f"logout controller hit for user_id: {user_id}")
    return log_out_service(user_id)


@router.post("/create-password", tags=["User Login and Other Details"])
def upsert_password(encoded_user_id: str, password: str):
    user_id = int(base64.b64decode(encoded_user_id))
    logger.info(f"upsert_password controller hit for user_id : {user_id}")
    if upsert_password_service(user_id, password):
        return GenericResponse(status_code=200, status="SUCCESS", message="Success")
    return GenericResponse(status_code=400, status="FAILED", message="Failed")


@router.post("/login-by-uid", tags=["User Login and Other Details"])
def login_by_uid(request: UidLoginRequest):
    logger.info(f"login-by-uid controller hit for user_id : {request.user_id}")
    url_tracer(request)
    return uid_login_service(request)


@router.post("/send-login-cred", tags=["User Login and Other Details"])
def send_login_cred(email: str, name: Optional[str] = "Guest", language: Optional[str] = "en-US", voice: Optional[str] = "en-US-AvaNeural", demo_flow: Optional[str] = "v2", org: Optional[int] = 1,is_bng: Optional[bool] = False):
    logger.info(f"send_login_cred controller hit with params : {email}, {name}, {language}, {voice}, {demo_flow}, {org}, {is_bng}")
    if name == "":
        name = "Guest"
    return send_login_cred_service(email, name, language, voice, demo_flow, org, is_bng)


@router.post("/save-url-count", tags=["Extra Utility"])
def save_url_count(url: str):
    logger.info(f"save_url_count controller hit for url : {url}")
    req = UidLoginRequest(user_id=url, ip="")
    url_tracer(req)
    return GenericResponse(status_code=200, status="SUCCESS", message="Data Saved")


@router.get("/get-all-url-count", tags=["Extra Utility"])
def get_all():
    logger.info(f"get_all_url_count controller hit")
    return get_all_url_service()


@router.get("/get-url-details", tags=["Extra Utility"])
def get_url(url: str):
    logger.info(f"get_url_details controller hit for url : {url}")
    return get_url_details_service(url)


@router.get("/get-url-details-by-email", tags=["Extra Utility"])
def get_url_details_by_email(email: str):
    logger.info(f"get_url_details_by_email controller hit for email : {email}")
    return get_url_details_by_email_service(email)


@router.get("/get-all-users", tags=["Extra Utility"])
def get_all_users():
    logger.info(f"get_all_users controller hit for all users")
    return get_all_users_service()


@router.post("/forgot-password", tags=["User Login and Other Details"])
def forgot_password(email: str):
    logger.info(f"forgot_password controller hit for email : {email}")
    return forgot_password_service(email)


@router.post("/contact-form", tags=["User Login and Other Details"])
def submit_contact_form(req: ContactForm):
    logger.info(f"submit_contact_form controller hit for request body : {req}")
    return contact_service(req)
