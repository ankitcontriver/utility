from sqlalchemy.orm import Session

from models.database_models import CallLog
from models.request_models import CallLogsRequest


def get_call_logs_asc(db: Session, email: str):
    return db.query(CallLog).filter(CallLog.email == email).order_by(CallLog.date.asc()).all()


def get_call_logs_desc(db: Session, email: str):
    return db.query(CallLog).filter(CallLog.email == email).order_by(CallLog.date.desc()).all()


def save(db: Session, call_log: CallLogsRequest):
    db.add(call_log)
    db.commit()
