from typing import List
from sqlalchemy.orm import Session
from models.global_database_models import SecurityProperties
from logger import get_logger

logger = get_logger(__name__)

def get_all_security_properties(db: Session) -> List[SecurityProperties]:
    """
    Get all security properties from global database.
    """
    try:
        settings = db.query(SecurityProperties).all()
        
        logger.info(f"Retrieved {len(settings)} security properties from global DB")
        return settings
        
    except Exception as e:
        logger.error(f"Error retrieving security properties from global DB: {e}")
        raise

def get_security_properties_by_operator_country(db: Session, operator: str, country: str) -> List[SecurityProperties]:
    """
    Get security properties for specific operator and country from global database.
    """
    try:
        settings = db.query(SecurityProperties).filter(
            SecurityProperties.operator == operator,
            SecurityProperties.country == country
        ).all()
        
        logger.info(f"Retrieved {len(settings)} security properties for {operator}_{country} from global DB")
        return settings
        
    except Exception as e:
        logger.error(f"Error retrieving security properties for {operator}_{country} from global DB: {e}")
        raise