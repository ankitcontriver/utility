import base64
import os
import re
from io import BytesIO

import requests
from elevenlabs import VoiceSettings
from elevenlabs.client import ElevenLabs
from openai import OpenAI

from logger import get_logger
from utils.alarm_utils import send_alarm, run_alarm_in_thread

logger = get_logger(__name__)

api_key = os.getenv('OPENAI_API_KEY')
# Removed hardcoded Azure TTS configuration - now using database-cached configurations
# All TTS operations now use multi-client configuration system

def get_tts_config_for_request(assistant_id: str = None) -> tuple:
    """Get appropriate TTS configuration based on assistant configuration"""
    if not assistant_id:
        logger.warning("No assistant_id provided for TTS configuration")
        return None, None
        
    try:
        from cache.assistant_configuration_cache import get_assistant_details_by_id
        from service.multi_client_config_service import multi_client_manager, get_op_co_key
        
        assistant_config = get_assistant_details_by_id(int(assistant_id))
        if not assistant_config:
            logger.warning(f"No assistant config found for assistant_id: {assistant_id}")
            return None, None
        
        operator = assistant_config.get('operator')
        country = assistant_config.get('country')
        
        if not operator or not country:
            logger.warning(f"Missing operator/country in assistant config for {assistant_id}")
            return None, None
        
        op_co = get_op_co_key(operator, country)
        tts_config = multi_client_manager.get_tts_client(op_co)
        
        if tts_config:
            logger.info(f"Using multi-client TTS for {op_co} (assistant: {assistant_id})")
            return tts_config.api_url, tts_config.api_key
        else:
            logger.error(f"No TTS client found for {op_co}")
            return None, None
            
    except Exception as e:
        logger.error(f"Error getting TTS config for assistant {assistant_id}: {e}")
        return None, None

ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY")
ARABIC_ELEVENLABS_API_KEY = os.getenv("ARABIC_ELEVENLABS_API_KEY")
ARABIC_VOICE_ID = os.getenv("ARABIC_VOICE_ID")

eleven_labs_client = ElevenLabs(
    api_key=ELEVENLABS_API_KEY,
)

# Dictionary with words and their equivalents
replacements_umniah = {
    "امنية": "أُمنية",
    "بسمعك": "بسْمَعك",
    "منسف": "مَنْسَف",
    "ملك": "مَلِك",
    "بتكون": "بِتْكُون",
    "بعرف": "بَعرِف",
    "منيح": "مْنِيح",
    "مرحبا": "مَرحَبا",
    "ذكي": "ذكْيِ",
    "اشتراكك": "اشتراكَكَ",
    "اشتركت": "اشترَكْتَ"
}

client = OpenAI(api_key=api_key)


def replace_vi_ssml(text):
    replace_text = "<phoneme alphabet='x-sampa' ph='vi'></phoneme>"
    result = re.sub(r"(?i)\bvi\b", replace_text, text)
    return result


def replace_omniah_ssml(text):
    replace_text = "<phoneme alphabet='x-sampa' ph='u:m.ni.ja:h'></phoneme>"
    result = re.sub(r"(?i)\bumniah\b", replace_text, text)
    return result


def replace_words_umniah(line: str) -> str:
    # Replace each target word with its equivalent
    for target, replacement in replacements_umniah.items():
        line = line.replace(target, replacement)

    return line


def replace_word_mueen(text):
    text = text.replace("مُعين", "موعين").replace("معين", "موعين")
    return text


def get_corrected_lang_code(lang_code: str, voice_name: str):
    try:
        final_code = f"{lang_code}-{voice_name.split('-')[1]}"
        logger.info(f"final language code ----> {final_code}")
        return final_code
    except Exception as e:
        logger.error(f"Error in getting correct language code in audio_controller.py: {e}", exc_info=True)
        raise RuntimeError("Error in getting correct language code")


def generate_audio_google(message: str, language_code: str = "en-IN", voice_name: str = "en-IN-Neural2-D",
                          gender: str = "female"):
    """Synthesizes speech from the input string of text."""
    try:
        from google.cloud import texttospeech

        client = texttospeech.TextToSpeechClient()

        input_text = texttospeech.SynthesisInput(text=message)

        gender_map = {
            "male": texttospeech.SsmlVoiceGender.MALE,
            "female": texttospeech.SsmlVoiceGender.FEMALE,
            "neutral": texttospeech.SsmlVoiceGender.NEUTRAL
        }

        ssml_gender = gender_map.get(gender.lower(), texttospeech.SsmlVoiceGender.NEUTRAL)
        logger.info(f"type ssml gender -------> {type(ssml_gender)}")

        if len(language_code.split("-")) < 2:
            language_code = get_corrected_lang_code(lang_code=language_code, voice_name=voice_name)

        voice = texttospeech.VoiceSelectionParams(
            language_code=language_code,
            name=voice_name,
            ssml_gender=ssml_gender,
        )

        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.MULAW,
            pitch=0.8,
            speaking_rate=1.12
        )

        response = client.synthesize_speech(
            request={"input": input_text, "voice": voice, "audio_config": audio_config}
        )

        # The response's audio_content is binary.
        audio_data = response.audio_content

        # Encode the audio data to Base64
        base64_audio = base64.b64encode(audio_data).decode("utf-8")

        return base64_audio
    except Exception as e:
        logger.error(f"Error in generating audio via google in audio_controller.py: {e}", exc_info=True)
        raise RuntimeError("Error in generating audio via google")


def generate_audio_azure(text: str, lang="en-US", voice_name="en-US-AvaNeural", tts_style="chat", retry=True, assistant_id=None):
    logger.info(f"inside generate_audio_azure")
    
    # Get TTS configuration from multi-client system
    tts_url, tts_key = get_tts_config_for_request(assistant_id)
    
    if not tts_url or not tts_key:
        logger.warning("No TTS configuration available, using environment fallback")
        tts_url = os.getenv('AZURE_TTS_URL')
        tts_key = os.getenv('AZURE_SUB_KEY')
    
    url = f'{tts_url}'
    text = text.replace("&", " and ")
    text = text.replace("<", " ")
    text = text.replace(">", " ")
    text = replace_words_umniah(text)
    logger.info(f"inside generate_audio_azure -> replacement done 1")
    headers = {
        'Ocp-Apim-Subscription-Key': f'{tts_key}',
        'Content-Type': 'application/ssml+xml',
        'X-Microsoft-OutputFormat': 'riff-8khz-16bit-mono-pcm',
        'User-Agent': 'curl'
    }
    text = replace_vi_ssml(text)
    text = replace_omniah_ssml(text)
    text = replace_word_mueen(text)
    logger.info(f"inside generate_audio_azure -> replacement done 2")
    data = f"""
    <speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xmlns:mstts='https://www.w3.org/2001/mstts' xml:lang='{lang}'>
        <voice name='{voice_name}'>
            <mstts:express-as style='{tts_style}' styledegree='1.5'>
                {text}
            </mstts:express-as>
        </voice>
    </speak>
    """
    logger.info(f"inside generate_audio_azure , url {url}  , data {data}, lang {lang}  , voicename {voice_name}")
    encoded_data = data.encode('utf-8')
    try:
        response = requests.post(url, headers=headers, data=encoded_data)
        logger.info(f"Azure TTS API response code: {response.status_code}")
        if response.status_code == 200:
            if response.content:
                audio_data = response.content
                base64_audio = base64.b64encode(audio_data).decode("utf-8")
                run_alarm_in_thread(send_alarm(alarm_type='Azure_TTS', remarks='Azure TTS working fine', status='clear'))
                return base64_audio
            else:
                logger.info(f"response.content ----> {response.content} is Empty")
                if retry:
                    # Retry with different parameters, e.g., different tts_style or voice_name
                    return generate_audio_azure(text, lang, "en-US-AvaMultilingualNeural", tts_style, retry=False, assistant_id=assistant_id)
                else:
                    run_alarm_in_thread(send_alarm(alarm_type='Azure_TTS', remarks="Empty response content received after retry", status='raise'))
                    raise Exception("Empty response content received after retry.")

        else:
            logger.error(f"Error in Azure TTS : status code -->{response.status_code},response text-->{response.text}")
            run_alarm_in_thread(send_alarm(alarm_type='Azure_TTS', remarks=response.text, status='raise'))
            raise Exception(f"Failed to generate speech. Status code: {response.status_code}")
    except Exception as e:
        logger.error(f"Error in generating audio via azure in audio_controller.py: {e}", exc_info=True)
        run_alarm_in_thread(send_alarm(alarm_type='Azure_TTS', remarks=str(e), status='raise'))


def generate_audio_whisper(message: str, voice_name: str = "nova"):
    try:
        response = client.audio.speech.create(
            model="tts-1", voice=voice_name, input=message, speed="1"
        )
        logger.info(f"audio generated for phrase --> {message}")
        audio_data = response.content
        base64_audio = base64.b64encode(audio_data).decode("utf-8")

        return base64_audio
    except Exception as e:
        logger.error(f"Error in generating audio: {e}", exc_info=True)
        raise RuntimeError("Error in generating audio")


def generate_audio_eleven_labs(message: str, voice_name: str):
    logger.info(f"params inside eleven_labs_tts ----> {message} , {voice_name} ")
    # Calling the text_to_speech conversion API with detailed parameters
    try:
        model_name = "eleven_turbo_v2"

        if voice_name == "mRdG9GYEjJmIzqbYTidv":
            model_name = "eleven_multilingual_v2"

        response = eleven_labs_client.text_to_speech.convert(
            voice_id=voice_name,  # Adam pre-made voice
            optimize_streaming_latency="4",
            output_format="mp3_22050_32",
            text=message,
            model_id=model_name,
            # use the turbo model for low latency, for other languages use the `eleven_multilingual_v2`
            voice_settings=VoiceSettings(
                stability=0.3,
                similarity_boost=0.7,
                style=0.0
            ),
        )

        logger.info(f"Eleven labs Response - {response}")

        audio_stream = BytesIO()

        # Write each chunk of audio data to the stream
        for chunk in response:
            if chunk:
                audio_stream.write(chunk)

        # Reset stream position to the beginning
        audio_stream.seek(0)

        audio_bytes = audio_stream.getvalue()

        base64_audio = base64.b64encode(audio_bytes).decode("utf-8")

        # Return the byte content
        return base64_audio
    except Exception as e:
        logger.error(f"exception occured in eleven labs api: {e}", exc_info=True)
        raise e


