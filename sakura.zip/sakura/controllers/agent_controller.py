import os
import shutil
import traceback

from fastapi import APIRouter, HTTPException, UploadFile, File, Query
from pydantic import BaseModel
from fastapi.responses import Response, FileResponse
from logger.__init__ import get_logger
from repository.agent_repository import download_doc, get_agent_UML
from service.agentManagerService import get_agents_by_assId_service, update_agent_tools_service, \
    update_agent_status_service, upload_doc_service, create_agent_service

from pathlib import Path
from typing import Optional
logger = get_logger(__name__)
router = APIRouter()


class UpdateAgentToolsRequest(BaseModel):
    tenantId: str
    assistantId: int
    agentId: int
    toolIds: str
    userId: str


@router.get("/workflow/view", tags=['Agents (Workflows)'])
def get_agents(tenantId: str = Query(..., min_length=1), assistantId: str = Query(..., min_length=1)):
    if not tenantId.strip() or not assistantId.strip():
        raise HTTPException(status_code=400, detail="tenantId and assistantId are required and cannot be empty.")

    logger.info(f"Received request to view agents with tenantId: {tenantId}, assistantId: {assistantId}")
    try:
        result = get_agents_by_assId_service(tenantId, assistantId)
        logger.info(f"Successfully retrieved agents for tenantId: {tenantId}, assistantId: {assistantId}")
        return result
    except Exception as e:
        logger.error(
            f"Error fetching agents for tenantId: {tenantId}, assistantId: {assistantId}. Error:  {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.patch("/agent/tools/edit", tags=['Agents (Workflows)'])
def edit_agent_tools(request: UpdateAgentToolsRequest):
    try:
        # Extract parameters from the request model
        tenantId = request.tenantId.strip()
        assistantId = request.assistantId
        agentId = request.agentId
        toolIds = request.toolIds.strip()
        userId = request.userId.strip()

        # Basic validation for empty values
        if not tenantId or not toolIds or not userId:
            raise HTTPException(status_code=400, detail="tenantId, toolIds, and userId cannot be empty.")

        logger.info(f"Request to edit agent tools for agentId: {agentId} with toolIds: {toolIds}, userId: {userId}")
        result = update_agent_tools_service(tenantId, assistantId, agentId, toolIds, userId)
        logger.info(f"Successfully updated tools for agentId: {agentId}, toolIds: {toolIds}, userId: {userId}")
        return result
    except Exception as e:
        logger.error(
            f"Error updating agent tools for agentId: {agentId}, toolIds: {toolIds}, userId: {userId}, Error - {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.patch("/agent/status/update", tags=['Agents (Workflows)'])
def update_agent_status(
        tenantId: str = Query(..., min_length=1),
        assistantId: int = Query(...),
        agentId: int = Query(...)
):
    if not tenantId.strip():
        raise HTTPException(status_code=400, detail="tenantId cannot be empty.")

    logger.info(
        f"Received request to update agent status. TenantId: {tenantId}, AssistantId: {assistantId}, AgentId: {agentId}")
    try:
        result = update_agent_status_service(tenantId, assistantId, agentId)
        logger.info(
            f"Successfully updated agent status for AgentId: {agentId}, AssistantId: {assistantId}, TenantId: {tenantId}")
        return result
    except Exception as e:
        logger.error(
            f"Error updating agent status for AgentId: {agentId}, AssistantId: {assistantId}, TenantId: {tenantId}. Error: {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.patch("/agent/doc/upload", tags=['Agents (Workflows)'])
def upload_file(
        tenantId: str = Query(..., min_length=1),
        assistantId: int = Query(...),
        agentId: int = Query(...),
        file: UploadFile = File(...)
):
    userId = "Parth"
    TEMP_DIR = "files/workflow_docs"
    os.makedirs(TEMP_DIR, exist_ok=True)
    
    logger.info(f"Received request to upload document for AgentId: {agentId}, AssistantId: {assistantId}, TenantId: {tenantId}")

    # Check if tenantId and userId are non-empty
    if not tenantId.strip() or not userId.strip():
        logger.error("Validation error: tenantId and userId cannot be empty.")
        raise HTTPException(status_code=400, detail="tenantId and userId cannot be empty.")

    # Validate file presence
    if not file:
        logger.error("Validation error: No file uploaded.")
        raise HTTPException(status_code=400, detail="No file uploaded")

    # Generate unique file path and save the file
    file_path = os.path.join(TEMP_DIR, file.filename)
    try:
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        logger.info(f"File '{file.filename}' successfully saved at path: {file_path}")

        # Call the service function to upload the document
        return upload_doc_service(tenantId, assistantId, agentId, file_path, file.filename, userId)
    
    except Exception as e:
        logger.error(
            f"Error uploading document for AgentId: {agentId}, AssistantId: {assistantId}, TenantId: {tenantId}. Error: {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.patch("/create/agent", tags=['Agents (Workflows)'])
def create_agent(
        tenantId: str = Query(..., min_length=1),
        assistantId: int = Query(...),
        userId: str = Query(..., min_length=1),
        file: UploadFile = File(...)
):
    TEMP_DIR = "files/workflow_docs"
    os.makedirs(TEMP_DIR, exist_ok=True)
    
    logger.info(f"Received request to create agent for AssistantId: {assistantId}, TenantId: {tenantId}, UserId: {userId}")

    # Check if tenantId and userId are non-empty
    if not tenantId.strip() or not userId.strip():
        logger.error("Validation error: tenantId and userId cannot be empty.")
        raise HTTPException(status_code=400, detail="tenantId and userId cannot be empty.")

    # Validate file presence
    if not file:
        logger.error("Validation error: No file uploaded.")
        raise HTTPException(status_code=400, detail="No file uploaded")

    # Generate unique file path and save the file
    file_path = os.path.join(TEMP_DIR, file.filename)
    try:
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        logger.info(f"File '{file.filename}' successfully saved at path: {file_path}")

        # Call the service function to create the agent
        logger.info(f"Calling create_agent_service with assistantId: {assistantId}, tenantId: {tenantId}, filePath: {file_path}")
        return create_agent_service(tenantId, assistantId, file_path, file.filename, userId)
    
    except Exception as e:
        logger.error(
            f"Error creating agent for AssistantId: {assistantId}, TenantId: {tenantId}. Error: {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")




@router.get("/download/files",tags=['Agents (Workflows)'])
def download_file(filename: str):
    FILES_DIRECTORY = Path("files/workflow_docs")
    # Create the full path to the file
    file_path = FILES_DIRECTORY / filename
    
    # Check if the file exists
    if not file_path.exists():
        logger.error(f"File not found: {file_path}")
        raise HTTPException(status_code=404, detail="File not found")
    
    # Return the file as a downloadable response
    return FileResponse(path=file_path, filename=filename, media_type='application/octet-stream')


@router.get("/download/umlImage",tags=['Agents (Workflows)'])
def download_file(filename: str):
    FILES_DIRECTORY = Path("files/umlImages")
    # Create the full path to the file
    file_path = FILES_DIRECTORY / filename
    
    # Check if the file exists
    if not file_path.exists():
        logger.error(f"File not found: {file_path}")
        raise HTTPException(status_code=404, detail="File not found")
    
    # Return the file as a downloadable response
    return FileResponse(path=file_path, filename=filename, media_type='application/octet-stream')




# @router.get("/agent/uml", tags=['Agents (Workflows)'])
# def get_UML(
#     agentId: str = Query(..., min_length=1), 
#     ):
    
#     return get_agent_UML(agentId)

# @router.get("/agent/flowdownload", tags=['Agents (Workflows)'])
# def download_file(agentId: int = Query(...)):
#     try:
#         return download_doc(agentId)
#     except Exception as e:
#         logger.error(f"Error downloading document for AgentId: {agentId}. Error: {e}\n{traceback.format_exc()}")
#         raise HTTPException(status_code=500, detail="Internal Server Error")