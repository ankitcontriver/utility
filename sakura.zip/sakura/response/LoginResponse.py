from response.GenericResponse import GenericResponse
from models.database_models import User


class LoginResponse(GenericResponse):
    def __init__(self, status, status_code, message, data: User):
        super().__init__(status=status, status_code=status_code,message=message)
        self.data = data

    def __repr__(self):
        return f"status={self.status}, status_code={self.status_code}, message={self.message}, data={self.data}"
