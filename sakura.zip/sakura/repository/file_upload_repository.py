import json
import os

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import sessionmaker
from logger import get_logger
from models.database_models import Base, Tool, ExtraColumns, AssistantConfiguration

load_dotenv()

logger = get_logger(__name__)

# Load the database URL from .env
DATABASE_URL = os.getenv("DATABASE_URL")

# Create an engine and a session
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Initialize the database schema (ensure the tables are created)
Base.metadata.create_all(bind=engine)

def get_all_tools():
    logger.info("Get all tools called")
    session = SessionLocal()
    tools = session.query(Tool).all()
    result = []
    logger.info(f"tools fetch from tool {tools}")
    for tool in tools:
        tool_id = tool.id
        tool_name = tool.name
        # logger.info(f"Get all tools function ---> Tool_id : {tool_id}, Tool Name {tool_name}")
        # Parse the JSON stored in the description field
        description_data = tool.gptTool
  
        description = description_data['description']
        required = description_data['parameters']['required']

        result.append({
            "id": tool_id,
            "name": tool_name,
            "description": description,
            "required": required
        })
    # logger.info(f"Get all tools result: {result}")
    return result

def generate_prompt_with_tools():
    # Placeholder prompt
    logger.info("Generate prompt with tools called")
    prompt_template = """You are a agent prompt generator. You can use the example prompt to see how detailed the prompt must be. You are given a workflow and need to generate the following things
    > Detailed Prompt for the agent which precisely describes the workflow given to you. You must only give steps based on the workflow. Dont add any personality for the agent.
    > Assigned tool for the agent. this will be comma separated string of ids for the tools that are required. Use the tools description provided.

    USE THE write_to_db tool to write the prompt and toolIndexes.

    The prompt that you make must contain mentions of the tools that you assign the agent. It should contain detailed cases , both negative and positive for the workflow. 

    Example prompt : 

    Ticket Workflow :-

    Collect Mobile Number First: For account-related requests, always request a valid mobile_number if it's missing. Ask politely.
    Avoid Duplicates: Once mobile_number is given, only re-ask if a different account is being discussed.
    Clarify Intent if Needed: If the request is unclear, ask the user for details.
    Handle Errors Gracefully: Apologize for system issues without technical jargon.
    Primary Workflow Scenarios

    Retrieve Ticket Status

    Latest Ticket: Confirm mobile_number, call fetch_ticket_status (no complaint_id), and display the status.
    Specific Ticket: Collect complaint_id after mobile_number, call fetch_ticket_status, and display the result or inform if no matching ticket is found.
    Errors: Prompt for missing mobile_number; validate complaint_id as numeric.
    Raise a New Ticket

    With Issue Description: Collect mobile_number and issue_description. Use raise_ticket, and share the new ticket_id if successful.
    Errors: Request missing mobile_number or fuller issue descriptions if needed.
    Retrieve All Tickets

    For Mobile Number: Confirm mobile_number, call get_tickets, and show summaries or state if no tickets are found.
    Errors: Prompt for missing mobile_number; notify politely if no tickets found.
    Retrieve Balance Amount

    For Mobile Number: Collect mobile_number, call get_balance, and display the balance. Inform if no balance found.
    Errors: Prompt for missing mobile_number and handle gracefully.


    Here are the descriptions of the tools that the agents can use:
    """

    # Fetch tools and format them
    tools = get_all_tools()
    
    # Create tool description string
    tools_description = "\n".join(
        f'[\n        "id" : {tool["id"]},\n'
        f'        "name": "{tool["name"]}",\n'
        f'        "description": "{tool["description"]}"\n    ]' for tool in tools
    )
    # Insert tools description into prompt template
    final_prompt = prompt_template + tools_description

    return final_prompt


def write_to_db(prompt, toolIndexes):
    # logger.info("write to db called")
    session = SessionLocal()
    try:
        # Validate required fields
        if not prompt:
            return ("prompt missing", False)
        if not toolIndexes:
            return ("tools missing", False)

        msg = update_assistant_configuration(toolIndexes=toolIndexes)
        logger.info(f"Result after update_assistant_configuration repository - {msg}")
        # Define fixed values
        fixed_agent_id = 1001
        fixed_org_id = 1001
        fixed_agent_type = "Customer Care"

        # Query for existing entry with fixed agent_id and org_id
        entry = session.query(ExtraColumns).filter_by(agent_id=fixed_agent_id, org_id=fixed_org_id).first()

        if entry:
            # Update the existing entry's enterprise_data field
            entry.enterprise_data = prompt
            # entry.parameters = toolIndexes  # You will specify what to do with toolIndexes later
            message = "Prompt and toolIndexes added succesfully"
        else:
            # No existing entry, create a new one with fixed values
            new_entry = ExtraColumns(
                agent_id=fixed_agent_id,
                org_id=fixed_org_id,
                agent_type=fixed_agent_type,
                enterprise_data=prompt,
                # parameters=toolIndexes  # Placeholder for toolIndexes logic
                website=""
            )
            session.add(new_entry)
            message = "New entry created successfully with prompt and toolIndexes"

        # Commit the transaction
        session.commit()
        return (message, True)

    except SQLAlchemyError as e:
        # Rollback on error
        session.rollback()
        return (f"Database error occurred: {str(e)}", False)
    finally:
        # Close the session
        session.close()


def update_assistant_configuration_old(toolIndexes):
    session = SessionLocal()
    try:
        # Parse toolIndexes into a list of integers
        tool_ids = [int(id.strip()) for id in toolIndexes.split(",") if id.strip().isdigit()]

        if not tool_ids:
            return "No valid tool IDs provided"

        # Query the Tool table to fetch gptTool and claudeTool for each tool ID
        tools = session.query(Tool).filter(Tool.id.in_(tool_ids)).all()

        # Separate gptTool and claudeTool data into two arrays
        gpt_tools = [tool.gptTool for tool in tools if tool.gptTool]
        claude_tools = [tool.claudeTool for tool in tools if tool.claudeTool]

        # Convert arrays to JSON strings for storage in the Text columns
        gpt_tools_json = json.dumps(gpt_tools)
        claude_tools_json = json.dumps(claude_tools)

        # Define fixed assistant_id
        assistant_id = 1001

        # Check if an entry for assistant_id = 1001 exists
        entry = session.query(AssistantConfiguration).filter_by(assistant_id=assistant_id).first()

        if entry:
            # Update existing entry
            entry.tools_supported = gpt_tools_json
            entry.claude_tools = claude_tools_json
            message = "Assistant configuration updated successfully"
        else:
            # Create a new entry with fixed assistant_id and populate tool arrays
            new_entry = AssistantConfiguration(
                assistant_id=assistant_id,
                tools_supported=gpt_tools_json,
                claude_tools=claude_tools_json
            )
            session.add(new_entry)
            message = "New assistant configuration created successfully"

        # Commit the transaction
        session.commit()
        return message

    except SQLAlchemyError as e:
        # Rollback on error
        session.rollback()
        return f"Database error occurred: {str(e)}"
    finally:
        # Close the session
        session.close()

def update_assistant_configuration(toolIndexes):
    session = SessionLocal()
    try:
        # Parse toolIndexes into a list of integers
        tool_ids = [int(id.strip()) for id in toolIndexes.split(",") if id.strip().isdigit()]
        logger.info(f"Parsed tool IDs: {tool_ids}")

        if not tool_ids:
            logger.warning("No valid tool IDs provided.")
            return "No valid tool IDs provided"

        # Query the Tool table to fetch gptTool and claudeTool for each tool ID
        tools = session.query(Tool).filter(Tool.id.in_(tool_ids)).all()
        logger.info(f"Fetched {len(tools)} tools from the database.")

        # Extract gptTool and claudeTool data from Tool table
        gpt_tools = [tool.gptTool for tool in tools if tool.gptTool]
        claude_tools = [tool.claudeTool for tool in tools if tool.claudeTool]
        logger.info(f"Extracted {len(gpt_tools)} GPT tools and {len(claude_tools)} Claude tools.")

        # Define fixed assistant_id
        assistant_id = 1001

        # Check if an entry for assistant_id = 1001 exists
        entry = session.query(AssistantConfiguration).filter_by(assistant_id=assistant_id).first()

        if entry:
            # Convert updated tool lists to JSON strings
            gpt_tools_json = json.dumps(gpt_tools)
            claude_tools_json = json.dumps(claude_tools)

            # Update existing entry
            logger.info(f"final gpt_tools_json to be inserted in assisatnt_configuration : {gpt_tools_json} ")
            logger.info(f"final claude_tools_json to be inserted in assisatnt_configuration : {claude_tools_json} ")
            entry.tools_supported = gpt_tools_json
            entry.claude_tools = claude_tools_json
            message = "Assistant configuration updated successfully"
            logger.info(message)
        else:
            # Create a new entry with fixed assistant_id and populate tool arrays
            new_entry = AssistantConfiguration(
                assistant_id=assistant_id,
                tools_supported=json.dumps(gpt_tools),
                claude_tools=json.dumps(claude_tools)
            )
            session.add(new_entry)
            message = "New assistant configuration created successfully"
            logger.info(message)

        # Commit the transaction
        session.commit()
        return message

    except SQLAlchemyError as e:
        # Rollback on error
        session.rollback()
        logger.error(f"Database error occurred: {str(e)}",exc_info=True)
        return f"Database error occurred: {str(e)}"
    finally:
        # Close the session
        session.close()


def get_assistant_configuration_by_id(assistant_id):
    """
    Retrieves the AssistantConfiguration entry by assistant_id.
    
    Parameters:
    - assistant_id (int): The ID of the assistant.

    Returns:
    - AssistantConfiguration or None: The AssistantConfiguration entry or None if not found.
    """
    session = SessionLocal()
    try:
        return session.query(AssistantConfiguration).filter_by(assistant_id=assistant_id).first()
    finally:
        session.close()

def get_extra_columns_by_agent_and_org(agent_id=1001, org_id=1001):
    """
    Retrieves the ExtraColumns entry by agent_id and org_id.
    
    Parameters:
    - agent_id (int): The ID of the agent (default is 1001).
    - org_id (int): The ID of the organization (default is 1001).

    Returns:
    - ExtraColumns or None: The ExtraColumns entry or None if not found.
    """
    session = SessionLocal()
    try:
        return session.query(ExtraColumns).filter_by(agent_id=agent_id, org_id=org_id).first()
    finally:
        session.close()
