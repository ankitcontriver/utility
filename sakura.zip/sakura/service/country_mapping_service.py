from config.database_config import SessionLocal
from logger import get_logger
from repository.country_repository import get_all_countries as get_all_countries_repo
from repository.country_repository import get_languages_for_country as get_languages_for_country_repo
from response.GetCountryLanguageResponse import GetCountryLanguageResponse, GetCountryLanguage
from response.GetCountryListResponse import GetCountryListResponse, GetCountryList

logger = get_logger(__name__)


def get_country_list():
    logger.info("get_country_list service' called")
    db = None
    try:
        db = SessionLocal()
        countries = get_all_countries_repo(db)
        logger.info(f"countries: {countries}")

        if (countries is None) or (len(countries) == 0):
            response = GetCountryListResponse(
                status_code=200,
                status="Success",
                message="No countries found",
                data=[]
            )
        else:
            country_list = [
                GetCountryList(id=country.id, country_name=country.country_name, country_code=country.country_iso_code)
                for
                country in countries]
            response = GetCountryListResponse(
                status_code=200,
                status="Success",
                message="Country list retrieved successfully",
                data=country_list
            )
    except Exception as e:
        logger.error(f"Failed to fetch country list: {e}")
        response = GetCountryListResponse(
            status_code=400,
            status="Failed",
            message="Failed to fetch country list",
            data=[]
        )
    finally:
        db.close()
    logger.info(f"get_country_list response: {response}")
    return response


def get_country_language(country_id: str):
    logger.info("get_country_language service called")
    logger.info(f"get_country_language request country_id: {country_id}")
    db = None
    try:
        db = SessionLocal()
        languages = get_languages_for_country_repo(db, country_id)
        logger.info(f"languages: {languages}")
        if (languages is None) or (len(languages) == 0):
            response = GetCountryLanguageResponse(status_code=200, status="Success",
                                                  message="No languages found for the country",
                                                  data=[])
        else:
            country_languages = [
                GetCountryLanguage(id=language.id, language_name=language.language_name,
                                   language_id=language.language_id)
                for language in languages]
            response = GetCountryLanguageResponse(status_code=200, status="Success",
                                                  message="Country Language List retrieved successfully",
                                                  data=country_languages)
    except Exception as e:
        logger.error(f"Failed to fetch languages for {country_id}: {e}")
        response = GetCountryLanguageResponse(status_code=400, status="Failed",
                                              message="Failed to fetch languages for the country",
                                              data=[])
    finally:
        db.close()
    logger.info(f"get_country_language response: {response}")
    return response
