from repository.tools_repository import get_all_tools
import os
from urllib.parse import urlencode
from logger import get_logger
import docx
import pandas as pd
import PyPDF2
import anthropic
from openai import OpenAI
from plantuml import PlantUML, PlantUMLHTTPError
import json
import os
import re
import threading
import uuid
from queue import Queue
from utils.thread_pool import get_named_thread_pool


logger = get_logger(__name__)


def generate_prompt_with_tools():
    # Placeholder prompt
    prompt_template = """
    You are a prompt generator for the Agents Of Customer Care Syetem. Agents are systems that performs the assigned task with the using assigned tools.Agents have to be assigned with the following parameters: You can use the example prompt to see how precise prompt must me. You are given a workflow and need to generate the following things
    > agent_token (name for the agent) . The name should be a normal string with the first word as capital. Eg: Balance Check
    > Detailed Prompt for the agent which precisely describes the workflow given to you. You must only give steps based on the workflow. Dont add any personality for the agent.
    > Assigned tool for the agent. this will be comma separated string of ids for the tools that are required. Use the exact tool id and description provided.
    > Description of the agent (the list of Descriptions are predefine, which are given. just assign one of the descriptions to the agent, don't include any kind of explaination or example. )

    USE THE write_to_db tool to write the prompt, tool_indexes, description and agent_token.

    The prompt that you make must contain mentions of the tools that you assign the agent. It should contain detailed cases , both negative and positive for the workflow. Do not write any personality traits in the prompt like "You are this this agent. You must follow these steps". Just give the steps in the prompt.

    Example prompt : 

    Ticket Workflow :-
    Steps: 

    Collect Mobile Number First: For account-related requests, always request a valid mobile_number if it's missing. Ask politely.
    Avoid Duplicates: Once mobile_number is given, only re-ask if a different account is being discussed.
    Clarify Intent if Needed: If the request is unclear, ask the user for details.
    Handle Errors Gracefully: Apologize for system issues without technical jargon.
    Primary Workflow Scenarios

    Retrieve Ticket Status

    Latest Ticket: Confirm mobile_number, call fetch_ticket_status (no complaint_id), and display the status.
    Specific Ticket: Collect complaint_id after mobile_number, call fetch_ticket_status, and display the result or inform if no matching ticket is found.
    Errors: Prompt for missing mobile_number; validate complaint_id as numeric.
    Raise a New Ticket

    With Issue Description: Collect mobile_number and issue_description. Use raise_ticket, and share the new ticket_id if successful.
    Errors: Request missing mobile_number or fuller issue descriptions if needed.
    Retrieve All Tickets

    For Mobile Number: Confirm mobile_number, call get_tickets, and show summaries or state if no tickets are found.
    Errors: Prompt for missing mobile_number; notify politely if no tickets found.
    Retrieve Balance Amount

    For Mobile Number: Collect mobile_number, call get_balance, and display the balance. Inform if no balance found.
    Errors: Prompt for missing mobile_number and handle gracefully.


    Here are the descriptions of the tools that the agents can use:
    """

    # Fetch tools and format them
    tools = get_all_tools()

    # Create tool description string
    tools_description = "\n".join(
        f'[\n        "id" : {tool["id"]},\n'
        f'        "name": "{tool["name"]}",\n'
        f'        "description": "{tool["description"]}"\n    ]' for tool in tools
    )

    cont_prompt = """ Here are the predefined descriptions: 
        1. Complaint Registration & Status
        Description: Queries related to registering complaints about service issues, product dissatisfaction, or other grievances.
        Example: Poor network coverage, technical issues, unresolved problems.

        2. Recharge & Top-Up
        Description: Queries related to recharging prepaid accounts or topping up balances.
        Example: Failed recharge, offers on top-ups, recharge history.

        3. Billing & Payments
        Description: Queries about billing issues, payment methods, bill disputes, and late payments.
        Example: Incorrect bill charges, bill breakdown, bill payment methods.

        4. Data & Internet Services
        Description: Issues or inquiries related to internet services, data usage, and data plans.
        Example: Slow internet, data balance, upgrading data plans.

        5. Network Coverage & Connectivity
        Description: Queries concerning network signal issues, call drops, or poor connectivity.
        Example: Weak signal, call drops, no network in specific locations.

        6. Account Management
        Description: Queries related to account settings, PINs, password resets, or updating personal information.
        Example: SIM card activation, account login issues, changing contact information.

        7. Service Plans & Subscriptions
        Description: Inquiries about available service plans, subscribing to or changing current plans.
        Example: Information on postpaid or prepaid plans, changing plans, promotional offers.

        8. Value-Added Services (VAS)
        Description: Issues or questions regarding additional services such as caller tunes, SMS packs, roaming, etc.
        Example: Activating international roaming, setting up caller tunes, VAS charges.

        9. SIM Card Issues
        Description: Queries related to SIM card activation, replacement, or deactivation.
        Example: Lost SIM card, SIM not working, SIM swap.

        10. Device Support
        Description: Support related to telecom devices such as modems, mobile phones, and routers provided by the telecom company.
        Example: Mobile device configuration, modem not connecting, device compatibility.

        11. Roaming Services
        Description: Queries about national and international roaming services, charges, and activation.
        Example: Activating roaming, roaming charges, connectivity issues while roaming.

        12. Promotions & Offers
        Description: Inquiries about special promotions, discounts, and time-limited offers.
        Example: Limited-time data offers, special call rates, bundle promotions.

        13. Fraud & Security
        Description: Issues related to fraudulent activities, spam, phishing, or unauthorized account access.
        Example: Reporting fraud, blocking spam calls or messages, security breaches.

        14. Porting/Number Transfer
        Description: Queries related to Mobile Number Portability (MNP) or transferring numbers between operators.
        Example: Porting to another network, porting delays, transfer status.

        15. General Information & Inquiries
        Description: Miscellaneous questions or general information requests about the company, services, or policies.
        Example: Store locations, working hours, how to contact customer care.
    """

    # Insert tools description into prompt template
    final_prompt = prompt_template + tools_description + cont_prompt

    return final_prompt


def append_tool_use_claude(messages, function_id, function_name, function_args):
    messages.append(
        {
            "role": "assistant",
            "content": [{
                "type": "tool_use",
                "id": function_id,
                "name": function_name,
                "input": function_args
            }]

        }
    )


def return_prompt():
    prompt = f"""You are expert in generating UML script for to generate flowchart for the given work flow. please give only UML Script.
       example of UML script:
        @startuml
        start
        :Call Opening;
        :Validate Security;
        stop
        @enduml
    """
    return prompt


def generate_download_file_url(file_path: str) -> str:
    """
    Generates a download URL for the specified file path.

    Args:
        file_path (str): The path of the file to download.

    Returns:
        str: The generated download URL.
    """
    logger.info(f"Generating download URL for file path: {file_path}")
    
    base_url = os.getenv("BASE_DOC_URL")  # Update this URL for frontend to download
    try:
        query_params = urlencode({"filename": file_path})  # Properly encode file_path as a query parameter
        download_url = f"{base_url}{query_params}"
        
        logger.info(f"Generated download URL: {download_url}")
        return download_url
    except Exception as e:
        logger.error(f"Error generating download URL for file path '{file_path}': {e}",exc_info=True)
        return ""


def generate_download_uml_url(file_path: str) -> str:
    """
    Generates a download URL for the specified file path.

    Args:
        file_path (str): The path of the file to download.

    Returns:
        str: The generated download URL.
    """
    logger.info(f"Generating UML download URL for file path: {file_path}")
    
    base_url = os.getenv("BASE_UML_URL") # Update this URL for frontend to download
    try:
        query_params = urlencode({"filename": file_path})  # Properly encode file_path as a query parameter
        download_url = f"{base_url}{query_params}"
        
        logger.info(f"Generated UML download URL: {download_url}")
        return download_url
    except Exception as e:
        logger.error(f"Error generating UML download URL for file path '{file_path}': {e}",exc_info=True)
        return ""




def extract_content(file_path):
    ext = os.path.splitext(file_path)[-1].lower()
    logger.info(f"Extracting file contents from: {file_path} with extension: {ext}")

    if ext == '.csv':
        logger.info("Reading CSV file...")
        df = pd.read_csv(file_path)
        return df.to_string(index=False)

    elif ext == '.xlsx':
        logger.info("Reading Excel file with multiple sheets...")
        excel_file = pd.ExcelFile(file_path)
        sheet_contents = {}
        for sheet in excel_file.sheet_names:
            logger.debug(f"Reading sheet: {sheet}")
            df = pd.read_excel(file_path, sheet_name=sheet)
            sheet_content = df.to_string(index=False)
            sheet_contents[sheet] = sheet_content
        return sheet_contents

    elif ext == '.docx':
        logger.info("Reading DOCX file...")
        doc = docx.Document(file_path)
        text = "\n".join([para.text for para in doc.paragraphs])
        return text

    elif ext == '.txt':
        logger.info("Reading TXT file...")
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()

    elif ext == '.pdf':
        logger.info("Reading PDF file...")
        text = ""
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            for page_num in range(len(reader.pages)):
                page = reader.pages[page_num]
                text += page.extract_text()
        return text

    else:
        logger.error("Unsupported file format encountered.")
        raise ValueError("Unsupported file format")




def generateUmlCode(file_text, queue):
    """Generates UML code and saves as an image, returns image filename in queue."""
    UmlImageName = None
    i = 1
    while(i<=3 and UmlImageName is None):
        logger.debug(f"Iteration {i} : Generating UML code from file text")
        # Step 1: Generate the UML code prompt and send API request
        prompt = return_prompt()  # Assuming return_prompt() is defined elsewhere
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        messages = [{"role": "system", "content": prompt}, {"role": "user", "content": file_text}]
        model = "gpt-4o"

        try:
            response = client.chat.completions.create(model=model, messages=messages)
            reply = response.choices[0].message.content

            # Step 2: Extract UML code from the API reply
            logger.info("Extracting UML code from the reply...")
            match = re.search(r'(@startuml.*?@enduml)', reply, re.DOTALL)
            if match:
                uml_code = match.group(1).strip()
                logger.info("UML code extracted successfully.")
            else:
                logger.warning("No UML code found in the response.")
                queue.put(None)  # Put None if no UML code is found
                return

            # Step 3: Save UML code as an image
            logger.info("Saving UML code as an image...")
            image_directory = "files/umlImages"
            os.makedirs(image_directory, exist_ok=True)

            plantuml_server = PlantUML(url="http://www.plantuml.com/plantuml/img/")
            unique_filename = f"uml_{uuid.uuid4().hex}.png"
            image_path = os.path.join(image_directory, unique_filename)

            with open("temp_diagram.uml", "w") as file:
                file.write(uml_code)

            # Generate the image
            plantuml_server.processes_file("temp_diagram.uml", outfile=image_path)
            UmlImageName = unique_filename
            logger.info(f"Image saved at: {image_path}")
            queue.put(UmlImageName)  # Put the image filename in the queue

        except PlantUMLHTTPError as e:
            logger.error(f"Error generating UML image: HTTP status {e.response.status_code} - {e.response.reason}")
            logger.debug(f"Response content: {e.response.text}")
            if i==3:
                queue.put(None)  # Put None if an error occurs

        except Exception as e:
            logger.error(f"An unexpected error occurred while generating and saving image: {e}")
            if i==3:
                queue.put(None)  # Put None if an error occurs
        
        i=i+1



def generate_response(file_text, file_path):
    logger.info(f"Generating response for file: {file_path}")

    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    model = "gpt-4-turbo-preview"

    # Queues for inter-thread communication
    uml_queue = Queue()
    desc_queue = Queue()

    # Create and start threads
    uml_executor = get_named_thread_pool(pool_name='uml_generator', max_workers=2)
    uml_executor.submit(generateUmlCode, file_text, uml_queue)

    desc_executor = get_named_thread_pool(pool_name='desc_generator', max_workers=2)
    desc_executor.submit(generate_desc, file_text, desc_queue)

    # Wait for threads to complete
    uml_code = uml_queue.get()
    desc = desc_queue.get()

    if uml_code is None or desc is None:
        logger.error("Failed to generate UML code or description")
        return []

    system_prompt = generate_prompt_with_tools()
    logger.debug(f"System prompt generated: {system_prompt}")

    tool = [{
        "name": "write_to_db",
        "input_schema": {
            "type": "object",
            "properties": {
                "agent_token": {"type": "string"},
                "prompt": {"type": "string"},
                "tool_indexes": {"type": "string", "description": "comma separated integers for example: (4,5,6)"},
                "agent_description": {"type": "string", "description": "one of the predefined descriptions corresponding to the agent"},
            },
            "required": ["agent_token", "prompt", "tool_indexes", "agent_description"]
        }
    }]
    messages = [{"role": "user", "content": file_text}]

    try:
        response = client.chat.completions.create(
            model=model,
            system=system_prompt,
            max_tokens=4096,
            messages=messages,
            tools=tool,
            tool_choice={"type": "auto"},
        )

        if response.stop_reason == "tool_use":
            tool_use = next(block for block in response.content if block.type == "tool_use")
            tool_name, tool_input = tool_use.name, tool_use.input
            return tool_name, tool_input, uml_code, desc
        else:
            logger.error("LLM hallucinated while generating prompt and tools")
            return []

    except Exception as e:
        logger.error(f"Error in generating response: {e}",exc_info=True)
        return []