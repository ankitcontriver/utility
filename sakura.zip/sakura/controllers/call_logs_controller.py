from fastapi import APIRouter

from logger import get_logger
from models.request_models import CallLogsRequest
from service.call_logs_service import get_call_logs_service, save_call_logs_service

logger = get_logger(__name__)

router = APIRouter()


@router.get("/get-call-logs", tags=["Call Logs"])
def get_call_logs(email: str, order: str):
    logger.info(f"Getting call logs for email id ~ {email}")
    return get_call_logs_service(email, order)


@router.post("/save-call-logs", tags=["Call Logs"])
def save_call_logs(request: CallLogsRequest):
    logger.info(f"save call logs controller hit for call id ~ {request.id}")
    return save_call_logs_service(request)
