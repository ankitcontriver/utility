import os
import json
import re
import uuid
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import logging
import asyncio
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct
from sentence_transformers import SentenceTransformer
import numpy as np
from sklearn.cluster import DBSCAN, KMeans
from sklearn.preprocessing import StandardScaler
from models.pa_vector_metadata import PAVectorMetadata, VectorDBPoint, ContextAnalysis, TokenUsage, ClusteringData
from service.pa_keyword_manager import get_keyword_manager



logger = logging.getLogger(__name__)

class PAVectorManager:
    """
    Manages vector database operations for PA service with clustering capabilities.
    Handles semantic search, similarity matching, and response storage.
    """
    
    def __init__(self, vector_db_host: str, vector_db_port: int, collection_name: str, 
                 semantic_model_name: str, keyword_manager):
        self.vector_db_host = vector_db_host
        self.vector_db_port = vector_db_port
        self.base_collection_name = collection_name
        self.semantic_model_name = semantic_model_name
        self.keyword_manager = keyword_manager
        
        # Initialize Qdrant client
        self.client = QdrantClient(host=vector_db_host, port=vector_db_port)
        
        # Initialize semantic model
        self.semantic_model = SentenceTransformer(semantic_model_name)
        
        # Collections are now created dynamically on-demand via _ensure_collection_exists()
        # New structure: {serviceType}_responses_{voiceName}
        # e.g., Personal_Assistant_responses_ps-AF-GulNawazNeural
        
        # Legacy attributes kept for backward compatibility (not used in main flow)
        self.language_collections = {}
        self.supported_languages = []
        
        logger.info(f"PAVectorManager initialized. Collections will be created dynamically as needed.")
    
    def _should_store_response(self, function_name: str = None) -> bool:
        """
        Determine if a response should be stored in vector DB based on function calling.
        
        Args:
            function_name: Function name if called (e.g., 'fresh_generation', 'disconnect_service')
            
        Returns:
            True if should store, False otherwise
        """
        # Store if:
        # 1. fresh_generation function call (3-tier enabled)
        # 2. No function call (normal generation, 3-tier disabled)
        
        if function_name == "fresh_generation":
            logger.debug("Storing fresh_generation function call response")
            return True
        elif function_name is None or function_name == "":
            logger.debug("Storing normal response (no function call)")
            return True
        else:
            logger.debug(f"Not storing function call response: {function_name}")
            return False
    
    def _create_language_collections(self):
        """Create separate Qdrant collections for each supported language"""
        try:
            for lang in self.supported_languages:
                collection_name = f"{self.base_collection_name}_{lang}"
                self.language_collections[lang] = collection_name
                
                # Use the new ensure collection exists method
                self._ensure_collection_exists(collection_name)
                    
        except Exception as e:
            logger.error(f"Error creating language collections: {e}")
            raise
    
    def _get_collection_name(self, service_type: str = None, voice_name: str = None) -> str:
        """
        Get appropriate collection name based on service type and voice name.
        New structure: {serviceType}_responses_{voiceName}
        
        Args:
            service_type: Service type (e.g., 'Personal_Assistant', 'Smart_IVR', 'ASK_ME')
            voice_name: Complete voice name (e.g., 'hi-IN-SwaraNeural', 'en-US-AvaNeural')
            
        Returns:
            Collection name for the specific service and voice combination
        """
        # Default values
        if not service_type:
            service_type = "Personal_Assistant"  # Default to Personal_Assistant if not provided
        
        if not voice_name:
            voice_name = "en-US-AvaNeural"  # Default voice if not provided
        
        # Create collection name: {serviceType}_responses_{voiceName}
        collection_name = f"{service_type}_responses_{voice_name}"
        
        logger.debug(f"Using collection: '{collection_name}' for service_type='{service_type}', voice_name='{voice_name}'")
        return collection_name
    
    def _normalize_language_code(self, language: str) -> str:
        """
        Normalize language code to supported format.
        
        Args:
            language: Raw language code (e.g., 'ps-AF', 'fa-IR', 'en-US')
            
        Returns:
            Normalized language code (e.g., 'ps', 'fa', 'en')
        """
        if not language:
            return 'en'
        
        # Handle full language codes (e.g., 'ps-AF' -> 'ps')
        if '-' in language:
            lang_part = language.split('-')[0].lower()
        else:
            lang_part = language.lower()
        
        # Map to supported languages
        language_mapping = {
            # English variants
            'en': 'en', 'english': 'en',
            
            # Arabic variants  
            'ar': 'ar', 'arabic': 'ar',
            
            # French variants
            'fr': 'fr', 'french': 'fr', 'français': 'fr',
            
            # Indonesian variants
            'id': 'id', 'indonesian': 'id', 'bahasa': 'id',
            
            # Swahili variants
            'sw': 'sw', 'swahili': 'sw', 'kiswahili': 'sw',
            
            # Pashto variants (NEW)
            'ps': 'ps', 'pashto': 'ps', 'pushto': 'ps', 'pukhto': 'ps',
            
            # Dari/Farsi variants (NEW)
            'fa': 'fa', 'dari': 'fa', 'farsi': 'fa', 'persian': 'fa',
            
            # Additional mappings for common variations
            'ur': 'ar',  # Urdu -> Arabic (closest match)
            'hi': 'ar',  # Hindi -> Arabic (closest match)
            'bn': 'ar',  # Bengali -> Arabic (closest match)
        }
        
        return language_mapping.get(lang_part, 'en')

    def _detect_language_from_voice_code(self, voice_code: str) -> str:
        """
        Enhanced language detection from voice code with comprehensive mapping.
        
        Args:
            voice_code: Voice code (e.g., 'ps-AF-GulNawazNeural', 'fa-IR-FaridNeural')
            
        Returns:
            Normalized language code
        """
        if not voice_code:
            return 'en'
        
        try:
            # Extract language prefix from voice code (e.g., 'ps-AF-GulNawazNeural' -> 'ps')
            parts = voice_code.split('-')
            if len(parts) >= 1:
                lang_prefix = parts[0].lower()
                
                # Comprehensive voice code to language mapping
                voice_code_mapping = {
                    # English voices
                    'en': 'en',
                    
                    # Arabic voices
                    'ar': 'ar',
                    
                    # French voices
                    'fr': 'fr',
                    
                    # Indonesian voices
                    'id': 'id',
                    
                    # Swahili voices
                    'sw': 'sw',
                    
                    # Pashto voices (NEW)
                    'ps': 'ps',
                    
                    # Dari/Farsi voices (NEW)
                    'fa': 'fa',
                    
                    # Additional Azure TTS voice mappings
                    'zh': 'en',  # Chinese -> English (fallback)
                    'ja': 'en',  # Japanese -> English (fallback)
                    'ko': 'en',  # Korean -> English (fallback)
                    'es': 'en',  # Spanish -> English (fallback)
                    'de': 'en',  # German -> English (fallback)
                    'it': 'en',  # Italian -> English (fallback)
                    'pt': 'en',  # Portuguese -> English (fallback)
                    'ru': 'en',  # Russian -> English (fallback)
                    'tr': 'en',  # Turkish -> English (fallback)
                    'nl': 'en',  # Dutch -> English (fallback)
                    'pl': 'en',  # Polish -> English (fallback)
                    'sv': 'en',  # Swedish -> English (fallback)
                    'da': 'en',  # Danish -> English (fallback)
                    'no': 'en',  # Norwegian -> English (fallback)
                    'fi': 'en',  # Finnish -> English (fallback)
                    'cs': 'en',  # Czech -> English (fallback)
                    'hu': 'en',  # Hungarian -> English (fallback)
                    'ro': 'en',  # Romanian -> English (fallback)
                    'bg': 'en',  # Bulgarian -> English (fallback)
                    'hr': 'en',  # Croatian -> English (fallback)
                    'sk': 'en',  # Slovak -> English (fallback)
                    'sl': 'en',  # Slovenian -> English (fallback)
                    'et': 'en',  # Estonian -> English (fallback)
                    'lv': 'en',  # Latvian -> English (fallback)
                    'lt': 'en',  # Lithuanian -> English (fallback)
                    'el': 'en',  # Greek -> English (fallback)
                    'he': 'ar',  # Hebrew -> Arabic (closest match)
                    'th': 'en',  # Thai -> English (fallback)
                    'vi': 'en',  # Vietnamese -> English (fallback)
                    'uk': 'en',  # Ukrainian -> English (fallback)
                    'ca': 'en',  # Catalan -> English (fallback)
                    'eu': 'en',  # Basque -> English (fallback)
                    'gl': 'en',  # Galician -> English (fallback)
                    'cy': 'en',  # Welsh -> English (fallback)
                    'ga': 'en',  # Irish -> English (fallback)
                    'mt': 'en',  # Maltese -> English (fallback)
                    'is': 'en',  # Icelandic -> English (fallback)
                    'mk': 'en',  # Macedonian -> English (fallback)
                    'sq': 'en',  # Albanian -> English (fallback)
                    'sr': 'en',  # Serbian -> English (fallback)
                    'bs': 'en',  # Bosnian -> English (fallback)
                    'me': 'en',  # Montenegrin -> English (fallback)
                }
                
                detected_lang = voice_code_mapping.get(lang_prefix, 'en')
                logger.debug(f"Detected language '{detected_lang}' from voice code '{voice_code}'")
                return detected_lang
                
        except Exception as e:
            logger.error(f"Error detecting language from voice code '{voice_code}': {e}")
        
        return 'en'  # Default fallback

    def debug_collection_mapping(self, voice_code: str = None, language: str = None) -> Dict[str, str]:
        """
        Debug method to show collection mapping for given parameters.
        
        Args:
            voice_code: Voice code to test
            language: Language code to test
            
        Returns:
            Dictionary with mapping information
        """
        result = {
            'input_voice_code': voice_code,
            'input_language': language,
            'detected_language': None,
            'collection_name': None,
            'supported_languages': self.supported_languages,
            'available_collections': list(self.language_collections.keys())
        }
        
        if language:
            detected_lang = self._normalize_language_code(language)
            result['detected_language'] = detected_lang
            result['collection_name'] = self.language_collections.get(detected_lang, self.language_collections['en'])
        elif voice_code:
            detected_lang = self._detect_language_from_voice_code(voice_code)
            result['detected_language'] = detected_lang
            result['collection_name'] = self.language_collections.get(detected_lang, self.language_collections['en'])
        else:
            result['collection_name'] = self.language_collections['en']
        
        return result

    def _get_supported_languages(self) -> List[str]:
        """
        Get list of supported languages from environment or default.
        
        Returns:
            List of supported language codes
        """
        # Get from environment variable
        env_languages = os.getenv('PA_SUPPORTED_LANGUAGES', 'en,ar,fr,id,sw,ps,fa')
        
        try:
            languages = [lang.strip().lower() for lang in env_languages.split(',')]
            # Validate languages
            valid_languages = []
            for lang in languages:
                if lang and len(lang) >= 2:
                    valid_languages.append(lang)
            
            if not valid_languages:
                logger.warning("No valid languages found in PA_SUPPORTED_LANGUAGES, using defaults")
                return ['en', 'ar', 'fr', 'id', 'sw', 'ps', 'fa']
            
            logger.info(f"Loaded supported languages from environment: {valid_languages}")
            return valid_languages
            
        except Exception as e:
            logger.error(f"Error parsing PA_SUPPORTED_LANGUAGES: {e}")
            return ['en', 'ar', 'fr', 'id', 'sw', 'ps', 'fa']  # Default fallback

    def _ensure_collection_exists(self, collection_name: str) -> bool:
        """
        Ensure collection exists, create if it doesn't.
        
        Args:
            collection_name: Name of the collection to check/create
            
        Returns:
            True if collection exists or was created successfully
        """
        try:
            # Check if collection exists
            collections = self.client.get_collections()
            existing_collections = [col.name for col in collections.collections]
            
            if collection_name not in existing_collections:
                logger.info(f"Creating missing collection: {collection_name}")
                self.client.create_collection(
                    collection_name=collection_name,
                    vectors_config=VectorParams(
                        size=768,  
                        distance=Distance.COSINE
                    )
                )
                logger.info(f"Successfully created collection: {collection_name}")
                return True
            else:
                logger.debug(f"Collection already exists: {collection_name}")
                return True
                
        except Exception as e:
            logger.error(f"Error ensuring collection '{collection_name}' exists: {e}")
            return False
    
    def _generate_embedding(self, text: str) -> List[float]:
        """Generate embedding for text using semantic model"""
        try:
            embedding = self.semantic_model.encode(text)
            return embedding.tolist()
        except Exception as e:
            logger.error(f"Error generating embedding: {e}")
            return []
    
    def _calculate_confidence(self, query: str, stored_query: str, 
                            query_analysis: Dict, stored_analysis: Dict) -> float:
        """
        Calculate confidence score based on multiple factors.
        
        Args:
            query: User query
            stored_query: Stored query from vector DB
            query_analysis: Keyword analysis of user query
            stored_analysis: Keyword analysis of stored query
            
        Returns:
            Confidence score between 0 and 1
        """
        try:
            # Semantic similarity (60%)
            query_embedding = self._generate_embedding(query)
            stored_embedding = self._generate_embedding(stored_query)
            
            if not query_embedding or not stored_embedding:
                return 0.0
            
            semantic_similarity = np.dot(query_embedding, stored_embedding) / (
                np.linalg.norm(query_embedding) * np.linalg.norm(stored_embedding)
            )
            
            # Debug logging for confidence calculation
            logger.debug(f"Confidence calculation for query '{query[:50]}...' vs stored '{stored_query[:50]}...'")
            logger.debug(f"  Semantic similarity: {semantic_similarity:.4f}")
            logger.debug(f"  Query analysis: {query_analysis}")
            logger.debug(f"  Stored analysis: {stored_analysis}")
            
            # Context compatibility (25%) - Enhanced with compatibility matrices
            context_compatibility = self._calculate_context_compatibility_enhanced(
                query_analysis, stored_analysis
            )
            
            # Historical success (10%) - Placeholder for future implementation
            historical_success = stored_analysis.get('historical_success_rate', 0.7)
            
            # Query complexity (5%) - Enhanced complexity calculation
            query_complexity = self._calculate_query_complexity(query_analysis, query)
            
            # Base weighted confidence calculation
            base_confidence = (
                semantic_similarity * 0.6 +
                context_compatibility * 0.25 +
                historical_success * 0.1 +
                query_complexity * 0.05
            )
            
            # Apply confidence boosters and penalties
            final_confidence = self._apply_confidence_modifiers(
                base_confidence, semantic_similarity, context_compatibility, historical_success
            )
            
            # Debug logging for final confidence
            logger.debug(f"  Context compatibility: {context_compatibility:.4f}")
            logger.debug(f"  Historical success: {historical_success:.4f}")
            logger.debug(f"  Query complexity: {query_complexity:.4f}")
            logger.debug(f"  Base confidence: {base_confidence:.4f}")
            logger.debug(f"  Final confidence: {final_confidence:.4f}")
            
            # If semantic similarity is very high (>0.8), boost confidence significantly
            if semantic_similarity > 0.8:
                final_confidence = max(final_confidence, semantic_similarity * 0.9)
                logger.debug(f"  Boosted confidence due to high semantic similarity: {final_confidence:.4f}")
            
            # Pattern-based similarity boost for similar query structures
            pattern_boost = self._calculate_pattern_similarity(query, stored_query)
            if pattern_boost > 0.0:
                final_confidence = max(final_confidence, pattern_boost)
                logger.debug(f"  Pattern-based similarity boost: {pattern_boost:.4f}")
            
            return min(1.0, max(0.0, final_confidence))
            
        except Exception as e:
            logger.error(f"Error calculating confidence: {e}")
            return 0.0
    
    def _calculate_context_compatibility_enhanced(self, query_analysis: Dict, stored_analysis: Dict) -> float:
        """
        Calculate context compatibility using compatibility matrices.
        
        Args:
            query_analysis: Analysis of current query
            stored_analysis: Analysis of stored query
            
        Returns:
            Compatibility score between 0 and 1
        """
        try:
            # Context compatibility matrices
            urgency_matrix = {
                ('critical', 'critical'): 1.0,
                ('critical', 'high'): 0.8,
                ('critical', 'medium'): 0.5,
                ('critical', 'low'): 0.2,
                ('high', 'critical'): 0.8,
                ('high', 'high'): 1.0,
                ('high', 'medium'): 0.7,
                ('high', 'low'): 0.4,
                ('medium', 'critical'): 0.5,
                ('medium', 'high'): 0.7,
                ('medium', 'medium'): 1.0,
                ('medium', 'low'): 0.8,
                ('low', 'critical'): 0.2,
                ('low', 'high'): 0.4,
                ('low', 'medium'): 0.8,
                ('low', 'low'): 1.0
            }
            
            formality_matrix = {
                ('formal', 'formal'): 1.0,
                ('formal', 'professional'): 0.8,
                ('formal', 'casual'): 0.4,
                ('professional', 'formal'): 0.8,
                ('professional', 'professional'): 1.0,
                ('professional', 'casual'): 0.6,
                ('casual', 'formal'): 0.4,
                ('casual', 'professional'): 0.6,
                ('casual', 'casual'): 1.0
            }
            
            intent_matrix = {
                ('emergency', 'emergency'): 1.0,
                ('emergency', 'message'): 0.7,
                ('emergency', 'callback'): 0.6,
                ('emergency', 'availability'): 0.5,
                ('emergency', 'meeting'): 0.4,
                ('message', 'emergency'): 0.7,
                ('message', 'message'): 1.0,
                ('message', 'callback'): 0.8,
                ('message', 'availability'): 0.6,
                ('message', 'meeting'): 0.7,
                ('callback', 'emergency'): 0.6,
                ('callback', 'message'): 0.8,
                ('callback', 'callback'): 1.0,
                ('callback', 'availability'): 0.7,
                ('callback', 'meeting'): 0.6,
                ('availability', 'emergency'): 0.5,
                ('availability', 'message'): 0.6,
                ('availability', 'callback'): 0.7,
                ('availability', 'availability'): 1.0,
                ('availability', 'meeting'): 0.8,
                ('meeting', 'emergency'): 0.4,
                ('meeting', 'message'): 0.7,
                ('meeting', 'callback'): 0.6,
                ('meeting', 'availability'): 0.8,
                ('meeting', 'meeting'): 1.0
            }
            
            # Calculate individual compatibility scores
            query_urgency = query_analysis.get('urgency', 'medium')
            stored_urgency = stored_analysis.get('urgency', 'medium')
            urgency_score = urgency_matrix.get((query_urgency, stored_urgency), 0.5)
            
            query_formality = query_analysis.get('formality', 'professional')
            stored_formality = stored_analysis.get('formality', 'professional')
            formality_score = formality_matrix.get((query_formality, stored_formality), 0.5)
            
            query_intent = query_analysis.get('intent', 'message')
            stored_intent = stored_analysis.get('intent', 'message')
            intent_score = intent_matrix.get((query_intent, stored_intent), 0.5)
            
            # Sentiment compatibility (simple exact match for now)
            query_sentiment = query_analysis.get('sentiment', 'neutral')
            stored_sentiment = stored_analysis.get('sentiment', 'neutral')
            sentiment_score = 1.0 if query_sentiment == stored_sentiment else 0.6
            
            # Weighted average of context factors
            context_compatibility = (
                urgency_score * 0.4 +      # Urgency is most important
                intent_score * 0.3 +       # Intent matching is crucial
                formality_score * 0.2 +    # Formality affects response tone
                sentiment_score * 0.1      # Sentiment has minor impact
            )
            
            return min(1.0, max(0.0, context_compatibility))
            
        except Exception as e:
            logger.error(f"Error calculating context compatibility: {e}")
            return 0.5
    
    def _calculate_query_complexity(self, query_analysis: Dict, query: str) -> float:
        """
        Enhanced query complexity calculation.
        
        Args:
            query_analysis: Analysis of the query
            query: Original query string
            
        Returns:
            Complexity score between 0 and 1
        """
        try:
            # Word count factor (simpler queries get higher scores)
            word_count = len(query.split())
            word_score = max(0, 1 - word_count / 20)
            
            # Intent complexity (more specific intents are more complex)
            intent_complexity = {
                'availability': 0.8,
                'message': 0.9,
                'callback': 0.8,
                'meeting': 0.6,
                'emergency': 0.4  # Emergency queries are complex
            }
            intent = query_analysis.get('intent', 'message')
            intent_score = intent_complexity.get(intent, 0.7)
            
            # Urgency factor (urgent queries are typically simpler)
            urgency_complexity = {
                'low': 0.9,
                'medium': 0.8,
                'high': 0.7,
                'critical': 0.6
            }
            urgency = query_analysis.get('urgency', 'medium')
            urgency_score = urgency_complexity.get(urgency, 0.8)
            
            # Combined complexity score
            complexity = (word_score * 0.5 + intent_score * 0.3 + urgency_score * 0.2)
            
            return min(1.0, max(0.0, complexity))
            
        except Exception as e:
            logger.error(f"Error calculating query complexity: {e}")
            return 0.7
    
    def _apply_confidence_modifiers(self, base_confidence: float, semantic_similarity: float, 
                                  context_compatibility: float, historical_success: float) -> float:
        """
        Apply confidence boosters and penalties based on specific criteria.
        
        Args:
            base_confidence: Base confidence score
            semantic_similarity: Semantic similarity score
            context_compatibility: Context compatibility score
            historical_success: Historical success rate
            
        Returns:
            Modified confidence score
        """
        try:
            modified_confidence = base_confidence
            
            # Confidence boosters
            if semantic_similarity > 0.9 and context_compatibility > 0.8:
                # Excellent matches get a boost
                modified_confidence += 0.05
                logger.debug("Applied excellent match booster (+0.05)")
            
            if historical_success > 0.9:
                # Proven responses get a boost
                modified_confidence += 0.03
                logger.debug("Applied proven response booster (+0.03)")
            
            # Confidence penalties
            if semantic_similarity < 0.3:
                # Very low semantic similarity gets penalized
                modified_confidence -= 0.05
                logger.debug("Applied low similarity penalty (-0.05)")
            
            if context_compatibility < 0.3:
                # Poor context match gets penalized
                modified_confidence -= 0.03
                logger.debug("Applied poor context penalty (-0.03)")
            
            return min(1.0, max(0.0, modified_confidence))
            
        except Exception as e:
            logger.error(f"Error applying confidence modifiers: {e}")
            return base_confidence
    
    def _calculate_pattern_similarity(self, query: str, stored_query: str) -> float:
        """
        Calculate pattern-based similarity for queries with similar structures.
        This helps identify queries that follow the same pattern even if the specific words differ.
        
        Args:
            query: Current user query
            stored_query: Stored query from vector DB
            
        Returns:
            Pattern similarity score between 0 and 1
        """
        try:
            query_lower = query.lower().strip()
            stored_lower = stored_query.lower().strip()
            
            # Common patterns for PA queries
            patterns = [
                # Location/availability patterns
                (r'where is (.+)', r'where is (.+)'),
                (r'is (.+) available', r'is (.+) available'),
                (r'can i talk to (.+)', r'can i talk to (.+)'),
                (r'i want to talk to (.+)', r'i want to talk to (.+)'),
                (r'is (.+) there', r'is (.+) there'),
                (r'is (.+) in', r'is (.+) in'),
                
                # Message patterns
                (r'tell (.+) (.+)', r'tell (.+) (.+)'),
                (r'let (.+) know (.+)', r'let (.+) know (.+)'),
                (r'message for (.+)', r'message for (.+)'),
                
                # Callback patterns
                (r'(.+) call me back', r'(.+) call me back'),
                (r'call me back about (.+)', r'call me back about (.+)'),
            ]
            
            import re
            
            # Check for pattern matches
            for pattern in patterns:
                query_match = re.match(pattern[0], query_lower)
                stored_match = re.match(pattern[1], stored_lower)
                
                if query_match and stored_match:
                    # Both queries match the same pattern
                    logger.debug(f"Pattern match found: '{query}' and '{stored_query}' both match pattern: {pattern[0]}")
                    return 0.7  # High confidence for pattern matches
            
            # Check for similar word count and structure
            query_words = query_lower.split()
            stored_words = stored_lower.split()
            
            if len(query_words) == len(stored_words) and len(query_words) >= 2:
                # Check if they have similar structure (same positions for common words)
                common_words = ['where', 'is', 'can', 'i', 'talk', 'to', 'tell', 'let', 'know', 'call', 'me', 'back', 'about']
                matching_positions = 0
                total_positions = 0
                
                for i in range(min(len(query_words), len(stored_words))):
                    if query_words[i] in common_words or stored_words[i] in common_words:
                        total_positions += 1
                        if query_words[i] == stored_words[i]:
                            matching_positions += 1
                
                if total_positions > 0:
                    structure_similarity = matching_positions / total_positions
                    if structure_similarity > 0.6:  # 60% of structure words match
                        logger.debug(f"Structure similarity: {structure_similarity:.3f} for '{query}' and '{stored_query}'")
                        return structure_similarity * 0.5  # Moderate boost for structure similarity
            
            return 0.0
            
        except Exception as e:
            logger.error(f"Error calculating pattern similarity: {e}")
            return 0.0
    
    async def search_similar_queries(self, query: str, top_k: int = 5, service_type: str = None, voice_name: str = None) -> List[Dict]:
        """
        Search for similar queries in vector database using new collection structure.
        
        Args:
            query: User query
            top_k: Number of top results to return
            service_type: Service type (e.g., 'Personal_Assistant', 'Smart_IVR', 'ASK_ME')
            voice_name: Complete voice name (e.g., 'hi-IN-SwaraNeural', 'en-US-AvaNeural')
            
        Returns:
            List of similar queries with metadata
        """
        try:
            # Generate embedding for query
            query_embedding = self._generate_embedding(query)
            if not query_embedding:
                return []
            
            # Get appropriate collection based on service_type and voice_name
            collection_name = self._get_collection_name(service_type=service_type, voice_name=voice_name)
            
            # Ensure collection exists
            self._ensure_collection_exists(collection_name)
            
            # Search in language-specific vector database
            search_results = self.client.search(
                collection_name=collection_name,
                query_vector=query_embedding,
                limit=top_k
            )
            
            logger.debug(f"Searching in collection {collection_name} for service_type='{service_type}', voice_name='{voice_name}'")
            logger.debug(f"Found {len(search_results)} raw search results for query: '{query}'")
            
            # Analyze query for context matching
            query_analysis = self.keyword_manager.analyze_query_keywords(query)
            
            # Process results with confidence scoring
            results = []
            for i, result in enumerate(search_results):
                stored_data = result.payload
                stored_query = stored_data.get('query', '')
                
                # Generate stored_analysis from stored context data
                stored_context = stored_data.get('context', {})
                if isinstance(stored_context, dict):
                    stored_analysis = {
                        'urgency': stored_context.get('urgency', 'medium'),
                        'formality': stored_context.get('formality', 'professional'),
                        'sentiment': stored_context.get('sentiment', 'neutral'),
                        'intent': stored_context.get('intent', 'general'),
                        'historical_success_rate': 0.7  # Default value
                    }
                else:
                    # Fallback: analyze the stored query if no context available
                    stored_analysis = self.keyword_manager.analyze_query_keywords(stored_query)
                
                # Debug log what's being retrieved from vector DB
                logger.debug(f"Retrieved from Vector DB - ID: {result.id}")
                logger.debug(f"   Stored Data Keys: {list(stored_data.keys())}")
                logger.debug(f"   Stored Context: {stored_context}")
                logger.debug(f"   Generated Analysis: {stored_analysis}")
                
                # Calculate confidence score
                confidence = self._calculate_confidence(
                    query, stored_query, query_analysis, stored_analysis
                )
                
                # Debug log each match
                logger.debug(f"Match {i+1}: ID={result.id}, Query='{stored_query}', Response='{stored_data.get('response', '')[:50]}...', Confidence={confidence:.3f}")
                
                # Extract all metadata fields properly
                metadata_dict = {
                    'response': stored_data.get('response', ''),
                    'tts_file_path': stored_data.get('tts_file_path', ''),
                    'voice_code': stored_data.get('voice_code', ''),
                    'tts_style': stored_data.get('tts_style', ''),
                    'provider': stored_data.get('provider', ''),
                    'gender': stored_data.get('gender', ''),
                    'assistant_id': stored_data.get('assistant_id', ''),
                    'call_id': stored_data.get('call_id', ''),
                    'service_type': stored_data.get('service_type', ''),
                    'response_id': stored_data.get('response_id', ''),
                    'timestamp': stored_data.get('timestamp', ''),
                    'confidence_score': stored_data.get('confidence_score', 0.0),
                    'tier_used': stored_data.get('tier_used', 0),
                    'context': stored_data.get('context', {}),
                    'generation_time': stored_data.get('generation_time'),
                    'token_usage': stored_data.get('token_usage'),
                    'clustering': stored_data.get('clustering')
                }
                
                results.append({
                    'id': result.id,
                    'query': stored_query,
                    'confidence': confidence,
                    'analysis': stored_analysis,
                    'metadata': metadata_dict
                })
            
            # Sort by confidence score
            results.sort(key=lambda x: x['confidence'], reverse=True)
            
            logger.info(f"Found {len(results)} similar queries for: {query}")
            return results
            
        except Exception as e:
            logger.error(f"Error searching similar queries: {e}")
            return []
    
    async def search_default_responses(self, service_type: str = None, voice_name: str = None, limit: int = 5) -> List[Dict]:
        """
        Search for default/fallback responses in vector database.
        
        Args:
            service_type: Service type (e.g., 'Personal_Assistant')
            voice_name: Complete voice name (e.g., 'ps-AF-GulNawazNeural')
            limit: Number of default responses to return
            
        Returns:
            List of default responses with metadata
        """
        try:
            # Get appropriate collection
            collection_name = self._get_collection_name(service_type=service_type, voice_name=voice_name)
            
            # Ensure collection exists
            self._ensure_collection_exists(collection_name)
            
            logger.debug(f"Searching for default responses in collection: {collection_name}")
            
            # Search for entries marked as default responses using scroll with filter
            from qdrant_client.models import Filter, FieldCondition, MatchValue
            
            scroll_result = self.client.scroll(
                collection_name=collection_name,
                scroll_filter=Filter(
                    must=[
                        FieldCondition(
                            key="is_default_response",
                            match=MatchValue(value=True)
                        )
                    ]
                ),
                limit=limit
            )
            
            # Extract results from scroll (returns tuple of (points, next_page_offset))
            points = scroll_result[0] if scroll_result else []
            
            logger.debug(f"Found {len(points)} default responses in collection {collection_name}")
            
            # Format results
            results = []
            for point in points:
                stored_data = point.payload
                
                # Extract context
                stored_context = stored_data.get('context', {})
                if isinstance(stored_context, dict):
                    analysis = {
                        'urgency': stored_context.get('urgency', 'medium'),
                        'formality': stored_context.get('formality', 'professional'),
                        'sentiment': stored_context.get('sentiment', 'neutral'),
                        'intent': stored_context.get('intent', 'default')
                    }
                else:
                    analysis = {
                        'urgency': 'medium',
                        'formality': 'professional',
                        'sentiment': 'neutral',
                        'intent': 'default'
                    }
                
                results.append({
                    'id': point.id,
                    'query': stored_data.get('query', ''),
                    'confidence': 1.0,  # Default responses don't need confidence scoring
                    'analysis': analysis,
                    'metadata': {
                        'response': stored_data.get('response', ''),
                        'tts_file_path': stored_data.get('tts_file_path', ''),
                        'voice_code': stored_data.get('voice_code', ''),
                        'default_category': stored_data.get('default_category', 'generic'),
                        'category': stored_data.get('category', 'generic'),
                        'is_default_response': True,
                        'tts_style': stored_data.get('tts_style', ''),
                        'provider': stored_data.get('provider', ''),
                        'gender': stored_data.get('gender', '')
                    }
                })
            
            logger.info(f"Found {len(results)} default responses for service_type={service_type}, voice_name={voice_name}")
            return results
            
        except Exception as e:
            logger.error(f"Error searching default responses: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return []
    
    async def store_response(self, query: str, response: str, tts_file_path: str, 
                           metadata: Dict = None, context_analysis: Dict = None,
                           performance_metrics: Dict = None, service_type: str = None, 
                           voice_name: str = None, function_name: str = None) -> str:
        """
        Store a new query-response pair with its embedding and metadata in Qdrant.
        Only stores responses from fresh_generation function calls or normal responses (no function calls).
        
        Args:
            query: User query
            response: Assistant response
            tts_file_path: Path to TTS file
            metadata: Additional metadata
            context_analysis: Context analysis data
            performance_metrics: Performance metrics
            service_type: Service type (e.g., 'Personal_Assistant', 'Smart_IVR', 'ASK_ME')
            voice_name: Complete voice name (e.g., 'hi-IN-SwaraNeural')
            function_name: Function name if called (e.g., 'fresh_generation', 'disconnect_service')
            
        Returns:
            Vector ID if stored, None if filtered out
        """
        try:
            # Filter based on function_name
            if not self._should_store_response(function_name):
                logger.debug(f"Skipping storage for function_name='{function_name}' - not eligible for vector DB")
                return None
            
            # Generate unique ID
            vector_id = str(uuid.uuid4())
            
            # Generate embedding
            embedding = self._generate_embedding(query)
            
            # Create context analysis
            if context_analysis:
                context = ContextAnalysis(**context_analysis)
            else:
                context = ContextAnalysis(
                    urgency="medium",
                    formality="professional", 
                    sentiment="neutral",
                    intent="general"
                )
            
            # Create token usage if provided
            token_usage = None
            if performance_metrics and "token_usage" in performance_metrics:
                token_usage = TokenUsage(**performance_metrics["token_usage"])
            
            # Create clustering data
            clustering = None
            if metadata and "cluster_id" in metadata:
                clustering = ClusteringData(
                    cluster_id=metadata.get("cluster_id"),
                    cluster_center_distance=metadata.get("cluster_center_distance")
                )
            
            # Create metadata object with type conversion for safety
            logger.debug(f"Creating vector metadata with full metadata: {metadata}")
            logger.info(f"Storing new vector DB entry: Query='{query[:50]}...', Response='{response[:50]}...', TTS={tts_file_path}")
            
            vector_metadata = PAVectorMetadata(
                query=query,
                normalized_query=self._normalize_query(query),
                response=response,
                tts_file_path=tts_file_path,
                assistant_id=str(metadata.get("assistant_id") or ""),
                call_id=str(metadata.get("call_id") or ""),
                service_type=str(metadata.get("service_type") or "Personal_Assistant"),
                response_id=str(metadata.get("response_id") or ""),
                timestamp=datetime.now(),
                voice_code=str(metadata.get("voice_code") or ""),
                tts_style=str(metadata.get("tts_style") or ""),
                provider=str(metadata.get("provider") or ""),
                gender=str(metadata.get("gender") or ""),
                is_translate=metadata.get("is_translate", False),
                context=context,
                confidence_score=performance_metrics.get("confidence_score", 0.0) if performance_metrics else 0.0,
                tier_used=metadata.get("tier_used", 3),
                generation_time=performance_metrics.get("generation_time") if performance_metrics else None,
                token_usage=token_usage,
                clustering=clustering
            )
            
            # Create vector point
            point = VectorDBPoint(
                id=vector_id,
                vector=embedding,
                payload=vector_metadata
            )
            
            # Get appropriate collection based on service_type and voice_name
            collection_name = self._get_collection_name(service_type=service_type, voice_name=voice_name)
            
            # Ensure collection exists
            self._ensure_collection_exists(collection_name)
            
            # Store in service-voice-specific Qdrant collection
            self.client.upsert(
                collection_name=collection_name,
                points=[point.dict()]
            )
            
            logger.debug(f"Stored response in collection {collection_name} for service_type='{service_type}', voice_name='{voice_name}'")
            
            # Debug logging for vector DB insertion
            logger.debug(f"Vector DB Insertion Debug:")
            logger.debug(f"   Vector ID: {vector_id}")
            logger.debug(f"   Collection: {collection_name}")
            logger.debug(f"   Query: '{query[:100]}...'")
            logger.debug(f"   Normalized Query: '{vector_metadata.normalized_query[:100]}...'")
            logger.debug(f"   Response Length: {len(response)} chars")
            logger.debug(f"   TTS File: {tts_file_path}")
            logger.debug(f"   Service Type: {service_type}")
            logger.debug(f"   Voice Name: {voice_name}")
            logger.debug(f"   Context: {vector_metadata.context}")
            logger.debug(f"   Context Type: {type(vector_metadata.context)}")
            logger.debug(f"   Context Dict: {vector_metadata.context.dict() if hasattr(vector_metadata.context, 'dict') else vector_metadata.context}")
            logger.debug(f"   Confidence Score: {vector_metadata.confidence_score}")
            logger.debug(f"   Tier Used: {vector_metadata.tier_used}")
            
            logger.info(f"Stored response in vector DB: {vector_id}")
            return vector_id
            
        except Exception as e:
            logger.error(f"Error storing response in vector DB: {e}")
            raise
    
    async def update_tts_file_path(self, vector_id: str, tts_file_path: str, voice_name: str = None) -> bool:
        """
        Update the TTS file path for an existing vector database entry.
        
        Args:
            vector_id: Vector database entry ID
            tts_file_path: New TTS file path
            voice_name: Voice name to determine collection (optional)
            
        Returns:
            bool: True if update successful, False otherwise
        """
        try:
            # Get appropriate collection based on voice_name
            collection_name = self._get_collection_name(voice_name=voice_name)
            
            # Retrieve the existing point
            points = self.client.retrieve(
                collection_name=collection_name,
                ids=[vector_id]
            )
            
            if not points or len(points) == 0:
                logger.warning(f"Vector ID {vector_id} not found in collection {collection_name}")
                return False
            
            # Get the existing point
            existing_point = points[0]
            existing_payload = existing_point.payload
            
            # Update the TTS file path in the payload
            if hasattr(existing_payload, 'tts_file_path'):
                existing_payload.tts_file_path = tts_file_path
            else:
                # Handle case where payload is a dict
                existing_payload['tts_file_path'] = tts_file_path
            
            # Update the point in the database
            self.client.upsert(
                collection_name=collection_name,
                points=[{
                    'id': vector_id,
                    'vector': existing_point.vector,
                    'payload': existing_payload
                }]
            )
            
            logger.info(f"Updated TTS file path for vector ID {vector_id}: {tts_file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error updating TTS file path for vector ID {vector_id}: {e}")
            return False

    async def update_generalized_query(self, vector_id: str, generalized_query: str, voice_name: str = None) -> bool:
        """
        Update the normalized_query field with the generalized query for an existing vector database entry.
        
        Args:
            vector_id: Vector database entry ID
            generalized_query: Generalized query to store
            voice_name: Voice name to determine collection (optional)
            
        Returns:
            bool: True if update successful, False otherwise
        """
        try:
            # Get appropriate collection based on voice_name
            collection_name = self._get_collection_name(voice_name=voice_name)
            
            # Retrieve the existing point
            points = self.client.retrieve(
                collection_name=collection_name,
                ids=[vector_id]
            )
            
            if not points or len(points) == 0:
                logger.warning(f"Vector ID {vector_id} not found in collection {collection_name}")
                return False
            
            # Get the existing point
            existing_point = points[0]
            existing_payload = existing_point.payload
            
            # Update the normalized_query with generalized query
            if hasattr(existing_payload, 'normalized_query'):
                existing_payload.normalized_query = generalized_query
            else:
                # Handle case where payload is a dict
                existing_payload['normalized_query'] = generalized_query
            
            # Update the point in the database
            self.client.upsert(
                collection_name=collection_name,
                points=[{
                    'id': vector_id,
                    'vector': existing_point.vector,
                    'payload': existing_payload
                }]
            )
            
            logger.info(f"Updated generalized query for vector ID {vector_id}: {generalized_query}")
            return True
            
        except Exception as e:
            logger.error(f"Error updating generalized query for vector ID {vector_id}: {e}")
            return False
    
    async def search_by_vector_id(self, vector_id: str, voice_name: str = None) -> Optional[dict]:
        """
        Search for a specific vector database entry by ID.
        
        Args:
            vector_id: Vector database entry ID
            voice_name: Voice name to determine collection (optional)
            
        Returns:
            dict: Vector entry data if found, None otherwise
        """
        try:
            # Get appropriate collection based on voice_name
            collection_name = self._get_collection_name(voice_name=voice_name)
            
            # Retrieve the point by ID
            points = self.client.retrieve(
                collection_name=collection_name,
                ids=[vector_id]
            )
            
            if not points or len(points) == 0:
                logger.warning(f"Vector ID {vector_id} not found in collection {collection_name}")
                return None
            
            # Get the point data
            point = points[0]
            payload = point.payload
            
            # Convert to the expected format
            result = {
                'id': vector_id,
                'metadata': payload,
                'confidence': 1.0  # Perfect match since we're searching by ID
            }
            
            logger.debug(f"Retrieved vector entry by ID: {vector_id}")
            return result
            
        except Exception as e:
            logger.error(f"Error searching by vector ID {vector_id}: {e}")
            return None



    def _normalize_query(self, query: str) -> str:
        """
        Normalize query for better matching.
        Note: Person name generalization is now handled by LLM during keyword extraction.
        """
        try:
            # Basic normalization only
            normalized = query.lower().strip()
            
            # Remove extra whitespace
            normalized = re.sub(r'\s+', ' ', normalized)
            
            logger.debug(f"Normalized query: '{query}' -> '{normalized}'")
            return normalized
            
        except Exception as e:
            logger.error(f"Error normalizing query: {e}")
            # Fallback to basic normalization
            return query.lower().strip()    
    
    async def cluster_responses(self, min_samples: int = 3, eps: float = 0.5, language: str = None):
        """
        Perform enhanced multi-dimensional clustering on stored responses using DBSCAN + K-Means.
        Supports language and voice_code separation for better clustering quality.
        
        Args:
            min_samples: Minimum samples for DBSCAN
            eps: Epsilon parameter for DBSCAN
            language: Specific language to cluster (if None, clusters all languages)
        """
        try:
            # Determine which collections to cluster
            collections_to_cluster = []
            if language and language in self.supported_languages:
                collections_to_cluster = [self.language_collections[language]]
            else:
                collections_to_cluster = list(self.language_collections.values())
            
            logger.info(f"Starting multi-dimensional clustering for collections: {collections_to_cluster}")
            
            # Cluster each language collection separately
            for collection_name in collections_to_cluster:
                await self._cluster_collection(collection_name, min_samples, eps)
                
            logger.info("Multi-dimensional clustering completed for all collections")
            
        except Exception as e:
            logger.error(f"Error during clustering: {e}")
    
    async def _cluster_collection(self, collection_name: str, min_samples: int, eps: float):
        """
        Cluster responses in a specific collection with voice-code separation.
        
        Args:
            collection_name: Name of the collection to cluster
            min_samples: Minimum samples for DBSCAN
            eps: Epsilon parameter for DBSCAN
        """
        try:
            logger.info(f"Clustering collection: {collection_name}")
            
            # Get all stored responses from this collection
            all_points = self.client.scroll(
                collection_name=collection_name,
                limit=10000  # Adjust based on your data size
            )[0]
            
            if len(all_points) < min_samples:
                logger.info(f"Not enough points for clustering in {collection_name}")
                return
            
            # Group by voice_code for multi-dimensional clustering
            voice_code_groups = {}
            for point in all_points:
                voice_code = point.payload.get('voice_code', 'unknown')
                if voice_code not in voice_code_groups:
                    voice_code_groups[voice_code] = []
                voice_code_groups[voice_code].append(point)
            
            logger.info(f"Found {len(voice_code_groups)} voice code groups in {collection_name}")
            
            # Cluster each voice_code group separately
            for voice_code, points in voice_code_groups.items():
                if len(points) >= min_samples:
                    await self._cluster_voice_group(collection_name, voice_code, points, min_samples, eps)
                else:
                    logger.info(f"Not enough points for voice_code {voice_code} in {collection_name}")
                    
        except Exception as e:
            logger.error(f"Error clustering collection {collection_name}: {e}")
    
    async def _cluster_voice_group(self, collection_name: str, voice_code: str, points: List, 
                                 min_samples: int, eps: float):
        """
        Cluster responses for a specific voice_code group.
        
        Args:
            collection_name: Name of the collection
            voice_code: Voice code for this group
            points: List of points to cluster
            min_samples: Minimum samples for DBSCAN
            eps: Epsilon parameter for DBSCAN
        """
        try:
            logger.info(f"Clustering {len(points)} points for voice_code {voice_code} in {collection_name}")
            
            # Extract embeddings
            embeddings = [point.vector for point in points]
            embeddings_array = np.array(embeddings)
            
            # Apply DBSCAN clustering
            dbscan = DBSCAN(eps=eps, min_samples=min_samples)
            dbscan_labels = dbscan.fit_predict(embeddings_array)
            
            # Apply K-Means to non-noise points for balanced organization
            noise_mask = dbscan_labels == -1
            non_noise_embeddings = embeddings_array[~noise_mask]
            non_noise_labels = dbscan_labels[~noise_mask]
            
            if len(non_noise_embeddings) > 0:
                # Determine optimal number of clusters for K-Means
                unique_dbscan_labels = set(non_noise_labels)
                n_clusters = max(2, min(len(unique_dbscan_labels), 10))  # Between 2-10 clusters
                
                if n_clusters > 1 and len(non_noise_embeddings) >= n_clusters:
                    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
                    kmeans_labels = kmeans.fit_predict(non_noise_embeddings)
                    
                    # Create final labels combining DBSCAN natural groups with K-Means organization
                    final_labels = dbscan_labels.copy()
                    final_labels[~noise_mask] = kmeans_labels + 100  # Offset to distinguish from DBSCAN
                else:
                    final_labels = dbscan_labels
            else:
                final_labels = dbscan_labels
            
            # Update points with cluster labels (include voice_code in cluster_id)
            cluster_updates = []
            for i, point in enumerate(points):
                cluster_id = f"{voice_code}_{final_labels[i]}"
                cluster_updates.append({
                    'id': point.id,
                    'payload': {
                        **point.payload,
                        'cluster_id': cluster_id,
                        'voice_code_group': voice_code
                    }
                })
            
            # Batch update the points
            if cluster_updates:
                self.client.update_collection(
                    collection_name=collection_name,
                    update_operations=cluster_updates
                )
            
            unique_clusters = len(set(final_labels))
            noise_points = sum(1 for label in final_labels if label == -1)
            
            logger.info(f"Voice group {voice_code} clustering completed: "
                       f"{unique_clusters} clusters, {noise_points} noise points")
                       
        except Exception as e:
            logger.error(f"Error clustering voice group {voice_code}: {e}")

# Global Vector Manager instance
pa_vector_manager = None

def get_vector_manager() -> Optional[PAVectorManager]:
    """Get the global Vector Manager instance (auto-initializes if needed)"""
    global pa_vector_manager
    
    if pa_vector_manager is None:
        try:
            from service.pa_keyword_manager import get_keyword_manager
            
            vector_db_host = os.getenv('THREE_TIER_VECTOR_DB_HOST', 'localhost')
            vector_db_port = int(os.getenv('THREE_TIER_VECTOR_DB_PORT', '6333'))
            collection_name = os.getenv('THREE_TIER_COLLECTION_NAME', 'pa_responses')
            semantic_model_name = os.getenv('THREE_TIER_SEMANTIC_MODEL_NAME', 'paraphrase-multilingual-mpnet-base-v2')
            
            keyword_manager = get_keyword_manager()
            if not keyword_manager:
                logger.error("Keyword Manager not available")
                return None
            
            pa_vector_manager = PAVectorManager(
                vector_db_host=vector_db_host,
                vector_db_port=vector_db_port,
                collection_name=collection_name,
                semantic_model_name=semantic_model_name,
                keyword_manager=keyword_manager
            )
            logger.info("Vector Manager auto-initialized successfully")
        except Exception as e:
            logger.error(f"Error auto-initializing Vector Manager: {e}")
            return None
    
    return pa_vector_manager