from typing import List, Dict, Optional
from logger import get_logger
from repository.assistant_config_repository import get_all_active_assistants
import time
import os
from sqlalchemy.exc import OperationalError, DisconnectionError, DatabaseError, TimeoutError
from utils.alarm_utils import send_alarm, run_alarm_in_thread
from dotenv import load_dotenv

load_dotenv()

country = os.getenv('DEFAULT_COUNTRY')
operator = os.getenv('DEFAULT_OPERATOR')
# In-memory cache variables
assistant_configs_cache: List[Dict] = []
assistant_details_cache: Dict[int, Dict] = {}
assistant_role_cache: Dict[str, Dict] = {}

logger = get_logger(__name__)

def load_cache():
    """
    Load assistant configurations from DB into memory cache as dict.
    Implements retry mechanism for database connection issues.
    Only sends alarms after all retries are exhausted.
    """
    from config.database_config import SessionLocal
    global assistant_configs_cache, assistant_details_cache, assistant_role_cache

    max_retries = 3
    delay = 1
    
    for attempt in range(max_retries):
        try:
            logger.info(f"Loading assistant configurations cache, attempt {attempt + 1}/{max_retries}")
            
            db = SessionLocal()
            try:
                configs = get_all_active_assistants(db)
                
                # Check if we actually got data
                if not configs:
                    logger.warning("No assistant configurations found in database")
                    # Clear existing cache
                    assistant_configs_cache = []
                    assistant_details_cache = {}
                    assistant_role_cache = {}
                    logger.info("Cache cleared due to no data available")
                    return
                
                # Convert SQLAlchemy objects to dict
                assistant_configs_cache = [model_to_dict(c) for c in configs]
                # Build quick lookup by assistant_id
                assistant_details_cache = {c['assistant_id']: c for c in assistant_configs_cache}
                assistant_role_cache = {c['role']: c for c in assistant_configs_cache if c.get('role')}
                
                logger.info(f"Assistant configurations cache loaded successfully. {len(assistant_configs_cache)} configurations cached.")
                return  # Success - exit the retry loop
                
            finally:
                db.close()
                
        except (OperationalError, DisconnectionError, DatabaseError, TimeoutError) as e:
            error_type = type(e).__name__
            logger.warning(f"Database connection error loading cache (attempt {attempt + 1}/{max_retries}): {error_type}: {e}")
            
            if attempt < max_retries - 1:
                logger.info(f"Retrying in {delay * (2 ** attempt)}s... (attempt {attempt + 1}/{max_retries})")
                time.sleep(delay * (2 ** attempt))
                continue
            else:
                # All retries failed - clear cache and log error
                logger.error(f"All {max_retries} attempts failed due to database connection issues. Clearing cache.")
                assistant_configs_cache = []
                assistant_details_cache = {}
                assistant_role_cache = {}
                logger.info("Cache cleared due to database connection failure")
                
                # Send alarm for database connection issues after all retries failed
                error_msg = f"Cache load failed after {max_retries} retries: {str(e)}"
                logger.error(f"Sending DB_Connection alarm: {error_msg}")
                
                try:
                    run_alarm_in_thread(send_alarm(
                        country=country,
                        operator=operator,
                        alarm_type="DB_Connection",
                        remarks=error_msg,
                        status="raise"
                    ))
                except Exception as alarm_error:
                    logger.error(f"Failed to send DB_Connection alarm: {alarm_error}")
                
                # Re-raise the exception so the controller can handle it
                raise
                
        except Exception as e:
            error_type = type(e).__name__
            logger.error(f"Unexpected error loading cache (attempt {attempt + 1}/{max_retries}): {error_type}: {e}")
            
            if attempt < max_retries - 1:
                logger.info(f"Retrying in {delay * (2 ** attempt)}s... (attempt {attempt + 1}/{max_retries})")
                time.sleep(delay * (2 ** attempt))
                continue
            else:
                # All retries failed - clear cache and log error
                logger.error(f"All {max_retries} attempts failed. Clearing cache and logging error.")
                assistant_configs_cache = []
                assistant_details_cache = {}
                assistant_role_cache = {}
                logger.info("Cache cleared due to load failure")
                
                # Re-raise the exception so the controller can handle it
                raise

def model_to_dict(obj) -> Dict:
    """
    Convert SQLAlchemy model instance to dict.
    """
    return {
        "assistant_id": obj.assistant_id,
        "role": obj.role,
        "name": obj.name,
        "age": obj.age,
        "company": obj.company,
        "description": obj.description,
        "male_picture_url": obj.male_picture_url,
        "female_picture_url": obj.female_picture_url,
        "prompt": obj.prompt,
        "call_summary_prompt":obj.call_summary_prompt,
        "opening_message": obj.opening_message,
        "model_id_list": obj.model_id_list,
        "tts_style": obj.tts_style,
        "user_specific": obj.user_specific,
        "tool_call_support": obj.tool_call_support,
        "tools_supported": obj.tools_supported,
        "createdOn": obj.createdOn,
        "updatedOn": obj.updatedOn,
        "status": obj.status,
        "header": obj.header,
        "questions": obj.questions,
        "claude_tools": obj.claude_tools,
        "country": obj.country,
        "operator": obj.operator,
        "country_code": obj.country_code,
        "ivr_stt_array": obj.ivr_stt_array,
        "path_finder_json": obj.path_finder_json,
        "calendar_prompt": obj.calendar_prompt,
        "lang_selection_via_asr": obj.lang_selection_via_asr,
        "tier2_prompt": obj.tier2_prompt,
        "tier2_tools": obj.tier2_tools
    }

def get_assistant_config(id_list: List[int], show_default: bool) -> List[Dict]:
    """
    Get assistant configurations from cache.
    Returns empty list if cache is empty or no matching configurations found.
    """
    # Check if cache is loaded
    if not assistant_configs_cache:
        logger.warning("Assistant configurations cache is empty")
        return []
    
    # Convert all ids in id_list to int
    id_set = set(int(i) for i in id_list) if id_list else set()

    results = []
    for config in assistant_configs_cache:
        if (config["assistant_id"] in id_set and config["status"]) or \
                (show_default and not config["user_specific"] and config["status"]):
            results.append(config)
    
    results.sort(key=lambda x: x["createdOn"])
    logger.info(f"Found {len(results)} matching assistant configurations")
    return results


def get_assistant_details_by_id(assistant_id: int) -> Optional[Dict]:
    """
    Return assistant config dict by id from cache or None if not found.
    """
    logger.info("Getting assistant details from cache for id: %s", assistant_id)
    return assistant_details_cache.get(assistant_id)

def get_assistant_details_by_role(role: str, country: Optional[str] = None, operator: Optional[str] = None) -> Optional[Dict]:
    """
    Return assistant config dict by role from cache, or None if not found.
    Assumes role is unique across all assistants.
    """
    logger.info("Getting assistant details from cache for role: %s, country: %s, operator: %s", role, country, operator)

    if not country and not operator:
        return assistant_role_cache.get(role)
    
    for assistant in assistant_role_cache.values():
        if assistant['role'] == role and assistant['country'] == country and assistant['operator'] == operator:
            return assistant

    return None

