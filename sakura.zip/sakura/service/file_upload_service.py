import PyPDF2
import anthropic
import os
import json
import docx
from logger import get_logger
from repository.file_upload_repository import *
from repository.agent_repository import get_prompts_and_tool_lists_by_assistant_id as get_prompt_tools
from dotenv import load_dotenv
from response.fileUploadResponse import UploadDocResponse
from typing import List, Tuple
# from repository.tool_repository import generate_prompt_with_tools
# from utils.utils import append_tool_call_result_claude,append_tool_use_claude
# from claude_agents.subagent import SubAgent

load_dotenv()

logger = get_logger(__name__)

def upload_doc_service(assistant_id):
    logger.info("Shivam upload doc service called")
    assistant_id = 1001
    logger.info(f"upload_doc_service called for assistant_id = {assistant_id}")

    try:
        # Call generate_response with the extracted content
        # result = generate_response(file_content)  # result contains (msg, flag) from write_to_db
        prompt, tools = combine_prompts_and_tool_lists(assistant_id=assistant_id)
        logger.info(f"prompt and tools = {tools} recieved")
        result = write_to_db(prompt=prompt,toolIndexes=tools)
        logger.info(f"Result after generate_response = {result}")

        # Check if write_to_db succeeded
        if not result[1]:  # If flag is False
            return UploadDocResponse(status="error", status_code=203, message=result[0])

        # Retrieve AssistantConfiguration for the given assistant_id
        assistant_entry = get_assistant_configuration_by_id(assistant_id)

        if not assistant_entry:
            return UploadDocResponse(status="error", status_code=203, message="Assistant configuration not found")

        # Retrieve ExtraColumns entry based on fixed values
        extra_entry = get_extra_columns_by_agent_and_org()

        if not extra_entry:
            return UploadDocResponse(status="error", status_code=203, message="Extra columns data not found")

        # Build the response data
        response_data = {
            "assistant_id": assistant_entry.assistant_id,
            # "prompt": extra_entry.enterprise_data,
            "message" : "Prompt added succesfully to extra_columns",
            "agent_id": extra_entry.agent_id,
            "organization_name": extra_entry.organization_name,
            "org_id": extra_entry.org_id,
            "agent_type": extra_entry.agent_type
        }
        
        return UploadDocResponse(
            status="success",
            status_code=200,
            message="Data retrieved successfully",
            data=response_data
        )

    except Exception as e:
        logger.error(f"An error occurred in upload_doc_service: {str(e)}")
        return UploadDocResponse(status="error", status_code=500, message=f"An error occurred: {str(e)}")

def combine_prompts_and_tool_lists(assistant_id: int) -> Tuple[str, str]:
    try:
        # Fetch data using the repository function
        prompts_and_tool_lists = get_prompt_tools(assistant_id)
        
        # Separate prompts and tool lists
        all_prompts = []
        all_tools = set()

        for prompt, tool_list in prompts_and_tool_lists:
            if prompt:
                all_prompts.append(prompt)  # Collect prompt strings
            if tool_list:
                tools = map(int, tool_list.split(','))  # Convert tool list to integers
                all_tools.update(tools)  # Union of all tool IDs as a set to avoid duplicates

        # Concatenate prompts and convert tool set to a sorted, comma-separated string
        combined_prompts = " \n ".join(all_prompts)
        combined_tool_list = ",".join(map(str, sorted(all_tools)))

        return combined_prompts, combined_tool_list
    
    except Exception as e:
        logger.error(f"An error occurred while combining prompts and tool lists for assistantId: {assistant_id} - {e}")
        return "", ""


# def append_tool_use_claude(messages , function_id , function_name , function_args):
#     messages.append(
#         {
#             "role": "assistant",
#             "content": [{
#                 "type": "tool_use",
#                 "id":function_id,
#                 "name": function_name,
#                 "input": function_args
#             }]
      
#         }
#     )

# def append_tool_call_result_claude(messages , function_id , function_returns):
#     messages.append(
#         {   "role": "user",
#             "content":
#             [{"type": "tool_result",
#             "tool_use_id": function_id,
#             # "name": function_name,
#             "content": function_returns}]
#         }
#     )


# def process_tool_call(tool_name, tool_input):
#     try:
#         if tool_name == "write_to_db":
#             return write_to_db(tool_input["prompt"], tool_input["toolIndexes"])
#         # if tool_name == "fetch_prompts_by_category":
#         #     return  fetch_prompts_by_category(category=tool_input["category"])
#         # if tool_name == "update_db":
#         #     return update_db(id=tool_input["id"],agent_token=tool_input["agent_token"], prompt=tool_input["prompt"], toolIndexes=tool_input["toolIndexes"], agentDescription=tool_input['agentDescription'],category= tool_input['category'],documentLink=documentLink)
#     except:
#         logger.error((tool_input))
#         return {"message":"Invalid input"}
    

# def generate_response(file_text):
#     logger.info("Generate response called")
#     client = anthropic.Client(api_key=os.getenv("ANTHROPIC_API_KEY"))
#     MODEL_NAME = "claude-3-5-sonnet-20240620"
#     messages = []
#     tools_info = [
#         {
#             "name": "write_to_db",
#             "input_schema": {
#                 "type": "object",
#                 "properties": {
#                     "prompt": {"type": "string","description":"The detailed prompt for the given workflow"},
#                     "toolIndexes": {"type": "string", "description": "comma separated integers for example: (4,5,6)"},
#                 },
#                 "required": ["prompt", "toolIndexes"]
#             }
#         }
#     ]

#     system_prompt = generate_prompt_with_tools()
#     # logger.info(f"Prompt generated : {system_prompt}")
#     # print(system_prompt)
#     messages.append({"role": "user", "content": file_text})
#     tool_input = None
#     tool_result = None
#     response = client.messages.create(
#         model=MODEL_NAME,
#         system=system_prompt,
#         max_tokens=4096,
#         messages=messages,
#         tools=tools_info,
#         tool_choice={"type": "auto"},
#     )

#     logger.info("Claude client call executed")

#     if response.stop_reason == "tool_use":
#         tool_use = next(block for block in response.content if block.type == "tool_use")
#         # print(tool_use)
#         tool_id = tool_use.id
#         tool_name = tool_use.name
#         tool_input = tool_use.input
#         # print(f"tool_name ----------> {tool_name}")
#         # print(f"tool input ---------> {tool_input}")
#         # messages.append({"role": "assistant", "content": response.content})
#         logger.info(f"Claude executed Tool id: {tool_id}, Tool Name: {tool_name}, Tool Input: {tool_input}")
#         tool_input_dict = tool_use.input if isinstance(tool_use.input, dict) else json.loads(tool_use.input)
#         append_tool_use_claude(messages, tool_id, tool_name, tool_input_dict)
#         tool_result_temp = process_tool_call(tool_name, tool_input)
#         logger.info(f"result after tool call = {tool_result_temp}")
#         tool_result=json.dumps(tool_result_temp[0],indent=4)
#         append_tool_call_result_claude(messages, tool_id, tool_result)
#         # print(type(tool_result))
#         # print("tool result ----->", tool_result)

#     return tool_result_temp