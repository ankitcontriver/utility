import base64

from sqlalchemy.orm import Session
from models.database_models import UrlLoginDetails
from models.request_models import UidLoginRequest
from datetime import datetime


def find_by_url(db:Session ,url: str):
    return db.query(UrlLoginDetails).filter(UrlLoginDetails.url == url).first()


def upsert_url(db: Session, url: UrlLoginDetails):
    db.add(url)
    db.commit()


def get_all_urls(db: Session):
    return db.query(UrlLoginDetails).all()


def get_url_details(db: Session, url: str):
    return db.query(UrlLoginDetails).filter(UrlLoginDetails.url == url).first()


def get_url_details_by_email(db: Session, email: str):
    return db.query(UrlLoginDetails).filter(UrlLoginDetails.email == email).first()