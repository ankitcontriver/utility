import asyncio
import json
import os
import re
import time
import traceback

import socketio
from dotenv import load_dotenv
from sqlalchemy.orm import Session

from config.assistant_config import assistants
from config.config import create_socketio_app, get_redis_client
from utils.redis_db_manager import redis_manager
from utils.redis_hash_optimizer import RedisHashOptimizer
from utils.redis_batch_manager import RedisBatchManager
from utils.memory_cache_manager import get_memory_cache, start_memory_cache, set_user_call_record, get_user_call_record, delete_user_call_record
from config.database_config import SessionLocal, get_db
from config.faq_config import faqs
from enums.call_enums import Event
from logger import get_logger
from models.database_models import ExtraColumns, DefaultPrompts
from models.redis_models import UserCallRecord, UserCallCDR
from models.request_models import CallStartData, MessageEvent, MessageResponse
from cache.assistant_configuration_cache import get_assistant_details_by_id, get_assistant_details_by_role
from repository.assistant_prompt_repository import get_org_id_by_email, get_non_null_data
# NOTE: Delayed import to avoid circular dependency - imported in function when needed
# from service.chat_analyser_service import analyse_user_transcript
from service.language_service import translate_transcript
from service.message_service import check_statement_complete, append_current_statement_to_user_messages, \
    check_is_statement_interrupting
from utils.asana_utils import get_all_resolved_complaints
from utils.chat_utils import send_chat_chunk_callback_socket
from utils.llm_util import create_opening_prompt_vini, send_call_record_to_jericho, generate_dynamic_message_id
from utils.utils import get_opening_message, handle_additional_info_call_start, get_voice_mapping_from_voice_code, \
    get_current_time_iso, iso_time_difference_in_seconds,check_if_should_mask_data,adjust_log_level
from utils.scalable_async_manager import get_async_manager, run_coroutine_safe
from enums.call_enums import ServiceType
from service.multi_client_config_service import (
    multi_client_manager,
    handle_configuration_not_found,
    get_op_co_key
)
from config.language_mapping_config import get_language_specific_ivr_stt_array

load_dotenv()
sio = create_socketio_app()
logger = get_logger(__name__)

# Configurable timing parameters via environment variables (in milliseconds)
# UTTERANCE_TIMER: Complete utterance processing timeout (default: 500ms)
# INCOMP_UTTERANCE_TIMER: Incomplete utterance wait timeout (default: 500ms)
# SPEECH_WAIT_TIMER: Speech processing wait timeout (default: 3000ms)
# MAX_CALL_ALLOWED_TIME: Maximum call duration in seconds (default: 3600s)
utterance_timer = int(os.getenv('UTTERANCE_TIMER', 500))
incomp_utterance_timer = int(os.getenv('INCOMP_UTTERANCE_TIMER', 500))
speech_utterance_timer = int(os.getenv('SPEECH_WAIT_TIMER', 3000))
max_call_allowed_time = int(os.getenv('MAX_CALL_ALLOWED_TIME', 3600))
vini_assistant_ids = os.getenv('VINI_ASSISTANT_ID', '').split(',')
vini_assistant_ids = [id.strip() for id in vini_assistant_ids]
no_reply_time = os.getenv("NO_REPLY_TIME")
pa_call_audio_path=os.getenv("PA_CALL_AUDIO_PATH")

sio_server = create_socketio_app()

sio_app = socketio.ASGIApp(socketio_server=sio_server)

# PERFORMANCE FIX: Initialize Redis clients and memory cache globally
redis_client = None
cdr_redis_client = None
cdr_hash_optimizer = None
timing_batch_manager = None
memory_cache = None

def initialize_redis_clients():
    """Initialize Redis clients, optimizers, and memory cache - called from main.py startup"""
    global redis_client, cdr_redis_client, cdr_hash_optimizer, timing_batch_manager, memory_cache

    try:
        logger.info("Initializing Redis connections and optimizers...")
        redis_client = redis_manager.get_main_client()      # Main operations (user records, timing keys)
        cdr_redis_client = redis_manager.get_cdr_client()   # CDR operations (heavy JSON writes)

        # PERFORMANCE FIX: Initialize Redis optimizers
        cdr_hash_optimizer = RedisHashOptimizer(cdr_redis_client)
        # NOTE: Removed batch manager for timing-critical operations - using memory cache instead

        # CRITICAL: Initialize memory cache for utterance operations
        memory_cache = get_memory_cache()
        start_memory_cache()
        logger.info("Redis and memory cache initialization completed")

        return True
    except Exception as e:
        logger.error(f"Redis initialization failed: {e}", exc_info=True)
        # Fallback to old Redis client to keep system running
        from config.config import get_redis_client
        redis_client = get_redis_client()
        cdr_redis_client = redis_client  # Use same client as fallback
        cdr_hash_optimizer = None   # Disable hash optimization as fallback

        # Still initialize memory cache even if Redis fails
        try:
            memory_cache = get_memory_cache()
            start_memory_cache()
            logger.info("Memory cache initialized (Redis fallback mode)")
        except Exception as cache_error:
            logger.error(f"Memory cache initialization also failed: {cache_error}")
            memory_cache = None

        logger.warning("Using fallback Redis configuration")
        return False

# Try to initialize immediately, but will be re-initialized by main.py
try:
    initialize_redis_clients()
except:
    # Fallback initialization will happen in main.py
    pass

# Initialize ScalableAsyncManager for routing heavy operations
# Note: Database is cached at startup, so during calls we only route:
# - API calls (translation, jericho)
# - Heavy processing (transcript analysis)
# - Cache lookups remain on main thread (fast operations)
async_manager = get_async_manager()

connected_clients = set()

# PERFORMANCE FIX: Re-enable AsyncLoop routing for better load distribution
DISABLE_ASYNC_ROUTING = False  # Enables AsyncLoop routing for Jericho API calls and transcript analysis

# Helper function to route heavy I/O operations (API calls, processing)
async def route_heavy_operation(operation_func, *args, **kwargs):
    """Route heavy I/O operations through ScalableAsyncManager or execute directly"""
    if DISABLE_ASYNC_ROUTING:
        # Execute on main thread to avoid lock contention
        try:
            if asyncio.iscoroutinefunction(operation_func):
                return await operation_func(*args, **kwargs)
            else:
                return operation_func(*args, **kwargs)
        except Exception as e:
            logger.error(f"Error in direct operation: {e}", exc_info=True)
            return None
    else:
        # Use AsyncLoop (may cause lock contention under high load)
        try:
            async def async_wrapper():
                if asyncio.iscoroutinefunction(operation_func):
                    return await operation_func(*args, **kwargs)
                else:
                    return operation_func(*args, **kwargs)

            return await run_coroutine_safe(async_wrapper())
        except Exception as e:
            logger.error(f"Error in heavy operation: {e}", exc_info=True)
            return None

# Helper function for non-blocking heavy operations
def route_heavy_operation_non_blocking(operation_func, *args, **kwargs):
    """Route heavy operations or execute directly (non-blocking)"""
    if DISABLE_ASYNC_ROUTING:
        # Execute directly in background thread to avoid blocking main thread
        import threading

        def execute_in_background():
            try:
                operation_func(*args, **kwargs)
                logger.info(f"Operation {operation_func.__name__} completed on background thread")
            except Exception as e:
                logger.error(f"Error in background operation {operation_func.__name__}: {e}", exc_info=True)

        thread = threading.Thread(target=execute_in_background, daemon=True)
        thread.start()
        logger.info(f"Operation {operation_func.__name__} routed to background thread (avoiding AsyncLoop)")
    else:
        # Use AsyncLoop (may cause lock contention under high load)
        try:
            async def async_wrapper():
                if asyncio.iscoroutinefunction(operation_func):
                    return await operation_func(*args, **kwargs)
                else:
                    return operation_func(*args, **kwargs)

            # Submit to async manager without waiting (run in background thread)
            import threading
            def run_in_background():
                try:
                    run_coroutine_safe(async_wrapper())
                    logger.debug(f"Heavy operation {operation_func.__name__} completed via AsyncLoop")
                except Exception as e:
                    logger.error(f"Error in AsyncLoop operation {operation_func.__name__}: {e}", exc_info=True)
            
            thread = threading.Thread(target=run_in_background, daemon=True)
            thread.start()
            logger.debug(f"Heavy operation {operation_func.__name__} routed to AsyncLoop workers (non-blocking)")
        except Exception as e:
            logger.error(f"Error routing heavy operation: {e}", exc_info=True)

# Connection tracking for startup optimization
_startup_complete = False
_last_connection_log_count = 0
_connection_log_threshold = 50  # Log every 50 connections during startup

def mark_startup_complete():
    """Mark startup as complete to enable individual connection logging"""
    global _startup_complete
    _startup_complete = True
    logger.info(f"Startup complete. Individual client connections will now be logged. Current total: {len(connected_clients)}")

@sio_server.event
async def connect(sid, environ, auth):
    """Log when client connects and track count"""
    global _last_connection_log_count
    connected_clients.add(sid)
    current_count = len(connected_clients)

    if _startup_complete:
        # After startup, log individual connections
        logger.info(f"Client connected: {sid}. Total clients: {current_count}")
    else:
        # During startup, batch log every N connections
        if current_count % _connection_log_threshold == 0 or current_count - _last_connection_log_count >= _connection_log_threshold:
            logger.info(f"Clients connected: {current_count} total")
            _last_connection_log_count = current_count

@sio_server.event
async def call_start(sid, data):
    logger.secure(f"call start for sid {sid}")
    try:
        json_data = json.loads(data)
        logger.debug(f"call_start json_data ----> {json_data}")

        call_data = CallStartData(**json_data)
        call_cdr_key = f"{call_data.callId}_cdr"
        assistant_id = call_data.assistantId
        service_type = call_data.serviceType
        email_id = call_data.email_id
        if call_data.country_code:
            country = call_data.country_code
        else:
            country = call_data.languageCode.split("-")[1]
        language = call_data.languageCode.split("-")[0]
        gender = call_data.gender.lower()
        
        # session = SessionLocal()
        values = {  # selected in tryeva website
            'gender': gender,
        }

        

        # Assistant lookup and result assignment
        if service_type == ServiceType.PA.value:
            result = get_assistant_details_by_role(ServiceType.PA.value, call_data.country, call_data.operator)
            assistant_id = result.get("assistant_id")
        else:
            result = get_assistant_details_by_id(int(assistant_id))

        if not result:
            logger.warning(f"No result found for assistant_id {assistant_id}")
            return

        logger.debug(f"Assistant details for assistant_id {assistant_id} - {result}")

        # Validate multi-client configuration
        operator = result.get('operator')
        country = result.get('country')

        if operator and country:
            op_co = get_op_co_key(operator, country)

            if not multi_client_manager.validate_op_co(op_co):
                logger.error(f"No multi-client configuration found for {op_co}")
                disconnect_response = await handle_configuration_not_found(
                    call_id=str(call_data.callId),
                    op_co=op_co,
                    assistant_id=str(assistant_id)
                )

                if disconnect_response and "####STOP####" in disconnect_response:
                    # Send disconnect message
                    message_response = MessageResponse(
                        callId=call_data.callId,
                        chunk="####STOP####",
                        isEndChunk=False,
                        transcript=disconnect_response["####STOP####"],
                        messageId="",
                        eventType="call"
                    )
                    logger.info(f"Sending disconnect message for {call_data.callId} - no configuration for {op_co}")
                    await sio_server.emit('call_message', message_response.dict(), to=sid)

                return  # Exit early - call configuration not available
            else:
                logger.info(f"Multi-client configuration validated for {op_co}")
        else:
            logger.warning(f"Missing operator/country in assistant config for {assistant_id}")

        enable_secure_logging = check_if_should_mask_data(operator, country, call_data.aParty, call_data.bParty)
        adjust_log_level(enable_secure_logging)

        # Tools supported and claude_tools parsing
        tools_supported = None
        claude_tools = None
        if result.get("tools_supported"):
            tools_supported_string = result.get("tools_supported", "")
            tools_supported_string = tools_supported_string.strip().replace("'", '"')
            tools_string = re.sub(r',\s*([\}\]])', r'\1', tools_supported_string)
            try:
                logger.secure(f"Tools supported string - {tools_string}")
                tools_supported = json.loads(tools_string)
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing tools_supported JSON: {e}",exc_info=True)
                tools_supported = None
        if result.get("claude_tools"):
            claude_tools_string = result.get("claude_tools", "")
            claude_tools_string = claude_tools_string.strip().replace("'", '"')
            claude_string = re.sub(r',\s*([\}\]])', r'\1', claude_tools_string)
            try:
                claude_tools = json.loads(claude_string)
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing claude_tools JSON: {e}",exc_info=True)
                claude_tools = None

        # Prompt, opening message, tts_style
        opening_message = ""
        system_message = ""
        if service_type == ServiceType.PA.value:
            logger.secure( "Personal Assistant call detected")
            system_message = replace_placeholders(result["prompt"], call_data)
            tts_style = result.get("tts_style", assistants['1']["tts_style"])

            # Add calendar blocking instructions to additionalInfo when isSendEmail is True
            if call_data.isSendEmail:
                calendar_instructions =result.get("opening_message")
                calendar_instructions=replace_placeholders(calendar_instructions,call_data)
                call_data.additionalInfo += calendar_instructions
                logger.secure(f"Added calendar instructions to additionalInfo for call {call_data.callId}")

        else:
            system_message = result["prompt"]
            opening_message = result["opening_message"]
            tts_style = result.get("tts_style", assistants['1']["tts_style"])

        logger.info(f"Opening message Earlier - {opening_message}")

        if assistant_id in vini_assistant_ids:
            opening_message = create_opening_prompt_vini(system_message, assistant_id)

        # Initialize variables
        start_msg = ""
        
        # Smart IVR and other service types
        if service_type == ServiceType.SMART_IVR.value:
            logger.secure( "Smart IVR call detected")
            gpt_response_stream = False
            node_obj_str = json.dumps({"current_node_id": call_data.node_id})
            
            assistant_ivr_stt_array = result['ivr_stt_array']
            if assistant_ivr_stt_array:
                # Parse the JSON string from the database
                if isinstance(assistant_ivr_stt_array, str):
                    assistant_ivr_stt_array = json.loads(assistant_ivr_stt_array)
                
                if isinstance(assistant_ivr_stt_array, dict):
                    # Get language-specific ivr_stt_array for the system message
                    lang_code = call_data.languageCode  # e.g., "en-IN", "en-US", "fr", "es"
                    language_specific_ivr_stt_array = get_language_specific_ivr_stt_array(
                        assistant_ivr_stt_array, 
                        lang_code
                    )
                    # Create the system message with the new structure
                    ivr_config_str = json.dumps(language_specific_ivr_stt_array)
                    system_message = f"{system_message}\n{node_obj_str}\nIVR Configuration: {ivr_config_str}"
                else:
                    logger.error(f"ivr_stt_array is not a valid dictionary after parsing: {type(assistant_ivr_stt_array)}")
            else:
                logger.error(f"SMART_IVR ivr_stt_array not found for assistant_id {assistant_id}")
        else:
            gpt_response_stream = True
            if opening_message:
                start_msg, start_audio, provider, gender = get_opening_message(
                    call_data.languageCode, call_data.voiceName, opening_message, tts_style, gender, call_data.ttsProvider
                )
                start_msg = start_msg.replace("معين", "مُعين")
                
                # First message: With actual content, isEndChunk=False
                message_response = MessageResponse(
                    callId=call_data.callId,
                    chunk=start_msg,
                    transcript=start_audio,
                    isEndChunk=False,
                    messageId=generate_dynamic_message_id("0_Avatar", "Avatar")
                )
                logger.info(f"{call_data.callId} - Sending opening message chunk - {message_response.__repr__()}")
                await sio.emit('call_message', message_response.dict(), to=sid)
                
                # Second message: Empty chunk, isEndChunk=True (signals end)
                message_response = MessageResponse(
                    callId=call_data.callId,
                    chunk="",
                    transcript="", 
                    isEndChunk=True,
                    messageId=generate_dynamic_message_id("0_Avatar", "Avatar")
                )
                logger.info(f"{call_data.callId} - Sending end chunk signal - {message_response.__repr__()}")
                await sio.emit('call_message', message_response.dict(), to=sid)
            else:
                logger.info(f"{call_data.callId} - No opening message, skipping all message responses")


        system_message = handle_additional_info_call_start(system_message, call_data.additionalInfo, call_data.callId)
        logger.debug(f"{call_data.callId} Final System message - {system_message}")

        if not call_data.isTranslate:
            if opening_message:
                llm_message = [{"role": "system", "content": system_message},
                               {"role": "assistant", "content": start_msg}]
            else:
                llm_message = [{"role": "system", "content": system_message}]
        else:
            llm_message = [{"role": "system", "content": system_message},
                           {"role": "assistant", "content": opening_message}]



        user_call_record = UserCallRecord(callId=call_data.callId, assistantId=result["assistant_id"],
                                          gender=gender, ttsModel=call_data.ttsModel,
                                          voiceName=call_data.voiceName, languageCode=call_data.languageCode,
                                          llmMessage=llm_message, socketId=sid, ttsStyle=tts_style,
                                          llmModel=call_data.llmModel, isTranslate=call_data.isTranslate,
                                          provider=call_data.ttsProvider, tools=tools_supported, claude_tools=claude_tools,
                                          isSendEmail=call_data.isSendEmail, aParty= call_data.aParty, bParty= call_data.bParty,
                                          serviceType=service_type,questionPerCall=call_data.questionPerCall ,isCallOngoing= True, gpt_response_stream=gpt_response_stream, current_node_id=call_data.node_id, user_path = None)
        logger.debug(f"{call_data.callId} User Call Record {user_call_record}")
        # PERFORMANCE FIX: Store user call record in memory instead of Redis
        set_user_call_record(str(call_data.callId), vars(user_call_record))

        cdr_call_messages = []
        
        # Only add to CDR if opening_message exists
        if opening_message:
            cdr_call_messages.append({
                "id": "0_Avatar",  # Generate a unique ID for the message
                "senderId": "eva",  # Use the sender_id from user_messages
                "body": opening_message,  # The actual message content
                "contentType": "text",  # Assuming text content; adjust as needed
                "attachments": [],  # Assuming no attachments; adjust as needed
                "createdAt": get_current_time_iso()  # Set the current time in ISO format
            })
        user_call_cdr = UserCallCDR(call_id=call_data.callId, assistant_id=result["assistant_id"],
                                    assistant_name=result["name"],
                                    call_start_time=get_current_time_iso(), call_end_time=None,
                                    call_duration=None, call_status="Active", call_type=None, user_id=email_id,
                                    question_count=0, answer_count=0, tools_used=0, rag_tool_use=0,
                                    satisfaction_score=None, sentiment=None, emotions=None, intent=None,
                                    call_messages=cdr_call_messages,avg_overall_response_time = 0,avg_normal_response_time=0,
                                    avg_time_first_chunk_generation=0,total_time_first_chunk_generation=0,total_output_token=0,
                                    total_input_token=0, avg_input_token=0, avg_output_token=0, avg_web_response_time=0,
                                    total_perplexity_queries=0, total_function_call_failure=0, total_web_response_time=0,
                                    gpt_failure_counts=0, total_overall_response_time=0, total_normal_response_time=0,
                                    language=call_data.languageCode, country=result["country"],
                                    operator=result["operator"], country_code=result["country_code"])

        # PERFORMANCE FIX: Use Redis hash instead of large JSON string
        cdr_data_dict = vars(user_call_cdr)
        if cdr_hash_optimizer:
            success = cdr_hash_optimizer.set_cdr_hash(call_data.callId, cdr_data_dict, max_call_allowed_time)
        else:
            # Fallback to basic Redis storage if hash optimizer failed to initialize
            serialized_data = json.dumps(cdr_data_dict)
            cdr_redis_client.set(f"cdr:{call_data.callId}", serialized_data, ex=max_call_allowed_time)
            success = True

        if not success:
            # Fallback to original method if hash operation fails
            user_call_cdr_serialized = json.dumps(cdr_data_dict)
            cdr_redis_client.set(call_cdr_key, user_call_cdr_serialized)
            cdr_redis_client.expire(call_cdr_key, max_call_allowed_time)
        logger.secure(f"CDR created successfully for call_id {call_data.callId}")
        logger.debug(f"CDR hash stored for call_id -> {call_data.callId}, redis_key={call_cdr_key}, socketId -> {sid}")
        await change_call_state(sid,data)
        redis_client.expire(call_data.callId, max_call_allowed_time)
        logger.debug(f"Data and user object stored for call_id={call_data.callId}, socketId={sid}")
        logger.secure(f"{call_data.callId} - Call start completed")

    except Exception as e:
        logger.error(f"Error processing data: {e}", exc_info=True)
        await sio_server.emit("error", {"sid": sid, "error": str(e)})


@sio_server.event
async def call_message(sid, message):
    logger.secure(f"call_message received for {sid}")
    try:
        json_message_data = json.loads(message)
        message_data = MessageEvent(**json_message_data)
        logger.debug(f"Message Data {message_data}")
        milliseconds = int(round(time.time() * 1000))
        logger.secure(f"{message_data.callId} Message data start time {message_data.startTime} ===== end Time {message_data.endTime},Time from client to server - {milliseconds - message_data.endTime}")

        callId = message_data.callId
        no_reply_key = f"{callId}:no_reply"
        redis_client.delete(no_reply_key)

        # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
        user_call_record_data = get_user_call_record(str(message_data.callId))
        if user_call_record_data is None:
            logger.debug(f"User call record not found in memory for callId: {message_data.callId}")
            return None
        user_call_record = UserCallRecord(**user_call_record_data)

        new_node_id = message_data.node_id
        lang_code = message_data.langCode
        if user_call_record.serviceType == ServiceType.SMART_IVR.value:
            # Update current_node_id
            user_call_record.current_node_id = new_node_id
            
            # Check if language code changed from call_start
            lang_code_changed = user_call_record.languageCode != lang_code
            
            # Update system message
            for msg in user_call_record.llmMessage:
                if msg.get("role") == "system":
                    # Always update current_node_id
                    new_content = re.sub(
                        r'("current_node_id"\s*:\s*)[0-9]+',
                        f'\\1{new_node_id}',
                        msg["content"]
                    )
                    
                    # Only update IVR Configuration if language changed
                    if lang_code_changed:
                        assistant_result = get_assistant_details_by_id(int(user_call_record.assistantId))
                        if assistant_result and 'ivr_stt_array' in assistant_result:
                            assistant_ivr_stt_array = assistant_result['ivr_stt_array']
                            
                            # Parse the JSON string from the database
                            if isinstance(assistant_ivr_stt_array, str):
                                assistant_ivr_stt_array = json.loads(assistant_ivr_stt_array)
                            
                            if isinstance(assistant_ivr_stt_array, dict):
                                language_specific_ivr_stt_array = get_language_specific_ivr_stt_array(
                                    assistant_ivr_stt_array, 
                                    lang_code
                                )
                                ivr_config_str = json.dumps(language_specific_ivr_stt_array)
                                new_content = re.sub(
                                    r'IVR Configuration: \{.*\}',
                                    f'IVR Configuration: {ivr_config_str}',
                                    new_content
                                )
                                logger.info(f"Language changed from {user_call_record.languageCode} to {lang_code}, updated IVR configuration")
                            else:
                                logger.error(f"ivr_stt_array is not a valid dictionary after parsing: {type(assistant_ivr_stt_array)}")
                        else:
                            logger.info(f"SMART_IVR language mappings not found in ivr_stt_array")
                    
                    if new_content != msg["content"]:
                        msg["content"] = new_content
                        # PERFORMANCE FIX: Update user call record in memory instead of Redis
                        set_user_call_record(str(message_data.callId), vars(user_call_record))
                    break

        user_call_message = message_data.transcript
        voice_code = message_data.voiceName
        user_call_record.eventType = message_data.eventType
        user_call_record.currentMessageId = message_data.messageId
        user_call_record.consecutive_no_reply_count = 0
        user_call_record.current_node_id = message_data.node_id

        is_translate = user_call_record.isTranslate

        language = lang_code.split("-")[0]
        logger.debug(f"Language in call start - {language}")

        # EMERGENCY FIX: Execute translation on main thread to avoid AsyncLoop saturation
        if is_translate:
            logger.debug(f"{message_data.callId} Language is {language}, Translating")
            try:
                user_call_message = translate_transcript(user_call_message, language)
            except Exception as e:
                logger.error(f"Translation error for {message_data.callId}: {e}")
                # Continue with original message on translation failure

        logger.info(f"{message_data.callId} user_call_message : {user_call_message}")
        utterance_key = f"{message_data.callId}:utterance"
        if user_call_record.speaking and message_data.eventType != Event.CHAT.value:
            logger.secure(f"[{message_data.callId}] In speaking state")
            transcript_to_check = user_call_message.lower()
            if check_is_statement_interrupting(transcript_to_check):
                sock_data = {
                    "callId": message_data.callId
                }
                user_call_record.interrupt = True
                user_call_record.speaking = False
                user_call_record.listening = True
                user_call_record.userMessage.clear()
                user_call_record.userMessage.append(transcript_to_check)
                # PERFORMANCE FIX: Update user call record in memory instead of Redis
                set_user_call_record(str(message_data.callId), vars(user_call_record))
                await send_chat_chunk_callback_socket(sid=user_call_record.socketId,
                                                      data=sock_data, event='call_interrupt')
                # PERFORMANCE FIX: Use memory cache for interrupt handling (deterministic timing)
                if memory_cache:
                    memory_cache.set_with_expiry(utterance_key, "interrupt", 100, message_data.callId, "utterance")
                    logger.debug(f"Set interrupt utterance key in memory cache: {utterance_key}")
                else:
                    logger.error("Memory cache not available for interrupt key - falling back to Redis")
                    try:
                        redis_client.set(utterance_key, "interrupt", px=100)
                    except Exception as e:
                        logger.error(f"Failed to set interrupt key {utterance_key}: {e}")
                        redis_client.set(utterance_key, "interrupt", ex=1)
                return
            else:
                return

        if user_call_record.processing:
            logger.secure(f"[{message_data.callId}] In processing state")
            if check_is_statement_interrupting(user_call_message.lower()):
                user_call_record.interrupt = True
                # PERFORMANCE FIX: Update user call record in memory instead of Redis
                set_user_call_record(str(message_data.callId), vars(user_call_record))
                return

        wait_key = f"{message_data.callId}:wait"

        # PERFORMANCE FIX: Delete keys from memory cache instead of Redis
        if memory_cache:
            memory_cache.delete(utterance_key)
            memory_cache.delete(wait_key)
            logger.debug(f"Deleted utterance and wait keys from memory cache: {utterance_key}, {wait_key}")
        else:
            redis_client.delete(utterance_key)
            redis_client.delete(wait_key)

        user_message = user_call_record.userMessage
        transcript = append_current_statement_to_user_messages(user_message, user_call_message)
        user_message.clear()
        user_message.append(transcript)
        user_call_record.userMessage = user_message
        user_call_record.interrupt = False
        user_call_record.langCode = lang_code
        user_call_record.languageCode = lang_code
        user_call_record.voiceCode = voice_code
        user_call_record.voiceName = voice_code  # Update voiceName as well for 3-tier system
        # PERFORMANCE FIX: Update user call record in memory instead of Redis
        set_user_call_record(str(message_data.callId), vars(user_call_record))

        # Now set the expiring utterance key
        utterance_key = f"{message_data.callId}:utterance"
        if check_statement_complete(transcript):
            if memory_cache:
                memory_cache.set_with_expiry(utterance_key, "processing", utterance_timer, message_data.callId, "utterance")
                logger.debug(f"Set utterance key in memory cache: {utterance_key} (expires in {utterance_timer}ms)")
            else:
                logger.error("Memory cache not available for utterance key - falling back to Redis")
                try:
                    if redis_client:
                        redis_client.set(utterance_key, "processing", px=utterance_timer)
                    else:
                        from config.config import get_redis_client
                        fallback_client = get_redis_client()
                        fallback_client.set(utterance_key, "processing", ex=int(utterance_timer/1000))
                except Exception as e:
                    logger.error(f"Failed to set utterance key {utterance_key}: {e}")
                    if redis_client:
                        redis_client.set(utterance_key, "processing", ex=int(utterance_timer/1000))
                    else:
                        from config.config import get_redis_client
                        fallback_client = get_redis_client()
                        fallback_client.set(utterance_key, "processing", ex=int(utterance_timer/1000))
            logger.info(
                f"[{message_data.callId}] Key {utterance_key} SET DIRECTLY in Redis at {int(round(time.time() * 1000))} with {utterance_timer}ms expiration")
        else:
            wait_key = f"{message_data.callId}:wait"
            if memory_cache:
                memory_cache.set_with_expiry(wait_key, "waiting", incomp_utterance_timer, message_data.callId, "wait")
                logger.debug(f"Set wait key in memory cache: {wait_key} (expires in {incomp_utterance_timer}ms)")
            else:
                logger.error("Memory cache not available for wait key - falling back to Redis")
                try:
                    redis_client.set(wait_key, "waiting", px=incomp_utterance_timer)
                except Exception as e:
                    logger.error(f"Failed to set wait key {wait_key}: {e}")
                    redis_client.set(wait_key, "waiting", ex=int(incomp_utterance_timer/1000))
    except Exception as e:
        logger.error(f"Error processing message in call_message: {e}", exc_info=True)
        await sio_server.emit("error", {"sid": sid, "error": str(e)})


@sio_server.event
async def call_end(sid, data):
    call_id = None
    try:
        logger.secure(f"call_end received for {sid}")
        json_message_data = json.loads(data)
        call_id = str(json_message_data["callId"])  # Ensure string type consistency
        call_cdr_key = f"{json_message_data['callId']}_cdr"

        # PERFORMANCE FIX: Try to get CDR from Redis hash first
        if cdr_hash_optimizer:
            cdr_data = cdr_hash_optimizer.get_cdr_hash(call_id)
        else:
            # Fallback to basic Redis get if hash optimizer failed to initialize
            try:
                serialized_data = cdr_redis_client.get(f"cdr:{call_id}")
                cdr_data = json.loads(serialized_data) if serialized_data else None
            except Exception as e:
                logger.error(f"Failed to get CDR from fallback Redis: {e}")
                cdr_data = None

        if cdr_data is None:
            # Fallback: try original JSON method
            serialized_user_call_cdr_record = cdr_redis_client.get(call_cdr_key)
            if serialized_user_call_cdr_record is None:
                logger.debug(f"CDR not found in Redis for key: {call_cdr_key}")
                delete_user_call_record(call_id)
                logger.info(f"Deleted call record {call_id} from memory (CDR not found)")
                return
            else:
                logger.debug(f"Using fallback JSON CDR for {call_cdr_key}")
                cdr_data = json.loads(serialized_user_call_cdr_record)

        user_call_cdr_record = UserCallCDR(**cdr_data)

        # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
        user_call_record_data = get_user_call_record(call_id)
        if user_call_record_data is None:
            logger.debug(f"User call record not found in memory for callId: {call_id}")
            return
        else:
            data = user_call_record_data

        if "currentNodeId" in data:
            data["current_node_id"] = data.pop("currentNodeId")
        user_call_record = UserCallRecord(**data)

        isCallOngoing=user_call_record.isCallOngoing
        if not isCallOngoing:
            logger.info(f"Call already ended for callId: {call_id}, skipping.")
            delete_user_call_record(call_id)
            logger.info(f"Deleted call record {call_id} from memory (already ended)")
            return
        else:
            user_call_record.isCallOngoing = False
            # PERFORMANCE FIX: Update user call record in memory instead of Redis
            set_user_call_record(call_id, vars(user_call_record))
            
        logger.info(f"call_id {call_id} User Call messages: {user_call_cdr_record.call_messages}")

        isSendEmail=user_call_record.isSendEmail
        aParty=user_call_record.aParty
        bParty=user_call_record.bParty
        llmMessage=user_call_record.llmMessage
        callFilePath= f"{pa_call_audio_path}/{aParty}_{call_id}.wav"
        callStartTime=user_call_cdr_record.call_start_time
        callEndTime=get_current_time_iso()
        result = get_assistant_details_by_id(user_call_record.assistantId)
        call_summary_prompt=result.get("call_summary_prompt")

        # Route heavy Jericho API calls through ScalableAsyncManager (non-blocking)
        try:
            if user_call_record.serviceType == ServiceType.PA.value:
                async def send_to_jericho():
                    logger.info(f"PA call {call_id} - Sending conversation to jericho")
                    await send_call_record_to_jericho(aParty,bParty,llmMessage,callFilePath,callStartTime,callEndTime,call_summary_prompt, user_call_record.assistantId)
                    return True

                logger.info(f"[{call_id}] Routing Jericho API call through AsyncLoop workers (non-blocking)")
                route_heavy_operation_non_blocking(send_to_jericho)
        except Exception as jericho_error:
            logger.error(f"Error routing Jericho API call for call_id {call_id}: {jericho_error}", exc_info=True)
            # Continue with cleanup regardless

        # Save cached vector metadata to vector DB at call end
        try:
            if hasattr(user_call_record, 'vector_metadata_cache') and user_call_record.vector_metadata_cache:
                async def save_vector_metadata():
                    logger.info(f"Call {call_id} - Saving {len(user_call_record.vector_metadata_cache)} cached vector metadata entries")
                    
                    from service.pa_three_tier_service import get_three_tier_service
                    three_tier_service = get_three_tier_service()
                    if three_tier_service:
                       for metadata in user_call_record.vector_metadata_cache:
                           try:
                               # Only store entries that have a valid TTS file path
                               tts_file_path = metadata.get("tts_file_path", "")
                               if tts_file_path and tts_file_path.strip():
                                   # Get service type and voice name from metadata
                                   service_type = metadata.get("service_type")
                                   if not service_type:
                                       # Fallback to call record service type
                                       service_type = getattr(user_call_record, 'serviceType', '')
                                       logger.debug(f"Using call record serviceType as fallback: {service_type}")
                                   
                                   voice_name = metadata.get("voice_name", "")
                                       
                                   # Store the response for learning
                                   await three_tier_service.store_new_response(
                                       query=metadata.get("query", ""),
                                       response=metadata.get("response", ""),
                                       tts_file_path=tts_file_path,
                                       metadata=metadata,
                                       service_type=service_type,  
                                       voice_name=voice_name,      
                                       function_name=metadata.get("function_name", None)
                                   )
                                   logger.info(f"Stored cached vector metadata for call {call_id}: {metadata.get('response_id', 'unknown')} in {service_type} collection")
                               else:
                                   logger.warning(f"Skipping vector metadata storage for call {call_id} - no TTS file path: {metadata.get('response_id', 'unknown')}")
                           except Exception as e:
                               logger.error(f"Failed to store cached vector metadata for call {call_id}: {e}")
                    else:
                        logger.warning(f"Three tier service not available for saving cached metadata for call {call_id}")
                    return True

                logger.info(f"[{call_id}] Routing vector metadata saving through AsyncLoop workers (non-blocking)")
                route_heavy_operation_non_blocking(save_vector_metadata)
            else:
                logger.info(f"[{call_id}] No cached vector metadata to save")
        except Exception as vector_error:
            logger.error(f"Error saving cached vector metadata for call_id {call_id}: {vector_error}", exc_info=True)
            # Continue with cleanup regardless

        # CRITICAL: Clean up ALL memory cache keys for this call to prevent timeout callbacks
        if memory_cache:
            utterance_key = f"{call_id}:utterance"
            wait_key = f"{call_id}:wait"
            no_reply_key = f"{call_id}:no_reply"

            # Delete all possible keys that might still be active
            keys_deleted = 0
            for key in [utterance_key, wait_key, no_reply_key]:
                if memory_cache.delete(key):
                    keys_deleted += 1

            logger.info(f"[{call_id}] Cleaned up {keys_deleted} memory cache keys to prevent timeout callbacks")

        # Always delete the call record from memory
        delete_user_call_record(call_id)
        
        # Push CDR to external API if enabled (async background task)
        try:
            from service.cdr_api_service import get_cdr_api_pusher
            pusher = get_cdr_api_pusher()
            
            # Only push if PUSH_CDR flag is enabled
            if pusher.push_cdr_enabled:
                pusher.push_cdr_async(call_id)
                logger.debug(f"CDR push initiated for call_id: {call_id}")
            else:
                logger.debug(f"CDR push disabled, skipping for call_id: {call_id}")
        except Exception as cdr_push_error:
            logger.error(f"Failed to push CDR for call_id {call_id}: {cdr_push_error}")

        logger.info(f"call ended for {sid}, call_id {call_id} - All cleanup completed")
    except Exception as e:
        logger.error(f"Error in call_end: {e}", exc_info=True)
        # Emergency cleanup - CRITICAL to prevent timeout callbacks
        if call_id:
            try:
                # Clean up memory cache keys first
                if memory_cache:
                    utterance_key = f"{call_id}:utterance"
                    wait_key = f"{call_id}:wait"
                    no_reply_key = f"{call_id}:no_reply"

                    keys_deleted = 0
                    for key in [utterance_key, wait_key, no_reply_key]:
                        try:
                            if memory_cache.delete(key):
                                keys_deleted += 1
                        except:
                            pass  # Ignore individual key deletion errors

                    logger.info(f"Emergency cleanup: cleaned up {keys_deleted} memory cache keys for {call_id}")

                # Clean up user call record
                delete_user_call_record(call_id)
                logger.info(f"Emergency cleanup: deleted call_id {call_id} from memory")
            except Exception as cleanup_error:
                logger.error(f"Failed emergency cleanup for {call_id}: {cleanup_error}")


@sio_server.event
async def call_message_utterance(sid, data):
    try:
        logger.info(f"utterance, {sid}, data {data} at time -> {int(round(time.time() * 1000))}")
        json_message_data = json.loads(data)
        utterance_key = f"{json_message_data['callId']}:utterance"
        wait_key = f"{json_message_data['callId']}:wait"
        logger.info(f"utterance key - {utterance_key}")
        # PERFORMANCE FIX: Use memory cache for expiry updates (deterministic timing)
        if memory_cache:
            if memory_cache.exists(utterance_key):
                memory_cache.set_with_expiry(utterance_key, "processing", speech_utterance_timer, json_message_data['callId'], "utterance")
                logger.debug(f"Updated utterance key expiry in memory cache: {utterance_key} ({speech_utterance_timer}ms)")
            if memory_cache.exists(wait_key):
                memory_cache.set_with_expiry(wait_key, "waiting", speech_utterance_timer, json_message_data['callId'], "wait")
                logger.debug(f"Updated wait key expiry in memory cache: {wait_key} ({speech_utterance_timer}ms)")
        else:
            logger.error("Memory cache not available for key expiry updates - falling back to Redis")
            if redis_client.exists(utterance_key):
                try:
                    redis_client.pexpire(utterance_key, speech_utterance_timer)
                except Exception as e:
                    logger.error(f"Failed to pexpire utterance key {utterance_key}: {e}")
                    redis_client.expire(utterance_key, int(speech_utterance_timer/1000))
            if redis_client.exists(wait_key):
                try:
                    redis_client.pexpire(wait_key, speech_utterance_timer)
                except Exception as e:
                    logger.error(f"Failed to pexpire wait key {wait_key}: {e}")
                    redis_client.expire(wait_key, int(speech_utterance_timer/1000))
    except Exception as e:
        logger.error(f"Error in call_message_utterance, {e}", exc_info=True)


@sio_server.event
async def change_call_state(sid, data):
    try:
        logger.info(f"change_call_state, {sid}, data {data} at time -> {int(round(time.time() * 1000))}")
        json_message_data = json.loads(data)
        callId = json_message_data["callId"]
        # PERFORMANCE FIX: Retrieve and update user call record from memory instead of Redis
        user_call_record_data = get_user_call_record(str(callId))
        if user_call_record_data is None:
            logger.debug(f"User call record not found in memory for callId: {callId}")
            return None
        if "currentNodeId" in user_call_record_data:
            user_call_record_data["current_node_id"] = user_call_record_data.pop("currentNodeId")
        user_call_record = UserCallRecord(**user_call_record_data)
        user_call_record.listening = True
        user_call_record.speaking = False
        user_call_record.processing = False
        # PERFORMANCE FIX: Update user call record in memory instead of Redis
        set_user_call_record(str(callId), vars(user_call_record))
        # no_reply_key = f"{callId}:no_reply"
        # redis_client.set(no_reply_key, no_reply_time)
        # redis_client.pexpire(no_reply_key, no_reply_time)

    except Exception as e:
        logger.error(f"Exception in change_call_state - {e}", exc_info=True)


@sio_server.event
async def call_transcription(sid, data):
    try:
        logger.debug(f"call_transcription , {sid} , data {data} at time - {int(round(time.time() * 1000))}")
        json_message_data = json.loads(data)
        call_id = json_message_data["callId"]
        transcript = json_message_data["transcript"]

        # Route heavy transcript analysis processing through ScalableAsyncManager (non-blocking)
        async def analyze_transcript():
            # Delayed import to avoid circular dependency
            from service.chat_analyser_service import analyse_user_transcript
            start_time = time.time()
            data = analyse_user_transcript(transcript)
            end_time = time.time()
            logger.info(f"call_id - {call_id} call_transcription data - {data} in time - {end_time - start_time}")
            return data

        logger.info(f"[{call_id}] Routing transcript analysis processing through AsyncLoop workers")
        route_heavy_operation_non_blocking(analyze_transcript)
    except Exception as e:
        logger.error(f"Exception in  call_transcription - {e}", exc_info=True)


@sio_server.event
async def payment_status(sid, data):
    try:
        logger.info(f"payment_status , {sid} , data {data} at time - {int(round(time.time() * 1000))}")
        json_message_data = json.loads(data)
        call_id = json_message_data["callId"]
        paymentStatus = json_message_data["paymentStatus"]

        if paymentStatus == "success":
            message = "User Payment is Success and plan activated successfully."
        else:
            message = "User Payment is Failed. Please try again later."

        # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
        user_call_record_data = get_user_call_record(call_id)
        if user_call_record_data is None:
            logger.debug(f"User call record not found in memory for call_id: {call_id}")
            return None
        user_call_record = UserCallRecord(**user_call_record_data)

        llm_message = {"role": "system", "content": message}

        user_call_record.llmMessage.append(llm_message)
        # PERFORMANCE FIX: Update user call record in memory instead of Redis
        set_user_call_record(call_id, vars(user_call_record))
        utterance_key = f"{call_id}:utterance"
        # PERFORMANCE FIX: Use memory cache for payment utterance timing (configurable expiry via UTTERANCE_TIMER env)
        if memory_cache:
            memory_cache.set_with_expiry(utterance_key, "processing", utterance_timer, call_id, "utterance")
            logger.debug(f"Set payment utterance key in memory cache: {utterance_key} (expires in {utterance_timer}ms)")
        else:
            logger.error("Memory cache not available for payment utterance key - falling back to Redis")
            try:
                redis_client.set(utterance_key, "processing", px=utterance_timer)
            except Exception as e:
                logger.error(f"Failed to set payment utterance key {utterance_key}: {e}")
                redis_client.set(utterance_key, "processing", ex=int(utterance_timer/1000))

    except Exception as e:
        logger.error(f"Exception in  payment_status - {e}", exc_info=True)


@sio_server.event
async def disconnect(sid):
    """Log when client disconnects, clean up stale records, and update count"""
    connected_clients.discard(sid)

    # Clean up stale Redis records for this socket
    try:
        # Find all Redis keys with this socket ID and clean them up
        # Use main Redis client for cleanup operations
        cleanup_redis_client = redis_manager.get_main_client()

        # Pattern to find all call records with this socket ID
        for key in cleanup_redis_client.scan_iter(match="*"):
            try:
                record_data = cleanup_redis_client.get(key)
                if record_data and f'"{sid}"' in record_data:
                    logger.info(f"Cleaning stale Redis record for disconnected socket {sid}: {key}")
                    # Set a short expiration instead of immediate deletion to avoid race conditions
                    cleanup_redis_client.expire(key, 5)  # Expire in 5 seconds
            except Exception as e:
                # Don't let cleanup errors affect disconnect handling
                logger.debug(f"Minor cleanup error for {key}: {e}")

    except Exception as e:
        logger.warning(f"Could not clean up Redis records for disconnected socket {sid}: {e}")

    if _startup_complete:
        logger.info(f"Client disconnected: {sid}. Total clients: {len(connected_clients)}")
    # During startup, don't log individual disconnections




def replace_placeholders(prompt, call_data):
    values = {
        "assistantName": getattr(call_data, "assistantName", ""),
        "userName": getattr(call_data, "userName", ""),
        "gender": getattr(call_data, "gender", ""),
        "assistantStyle": getattr(call_data, "assistantStyle", ""),
        "languageCode": getattr(call_data, "languageCode", ""),
        "language": getattr(call_data, "language", ""),
        "questionPerCall": getattr(call_data, "questionPerCall", ""),
        "handleTelemarketingCalls": getattr(call_data, "handleTelemarketingCalls", False),
        "reference_current_datetime": get_current_time_iso(),
        "query_language": getattr(call_data, "languageCode", "en-US"),
        "voice_code": getattr(call_data, "voiceName", "en-US-AvaNeural"),
        "user_gender": getattr(call_data, "gender", "female"),
        "conversation_history": "",  # This will be populated dynamically
        "session_id": getattr(call_data, "callId", ""),
        "aParty": getattr(call_data, "aParty", ""),
        "bParty": getattr(call_data, "bParty", ""),
        "assistant_id": getattr(call_data, "assistantId", ""),
        "call_id": getattr(call_data, "callId", ""),
        "service_type": getattr(call_data, "serviceType", ""),
        "tts_provider": getattr(call_data, "ttsProvider", "Azure"),
        "llm_model": getattr(call_data, "llmModel", "gpt-4o-mini")
    }
    if getattr(call_data, "handleTelemarketingCalls", False):
        values["telemarketing_keywords"] = getattr(call_data, "telemarketingKeywords", "none")
    else:
        values["telemarketing_keywords"] = "none"
    
    # Replace both <<placeholder>> and {placeholder} formats
    for placeholder, value in values.items():
        prompt = prompt.replace(f"<<{placeholder}>>", str(value))
        prompt = prompt.replace(f"{{{placeholder}}}", str(value))
    
    return prompt
