from fastapi import APIRouter

from logger import get_logger
from models.request_models import IntentAnalyserRequest
from service.chat_analyser_service import chat_intent_analyser as chat_intent_analyser_service

router = APIRouter()

logger = get_logger(__name__)


@router.post("/intent_analyser", tags=["Chat Analyser"])
def chat_intent_analyser(intent_analyser_req: IntentAnalyserRequest):
    try:
        logger.info("chat_intent_analyser controller called")
        return chat_intent_analyser_service(intent_analyser_req)
    except Exception as e:
        logger.error(f"Error in chat_intent_analyser controller, {e}, exc_info=True")
        # todo raise Exception kaunsa karna idhar?
