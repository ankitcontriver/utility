voices = {
    'Afrikaans': {
        'text-lang-code': 'af',
        'voice-codes': [
            {'name': 'Afrikaans South Africa Female', 'gender': 'Female', 'code': 'af-ZA-AdriNeural'},
            {'name': 'Afrikaans South Africa Male', 'gender': 'Male', 'code': 'af-ZA-WillemNeural'}
        ]
    },
    'Amharic': {
        'text-lang-code': 'am',
        'voice-codes': [
            {'name': 'Amharic Ethiopia Female', 'gender': 'Female', 'code': 'am-ET-MekdesNeural'},
            {'name': 'Amharic Ethiopia Male', 'gender': 'Male', 'code': 'am-ET-AmehaNeural'}
        ]
    },
    'Arabic': {
        'text-lang-code': 'ar',
        'voice-codes': [
            {'name': 'Arabic United Arab Emirates Female', 'gender': 'Female', 'code': 'ar-AE-FatimaNeural'},
            {'name': 'Arabic United Arab Emirates Male', 'gender': 'Male', 'code': 'ar-AE-HamdanNeural'},
            {'name': 'Arabic Bahrain Female', 'gender': 'Female', 'code': 'ar-BH-LailaNeural'},
            {'name': 'Arabic Bahrain Male', 'gender': 'Male', 'code': 'ar-BH-AliNeural'},
            {'name': 'Arabic Algeria Female', 'gender': 'Female', 'code': 'ar-DZ-AminaNeural'},
            {'name': 'Arabic Algeria Male', 'gender': 'Male', 'code': 'ar-DZ-IsmaelNeural'},
            {'name': 'Arabic Egypt Female', 'gender': 'Female', 'code': 'ar-EG-SalmaNeural'},
            {'name': 'Arabic Egypt Male', 'gender': 'Male', 'code': 'ar-EG-ShakirNeural'},
            {'name': 'Arabic Iraq Female', 'gender': 'Female', 'code': 'ar-IQ-RanaNeural'},
            {'name': 'Arabic Iraq Male', 'gender': 'Male', 'code': 'ar-IQ-BasselNeural'},
            {'name': 'Arabic Jordan Female', 'gender': 'Female', 'code': 'ar-JO-SanaNeural'},
            {'name': 'Arabic Jordan Male', 'gender': 'Male', 'code': 'ar-JO-TaimNeural'},
            {'name': 'Arabic Kuwait Female', 'gender': 'Female', 'code': 'ar-KW-NouraNeural'},
            {'name': 'Arabic Kuwait Male', 'gender': 'Male', 'code': 'ar-KW-FahedNeural'},
            {'name': 'Arabic Lebanon Female', 'gender': 'Female', 'code': 'ar-LB-LaylaNeural'},
            {'name': 'Arabic Lebanon Male', 'gender': 'Male', 'code': 'ar-LB-RamiNeural'},
            {'name': 'Arabic Libya Female', 'gender': 'Female', 'code': 'ar-LY-ImanNeural'},
            {'name': 'Arabic Libya Male', 'gender': 'Male', 'code': 'ar-LY-OmarNeural'},
            {'name': 'Arabic Morocco Female', 'gender': 'Female', 'code': 'ar-MA-MounaNeural'},
            {'name': 'Arabic Morocco Male', 'gender': 'Male', 'code': 'ar-MA-JamalNeural'},
            {'name': 'Arabic Oman Female', 'gender': 'Female', 'code': 'ar-OM-AyshaNeural'},
            {'name': 'Arabic Oman Male', 'gender': 'Male', 'code': 'ar-OM-AbdullahNeural'},
            {'name': 'Arabic Qatar Female', 'gender': 'Female', 'code': 'ar-QA-AmalNeural'},
            {'name': 'Arabic Qatar Male', 'gender': 'Male', 'code': 'ar-QA-MoazNeural'},
            {'name': 'Arabic Saudi Arabia Female', 'gender': 'Female', 'code': 'ar-SA-ZariyahNeural'},
            {'name': 'Arabic Saudi Arabia Male', 'gender': 'Male', 'code': 'ar-SA-HamedNeural'},
            {'name': 'Arabic Syria Female', 'gender': 'Female', 'code': 'ar-SY-AmanyNeural'},
            {'name': 'Arabic Syria Male', 'gender': 'Male', 'code': 'ar-SY-LaithNeural'},
            {'name': 'Arabic Tunisia Female', 'gender': 'Female', 'code': 'ar-TN-ReemNeural'},
            {'name': 'Arabic Tunisia Male', 'gender': 'Male', 'code': 'ar-TN-HediNeural'},
            {'name': 'Arabic Yemen Female', 'gender': 'Female', 'code': 'ar-YE-MaryamNeural'},
            {'name': 'Arabic Yemen Male', 'gender': 'Male', 'code': 'ar-YE-SalehNeural'},
            {'name': 'Arabic Female 1', 'gender': 'Female', 'code': 'ar-XA-Wavenet-A'},
            {'name': 'Arabic Male 1', 'gender': 'Male', 'code': 'ar-XA-Wavenet-B'},
            {'name': 'Arabic Male 2', 'gender': 'Male', 'code': 'ar-XA-Wavenet-C'},
            {'name': 'Arabic Female 2', 'gender': 'Female', 'code': 'ar-XA-Wavenet-D'}
        ]
    },
    'Azerbaijani': {
        'text-lang-code': 'az',
        'voice-codes': [
            {'name': 'Azerbaijani Latin, Azerbaijan Female', 'gender': 'Female', 'code': 'az-AZ-BanuNeural'},
            {'name': 'Azerbaijani Latin, Azerbaijan Male', 'gender': 'Male', 'code': 'az-AZ-BabekNeural'}
        ]
    },
    'Bulgarian': {
        'text-lang-code': 'bg',
        'voice-codes': [
            {'name': 'Bulgarian Bulgaria Female', 'gender': 'Female', 'code': 'bg-BG-KalinaNeural'},
            {'name': 'Bulgarian Bulgaria Male', 'gender': 'Male', 'code': 'bg-BG-BorislavNeural'}
        ]
    },
    'Bangla': {
        'text-lang-code': 'bn',
        'voice-codes': [
            {'name': 'Bangla Bangladesh Female', 'gender': 'Female', 'code': 'bn-BD-NabanitaNeural'},
            {'name': 'Bangla Bangladesh Male', 'gender': 'Male', 'code': 'bn-BD-PradeepNeural'}
        ]
    },
    'Bengali': {
        'text-lang-code': 'bn',
        'voice-codes': [
            {'name': 'Bengali India Female 1', 'gender': 'Female', 'code': 'bn-IN-TanishaaNeural'},
            {'name': 'Bengali India Male 1', 'gender': 'Male', 'code': 'bn-IN-BashkarNeural'},
            {'name': 'Bengali India Female 2', 'gender': 'Female', 'code': 'bn-IN-Wavenet-A'},
            {'name': 'Bengali India Male 2', 'gender': 'Male', 'code': 'bn-IN-Wavenet-B'},
            {'name': 'Bengali India Female 3', 'gender': 'Female', 'code': 'bn-IN-Wavenet-C'},
            {'name': 'Bengali India Male 3', 'gender': 'Male', 'code': 'bn-IN-Wavenet-D'}
        ]
    },
    'Bosnian': {
        'text-lang-code': 'bs',
        'voice-codes': [
            {'name': 'Bosnian Bosnia and Herzegovina Female', 'gender': 'Female', 'code': 'bs-BA-VesnaNeural'},
            {'name': 'Bosnian Bosnia and Herzegovina Male', 'gender': 'Male', 'code': 'bs-BA-GoranNeural'}
        ]
    },
    'Catalan': {
        'text-lang-code': 'ca',
        'voice-codes': [
            {'name': 'Catalan General Female 1', 'gender': 'Female', 'code': 'ca-ES-JoanaNeural'},
            {'name': 'Catalan General Male', 'gender': 'Male', 'code': 'ca-ES-EnricNeural'},
            {'name': 'Catalan General Female 2', 'gender': 'Female', 'code': 'ca-ES-AlbaNeural'}
        ]
    },
    'Czech': {
        'text-lang-code': 'cs',
        'voice-codes': [
            {'name': 'Czech Czechia Female', 'gender': 'Female', 'code': 'cs-CZ-VlastaNeural'},
            {'name': 'Czech Czechia Male', 'gender': 'Male', 'code': 'cs-CZ-AntoninNeural'},
            {'name': 'Czech Czech Republic Female', 'gender': 'Female', 'code': 'cs-CZ-Wavenet-A'}
        ]
    },
    'Welsh': {
        'text-lang-code': 'cy',
        'voice-codes': [
            {'name': 'Welsh United Kingdom Female', 'gender': 'Female', 'code': 'cy-GB-NiaNeural'},
            {'name': 'Welsh United Kingdom Male', 'gender': 'Male', 'code': 'cy-GB-AledNeural'}
        ]
    },
    'Danish': {
        'text-lang-code': 'da',
        'voice-codes': [
            {'name': 'Danish Denmark Female 1', 'gender': 'Female', 'code': 'da-DK-ChristelNeural'},
            {'name': 'Danish Denmark Male 1', 'gender': 'Male', 'code': 'da-DK-JeppeNeural'},
            {'name': 'Danish Denmark Female 2', 'gender': 'Female', 'code': 'da-DK-Neural2-D'},
            {'name': 'Danish Denmark Female 3', 'gender': 'Female', 'code': 'da-DK-Wavenet-A'},
            {'name': 'Danish Denmark Male 2', 'gender': 'Male', 'code': 'da-DK-Wavenet-C'},
            {'name': 'Danish Denmark Female 4', 'gender': 'Female', 'code': 'da-DK-Wavenet-D'},
            {'name': 'Danish Denmark Female 5', 'gender': 'Female', 'code': 'da-DK-Wavenet-E'}
        ]
    },
    'German': {
        'text-lang-code': 'de',
        'voice-codes': [
            {'name': 'German Austria Female', 'gender': 'Female', 'code': 'de-AT-IngridNeural'},
            {'name': 'German Austria Male', 'gender': 'Male', 'code': 'de-AT-JonasNeural'},
            {'name': 'German Switzerland Female', 'gender': 'Female', 'code': 'de-CH-LeniNeural'},
            {'name': 'German Switzerland Male', 'gender': 'Male', 'code': 'de-CH-JanNeural'},
            {'name': 'German Germany Female 1', 'gender': 'Female', 'code': 'de-DE-KatjaNeural'},
            {'name': 'German Germany Male 1', 'gender': 'Male', 'code': 'de-DE-ConradNeural'},
            {'name': 'German Germany Female 2', 'gender': 'Female', 'code': 'de-DE-AmalaNeural'},
            {'name': 'German Germany Male 2', 'gender': 'Male', 'code': 'de-DE-BerndNeural'},
            {'name': 'German Germany Male 3', 'gender': 'Male', 'code': 'de-DE-ChristophNeural'},
            {'name': 'German Germany Female 3', 'gender': 'Female', 'code': 'de-DE-ElkeNeural'},
            {'name': 'German Germany Female 4,', 'gender': 'Female,', 'code': 'de-DE-GiselaNeural'},
            {'name': 'German Germany Male 4', 'gender': 'Male', 'code': 'de-DE-KasperNeural'},
            {'name': 'German Germany Male 5', 'gender': 'Male', 'code': 'de-DE-KillianNeural'},
            {'name': 'German Germany Female 5', 'gender': 'Female', 'code': 'de-DE-KlarissaNeural'},
            {'name': 'German Germany Male 6', 'gender': 'Male', 'code': 'de-DE-KlausNeural'},
            {'name': 'German Germany Female 6', 'gender': 'Female', 'code': 'de-DE-LouisaNeural'},
            {'name': 'German Germany Female 7', 'gender': 'Female', 'code': 'de-DE-MajaNeural'},
            {'name': 'German Germany Male 7', 'gender': 'Male', 'code': 'de-DE-RalfNeural'},
            {'name': 'German Germany Female 8', 'gender': 'Female', 'code': 'de-DE-TanjaNeural'},
            {'name': 'German Germany Male 8', 'gender': 'Male', 'code': 'de-DE-FlorianMultilingualNeural'},
            {'name': 'German Germany Female 9', 'gender': 'Female', 'code': 'de-DE-SeraphinaMultilingualNeural'},
            {'name': 'German Germany Female 10', 'gender': 'Female', 'code': 'de-DE-Neural2-A'},
            {'name': 'German Germany Male 9', 'gender': 'Male', 'code': 'de-DE-Neural2-B'},
            {'name': 'German Germany Female 11', 'gender': 'Female', 'code': 'de-DE-Neural2-C'},
            {'name': 'German Germany Male 10', 'gender': 'Male', 'code': 'de-DE-Neural2-D'},
            {'name': 'German Germany Female 12', 'gender': 'Female', 'code': 'de-DE-Neural2-F'},
            {'name': 'German Germany Male 11', 'gender': 'Male', 'code': 'de-DE-Polyglot-1'},
            {'name': 'German Germany Female 13', 'gender': 'Female', 'code': 'de-DE-Wavenet-A'},
            {'name': 'German Germany Male 12', 'gender': 'Male', 'code': 'de-DE-Wavenet-B'},
            {'name': 'German Germany Female 14', 'gender': 'Female', 'code': 'de-DE-Wavenet-C'},
            {'name': 'German Germany Male 13', 'gender': 'Male', 'code': 'de-DE-Wavenet-D'},
            {'name': 'German Germany Male 14', 'gender': 'Male', 'code': 'de-DE-Wavenet-E'},
            {'name': 'German Germany Female 15', 'gender': 'Female', 'code': 'de-DE-Wavenet-F'}
        ]
    },
    'Greek': {
        'text-lang-code': 'el',
        'voice-codes': [
            {'name': 'Greek Greece Female 1', 'gender': 'Female', 'code': 'el-GR-AthinaNeural'},
            {'name': 'Greek Greece Male', 'gender': 'Male', 'code': 'el-GR-NestorasNeural'},
            {'name': 'Greek Greece Female 2', 'gender': 'Female', 'code': 'el-GR-Wavenet-A'}
        ]
    },
    'English': {
        'text-lang-code': 'en',
        'voice-codes': [
            {'name': 'English Australia Female 1', 'gender': 'Female', 'code': 'en-AU-NatashaNeural'},
            {'name': 'English Australia Male 1', 'gender': 'Male', 'code': 'en-AU-WilliamNeural'},
            {'name': 'English Australia Female 2', 'gender': 'Female', 'code': 'en-AU-AnnetteNeural'},
            {'name': 'English Australia Female 3', 'gender': 'Female', 'code': 'en-AU-CarlyNeural'},
            {'name': 'English Australia Male 2', 'gender': 'Male', 'code': 'en-AU-DarrenNeural'},
            {'name': 'English Australia Male 3', 'gender': 'Male', 'code': 'en-AU-DuncanNeural'},
            {'name': 'English Australia Female 4', 'gender': 'Female', 'code': 'en-AU-ElsieNeural'},
            {'name': 'English Australia Female 5', 'gender': 'Female', 'code': 'en-AU-FreyaNeural'},
            {'name': 'English Australia Female 6', 'gender': 'Female', 'code': 'en-AU-JoanneNeural'},
            {'name': 'English Australia Male 4', 'gender': 'Male', 'code': 'en-AU-KenNeural'},
            {'name': 'English Australia Female 7', 'gender': 'Female', 'code': 'en-AU-KimNeural'},
            {'name': 'English Australia Male 5', 'gender': 'Male', 'code': 'en-AU-NeilNeural'},
            {'name': 'English Australia Male 6', 'gender': 'Male', 'code': 'en-AU-TimNeural'},
            {'name': 'English Australia Female 8', 'gender': 'Female', 'code': 'en-AU-TinaNeural'},
            {'name': 'English Canada Female', 'gender': 'Female', 'code': 'en-CA-ClaraNeural'},
            {'name': 'English Canada Male', 'gender': 'Male', 'code': 'en-CA-LiamNeural'},
            {'name': 'English United Kingdom Female 1', 'gender': 'Female', 'code': 'en-GB-SoniaNeural'},
            {'name': 'English United Kingdom Male 1', 'gender': 'Male', 'code': 'en-GB-RyanNeural'},
            {'name': 'English United Kingdom Female 2', 'gender': 'Female', 'code': 'en-GB-LibbyNeural'},
            {'name': 'English United Kingdom Female 3', 'gender': 'Female', 'code': 'en-GB-AbbiNeural'},
            {'name': 'English United Kingdom Male 2', 'gender': 'Male', 'code': 'en-GB-AlfieNeural'},
            {'name': 'English United Kingdom Female 4', 'gender': 'Female', 'code': 'en-GB-BellaNeural'},
            {'name': 'English United Kingdom Male 3', 'gender': 'Male', 'code': 'en-GB-ElliotNeural'},
            {'name': 'English United Kingdom Male 4', 'gender': 'Male', 'code': 'en-GB-EthanNeural'},
            {'name': 'English United Kingdom Female 5', 'gender': 'Female', 'code': 'en-GB-HollieNeural'},
            {'name': 'English United Kingdom Female 6,', 'gender': 'Female,', 'code': 'en-GB-MaisieNeural'},
            {'name': 'English United Kingdom Male 5', 'gender': 'Male', 'code': 'en-GB-NoahNeural'},
            {'name': 'English United Kingdom Male 6', 'gender': 'Male', 'code': 'en-GB-OliverNeural'},
            {'name': 'English United Kingdom Female 7', 'gender': 'Female', 'code': 'en-GB-OliviaNeural'},
            {'name': 'English United Kingdom Male 7', 'gender': 'Male', 'code': 'en-GB-ThomasNeural'},
            {'name': 'English Hong Kong SAR Female', 'gender': 'Female', 'code': 'en-HK-YanNeural'},
            {'name': 'English Hong Kong SAR Male', 'gender': 'Male', 'code': 'en-HK-SamNeural'},
            {'name': 'English Ireland Female', 'gender': 'Female', 'code': 'en-IE-EmilyNeural'},
            {'name': 'English Ireland Male', 'gender': 'Male', 'code': 'en-IE-ConnorNeural'},
            {'name': 'English India Female 1', 'gender': 'Female', 'code': 'en-IN-NeerjaNeural'},
            {'name': 'English India Male 1', 'gender': 'Male', 'code': 'en-IN-PrabhatNeural'},
            {'name': 'English Kenya Female', 'gender': 'Female', 'code': 'en-KE-AsiliaNeural'},
            {'name': 'English Kenya Male', 'gender': 'Male', 'code': 'en-KE-ChilembaNeural'},
            {'name': 'English Nigeria Female', 'gender': 'Female', 'code': 'en-NG-EzinneNeural'},
            {'name': 'English Nigeria Male', 'gender': 'Male', 'code': 'en-NG-AbeoNeural'},
            {'name': 'English New Zealand Female', 'gender': 'Female', 'code': 'en-NZ-MollyNeural'},
            {'name': 'English New Zealand Male', 'gender': 'Male', 'code': 'en-NZ-MitchellNeural'},
            {'name': 'English Philippines Female', 'gender': 'Female', 'code': 'en-PH-RosaNeural'},
            {'name': 'English Philippines Male', 'gender': 'Male', 'code': 'en-PH-JamesNeural'},
            {'name': 'English Singapore Female', 'gender': 'Female', 'code': 'en-SG-LunaNeural'},
            {'name': 'English Singapore Male', 'gender': 'Male', 'code': 'en-SG-WayneNeural'},
            {'name': 'English Tanzania Female', 'gender': 'Female', 'code': 'en-TZ-ImaniNeural'},
            {'name': 'English Tanzania Male', 'gender': 'Male', 'code': 'en-TZ-ElimuNeural'},
            {'name': 'English United States Female 1', 'gender': 'Female', 'code': 'en-US-AvaNeural'},
            {'name': 'English United States Male 1', 'gender': 'Male', 'code': 'en-US-AndrewNeural'},
            {'name': 'English United States Female 2', 'gender': 'Female', 'code': 'en-US-EmmaNeural'},
            {'name': 'English United States Male 2', 'gender': 'Male', 'code': 'en-US-BrianNeural'},
            {'name': 'English United States Female 3', 'gender': 'Female', 'code': 'en-US-JennyNeural'},
            {'name': 'English United States Male 3', 'gender': 'Male', 'code': 'en-US-GuyNeural'},
            {'name': 'English United States Female 4', 'gender': 'Female', 'code': 'en-US-AriaNeural'},
            {'name': 'English United States Male 4', 'gender': 'Male', 'code': 'en-US-DavisNeural'},
            {'name': 'English United States Female 5', 'gender': 'Female', 'code': 'en-US-JaneNeural'},
            {'name': 'English United States Male 5', 'gender': 'Male', 'code': 'en-US-JasonNeural'},
            {'name': 'English United States Female 6', 'gender': 'Female', 'code': 'en-US-SaraNeural'},
            {'name': 'English United States Male 6', 'gender': 'Male', 'code': 'en-US-TonyNeural'},
            {'name': 'English United States Female 7', 'gender': 'Female', 'code': 'en-US-NancyNeural'},
            {'name': 'English United States Female 8', 'gender': 'Female', 'code': 'en-US-AmberNeural'},
            {'name': 'English United States Female 9,', 'gender': 'Female,', 'code': 'en-US-AnaNeural'},
            {'name': 'English United States Female 10', 'gender': 'Female', 'code': 'en-US-AshleyNeural'},
            {'name': 'English United States Male 7', 'gender': 'Male', 'code': 'en-US-BrandonNeural'},
            {'name': 'English United States Male 8', 'gender': 'Male', 'code': 'en-US-ChristopherNeural'},
            {'name': 'English United States Female 11', 'gender': 'Female', 'code': 'en-US-CoraNeural'},
            {'name': 'English United States Female 12', 'gender': 'Female', 'code': 'en-US-ElizabethNeural'},
            {'name': 'English United States Male 9', 'gender': 'Male', 'code': 'en-US-EricNeural'},
            {'name': 'English United States Male 10', 'gender': 'Male', 'code': 'en-US-JacobNeural'},
            {'name': 'English United States Female 13', 'gender': 'Female', 'code': 'en-US-JennyMultilingualNeural'},
            {'name': 'English United States Female 14', 'gender': 'Female', 'code': 'en-US-MichelleNeural'},
            {'name': 'English United States Female 15', 'gender': 'Female', 'code': 'en-US-MonicaNeural'},
            {'name': 'English United States Male 11', 'gender': 'Male', 'code': 'en-US-RogerNeural'},
            {'name': 'English United States Male 12', 'gender': 'Male', 'code': 'en-US-RyanMultilingualNeural'},
            {'name': 'English United States Male 13', 'gender': 'Male', 'code': 'en-US-SteffanNeural'},
            {'name': 'English United States Male 14', 'gender': 'Male', 'code': 'en-US-AIGenerate1Neural'},
            {'name': 'English United States Female 16', 'gender': 'Female', 'code': 'en-US-AIGenerate2Neural'},
            {'name': 'English United States Male 15', 'gender': 'Male', 'code': 'en-US-AndrewMultilingualNeural'},
            {'name': 'English United States Female 17', 'gender': 'Female', 'code': 'en-US-AvaMultilingualNeural'},
            {'name': 'English United States Neutral', 'gender': 'Neutral', 'code': 'en-US-BlueNeural'},
            {'name': 'English United States Male 16', 'gender': 'Male', 'code': 'en-US-BrianMultilingualNeural'},
            {'name': 'English United States Female 18', 'gender': 'Female', 'code': 'en-US-EmmaMultilingualNeural'},
            {'name': 'English United States Male 17', 'gender': 'Male', 'code': 'en-US-AlloyMultilingualNeural'},
            {'name': 'English United States Male 18', 'gender': 'Male', 'code': 'en-US-EchoMultilingualNeural'},
            {'name': 'English United States Neutral', 'gender': 'Neutral', 'code': 'en-US-FableMultilingualNeural'},
            {'name': 'English United States Male 19', 'gender': 'Male', 'code': 'en-US-OnyxMultilingualNeural'},
            {'name': 'English United States Female 19', 'gender': 'Female', 'code': 'en-US-NovaMultilingualNeural'},
            {'name': 'English United States Female 20', 'gender': 'Female', 'code': 'en-US-ShimmerMultilingualNeural'},
            {'name': 'English United States Male 20', 'gender': 'Male', 'code': 'en-US-AlloyMultilingualNeuralHD'},
            {'name': 'English United States Male 21', 'gender': 'Male', 'code': 'en-US-EchoMultilingualNeuralHD'},
            {'name': 'English United States Neutral', 'gender': 'Neutral', 'code': 'en-US-FableMultilingualNeuralHD'},
            {'name': 'English United States Male 22', 'gender': 'Male', 'code': 'en-US-OnyxMultilingualNeuralHD'},
            {'name': 'English United States Female 21', 'gender': 'Female', 'code': 'en-US-NovaMultilingualNeuralHD'},
            {'name': 'English United States Female 22', 'gender': 'Female', 'code': 'en-US-ShimmerMultilingualNeuralHD'},
            {'name': 'English South Africa Female', 'gender': 'Female', 'code': 'en-ZA-LeahNeural'},
            {'name': 'English South Africa Male', 'gender': 'Male', 'code': 'en-ZA-LukeNeural'},
            {'name': 'English Australia Female 9', 'gender': 'Female', 'code': 'en-AU-Neural2-A'},
            {'name': 'English Australia Male 7', 'gender': 'Male', 'code': 'en-AU-Neural2-B'},
            {'name': 'English Australia Female 10', 'gender': 'Female', 'code': 'en-AU-Neural2-C'},
            {'name': 'English Australia Male 8', 'gender': 'Male', 'code': 'en-AU-Neural2-D'},
            {'name': 'English Australia Female 11', 'gender': 'Female', 'code': 'en-AU-News-E'},
            {'name': 'English Australia Female 12', 'gender': 'Female', 'code': 'en-AU-News-F'},
            {'name': 'English Australia Male 9', 'gender': 'Male', 'code': 'en-AU-News-G'},
            {'name': 'English Australia Male 10', 'gender': 'Male', 'code': 'en-AU-Polyglot-1'},
            {'name': 'English Australia Female 13', 'gender': 'Female', 'code': 'en-AU-Wavenet-A'},
            {'name': 'English Australia Male 11', 'gender': 'Male', 'code': 'en-AU-Wavenet-B'},
            {'name': 'English Australia Female 14', 'gender': 'Female', 'code': 'en-AU-Wavenet-C'},
            {'name': 'English Australia Male 12', 'gender': 'Male', 'code': 'en-AU-Wavenet-D'},
            {'name': 'English India Female 2', 'gender': 'Female', 'code': 'en-IN-Neural2-A'},
            {'name': 'English India Male 2', 'gender': 'Male', 'code': 'en-IN-Neural2-B'},
            {'name': 'English India Male 3', 'gender': 'Male', 'code': 'en-IN-Neural2-C'},
            {'name': 'English India Female 3', 'gender': 'Female', 'code': 'en-IN-Neural2-D'},
            {'name': 'English India Female 4', 'gender': 'Female', 'code': 'en-IN-Wavenet-A'},
            {'name': 'English India Male 4', 'gender': 'Male', 'code': 'en-IN-Wavenet-B'},
            {'name': 'English India Male 5', 'gender': 'Male', 'code': 'en-IN-Wavenet-C'},
            {'name': 'English India Female 5', 'gender': 'Female', 'code': 'en-IN-Wavenet-D'},
            {'name': 'English UK Female 1', 'gender': 'Female', 'code': 'en-GB-Neural2-A'},
            {'name': 'English UK Male 1', 'gender': 'Male', 'code': 'en-GB-Neural2-B'},
            {'name': 'English UK Female 2', 'gender': 'Female', 'code': 'en-GB-Neural2-C'},
            {'name': 'English UK Male 2', 'gender': 'Male', 'code': 'en-GB-Neural2-D'},
            {'name': 'English UK Female 3', 'gender': 'Female', 'code': 'en-GB-Neural2-F'},
            {'name': 'English UK Female 4', 'gender': 'Female', 'code': 'en-GB-News-G'},
            {'name': 'English UK Female 5', 'gender': 'Female', 'code': 'en-GB-News-H'},
            {'name': 'English UK Female 6', 'gender': 'Female', 'code': 'en-GB-News-I'},
            {'name': 'English UK Male 3', 'gender': 'Male', 'code': 'en-GB-News-J'},
            {'name': 'English UK Male 4', 'gender': 'Male', 'code': 'en-GB-News-K'},
            {'name': 'English UK Male 5', 'gender': 'Male', 'code': 'en-GB-News-L'},
            {'name': 'English UK Male 6', 'gender': 'Male', 'code': 'en-GB-News-M'},
            {'name': 'English UK Female 7', 'gender': 'Female', 'code': 'en-GB-Wavenet-A'},
            {'name': 'English UK Male 7', 'gender': 'Male', 'code': 'en-GB-Wavenet-B'},
            {'name': 'English UK Female 8', 'gender': 'Female', 'code': 'en-GB-Wavenet-C'},
            {'name': 'English UK Male 8', 'gender': 'Male', 'code': 'en-GB-Wavenet-D'},
            {'name': 'English UK Female 9', 'gender': 'Female', 'code': 'en-GB-Wavenet-F'},
            {'name': 'English US Male 1', 'gender': 'Male', 'code': 'en-US-Casual-K'},
            {'name': 'English US Male 2', 'gender': 'Male', 'code': 'en-US-Journey-D'},
            {'name': 'English US Female 1', 'gender': 'Female', 'code': 'en-US-Journey-F'},
            {'name': 'English US Female 2', 'gender': 'Female', 'code': 'en-US-Journey-O'},
            {'name': 'English US Male 3', 'gender': 'Male', 'code': 'en-US-Neural2-A'},
            {'name': 'English US Female 3', 'gender': 'Female', 'code': 'en-US-Neural2-C'},
            {'name': 'English US Male 4', 'gender': 'Male', 'code': 'en-US-Neural2-D'},
            {'name': 'English US Female 4', 'gender': 'Female', 'code': 'en-US-Neural2-E'},
            {'name': 'English US Female 5', 'gender': 'Female', 'code': 'en-US-Neural2-F'},
            {'name': 'English US Female 6', 'gender': 'Female', 'code': 'en-US-Neural2-G'},
            {'name': 'English US Female 7', 'gender': 'Female', 'code': 'en-US-Neural2-H'},
            {'name': 'English US Male 5', 'gender': 'Male', 'code': 'en-US-Neural2-I'},
            {'name': 'English US Male 6', 'gender': 'Male', 'code': 'en-US-Neural2-J'},
            {'name': 'English US Female 8', 'gender': 'Female', 'code': 'en-US-News-K'},
            {'name': 'English US Female 9', 'gender': 'Female', 'code': 'en-US-News-L'},
            {'name': 'English US Male 7', 'gender': 'Male', 'code': 'en-US-News-N'},
            {'name': 'English US Male 8', 'gender': 'Male', 'code': 'en-US-Polyglot-1'},
            {'name': 'English US Male 9', 'gender': 'Male', 'code': 'en-US-Wavenet-A'},
            {'name': 'English US Male 10', 'gender': 'Male', 'code': 'en-US-Wavenet-B'},
            {'name': 'English US Female 10', 'gender': 'Female', 'code': 'en-US-Wavenet-C'},
            {'name': 'English US Male 11', 'gender': 'Male', 'code': 'en-US-Wavenet-D'},
            {'name': 'English US Female 11', 'gender': 'Female', 'code': 'en-US-Wavenet-E'},
            {'name': 'English US Female 12', 'gender': 'Female', 'code': 'en-US-Wavenet-F'},
            {'name': 'English US Female 13', 'gender': 'Female', 'code': 'en-US-Wavenet-G'},
            {'name': 'English US Female 14', 'gender': 'Female', 'code': 'en-US-Wavenet-H'},
            {'name': 'English US Male 12', 'gender': 'Male', 'code': 'en-US-Wavenet-I'},
            {'name': 'English US Male 13', 'gender': 'Male', 'code': 'en-US-Wavenet-J'}
        ]
    },
    'Spanish': {
        'text-lang-code': 'es',
        'voice-codes': [
            {'name': 'Spanish Argentina Female', 'gender': 'Female', 'code': 'es-AR-ElenaNeural'},
            {'name': 'Spanish Argentina Male', 'gender': 'Male', 'code': 'es-AR-TomasNeural'},
            {'name': 'Spanish Bolivia Female', 'gender': 'Female', 'code': 'es-BO-SofiaNeural'},
            {'name': 'Spanish Bolivia Male', 'gender': 'Male', 'code': 'es-BO-MarceloNeural'},
            {'name': 'Spanish Chile Female', 'gender': 'Female', 'code': 'es-CL-CatalinaNeural'},
            {'name': 'Spanish Chile Male', 'gender': 'Male', 'code': 'es-CL-LorenzoNeural'},
            {'name': 'Spanish Colombia Female', 'gender': 'Female', 'code': 'es-CO-SalomeNeural'},
            {'name': 'Spanish Colombia Male', 'gender': 'Male', 'code': 'es-CO-GonzaloNeural'},
            {'name': 'Spanish Costa Rica Female', 'gender': 'Female', 'code': 'es-CR-MariaNeural'},
            {'name': 'Spanish Costa Rica Male', 'gender': 'Male', 'code': 'es-CR-JuanNeural'},
            {'name': 'Spanish Cuba Female', 'gender': 'Female', 'code': 'es-CU-BelkysNeural'},
            {'name': 'Spanish Cuba Male', 'gender': 'Male', 'code': 'es-CU-ManuelNeural'},
            {'name': 'Spanish Dominican Republic Female', 'gender': 'Female', 'code': 'es-DO-RamonaNeural'},
            {'name': 'Spanish Dominican Republic Male', 'gender': 'Male', 'code': 'es-DO-EmilioNeural'},
            {'name': 'Spanish Ecuador Female', 'gender': 'Female', 'code': 'es-EC-AndreaNeural'},
            {'name': 'Spanish Ecuador Male', 'gender': 'Male', 'code': 'es-EC-LuisNeural'},
            {'name': 'Spanish Spain Female 1', 'gender': 'Female', 'code': 'es-ES-ElviraNeural'},
            {'name': 'Spanish Spain Male 1', 'gender': 'Male', 'code': 'es-ES-AlvaroNeural'},
            {'name': 'Spanish Spain Female 2', 'gender': 'Female', 'code': 'es-ES-AbrilNeural'},
            {'name': 'Spanish Spain Male 2', 'gender': 'Male', 'code': 'es-ES-ArnauNeural'},
            {'name': 'Spanish Spain Male 3', 'gender': 'Male', 'code': 'es-ES-DarioNeural'},
            {'name': 'Spanish Spain Male 4', 'gender': 'Male', 'code': 'es-ES-EliasNeural'},
            {'name': 'Spanish Spain Female 3', 'gender': 'Female', 'code': 'es-ES-EstrellaNeural'},
            {'name': 'Spanish Spain Female 4', 'gender': 'Female', 'code': 'es-ES-IreneNeural'},
            {'name': 'Spanish Spain Female 5', 'gender': 'Female', 'code': 'es-ES-LaiaNeural'},
            {'name': 'Spanish Spain Female 6', 'gender': 'Female', 'code': 'es-ES-LiaNeural'},
            {'name': 'Spanish Spain Male 5', 'gender': 'Male', 'code': 'es-ES-NilNeural'},
            {'name': 'Spanish Spain Male 6', 'gender': 'Male', 'code': 'es-ES-SaulNeural'},
            {'name': 'Spanish Spain Male 7', 'gender': 'Male', 'code': 'es-ES-TeoNeural'},
            {'name': 'Spanish Spain Female 7', 'gender': 'Female', 'code': 'es-ES-TrianaNeural'},
            {'name': 'Spanish Spain Female 8', 'gender': 'Female', 'code': 'es-ES-VeraNeural'},
            {'name': 'Spanish Spain Female 9', 'gender': 'Female', 'code': 'es-ES-XimenaNeural'},
            {'name': 'Spanish Equatorial Guinea Female', 'gender': 'Female', 'code': 'es-GQ-TeresaNeural'},
            {'name': 'Spanish Equatorial Guinea Male', 'gender': 'Male', 'code': 'es-GQ-JavierNeural'},
            {'name': 'Spanish Guatemala Female', 'gender': 'Female', 'code': 'es-GT-MartaNeural'},
            {'name': 'Spanish Guatemala Male', 'gender': 'Male', 'code': 'es-GT-AndresNeural'},
            {'name': 'Spanish Honduras Female', 'gender': 'Female', 'code': 'es-HN-KarlaNeural'},
            {'name': 'Spanish Honduras Male', 'gender': 'Male', 'code': 'es-HN-CarlosNeural'},
            {'name': 'Spanish Mexico Female 1', 'gender': 'Female', 'code': 'es-MX-DaliaNeural'},
            {'name': 'Spanish Mexico Male 1', 'gender': 'Male', 'code': 'es-MX-JorgeNeural'},
            {'name': 'Spanish Mexico Female 2', 'gender': 'Female', 'code': 'es-MX-BeatrizNeural'},
            {'name': 'Spanish Mexico Female 3', 'gender': 'Female', 'code': 'es-MX-CandelaNeural'},
            {'name': 'Spanish Mexico Female 4', 'gender': 'Female', 'code': 'es-MX-CarlotaNeural'},
            {'name': 'Spanish Mexico Male 2', 'gender': 'Male', 'code': 'es-MX-CecilioNeural'},
            {'name': 'Spanish Mexico Male 3', 'gender': 'Male', 'code': 'es-MX-GerardoNeural'},
            {'name': 'Spanish Mexico Female 5', 'gender': 'Female', 'code': 'es-MX-LarissaNeural'},
            {'name': 'Spanish Mexico Male 4', 'gender': 'Male', 'code': 'es-MX-LibertoNeural'},
            {'name': 'Spanish Mexico Male 5', 'gender': 'Male', 'code': 'es-MX-LucianoNeural'},
            {'name': 'Spanish Mexico Female 6', 'gender': 'Female', 'code': 'es-MX-MarinaNeural'},
            {'name': 'Spanish Mexico Female 7', 'gender': 'Female', 'code': 'es-MX-NuriaNeural'},
            {'name': 'Spanish Mexico Male 6', 'gender': 'Male', 'code': 'es-MX-PelayoNeural'},
            {'name': 'Spanish Mexico Female 8', 'gender': 'Female', 'code': 'es-MX-RenataNeural'},
            {'name': 'Spanish Mexico Male 7', 'gender': 'Male', 'code': 'es-MX-YagoNeural'},
            {'name': 'Spanish Nicaragua Female', 'gender': 'Female', 'code': 'es-NI-YolandaNeural'},
            {'name': 'Spanish Nicaragua Male', 'gender': 'Male', 'code': 'es-NI-FedericoNeural'},
            {'name': 'Spanish Panama Female', 'gender': 'Female', 'code': 'es-PA-MargaritaNeural'},
            {'name': 'Spanish Panama Male', 'gender': 'Male', 'code': 'es-PA-RobertoNeural'},
            {'name': 'Spanish Peru Female', 'gender': 'Female', 'code': 'es-PE-CamilaNeural'},
            {'name': 'Spanish Peru Male', 'gender': 'Male', 'code': 'es-PE-AlexNeural'},
            {'name': 'Spanish Puerto Rico Female', 'gender': 'Female', 'code': 'es-PR-KarinaNeural'},
            {'name': 'Spanish Puerto Rico Male', 'gender': 'Male', 'code': 'es-PR-VictorNeural'},
            {'name': 'Spanish Paraguay Female', 'gender': 'Female', 'code': 'es-PY-TaniaNeural'},
            {'name': 'Spanish Paraguay Male', 'gender': 'Male', 'code': 'es-PY-MarioNeural'},
            {'name': 'Spanish El Salvador Female', 'gender': 'Female', 'code': 'es-SV-LorenaNeural'},
            {'name': 'Spanish El Salvador Male', 'gender': 'Male', 'code': 'es-SV-RodrigoNeural'},
            {'name': 'Spanish United States Female', 'gender': 'Female', 'code': 'es-US-PalomaNeural'},
            {'name': 'Spanish United States Male', 'gender': 'Male', 'code': 'es-US-AlonsoNeural'},
            {'name': 'Spanish Uruguay Female', 'gender': 'Female', 'code': 'es-UY-ValentinaNeural'},
            {'name': 'Spanish Uruguay Male', 'gender': 'Male', 'code': 'es-UY-MateoNeural'},
            {'name': 'Spanish Venezuela Female', 'gender': 'Female', 'code': 'es-VE-PaolaNeural'},
            {'name': 'Spanish Venezuela Male', 'gender': 'Male', 'code': 'es-VE-SebastianNeural'},
            {'name': 'Spanish Spain Female 10', 'gender': 'Female', 'code': 'es-ES-Neural2-A'},
            {'name': 'Spanish Spain Male 8', 'gender': 'Male', 'code': 'es-ES-Neural2-B'},
            {'name': 'Spanish Spain Female 11', 'gender': 'Female', 'code': 'es-ES-Neural2-C'},
            {'name': 'Spanish Spain Female 12', 'gender': 'Female', 'code': 'es-ES-Neural2-D'},
            {'name': 'Spanish Spain Female 13', 'gender': 'Female', 'code': 'es-ES-Neural2-E'},
            {'name': 'Spanish Spain Male 9', 'gender': 'Male', 'code': 'es-ES-Neural2-F'},
            {'name': 'Spanish Spain Male 10', 'gender': 'Male', 'code': 'es-ES-Polyglot-1'},
            {'name': 'Spanish Spain Male 11', 'gender': 'Male', 'code': 'es-ES-Wavenet-B'},
            {'name': 'Spanish Spain Female 14', 'gender': 'Female', 'code': 'es-ES-Wavenet-C'},
            {'name': 'Spanish Spain Female 15', 'gender': 'Female', 'code': 'es-ES-Wavenet-D'},
            {'name': 'Spanish US Female 1', 'gender': 'Female', 'code': 'es-US-Neural2-A'},
            {'name': 'Spanish US Male 1', 'gender': 'Male', 'code': 'es-US-Neural2-B'},
            {'name': 'Spanish US Male 2', 'gender': 'Male', 'code': 'es-US-Neural2-C'},
            {'name': 'Spanish US Male 3', 'gender': 'Male', 'code': 'es-US-News-D'},
            {'name': 'Spanish US Male 4', 'gender': 'Male', 'code': 'es-US-News-E'},
            {'name': 'Spanish US Female 2', 'gender': 'Female', 'code': 'es-US-News-F'},
            {'name': 'Spanish US Female 3', 'gender': 'Female', 'code': 'es-US-News-G'},
            {'name': 'Spanish US Male 5', 'gender': 'Male', 'code': 'es-US-Polyglot-1'},
            {'name': 'Spanish US Female 4', 'gender': 'Female', 'code': 'es-US-Wavenet-A'},
            {'name': 'Spanish US Male 6', 'gender': 'Male', 'code': 'es-US-Wavenet-B'},
            {'name': 'Spanish US Male 7', 'gender': 'Male', 'code': 'es-US-Wavenet-C'}
        ]
    },
    'Estonian': {
        'text-lang-code': 'et',
        'voice-codes': [
            {'name': 'Estonian Estonia Female', 'gender': 'Female', 'code': 'et-EE-AnuNeural'},
            {'name': 'Estonian Estonia Male', 'gender': 'Male', 'code': 'et-EE-KertNeural'}
        ]
    },
    'Basque': {
        'text-lang-code': 'eu',
        'voice-codes': [
            {'name': 'Basque General Female', 'gender': 'Female', 'code': 'eu-ES-AinhoaNeural'},
            {'name': 'Basque General Male', 'gender': 'Male', 'code': 'eu-ES-AnderNeural'}
        ]
    },
    'Persian': {
        'text-lang-code': 'fa',
        'voice-codes': [
            {'name': 'Persian Iran Female', 'gender': 'Female', 'code': 'fa-IR-DilaraNeural'},
            {'name': 'Persian Iran Male', 'gender': 'Male', 'code': 'fa-IR-FaridNeural'}
        ]
    },
    'Finnish': {
        'text-lang-code': 'fi',
        'voice-codes': [
            {'name': 'Finnish Finland Female 1', 'gender': 'Female', 'code': 'fi-FI-SelmaNeural'},
            {'name': 'Finnish Finland Male', 'gender': 'Male', 'code': 'fi-FI-HarriNeural'},
            {'name': 'Finnish Finland Female 2', 'gender': 'Female', 'code': 'fi-FI-NooraNeural'},
            {'name': 'Finnish Finland Female 3', 'gender': 'Female', 'code': 'fi-FI-Wavenet-A'}
        ]
    },
    'Filipino': {
        'text-lang-code': 'fil',
        'voice-codes': [
            {'name': 'Filipino Philippines Female 1', 'gender': 'Female', 'code': 'fil-PH-BlessicaNeural'},
            {'name': 'Filipino Philippines Male 1', 'gender': 'Male', 'code': 'fil-PH-AngeloNeural'},
            {'name': 'Filipino Philippines Female 2', 'gender': 'Female', 'code': 'fil-PH-Wavenet-A'},
            {'name': 'Filipino Philippines Female 3', 'gender': 'Female', 'code': 'fil-PH-Wavenet-B'},
            {'name': 'Filipino Philippines Male 2', 'gender': 'Male', 'code': 'fil-PH-Wavenet-C'},
            {'name': 'Filipino Philippines Male 3', 'gender': 'Male', 'code': 'fil-PH-Wavenet-D'},
            {'name': 'Filipino Philippines Female 4', 'gender': 'Female', 'code': 'fil-ph-Neural2-A'},
            {'name': 'Filipino Philippines Male 4', 'gender': 'Male', 'code': 'fil-ph-Neural2-D'}
        ]
    },
    'French': {
        'text-lang-code': 'fr',
        'voice-codes': [
            {'name': 'French Belgium Female', 'gender': 'Female', 'code': 'fr-BE-CharlineNeural'},
            {'name': 'French Belgium Male', 'gender': 'Male', 'code': 'fr-BE-GerardNeural'},
            {'name': 'French Canada Female 1', 'gender': 'Female', 'code': 'fr-CA-SylvieNeural'},
            {'name': 'French Canada Male 1', 'gender': 'Male', 'code': 'fr-CA-JeanNeural'},
            {'name': 'French Canada Male 2', 'gender': 'Male', 'code': 'fr-CA-AntoineNeural'},
            {'name': 'French Canada Male 3', 'gender': 'Male', 'code': 'fr-CA-ThierryNeural'},
            {'name': 'French Switzerland Female', 'gender': 'Female', 'code': 'fr-CH-ArianeNeural'},
            {'name': 'French Switzerland Male', 'gender': 'Male', 'code': 'fr-CH-FabriceNeural'},
            {'name': 'French France Female 1', 'gender': 'Female', 'code': 'fr-FR-DeniseNeural'},
            {'name': 'French France Male 1', 'gender': 'Male', 'code': 'fr-FR-HenriNeural'},
            {'name': 'French France Male 2', 'gender': 'Male', 'code': 'fr-FR-AlainNeural'},
            {'name': 'French France Female 2', 'gender': 'Female', 'code': 'fr-FR-BrigitteNeural'},
            {'name': 'French France Female 3', 'gender': 'Female', 'code': 'fr-FR-CelesteNeural'},
            {'name': 'French France Male 3', 'gender': 'Male', 'code': 'fr-FR-ClaudeNeural'},
            {'name': 'French France Female 4', 'gender': 'Female', 'code': 'fr-FR-CoralieNeural'},
            {'name': 'French France Female 5,', 'gender': 'Female,', 'code': 'fr-FR-EloiseNeural'},
            {'name': 'French France Female 6', 'gender': 'Female', 'code': 'fr-FR-JacquelineNeural'},
            {'name': 'French France Male 4', 'gender': 'Male', 'code': 'fr-FR-JeromeNeural'},
            {'name': 'French France Female 7', 'gender': 'Female', 'code': 'fr-FR-JosephineNeural'},
            {'name': 'French France Male 5', 'gender': 'Male', 'code': 'fr-FR-MauriceNeural'},
            {'name': 'French France Male 6', 'gender': 'Male', 'code': 'fr-FR-YvesNeural'},
            {'name': 'French France Female 8', 'gender': 'Female', 'code': 'fr-FR-YvetteNeural'},
            {'name': 'French France Male 7', 'gender': 'Male', 'code': 'fr-FR-RemyMultilingualNeural'},
            {'name': 'French France Female 9', 'gender': 'Female', 'code': 'fr-FR-VivienneMultilingualNeural'},
            {'name': 'French Canada Female 2', 'gender': 'Female', 'code': 'fr-CA-Neural2-A'},
            {'name': 'French Canada Male 4', 'gender': 'Male', 'code': 'fr-CA-Neural2-B'},
            {'name': 'French Canada Female 3', 'gender': 'Female', 'code': 'fr-CA-Neural2-C'},
            {'name': 'French Canada Male 5', 'gender': 'Male', 'code': 'fr-CA-Neural2-D'},
            {'name': 'French Canada Female 4', 'gender': 'Female', 'code': 'fr-CA-Wavenet-A'},
            {'name': 'French Canada Male 6', 'gender': 'Male', 'code': 'fr-CA-Wavenet-B'},
            {'name': 'French Canada Female 5', 'gender': 'Female', 'code': 'fr-CA-Wavenet-C'},
            {'name': 'French Canada Male 7', 'gender': 'Male', 'code': 'fr-CA-Wavenet-D'},
            {'name': 'French France Female 10', 'gender': 'Female', 'code': 'fr-FR-Neural2-A'},
            {'name': 'French France Male 8', 'gender': 'Male', 'code': 'fr-FR-Neural2-B'},
            {'name': 'French France Female 11', 'gender': 'Female', 'code': 'fr-FR-Neural2-C'},
            {'name': 'French France Male 9', 'gender': 'Male', 'code': 'fr-FR-Neural2-D'},
            {'name': 'French France Female 12', 'gender': 'Female', 'code': 'fr-FR-Neural2-E'},
            {'name': 'French France Male 10', 'gender': 'Male', 'code': 'fr-FR-Polyglot-1'},
            {'name': 'French France Female 13', 'gender': 'Female', 'code': 'fr-FR-Wavenet-A'},
            {'name': 'French France Male 11', 'gender': 'Male', 'code': 'fr-FR-Wavenet-B'},
            {'name': 'French France Female 14', 'gender': 'Female', 'code': 'fr-FR-Wavenet-C'},
            {'name': 'French France Male 12', 'gender': 'Male', 'code': 'fr-FR-Wavenet-D'},
            {'name': 'French France Female 15', 'gender': 'Female', 'code': 'fr-FR-Wavenet-E'}
        ]
    },
    'Irish': {
        'text-lang-code': 'ga',
        'voice-codes': [
            {'name': 'Irish Ireland Female', 'gender': 'Female', 'code': 'ga-IE-OrlaNeural'},
            {'name': 'Irish Ireland Male', 'gender': 'Male', 'code': 'ga-IE-ColmNeural'}
        ]
    },
    'Galician': {
        'text-lang-code': 'gl',
        'voice-codes': [
            {'name': 'Galician General Female', 'gender': 'Female', 'code': 'gl-ES-SabelaNeural'},
            {'name': 'Galician General Male', 'gender': 'Male', 'code': 'gl-ES-RoiNeural'}
        ]
    },
    'Gujarati': {
        'text-lang-code': 'gu',
        'voice-codes': [
            {'name': 'Gujarati India Female 1', 'gender': 'Female', 'code': 'gu-IN-DhwaniNeural'},
            {'name': 'Gujarati India Male 1', 'gender': 'Male', 'code': 'gu-IN-NiranjanNeural'},
            {'name': 'Gujarati India Female 2', 'gender': 'Female', 'code': 'gu-IN-Wavenet-A'},
            {'name': 'Gujarati India Male 2', 'gender': 'Male', 'code': 'gu-IN-Wavenet-B'},
            {'name': 'Gujarati India Female 3', 'gender': 'Female', 'code': 'gu-IN-Wavenet-C'},
            {'name': 'Gujarati India Male 3', 'gender': 'Male', 'code': 'gu-IN-Wavenet-D'}
        ]
    },
    'Hebrew': {
        'text-lang-code': 'he',
        'voice-codes': [
            {'name': 'Hebrew Israel Female 1', 'gender': 'Female', 'code': 'he-IL-HilaNeural'},
            {'name': 'Hebrew Israel Male 1', 'gender': 'Male', 'code': 'he-IL-AvriNeural'},
            {'name': 'Hebrew Israel Female 2', 'gender': 'Female', 'code': 'he-IL-Wavenet-A'},
            {'name': 'Hebrew Israel Male 2', 'gender': 'Male', 'code': 'he-IL-Wavenet-B'},
            {'name': 'Hebrew Israel Female 3', 'gender': 'Female', 'code': 'he-IL-Wavenet-C'},
            {'name': 'Hebrew Israel Male 3', 'gender': 'Male', 'code': 'he-IL-Wavenet-D'}
        ]
    },
    'Hindi': {
        'text-lang-code': 'hi',
        'voice-codes': [
            {'name': 'Hindi India Female 1', 'gender': 'Female', 'code': 'hi-IN-SwaraNeural'},
            {'name': 'Hindi India Male 1', 'gender': 'Male', 'code': 'hi-IN-MadhurNeural'},
            {'name': 'Hindi India Female 2', 'gender': 'Female', 'code': 'hi-IN-Neural2-A'},
            {'name': 'Hindi India Male 2', 'gender': 'Male', 'code': 'hi-IN-Neural2-B'},
            {'name': 'Hindi India Male 3', 'gender': 'Male', 'code': 'hi-IN-Neural2-C'},
            {'name': 'Hindi India Female 3', 'gender': 'Female', 'code': 'hi-IN-Neural2-D'},
            {'name': 'Hindi India Female 4', 'gender': 'Female', 'code': 'hi-IN-Wavenet-A'},
            {'name': 'Hindi India Male 4', 'gender': 'Male', 'code': 'hi-IN-Wavenet-B'},
            {'name': 'Hindi India Male 5', 'gender': 'Male', 'code': 'hi-IN-Wavenet-C'},
            {'name': 'Hindi India Female 5', 'gender': 'Female', 'code': 'hi-IN-Wavenet-D'}
        ]
    },
    'Croatian': {
        'text-lang-code': 'hr',
        'voice-codes': [
            {'name': 'Croatian Croatia Female', 'gender': 'Female', 'code': 'hr-HR-GabrijelaNeural'},
            {'name': 'Croatian Croatia Male', 'gender': 'Male', 'code': 'hr-HR-SreckoNeural'}
        ]
    },
    'Hungarian': {
        'text-lang-code': 'hu',
        'voice-codes': [
            {'name': 'Hungarian Hungary Female 1', 'gender': 'Female', 'code': 'hu-HU-NoemiNeural'},
            {'name': 'Hungarian Hungary Male', 'gender': 'Male', 'code': 'hu-HU-TamasNeural'},
            {'name': 'Hungarian Hungary Female 2', 'gender': 'Female', 'code': 'hu-HU-Wavenet-A'}
        ]
    },
    'Armenian': {
        'text-lang-code': 'hy',
        'voice-codes': [
            {'name': 'Armenian Armenia Female', 'gender': 'Female', 'code': 'hy-AM-AnahitNeural'},
            {'name': 'Armenian Armenia Male', 'gender': 'Male', 'code': 'hy-AM-HaykNeural'}
        ]
    },
    'Indonesian': {
        'text-lang-code': 'id',
        'voice-codes': [
            {'name': 'Indonesian Indonesia Female 1', 'gender': 'Female', 'code': 'id-ID-GadisNeural'},
            {'name': 'Indonesian Indonesia Male 1', 'gender': 'Male', 'code': 'id-ID-ArdiNeural'},
            {'name': 'Indonesian Indonesia Female 2', 'gender': 'Female', 'code': 'id-ID-Wavenet-A'},
            {'name': 'Indonesian Indonesia Male 2', 'gender': 'Male', 'code': 'id-ID-Wavenet-B'},
            {'name': 'Indonesian Indonesia Male 3', 'gender': 'Male', 'code': 'id-ID-Wavenet-C'},
            {'name': 'Indonesian Indonesia Female 3', 'gender': 'Female', 'code': 'id-ID-Wavenet-D'}
        ]
    },
    'Icelandic': {
        'text-lang-code': 'is',
        'voice-codes': [
            {'name': 'Icelandic Iceland Female', 'gender': 'Female', 'code': 'is-IS-GudrunNeural'},
            {'name': 'Icelandic Iceland Male', 'gender': 'Male', 'code': 'is-IS-GunnarNeural'}
        ]
    },
    'Italian': {
        'text-lang-code': 'it',
        'voice-codes': [
            {'name': 'Italian Italy Female 1', 'gender': 'Female', 'code': 'it-IT-ElsaNeural'},
            {'name': 'Italian Italy Female 2', 'gender': 'Female', 'code': 'it-IT-IsabellaNeural'},
            {'name': 'Italian Italy Male 1', 'gender': 'Male', 'code': 'it-IT-DiegoNeural'},
            {'name': 'Italian Italy Male 2', 'gender': 'Male', 'code': 'it-IT-BenignoNeural'},
            {'name': 'Italian Italy Male 3', 'gender': 'Male', 'code': 'it-IT-CalimeroNeural'},
            {'name': 'Italian Italy Male 4', 'gender': 'Male', 'code': 'it-IT-CataldoNeural'},
            {'name': 'Italian Italy Female 3', 'gender': 'Female', 'code': 'it-IT-FabiolaNeural'},
            {'name': 'Italian Italy Female 4', 'gender': 'Female', 'code': 'it-IT-FiammaNeural'},
            {'name': 'Italian Italy Male 5', 'gender': 'Male', 'code': 'it-IT-GianniNeural'},
            {'name': 'Italian Italy Female 5', 'gender': 'Female', 'code': 'it-IT-ImeldaNeural'},
            {'name': 'Italian Italy Female 6', 'gender': 'Female', 'code': 'it-IT-IrmaNeural'},
            {'name': 'Italian Italy Male 6', 'gender': 'Male', 'code': 'it-IT-LisandroNeural'},
            {'name': 'Italian Italy Female 7', 'gender': 'Female', 'code': 'it-IT-PalmiraNeural'},
            {'name': 'Italian Italy Female 8', 'gender': 'Female', 'code': 'it-IT-PierinaNeural'},
            {'name': 'Italian Italy Male 7', 'gender': 'Male', 'code': 'it-IT-RinaldoNeural'},
            {'name': 'Italian Italy Male 8', 'gender': 'Male', 'code': 'it-IT-GiuseppeNeural'},
            {'name': 'Italian Italy Female 9', 'gender': 'Female', 'code': 'it-IT-Neural2-A'},
            {'name': 'Italian Italy Male 9', 'gender': 'Male', 'code': 'it-IT-Neural2-C'},
            {'name': 'Italian Italy Female 10', 'gender': 'Female', 'code': 'it-IT-Wavenet-A'},
            {'name': 'Italian Italy Female 11', 'gender': 'Female', 'code': 'it-IT-Wavenet-B'},
            {'name': 'Italian Italy Male 10', 'gender': 'Male', 'code': 'it-IT-Wavenet-C'},
            {'name': 'Italian Italy Male 11', 'gender': 'Male', 'code': 'it-IT-Wavenet-D'}
        ]
    },
    'Japanese': {
        'text-lang-code': 'ja',
        'voice-codes': [
            {'name': 'Japanese Japan Female 1', 'gender': 'Female', 'code': 'ja-JP-NanamiNeural'},
            {'name': 'Japanese Japan Male 1', 'gender': 'Male', 'code': 'ja-JP-KeitaNeural'},
            {'name': 'Japanese Japan Female 2', 'gender': 'Female', 'code': 'ja-JP-AoiNeural'},
            {'name': 'Japanese Japan Male 2', 'gender': 'Male', 'code': 'ja-JP-DaichiNeural'},
            {'name': 'Japanese Japan Female 3', 'gender': 'Female', 'code': 'ja-JP-MayuNeural'},
            {'name': 'Japanese Japan Male 3', 'gender': 'Male', 'code': 'ja-JP-NaokiNeural'},
            {'name': 'Japanese Japan Female 4', 'gender': 'Female', 'code': 'ja-JP-ShioriNeural'},
            {'name': 'Japanese Japan Male 4', 'gender': 'Male', 'code': 'ja-JP-MasaruMultilingualNeural1,'},
            {'name': 'Japanese Japan Female 5', 'gender': 'Female', 'code': 'ja-JP-Neural2-B'},
            {'name': 'Japanese Japan Male 5', 'gender': 'Male', 'code': 'ja-JP-Neural2-C'},
            {'name': 'Japanese Japan Male 6', 'gender': 'Male', 'code': 'ja-JP-Neural2-D'},
            {'name': 'Japanese Japan Female 6', 'gender': 'Female', 'code': 'ja-JP-Wavenet-A'},
            {'name': 'Japanese Japan Female 7', 'gender': 'Female', 'code': 'ja-JP-Wavenet-B'},
            {'name': 'Japanese Japan Male 7', 'gender': 'Male', 'code': 'ja-JP-Wavenet-C'},
            {'name': 'Japanese Japan Male 8', 'gender': 'Male', 'code': 'ja-JP-Wavenet-D'}
        ]
    },
    'Javanese': {
        'text-lang-code': 'jv',
        'voice-codes': [
            {'name': 'Javanese Latin, Indonesia Female', 'gender': 'Female', 'code': 'jv-ID-SitiNeural'},
            {'name': 'Javanese Latin, Indonesia Male', 'gender': 'Male', 'code': 'jv-ID-DimasNeural'}
        ]
    },
    'Georgian': {
        'text-lang-code': 'ka',
        'voice-codes': [
            {'name': 'Georgian Georgia Female', 'gender': 'Female', 'code': 'ka-GE-EkaNeural'},
            {'name': 'Georgian Georgia Male', 'gender': 'Male', 'code': 'ka-GE-GiorgiNeural'}
        ]
    },
    'Kazakh': {
        'text-lang-code': 'kk',
        'voice-codes': [
            {'name': 'Kazakh Kazakhstan Female', 'gender': 'Female', 'code': 'kk-KZ-AigulNeural'},
            {'name': 'Kazakh Kazakhstan Male', 'gender': 'Male', 'code': 'kk-KZ-DauletNeural'}
        ]
    },
    'Khmer': {
        'text-lang-code': 'km',
        'voice-codes': [
            {'name': 'Khmer Cambodia Female', 'gender': 'Female', 'code': 'km-KH-SreymomNeural'},
            {'name': 'Khmer Cambodia Male', 'gender': 'Male', 'code': 'km-KH-PisethNeural'}
        ]
    },
    'Kannada': {
        'text-lang-code': 'kn',
        'voice-codes': [
            {'name': 'Kannada India Female 1', 'gender': 'Female', 'code': 'kn-IN-SapnaNeural'},
            {'name': 'Kannada India Male 1', 'gender': 'Male', 'code': 'kn-IN-GaganNeural'},
            {'name': 'Kannada India Female 2', 'gender': 'Female', 'code': 'kn-IN-Wavenet-A'},
            {'name': 'Kannada India Male 2', 'gender': 'Male', 'code': 'kn-IN-Wavenet-B'},
            {'name': 'Kannada India Female 3', 'gender': 'Female', 'code': 'kn-IN-Wavenet-C'},
            {'name': 'Kannada India Male 3', 'gender': 'Male', 'code': 'kn-IN-Wavenet-D'}
        ]
    },
    'Korean': {
        'text-lang-code': 'ko',
        'voice-codes': [
            {'name': 'Korean Korea Female 1', 'gender': 'Female', 'code': 'ko-KR-SunHiNeural'},
            {'name': 'Korean Korea Male 1', 'gender': 'Male', 'code': 'ko-KR-InJoonNeural'},
            {'name': 'Korean Korea Male 2', 'gender': 'Male', 'code': 'ko-KR-BongJinNeural'},
            {'name': 'Korean Korea Male 3', 'gender': 'Male', 'code': 'ko-KR-GookMinNeural'},
            {'name': 'Korean Korea Female 2', 'gender': 'Female', 'code': 'ko-KR-JiMinNeural'},
            {'name': 'Korean Korea Female 3', 'gender': 'Female', 'code': 'ko-KR-SeoHyeonNeural'},
            {'name': 'Korean Korea Female 4', 'gender': 'Female', 'code': 'ko-KR-SoonBokNeural'},
            {'name': 'Korean Korea Female 5', 'gender': 'Female', 'code': 'ko-KR-YuJinNeural'},
            {'name': 'Korean Korea Male 4', 'gender': 'Male', 'code': 'ko-KR-HyunsuNeural'},
            {'name': 'Korean South Korea Female 1', 'gender': 'Female', 'code': 'ko-KR-Neural2-A'},
            {'name': 'Korean South Korea Female 2', 'gender': 'Female', 'code': 'ko-KR-Neural2-B'},
            {'name': 'Korean South Korea Male 1', 'gender': 'Male', 'code': 'ko-KR-Neural2-C'},
            {'name': 'Korean South Korea Female 3', 'gender': 'Female', 'code': 'ko-KR-Wavenet-A'},
            {'name': 'Korean South Korea Female 4', 'gender': 'Female', 'code': 'ko-KR-Wavenet-B'},
            {'name': 'Korean South Korea Male 2', 'gender': 'Male', 'code': 'ko-KR-Wavenet-C'},
            {'name': 'Korean South Korea Male 3', 'gender': 'Male', 'code': 'ko-KR-Wavenet-D'}
        ]
    },
    'Lao': {
        'text-lang-code': 'lo',
        'voice-codes': [
            {'name': 'Lao Laos Female', 'gender': 'Female', 'code': 'lo-LA-KeomanyNeural'},
            {'name': 'Lao Laos Male', 'gender': 'Male', 'code': 'lo-LA-ChanthavongNeural'}
        ]
    },
    'Lithuanian': {
        'text-lang-code': 'lt',
        'voice-codes': [
            {'name': 'Lithuanian Lithuania Female', 'gender': 'Female', 'code': 'lt-LT-OnaNeural'},
            {'name': 'Lithuanian Lithuania Male', 'gender': 'Male', 'code': 'lt-LT-LeonasNeural'}
        ]
    },
    'Latvian': {
        'text-lang-code': 'lv',
        'voice-codes': [
            {'name': 'Latvian Latvia Female', 'gender': 'Female', 'code': 'lv-LV-EveritaNeural'},
            {'name': 'Latvian Latvia Male', 'gender': 'Male', 'code': 'lv-LV-NilsNeural'}
        ]
    },
    'Macedonian': {
        'text-lang-code': 'mk',
        'voice-codes': [
            {'name': 'Macedonian North Macedonia Female', 'gender': 'Female', 'code': 'mk-MK-MarijaNeural'},
            {'name': 'Macedonian North Macedonia Male', 'gender': 'Male', 'code': 'mk-MK-AleksandarNeural'}
        ]
    },
    'Malayalam': {
        'text-lang-code': 'ml',
        'voice-codes': [
            {'name': 'Malayalam India Female 1', 'gender': 'Female', 'code': 'ml-IN-SobhanaNeural'},
            {'name': 'Malayalam India Male 1', 'gender': 'Male', 'code': 'ml-IN-MidhunNeural'},
            {'name': 'Malayalam India Female 2', 'gender': 'Female', 'code': 'ml-IN-Wavenet-A'},
            {'name': 'Malayalam India Male 2', 'gender': 'Male', 'code': 'ml-IN-Wavenet-B'},
            {'name': 'Malayalam India Female 3', 'gender': 'Female', 'code': 'ml-IN-Wavenet-C'},
            {'name': 'Malayalam India Male 3', 'gender': 'Male', 'code': 'ml-IN-Wavenet-D'}
        ]
    },
    'Mongolian': {
        'text-lang-code': 'mn',
        'voice-codes': [
            {'name': 'Mongolian Mongolia Female', 'gender': 'Female', 'code': 'mn-MN-YesuiNeural'},
            {'name': 'Mongolian Mongolia Male', 'gender': 'Male', 'code': 'mn-MN-BataaNeural'}
        ]
    },
    'Marathi': {
        'text-lang-code': 'mr',
        'voice-codes': [
            {'name': 'Marathi India Female 1', 'gender': 'Female', 'code': 'mr-IN-AarohiNeural'},
            {'name': 'Marathi India Male 1', 'gender': 'Male', 'code': 'mr-IN-ManoharNeural'},
            {'name': 'Marathi India Female 2', 'gender': 'Female', 'code': 'mr-IN-Wavenet-A'},
            {'name': 'Marathi India Male 1', 'gender': 'Male', 'code': 'mr-IN-Wavenet-B'},
            {'name': 'Marathi India Female 3', 'gender': 'Female', 'code': 'mr-IN-Wavenet-C'}
        ]
    },
    'Malay': {
        'text-lang-code': 'ms',
        'voice-codes': [
            {'name': 'Malay Malaysia Female 1', 'gender': 'Female', 'code': 'ms-MY-YasminNeural'},
            {'name': 'Malay Malaysia Male 1', 'gender': 'Male', 'code': 'ms-MY-OsmanNeural'},
            {'name': 'Malay Malaysia Female 2', 'gender': 'Female', 'code': 'ms-MY-Wavenet-A'},
            {'name': 'Malay Malaysia Male 2', 'gender': 'Male', 'code': 'ms-MY-Wavenet-B'},
            {'name': 'Malay Malaysia Female 3', 'gender': 'Female', 'code': 'ms-MY-Wavenet-C'},
            {'name': 'Malay Malaysia Male 3', 'gender': 'Male', 'code': 'ms-MY-Wavenet-D'}
        ]
    },
    'Maltese': {
        'text-lang-code': 'mt',
        'voice-codes': [
            {'name': 'Maltese Malta Female', 'gender': 'Female', 'code': 'mt-MT-GraceNeural'},
            {'name': 'Maltese Malta Male', 'gender': 'Male', 'code': 'mt-MT-JosephNeural'}
        ]
    },
    'Burmese': {
        'text-lang-code': 'my',
        'voice-codes': [
            {'name': 'Burmese Myanmar Female', 'gender': 'Female', 'code': 'my-MM-NilarNeural'},
            {'name': 'Burmese Myanmar Male', 'gender': 'Male', 'code': 'my-MM-ThihaNeural'}
        ]
    },
    'Norwegian Bokmål': {
        'text-lang-code': 'nb',
        'voice-codes': [
            {'name': 'Norwegian Bokmål Norway Female 1', 'gender': 'Female', 'code': 'nb-NO-PernilleNeural'},
            {'name': 'Norwegian Bokmål Norway Male', 'gender': 'Male', 'code': 'nb-NO-FinnNeural'},
            {'name': 'Norwegian Bokmål Norway Female 2', 'gender': 'Female', 'code': 'nb-NO-IselinNeural'}
        ]
    },
    'Nepali': {
        'text-lang-code': 'ne',
        'voice-codes': [
            {'name': 'Nepali Nepal Female', 'gender': 'Female', 'code': 'ne-NP-HemkalaNeural'},
            {'name': 'Nepali Nepal Male', 'gender': 'Male', 'code': 'ne-NP-SagarNeural'}
        ]
    },
    'Dutch': {
        'text-lang-code': 'nl',
        'voice-codes': [
            {'name': 'Dutch Belgium Female 1', 'gender': 'Female', 'code': 'nl-BE-DenaNeural'},
            {'name': 'Dutch Belgium Male 1', 'gender': 'Male', 'code': 'nl-BE-ArnaudNeural'},
            {'name': 'Dutch Netherlands Female 1', 'gender': 'Female', 'code': 'nl-NL-FennaNeural'},
            {'name': 'Dutch Netherlands Male 1', 'gender': 'Male', 'code': 'nl-NL-MaartenNeural'},
            {'name': 'Dutch Netherlands Female 2', 'gender': 'Female', 'code': 'nl-NL-ColetteNeural'},
            {'name': 'Dutch Belgium Female 2', 'gender': 'Female', 'code': 'nl-BE-Wavenet-A'},
            {'name': 'Dutch Belgium Male 2', 'gender': 'Male', 'code': 'nl-BE-Wavenet-B'},
            {'name': 'Dutch Netherlands Female 3', 'gender': 'Female', 'code': 'nl-NL-Wavenet-A'},
            {'name': 'Dutch Netherlands Male 2', 'gender': 'Male', 'code': 'nl-NL-Wavenet-B'},
            {'name': 'Dutch Netherlands Male 3', 'gender': 'Male', 'code': 'nl-NL-Wavenet-C'},
            {'name': 'Dutch Netherlands Female 4', 'gender': 'Female', 'code': 'nl-NL-Wavenet-D'},
            {'name': 'Dutch Netherlands Female 5', 'gender': 'Female', 'code': 'nl-NL-Wavenet-E'}
        ]
    },
    'Polish': {
        'text-lang-code': 'pl',
        'voice-codes': [
            {'name': 'Polish Poland Female 1', 'gender': 'Female', 'code': 'pl-PL-AgnieszkaNeural'},
            {'name': 'Polish Poland Male 1', 'gender': 'Male', 'code': 'pl-PL-MarekNeural'},
            {'name': 'Polish Poland Female 2', 'gender': 'Female', 'code': 'pl-PL-ZofiaNeural'},
            {'name': 'Polish Poland Female 3', 'gender': 'Female', 'code': 'pl-PL-Wavenet-A'},
            {'name': 'Polish Poland Male 2', 'gender': 'Male', 'code': 'pl-PL-Wavenet-B'},
            {'name': 'Polish Poland Male 3', 'gender': 'Male', 'code': 'pl-PL-Wavenet-C'},
            {'name': 'Polish Poland Female 4', 'gender': 'Female', 'code': 'pl-PL-Wavenet-D'},
            {'name': 'Polish Poland Female 5', 'gender': 'Female', 'code': 'pl-PL-Wavenet-E'}
        ]
    },
    'Pashto': {
        'text-lang-code': 'ps',
        'voice-codes': [
            {'name': 'Pashto Afghanistan Female', 'gender': 'Female', 'code': 'ps-AF-LatifaNeural'},
            {'name': 'Pashto Afghanistan Male', 'gender': 'Male', 'code': 'ps-AF-GulNawazNeural'}
        ]
    },
    'Portuguese': {
        'text-lang-code': 'pt',
        'voice-codes': [
            {'name': 'Portuguese Brazil Female 1', 'gender': 'Female', 'code': 'pt-BR-FranciscaNeural'},
            {'name': 'Portuguese Brazil Male 1', 'gender': 'Male', 'code': 'pt-BR-AntonioNeural'},
            {'name': 'Portuguese Brazil Female 2', 'gender': 'Female', 'code': 'pt-BR-BrendaNeural'},
            {'name': 'Portuguese Brazil Male 2', 'gender': 'Male', 'code': 'pt-BR-DonatoNeural'},
            {'name': 'Portuguese Brazil Female 3', 'gender': 'Female', 'code': 'pt-BR-ElzaNeural'},
            {'name': 'Portuguese Brazil Male 3', 'gender': 'Male', 'code': 'pt-BR-FabioNeural'},
            {'name': 'Portuguese Brazil Female 4', 'gender': 'Female', 'code': 'pt-BR-GiovannaNeural'},
            {'name': 'Portuguese Brazil Male 4', 'gender': 'Male', 'code': 'pt-BR-HumbertoNeural'},
            {'name': 'Portuguese Brazil Male 5', 'gender': 'Male', 'code': 'pt-BR-JulioNeural'},
            {'name': 'Portuguese Brazil Female 5', 'gender': 'Female', 'code': 'pt-BR-LeilaNeural'},
            {'name': 'Portuguese Brazil Female 6', 'gender': 'Female', 'code': 'pt-BR-LeticiaNeural'},
            {'name': 'Portuguese Brazil Female 7', 'gender': 'Female', 'code': 'pt-BR-ManuelaNeural'},
            {'name': 'Portuguese Brazil Male 6', 'gender': 'Male', 'code': 'pt-BR-NicolauNeural'},
            {'name': 'Portuguese Brazil Male 7', 'gender': 'Male', 'code': 'pt-BR-ValerioNeural'},
            {'name': 'Portuguese Brazil Female 8', 'gender': 'Female', 'code': 'pt-BR-YaraNeural'},
            {'name': 'Portuguese Brazil Female 9', 'gender': 'Female', 'code': 'pt-BR-ThalitaNeural'},
            {'name': 'Portuguese Portugal Female 1', 'gender': 'Female', 'code': 'pt-PT-RaquelNeural'},
            {'name': 'Portuguese Portugal Male 1', 'gender': 'Male', 'code': 'pt-PT-DuarteNeural'},
            {'name': 'Portuguese Portugal Female 2', 'gender': 'Female', 'code': 'pt-PT-FernandaNeural'},
            {'name': 'Portuguese Brazil Female 10', 'gender': 'Female', 'code': 'pt-BR-Neural2-A'},
            {'name': 'Portuguese Brazil Male 8', 'gender': 'Male', 'code': 'pt-BR-Neural2-B'},
            {'name': 'Portuguese Brazil Female 11', 'gender': 'Female', 'code': 'pt-BR-Neural2-C'},
            {'name': 'Portuguese Brazil Female 12', 'gender': 'Female', 'code': 'pt-BR-Wavenet-A'},
            {'name': 'Portuguese Brazil Male 9', 'gender': 'Male', 'code': 'pt-BR-Wavenet-B'},
            {'name': 'Portuguese Brazil Female 13', 'gender': 'Female', 'code': 'pt-BR-Wavenet-C'},
            {'name': 'Portuguese Portugal Female 3', 'gender': 'Female', 'code': 'pt-PT-Wavenet-A'},
            {'name': 'Portuguese Portugal Male 2', 'gender': 'Male', 'code': 'pt-PT-Wavenet-B'},
            {'name': 'Portuguese Portugal Male 3', 'gender': 'Male', 'code': 'pt-PT-Wavenet-C'},
            {'name': 'Portuguese Portugal Female 4', 'gender': 'Female', 'code': 'pt-PT-Wavenet-D'}
        ]
    },
    'Romanian': {
        'text-lang-code': 'ro',
        'voice-codes': [
            {'name': 'Romanian Romania Female 1', 'gender': 'Female', 'code': 'ro-RO-AlinaNeural'},
            {'name': 'Romanian Romania Male', 'gender': 'Male', 'code': 'ro-RO-EmilNeural'},
            {'name': 'Romanian Romania Female 2', 'gender': 'Female', 'code': 'ro-RO-Wavenet-A'}
        ]
    },
    'Russian': {
        'text-lang-code': 'ru',
        'voice-codes': [
            {'name': 'Russian Russia Female 1', 'gender': 'Female', 'code': 'ru-RU-SvetlanaNeural'},
            {'name': 'Russian Russia Male !', 'gender': 'Male', 'code': 'ru-RU-DmitryNeural'},
            {'name': 'Russian Russia Female 2', 'gender': 'Female', 'code': 'ru-RU-DariyaNeural'},
            {'name': 'Russian Russia Female 3', 'gender': 'Female', 'code': 'ru-RU-Wavenet-A'},
            {'name': 'Russian Russia Male 2', 'gender': 'Male', 'code': 'ru-RU-Wavenet-B'},
            {'name': 'Russian Russia Female 4', 'gender': 'Female', 'code': 'ru-RU-Wavenet-C'},
            {'name': 'Russian Russia Male 3', 'gender': 'Male', 'code': 'ru-RU-Wavenet-D'},
            {'name': 'Russian Russia Female 5', 'gender': 'Female', 'code': 'ru-RU-Wavenet-E'}
        ]
    },
    'Sinhala': {
        'text-lang-code': 'si',
        'voice-codes': [
            {'name': 'Sinhala Sri Lanka Female', 'gender': 'Female', 'code': 'si-LK-ThiliniNeural'},
            {'name': 'Sinhala Sri Lanka Male', 'gender': 'Male', 'code': 'si-LK-SameeraNeural'}
        ]
    },
    'Slovak': {
        'text-lang-code': 'sk',
        'voice-codes': [
            {'name': 'Slovak Slovakia Female 1', 'gender': 'Female', 'code': 'sk-SK-ViktoriaNeural'},
            {'name': 'Slovak Slovakia Male', 'gender': 'Male', 'code': 'sk-SK-LukasNeural'},
            {'name': 'Slovak Slovakia Female 2', 'gender': 'Female', 'code': 'sk-SK-Wavenet-A'}
        ]
    },
    'Slovenian': {
        'text-lang-code': 'sl',
        'voice-codes': [
            {'name': 'Slovenian Slovenia Female', 'gender': 'Female', 'code': 'sl-SI-PetraNeural'},
            {'name': 'Slovenian Slovenia Male', 'gender': 'Male', 'code': 'sl-SI-RokNeural'}
        ]
    },
    'Somali': {
        'text-lang-code': 'so',
        'voice-codes': [
            {'name': 'Somali Somalia Female', 'gender': 'Female', 'code': 'so-SO-UbaxNeural'},
            {'name': 'Somali Somalia Male', 'gender': 'Male', 'code': 'so-SO-MuuseNeural'}
        ]
    },
    'Albanian': {
        'text-lang-code': 'sq',
        'voice-codes': [
            {'name': 'Albanian Albania Female', 'gender': 'Female', 'code': 'sq-AL-AnilaNeural'},
            {'name': 'Albanian Albania Male', 'gender': 'Male', 'code': 'sq-AL-IlirNeural'}
        ]
    },
    'Serbian': {
        'text-lang-code': 'sr',
        'voice-codes': [
            {'name': 'Serbian Latin, Serbia Male', 'gender': 'Male', 'code': 'sr-Latn-RS-NicholasNeural'},
            {'name': 'Serbian Latin, Serbia Female', 'gender': 'Female', 'code': 'sr-Latn-RS-SophieNeural'},
            {'name': 'Serbian Cyrillic, Serbia Female', 'gender': 'Female', 'code': 'sr-RS-SophieNeural'},
            {'name': 'Serbian Cyrillic, Serbia Male', 'gender': 'Male', 'code': 'sr-RS-NicholasNeural'}
        ]
    },
    'Sundanese': {
        'text-lang-code': 'su',
        'voice-codes': [
            {'name': 'Sundanese Indonesia Female', 'gender': 'Female', 'code': 'su-ID-TutiNeural'},
            {'name': 'Sundanese Indonesia Male', 'gender': 'Male', 'code': 'su-ID-JajangNeural'}
        ]
    },
    'Swedish': {
        'text-lang-code': 'sv',
        'voice-codes': [
            {'name': 'Swedish Sweden Female 1', 'gender': 'Female', 'code': 'sv-SE-SofieNeural'},
            {'name': 'Swedish Sweden Male 1', 'gender': 'Male', 'code': 'sv-SE-MattiasNeural'},
            {'name': 'Swedish Sweden Female 2', 'gender': 'Female', 'code': 'sv-SE-HilleviNeural'},
            {'name': 'Swedish Sweden Female 3', 'gender': 'Female', 'code': 'sv-SE-Wavenet-A'},
            {'name': 'Swedish Sweden Female 4', 'gender': 'Female', 'code': 'sv-SE-Wavenet-B'},
            {'name': 'Swedish Sweden Male 2', 'gender': 'Male', 'code': 'sv-SE-Wavenet-C'},
            {'name': 'Swedish Sweden Female 5', 'gender': 'Female', 'code': 'sv-SE-Wavenet-D'},
            {'name': 'Swedish Sweden Male 3', 'gender': 'Male', 'code': 'sv-SE-Wavenet-E'}
        ]
    },
    'Swahili': {
        'text-lang-code': 'sw',
        'voice-codes': [
            {'name': 'Swahili Kenya Female', 'gender': 'Female', 'code': 'sw-KE-ZuriNeural'},
            {'name': 'Swahili Kenya Male', 'gender': 'Male', 'code': 'sw-KE-RafikiNeural'},
            {'name': 'Swahili Tanzania Female', 'gender': 'Female', 'code': 'sw-TZ-RehemaNeural'},
            {'name': 'Swahili Tanzania Male', 'gender': 'Male', 'code': 'sw-TZ-DaudiNeural'}
        ]
    },
    'Tamil': {
        'text-lang-code': 'ta',
        'voice-codes': [
            {'name': 'Tamil India Female 1', 'gender': 'Female', 'code': 'ta-IN-PallaviNeural'},
            {'name': 'Tamil India Male 1', 'gender': 'Male', 'code': 'ta-IN-ValluvarNeural'},
            {'name': 'Tamil Sri Lanka Female', 'gender': 'Female', 'code': 'ta-LK-SaranyaNeural'},
            {'name': 'Tamil Sri Lanka Male', 'gender': 'Male', 'code': 'ta-LK-KumarNeural'},
            {'name': 'Tamil Malaysia Female', 'gender': 'Female', 'code': 'ta-MY-KaniNeural'},
            {'name': 'Tamil Malaysia Male', 'gender': 'Male', 'code': 'ta-MY-SuryaNeural'},
            {'name': 'Tamil Singapore Female', 'gender': 'Female', 'code': 'ta-SG-VenbaNeural'},
            {'name': 'Tamil Singapore Male', 'gender': 'Male', 'code': 'ta-SG-AnbuNeural'},
            {'name': 'Tamil India Female 2', 'gender': 'Female', 'code': 'ta-IN-Wavenet-A'},
            {'name': 'Tamil India Male 2', 'gender': 'Male', 'code': 'ta-IN-Wavenet-B'},
            {'name': 'Tamil India Female 3', 'gender': 'Female', 'code': 'ta-IN-Wavenet-C'},
            {'name': 'Tamil India Male 3', 'gender': 'Male', 'code': 'ta-IN-Wavenet-D'}
        ]
    },
    'Telugu': {
        'text-lang-code': 'te',
        'voice-codes': [
            {'name': 'Telugu India Female', 'gender': 'Female', 'code': 'te-IN-ShrutiNeural'},
            {'name': 'Telugu India Male', 'gender': 'Male', 'code': 'te-IN-MohanNeural'}
        ]
    },
    'Thai': {
        'text-lang-code': 'th',
        'voice-codes': [
            {'name': 'Thai Thailand Female 1', 'gender': 'Female', 'code': 'th-TH-PremwadeeNeural'},
            {'name': 'Thai Thailand Male', 'gender': 'Male', 'code': 'th-TH-NiwatNeural'},
            {'name': 'Thai Thailand Female 2', 'gender': 'Female', 'code': 'th-TH-AcharaNeural'},
            {'name': 'Thai Thailand Female 3', 'gender': 'Female', 'code': 'th-TH-Neural2-C'}
        ]
    },
    'Turkish': {
        'text-lang-code': 'tr',
        'voice-codes': [
            {'name': 'Turkish Türkiye Female', 'gender': 'Female', 'code': 'tr-TR-EmelNeural'},
            {'name': 'Turkish Türkiye Male', 'gender': 'Male', 'code': 'tr-TR-AhmetNeural'},
            {'name': 'Turkish Turkey Female 1', 'gender': 'Female', 'code': 'tr-TR-Wavenet-A'},
            {'name': 'Turkish Turkey Male 1', 'gender': 'Male', 'code': 'tr-TR-Wavenet-B'},
            {'name': 'Turkish Turkey Female 2', 'gender': 'Female', 'code': 'tr-TR-Wavenet-C'},
            {'name': 'Turkish Turkey Female 3', 'gender': 'Female', 'code': 'tr-TR-Wavenet-D'},
            {'name': 'Turkish Turkey Male 2', 'gender': 'Male', 'code': 'tr-TR-Wavenet-E'}
        ]
    },
    'Ukrainian': {
        'text-lang-code': 'uk',
        'voice-codes': [
            {'name': 'Ukrainian Ukraine Female 1', 'gender': 'Female', 'code': 'uk-UA-PolinaNeural'},
            {'name': 'Ukrainian Ukraine Male', 'gender': 'Male', 'code': 'uk-UA-OstapNeural'},
            {'name': 'Ukrainian Ukraine Female 2', 'gender': 'Female', 'code': 'uk-UA-Wavenet-A'}
        ]
    },
    'Urdu': {
        'text-lang-code': 'ur',
        'voice-codes': [
            {'name': 'Urdu India Female', 'gender': 'Female', 'code': 'ur-IN-GulNeural'},
            {'name': 'Urdu India Male', 'gender': 'Male', 'code': 'ur-IN-SalmanNeural'},
            {'name': 'Urdu Pakistan Female', 'gender': 'Female', 'code': 'ur-PK-UzmaNeural'},
            {'name': 'Urdu Pakistan Male', 'gender': 'Male', 'code': 'ur-PK-AsadNeural'}
        ]
    },
    'Uzbek': {
        'text-lang-code': 'uz',
        'voice-codes': [
            {'name': 'Uzbek Latin, Uzbekistan Female', 'gender': 'Female', 'code': 'uz-UZ-MadinaNeural'},
            {'name': 'Uzbek Latin, Uzbekistan Male', 'gender': 'Male', 'code': 'uz-UZ-SardorNeural'}
        ]
    },
    'Vietnamese': {
        'text-lang-code': 'vi',
        'voice-codes': [
            {'name': 'Vietnamese Vietnam Female 1', 'gender': 'Female', 'code': 'vi-VN-HoaiMyNeural'},
            {'name': 'Vietnamese Vietnam Male 1', 'gender': 'Male', 'code': 'vi-VN-NamMinhNeural'},
            {'name': 'Vietnamese Vietnam Female 2', 'gender': 'Female', 'code': 'vi-VN-Neural2-A'},
            {'name': 'Vietnamese Vietnam Male 2', 'gender': 'Male', 'code': 'vi-VN-Neural2-D'},
            {'name': 'Vietnamese Vietnam Female 3', 'gender': 'Female', 'code': 'vi-VN-Wavenet-A'},
            {'name': 'Vietnamese Vietnam Male 3', 'gender': 'Male', 'code': 'vi-VN-Wavenet-B'},
            {'name': 'Vietnamese Vietnam Female 4', 'gender': 'Female', 'code': 'vi-VN-Wavenet-C'},
            {'name': 'Vietnamese Vietnam Male 4', 'gender': 'Male', 'code': 'vi-VN-Wavenet-D'}
        ]
    },
    'Chinese': {
        'text-lang-code': 'wuu',
        'voice-codes': [
            {'name': 'Chinese Wu, Simplified Female', 'gender': 'Female', 'code': 'wuu-CN-XiaotongNeural'},
            {'name': 'Chinese Wu, Simplified Male', 'gender': 'Male', 'code': 'wuu-CN-YunzheNeural'},
            {'name': 'Chinese Cantonese, Simplified Female', 'gender': 'Female', 'code': 'yue-CN-XiaoMinNeural'},
            {'name': 'Chinese Cantonese, Simplified Male', 'gender': 'Male', 'code': 'yue-CN-YunSongNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 1', 'gender': 'Female', 'code': 'zh-CN-XiaoxiaoNeural'},
            {'name': 'Chinese Mandarin, Simplified Male 1', 'gender': 'Male', 'code': 'zh-CN-YunxiNeural'},
            {'name': 'Chinese Mandarin, Simplified Male 2', 'gender': 'Male', 'code': 'zh-CN-YunjianNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 2', 'gender': 'Female', 'code': 'zh-CN-XiaoyiNeural'},
            {'name': 'Chinese Mandarin, Simplified Male 3', 'gender': 'Male', 'code': 'zh-CN-YunyangNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 3', 'gender': 'Female', 'code': 'zh-CN-XiaochenNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 4', 'gender': 'Female', 'code': 'zh-CN-XiaohanNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 5', 'gender': 'Female', 'code': 'zh-CN-XiaomengNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 6', 'gender': 'Female', 'code': 'zh-CN-XiaomoNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 7', 'gender': 'Female', 'code': 'zh-CN-XiaoqiuNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 8', 'gender': 'Female', 'code': 'zh-CN-XiaoruiNeural'},
            {'name': 'Chinese Mandarin, Simplified Female,', 'gender': 'Female,', 'code': 'zh-CN-XiaoshuangNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 9', 'gender': 'Female', 'code': 'zh-CN-XiaoyanNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 10,', 'gender': 'Female,', 'code': 'zh-CN-XiaoyouNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 11', 'gender': 'Female', 'code': 'zh-CN-XiaozhenNeural'},
            {'name': 'Chinese Mandarin, Simplified Male 4', 'gender': 'Male', 'code': 'zh-CN-YunfengNeural'},
            {'name': 'Chinese Mandarin, Simplified Male 5', 'gender': 'Male', 'code': 'zh-CN-YunhaoNeural'},
            {'name': 'Chinese Mandarin, Simplified Male 6', 'gender': 'Male', 'code': 'zh-CN-YunxiaNeural'},
            {'name': 'Chinese Mandarin, Simplified Male 7', 'gender': 'Male', 'code': 'zh-CN-YunyeNeural'},
            {'name': 'Chinese Mandarin, Simplified Male 8', 'gender': 'Male', 'code': 'zh-CN-YunzeNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 12', 'gender': 'Female', 'code': 'zh-CN-XiaochenMultilingualNeural1,'},
            {'name': 'Chinese Mandarin, Simplified Female 13', 'gender': 'Female', 'code': 'zh-CN-XiaorouNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 14', 'gender': 'Female', 'code': 'zh-CN-XiaoxiaoDialectsNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 15', 'gender': 'Female', 'code': 'zh-CN-XiaoxiaoMultilingualNeural'},
            {'name': 'Chinese Mandarin, Simplified Female 16', 'gender': 'Female', 'code': 'zh-CN-XiaoyuMultilingualNeural1,'},
            {'name': 'Chinese Mandarin, Simplified Male 9', 'gender': 'Male', 'code': 'zh-CN-YunjieNeural'},
            {'name': 'Chinese Mandarin, Simplified Male 10', 'gender': 'Male', 'code': 'zh-CN-YunyiMultilingualNeural1,'},
            {'name': 'Chinese Guangxi Accent Mandarin, Simplified Male', 'gender': 'Male', 'code': 'zh-CN-guangxi-YunqiNeural1,'},
            {'name': 'Chinese Zhongyuan Mandarin Henan, Simplified Male', 'gender': 'Male', 'code': 'zh-CN-henan-YundengNeural'},
            {'name': 'Chinese Northeastern Mandarin, Simplified Female', 'gender': 'Female', 'code': 'zh-CN-liaoning-XiaobeiNeural1,'},
            {'name': 'Chinese Northeastern Mandarin, Simplified Male', 'gender': 'Male', 'code': 'zh-CN-liaoning-YunbiaoNeural1,'},
            {'name': 'Chinese Zhongyuan Mandarin Shaanxi, Simplified Female', 'gender': 'Female', 'code': 'zh-CN-shaanxi-XiaoniNeural1,'},
            {'name': 'Chinese Jilu Mandarin, Simplified Male', 'gender': 'Male', 'code': 'zh-CN-shandong-YunxiangNeural'},
            {'name': 'Chinese Southwestern Mandarin, Simplified Male', 'gender': 'Male', 'code': 'zh-CN-sichuan-YunxiNeural1,'},
            {'name': 'Chinese Cantonese, Traditional Female 1', 'gender': 'Female', 'code': 'zh-HK-HiuMaanNeural'},
            {'name': 'Chinese Cantonese, Traditional Male', 'gender': 'Male', 'code': 'zh-HK-WanLungNeural'},
            {'name': 'Chinese Cantonese, Traditional Female 2', 'gender': 'Female', 'code': 'zh-HK-HiuGaaiNeural'},
            {'name': 'Chinese Taiwanese Mandarin, Traditional Female 1', 'gender': 'Female', 'code': 'zh-TW-HsiaoChenNeural'},
            {'name': 'Chinese Taiwanese Mandarin, Traditional Male', 'gender': 'Male', 'code': 'zh-TW-YunJheNeural'},
            {'name': 'Chinese Taiwanese Mandarin, Traditional Female 2', 'gender': 'Female', 'code': 'zh-TW-HsiaoYuNeural'}
        ]
    },
    'Zulu': {
        'text-lang-code': 'zu',
        'voice-codes': [
            {'name': 'Zulu South Africa Female', 'gender': 'Female', 'code': 'zu-ZA-ThandoNeural'},
            {'name': 'Zulu South Africa Male', 'gender': 'Male', 'code': 'zu-ZA-ThembaNeural'}
        ]
    },
    'Mandarin Chinese': {
        'text-lang-code': 'cm',
        'voice-codes': [
            {'name': 'Mandarin Chinese Female 1', 'gender': 'Female', 'code': 'cmn-CN-Wavenet-A'},
            {'name': 'Mandarin Chinese Male 1', 'gender': 'Male', 'code': 'cmn-CN-Wavenet-B'},
            {'name': 'Mandarin Chinese Male 2', 'gender': 'Male', 'code': 'cmn-CN-Wavenet-C'},
            {'name': 'Mandarin Chinese Female 2', 'gender': 'Female', 'code': 'cmn-CN-Wavenet-D'},
            {'name': 'Mandarin Chinese Female 3', 'gender': 'Female', 'code': 'cmn-TW-Wavenet-A'},
            {'name': 'Mandarin Chinese Male 3', 'gender': 'Male', 'code': 'cmn-TW-Wavenet-B'},
            {'name': 'Mandarin Chinese Male 4', 'gender': 'Male', 'code': 'cmn-TW-Wavenet-C'}
        ]
    },
    'Norwegian': {
        'text-lang-code': 'nb',
        'voice-codes': [
            {'name': 'Norwegian Norway Female 1', 'gender': 'Female', 'code': 'nb-NO-Wavenet-A'},
            {'name': 'Norwegian Norway Male 1', 'gender': 'Male', 'code': 'nb-NO-Wavenet-B'},
            {'name': 'Norwegian Norway Female 2', 'gender': 'Female', 'code': 'nb-NO-Wavenet-C'},
            {'name': 'Norwegian Norway Male 2', 'gender': 'Male', 'code': 'nb-NO-Wavenet-D'},
            {'name': 'Norwegian Norway Female 3', 'gender': 'Female', 'code': 'nb-NO-Wavenet-E'}
        ]
    },
    'Punjabi': {
        'text-lang-code': 'pa',
        'voice-codes': [
            {'name': 'Punjabi India Female 1', 'gender': 'Female', 'code': 'pa-IN-Wavenet-A'},
            {'name': 'Punjabi India Male 1', 'gender': 'Male', 'code': 'pa-IN-Wavenet-B'},
            {'name': 'Punjabi India Female 2', 'gender': 'Female', 'code': 'pa-IN-Wavenet-C'},
            {'name': 'Punjabi India Male 2', 'gender': 'Male', 'code': 'pa-IN-Wavenet-D'}
        ]
    }
}
