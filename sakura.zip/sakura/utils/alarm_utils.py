import os
import base64
import hashlib
import secrets
import json
import threading
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import time
from typing import Optional, Dict, Any
import httpx

from logger import get_logger
from dotenv import load_dotenv
load_dotenv()

logger = get_logger(__name__)

alarm_opco_key = os.getenv('ALARM_OPCO_KEY')
alarm_secret_key = os.getenv('ALARM_SECRET_KEY')
alarm_hostname = os.getenv('ALARM_HOSTNAME')
notification_agent_base_url = os.getenv('NOTIFICATION_AGENT_BASE_URL')
proxy_ip_notification_agent = os.getenv('PROXY_IP_NOTIFICATION_AGENT')

# Global alarm tracking variables
_alarm_tracker = {}
_alarm_processing_locks = {}  # Dictionary of per-alarm-key locks
_alarm_locks_lock = threading.Lock()  # Lock to manage the dictionary of locks
RAISE_RESEND_COUNT = 5  # Number of repeated raises before resending

def get_aes_key_from_base64(base64_key: str) -> bytes:
    """
    Converts a Base64-encoded short key to a 256-bit AES key using SHA-256.
    
    Args:
        base64_key (str): Base64 encoded key
        
    Returns:
        bytes: 256-bit AES key
    """
    try:
        raw_key_bytes = base64.b64decode(base64_key)
        sha = hashlib.sha256()
        sha.update(raw_key_bytes)
        key_bytes = sha.digest()
        return key_bytes
    except Exception as e:
        raise Exception(f"Error generating AES key: {str(e)}")


def generate_iv() -> bytes:
    """
    Generates a secure random 16-byte IV.
    
    Returns:
        bytes: 16-byte initialization vector
    """
    return secrets.token_bytes(16)


def encrypt_text(plain_text: str) -> str:
    """
    Encrypt the plaintext using AES-256-CBC with IV and PKCS7 padding.
    
    Args:
        plain_text (str): Text to encrypt
        secret (str): Base64 encoded secret key
        
    Returns:
        str: Encrypted text in format "iv_base64:encrypted_base64"
    """
    try:
        key = get_aes_key_from_base64(alarm_secret_key)
        iv = generate_iv()
        
        # Create cipher and encrypt
        cipher = AES.new(key, AES.MODE_CBC, iv)
        padded_data = pad(plain_text.encode('utf-8'), AES.block_size)
        encrypted = cipher.encrypt(padded_data)
        
        # Encode IV and encrypted data as base64
        iv_base64 = base64.b64encode(iv).decode('utf-8')
        encrypted_base64 = base64.b64encode(encrypted).decode('utf-8')
        
        return f"{iv_base64}:{encrypted_base64}"
        
    except Exception as e:
        logger.error(f"Error encrypting text: {e}", exc_info=True)


def generate_x_api_key(operator: str, country: str) -> str:
    """
    Generate X-API-KEY in format: <operator>_<country>_<key-value>_<timestamp>
    where timestamp is UTC unix timestamp.
    
    Args:
        operator (str): Operator name
        country (str): Country code
        key_value (str): Key value
        
    Returns:
        str: Generated X-API-KEY
    """
    timestamp = int(time.time() * 1000)  # UTC unix timestamp
    return f"{operator}_{country}_{alarm_opco_key}_{timestamp}"

def create_payload(operator: str, country: str, alarm_type: str, remarks: Any = None) -> Dict[str, Any]:
    """
    Create payload with the required structure.
    
    Args:
        operator (str): Operator name
        country (str): Country code
        alarm_type (str): Type of alarm
        remarks (Any, optional): Additional remarks
        
    Returns:
        dict: Payload with required structure
    """
    payload = {
        "country": country,
        "module": "SAKURA",
        "operator": operator,
        "hostname": alarm_hostname,
        "alarmType": alarm_type
    }
    
    if remarks is not None:
        payload["remarks"] = remarks
        
    return payload


def get_alarm_key(alarm_type, operator, country):
    """Generate unique alarm key from alarm_type, operator, and country."""
    return f"{alarm_type}_{operator}_{country}"

def get_processing_lock(alarm_key):
    """Get or create a processing lock for the given alarm key."""
    with _alarm_locks_lock:
        if alarm_key not in _alarm_processing_locks:
            _alarm_processing_locks[alarm_key] = threading.Lock()
        return _alarm_processing_locks[alarm_key]

async def send_alarm(operator: str = None, country: str = None, alarm_type: str = None, remarks: any = None, status=None, assistant_id: str = None):
    """
    Send alarm notification to the notification agent asynchronously.
    If operator or country is missing, try to get them from assistant configuration cache using assistant_id.
    If still missing, use environment fallback.
    
    Note: Alarms are only sent if RAISE_ALARMS environment variable is set to 'true'.
    """
    # Step 1: Check raise_alarm flag directly
    raise_alarms = os.environ.get('RAISE_ALARMS', 'false').lower()
    if raise_alarms != 'true':
        return

    # Step 2: Check for required env variables, skip if missing
    if not (alarm_opco_key and alarm_secret_key and alarm_hostname and notification_agent_base_url):
        logger.info("Missing required environment variables for send_alarm. Alarm not sent.")
        return

    # Try to extract assistant_id from user_call_record if not provided
    if (not operator or not country):
        if assistant_id:
            try:
                from cache.assistant_configuration_cache import get_assistant_details_by_id  
                assistant_config = get_assistant_details_by_id(int(assistant_id))
                operator = assistant_config.get('operator', operator)
                country = assistant_config.get('country', country)
            except Exception as e:
                logger.warning(f"Could not get operator/country from assistant_id {assistant_id}: {e}")
        # Fallback to environment variables if still missing
        if not operator:
            operator = os.getenv('DEFAULT_OPERATOR')
        if not country:
            country = os.getenv('DEFAULT_COUNTRY')
        if not operator and not country:
            logger.warning("No operator, country, or assistant_id available for send_alarm. Alarm not sent.")
            return

    alarm_key = get_alarm_key(alarm_type, operator, country)
    
    # Get the processing lock for this specific alarm key
    processing_lock = get_processing_lock(alarm_key)

    if status == "raise":
        # Thread-safe access to alarm tracker using per-key lock
        with processing_lock:
            # Get current status or assume "cleared" if not present
            current_status = _alarm_tracker.get(alarm_key, "cleared")
            
            # Initialize new_count variable
            new_count = 1
            
            if current_status == "active":
                logger.info(f"Alarm {alarm_key} already active, skipping resend")
                
                # Don't resend until count threshold is reached
                if new_count < RAISE_RESEND_COUNT:
                    _alarm_tracker[alarm_key] = new_count
                    return  # Skip resend
                else:
                    logger.info(f"Alarm {alarm_key} threshold reached, will resend")
            elif isinstance(current_status, int) and current_status > 0:
                # Being processed - increment count and check threshold
                new_count = current_status + 1
                logger.info(f"Alarm {alarm_key} being processed, attempt {new_count}")
                
                # Don't resend until count threshold is reached
                if new_count < RAISE_RESEND_COUNT:
                    _alarm_tracker[alarm_key] = new_count
                    return  # Skip resend
                else:
                    logger.info(f"Alarm {alarm_key} threshold reached, will resend")
            else:
                logger.info(f"Alarm {alarm_key} not active, sending first alarm")
                # new_count is already initialized to 1 above
        
        # Send raise alarm (inside the lock for complete atomicity)
        logger.info(f"Thread {threading.current_thread().name} - Sending raise alarm for {alarm_key} with count {new_count}")
        try:
            alarm_data = create_payload(operator, country, alarm_type, remarks)
            x_api_key = generate_x_api_key(operator, country)
            encrypted_x_api_key = encrypt_text(x_api_key)
            payload_json = json.dumps(alarm_data)
            encrypted_payload = encrypt_text(payload_json)
            headers = {
                'Content-Type': 'application/json',
                'X-API-KEY': encrypted_x_api_key
            }
            
            logger.info(f"Sending RAISE alarm for {alarm_key}: {alarm_type}")
            
            if proxy_ip_notification_agent:
                headers['X-Forwarded-For'] = proxy_ip_notification_agent
            url = f"{notification_agent_base_url}/raise"
            logger.debug(f"Sending alarm to {url} with headers: {headers} and data: {encrypted_payload}")
            async with httpx.AsyncClient(timeout=30, verify=False) as client:
                response = await client.post(
                    url,
                    headers=headers,
                    data=encrypted_payload
                )
            
            if response.status_code == 200:
                # Mark as raised successfully - set status to "active"
                _alarm_tracker[alarm_key] = "active"
                logger.info(f"Alarm {alarm_key} sent successfully and marked as active")
            else:
                logger.debug(f"Failed to send alarm {alarm_key}. Status: {response.status_code}")
                
        except Exception as e:
            logger.warning(f"Exception occurred while sending alarm {alarm_key}: {e}", exc_info=True)
                    
    elif status == "clear":
        # Get the processing lock for this specific alarm key
        processing_lock = get_processing_lock(alarm_key)
        
        # Thread-safe access to alarm tracker using per-key lock
        with processing_lock:
            # Get current status or assume "cleared" if not present
            current_status = _alarm_tracker.get(alarm_key, "cleared")
            
            # Early return if already cleared
            if current_status == "cleared":
                logger.info(f"Alarm {alarm_key} already cleared, skipping")
                return
                
            # Send clear alarm (inside the lock for complete atomicity)
            try:
                alarm_data = create_payload(operator, country, alarm_type, remarks)
                x_api_key = generate_x_api_key(operator, country)
                encrypted_x_api_key = encrypt_text(x_api_key)
                payload_json = json.dumps(alarm_data)
                encrypted_payload = encrypt_text(payload_json)
                headers = {
                    'Content-Type': 'application/json',
                    'X-API-KEY': encrypted_x_api_key
                }
                
                logger.info(f"Sending CLEAR alarm for {alarm_key}")
                
                if proxy_ip_notification_agent:
                    headers['X-Forwarded-For'] = proxy_ip_notification_agent
                url = f"{notification_agent_base_url}/clear"
                async with httpx.AsyncClient(timeout=30, verify=False) as client:
                    response = await client.post(
                        url,
                        headers=headers,
                        data=encrypted_payload
                    )
                
                if response.status_code == 200:
                    # Mark as cleared
                    _alarm_tracker[alarm_key] = "cleared"
                    logger.info(f"Alarm {alarm_key} cleared successfully")
                else:
                    logger.warning(f"Failed to send clear alarm for {alarm_key}. Status: {response.status_code}")
                
            except Exception as e:
                logger.warning(f"Exception occurred while sending clear alarm for {alarm_key}: {e}", exc_info=True)
    else:
        return

def run_alarm_in_thread(coro):
    from service.redis_service import alarm_executor
    def runner():
        import asyncio
        try:
            asyncio.run(coro)
        except Exception as e:
            logger.warning(f"Alarm task failed in thread: {e}", exc_info=True)
    alarm_executor.submit(runner)
       
