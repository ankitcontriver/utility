import concurrent.futures
from datetime import datetime
import json
import os
import re
import time
import traceback
import httpx
from config.filler_prompt import config_language_response
from dotenv import load_dotenv
from openai import OpenAI, AzureOpenAI
import tiktoken
import random
from service.pa_three_tier_service import get_three_tier_service
from service.pa_tts_manager import get_tts_manager
from utils.redis_db_manager import redis_manager
from utils.redis_hash_optimizer import RedisHashOptimizer
from utils.memory_cache_manager import get_user_call_record, set_user_call_record
from logger import get_logger
from models.redis_models import UserCallCDR, UserCallRecord
from models.request_models import MessageResponse
from service.ivr_path_analysis_service import IVRPathAnalysisService
from utils.chat_utils import send_chat_chunk_callback_socket
from utils.function_call_util_functions import execute_function_call
from utils.llm_util import convert_chunk_to_transcript_based_on_voice_code, get_buildup_prompt, \
    generate_transcript_based_on_provider, generate_dynamic_message_id
from utils.utils import append_tool_call_message, append_asst_msg, function_args_check, adjust_messages_length, \
    convert_wav_to_base64, remove_messages_in_range, get_current_time_iso
from utils.function_call_util_functions import disconnect_service
from utils.thread_pool import get_named_thread_pool
from cache.assistant_configuration_cache import get_assistant_details_by_id
import asyncio
from config.ivr_path_config import get_node_type_map
from enums.call_enums import Event, ServiceType
from config.ivr_path_config import build_node_type_map
from utils.alarm_utils import send_alarm
from utils.scalable_cdr_manager import update_cdr_record_with_expiration
from utils.function_call_util_functions import get_cdr_data
from service.multi_client_config_service import (
    multi_client_manager,
    handle_configuration_not_found,
    get_op_co_key
)

load_dotenv()
logger = get_logger(__name__)
base_path = os.getenv("BASE_PATH")
filler_prompt_path = os.getenv("FILLER_AUDIO_PROMPTS_PATH")
client = OpenAI()

# Removed hardcoded azure_deployment_model - now using database-cached model names

def get_llm_client_config_for_request(assistant_id: str) -> tuple:
    """Get appropriate LLM client configuration based on assistant configuration"""
    try:
        logger.info(f"Getting LLM client config for assistant_id: {assistant_id}")
        assistant_config = get_assistant_details_by_id(int(assistant_id))
        if not assistant_config:
            logger.warning(f"No assistant config found for assistant_id: {assistant_id}")
            return None, None

        operator = assistant_config.get('operator')
        country = assistant_config.get('country')
        logger.info(f"Assistant {assistant_id} has operator: {operator}, country: {country}")

        if not operator or not country:
            logger.warning(f"Missing operator/country in assistant config for {assistant_id}")
            return None, None

        op_co = get_op_co_key(operator, country)
        logger.info(f"Looking for multi-client config with op_co: {op_co}")
        client_config = multi_client_manager.get_llm_client(op_co)

        if client_config:
            logger.info(f"Using multi-client for {op_co} (assistant: {assistant_id}) with model: {client_config.model}")
            return client_config.client, client_config.model
        else:
            logger.error(f"No LLM client found for {op_co}")
            return None, None

    except Exception as e:
        logger.error(f"Error getting LLM client config for assistant {assistant_id}: {e}")
        return None, None

# Testing mode configuration
TESTING_MODE = os.getenv("TESTING_MODE", "false").lower() == "true"
MOCK_LLM_URL = os.getenv("MOCK_LLM_URL", "http://localhost:8001")

# Create a mock client for testing
mock_client = None
if TESTING_MODE:
    mock_client = httpx.AsyncClient(base_url=MOCK_LLM_URL, timeout=60.0)
    logger.info(f"TESTING_MODE enabled - using mock LLM API at {MOCK_LLM_URL}")
else:
    logger.info("Production mode - using real Azure OpenAI API")

# Removed hardcoded azure_model_name - now using database-cached model names

# Single Redis client for CDR operations only (DB=2)
redis_client = redis_manager.get_cdr_client()   # CDR operations (DB=2)
# Initialize hash optimizer for efficient CDR operations
cdr_hash_optimizer = RedisHashOptimizer(redis_client)


random_responses = [
    "Sure, just a sec!!",
    "Sure thing, just a sec!",
    "Okay, give me a moment!",
    "Alright, let me check!",
    "Sure, give me a sec!",
    "Sure, hold on a bit!"
]

pa_random_responses=[
    "Your message will be conveyed.",
    "I'll pass along your request.",
    "I'll make sure that gets taken care of.",
    "I'll relay your request.",
    "I'll make sure this gets addressed."
]
# Global variable to store system content
global_system_content = None

# CDR update function now uses scalable implementation for optimal batching

def safe_calculate_moving_average(current_avg: float, new_value: float, count: int, req_id: str = None) -> float:
    """
    Safely calculate moving average with zero division protection
    
    Args:
        current_avg: Current average value
        new_value: New value to add to the average
        count: Total count (question_count)
        req_id: Request ID for logging (optional)
    
    Returns:
        Updated moving average or the new_value if count is 0 or 1
    """
    try:
        if count <= 0:
            logger.warning(f"Zero or negative question_count ({count}) detected for req_id: {req_id}. Using new_value as average.")
            return new_value
        elif count == 1:
            # First calculation, return the new value
            return new_value
        else:
            # Standard moving average formula: ((avg * (n-1)) + new_value) / n
            return ((current_avg * (count - 1)) + new_value) / count
            
    except (ZeroDivisionError, TypeError, ValueError) as e:
        logger.error(f"Error calculating moving average for req_id {req_id}: {e}. Using new_value as fallback.")
        return new_value
    except Exception as e:
        logger.error(f"Unexpected error in moving average calculation for req_id {req_id}: {e}")
        return current_avg if current_avg is not None else new_value

def validate_and_fix_question_count(user_call_cdr_record, req_id: str = None) -> bool:
    """
    Validate and fix CDR record question_count to prevent division by zero
    
    Args:
        user_call_cdr_record: CDR record object
        req_id: Request ID for logging
        
    Returns:
        True if counts were valid, False if they were fixed
    """
    try:
        if hasattr(user_call_cdr_record, 'question_count'):
            if user_call_cdr_record.question_count <= 0:
                logger.warning(f"Invalid question_count ({user_call_cdr_record.question_count}) for req_id: {req_id}. Fixing to 1.")
                user_call_cdr_record.question_count = 1
                return False
        return True
    except Exception as e:
        logger.error(f"Error validating CDR counts for req_id {req_id}: {e}")
        if hasattr(user_call_cdr_record, 'question_count'):
            user_call_cdr_record.question_count = 1
        return False

def validate_and_fix_answer_count(user_call_cdr_record, req_id: str = None) -> bool:
    """
    Validate and fix CDR record answer_count to prevent division by zero
    
    Args:
        user_call_cdr_record: CDR record object
        req_id: Request ID for logging
        
    Returns:
        True if counts were valid, False if they were fixed
    """
    try:
        if hasattr(user_call_cdr_record, 'answer_count'):
            if user_call_cdr_record.answer_count <= 0:
                logger.warning(f"Invalid answer_count ({user_call_cdr_record.answer_count}) for req_id: {req_id}. Fixing to 1.")
                user_call_cdr_record.answer_count = 1
                return False
        return True
    except Exception as e:
        logger.error(f"Error validating CDR counts for req_id {req_id}: {e}")
        if hasattr(user_call_cdr_record, 'question_count'):
            user_call_cdr_record.answer_count = 1
        return False

def check_before_or_after_comma_is_number(s):
    # Use regex to find a digit followed by a comma or a comma followed by a digit
    # pattern = r'\d,|,\d'
    try:
        pattern = r'\d[,.]|[,.]\d'
        match = re.search(pattern, s)
        return bool(match)
    except Exception as e:
        logger.error(f"Error in check_before_or_after_comma_is_number: {e}", exc_info=True)
        return False


def extract_json_from_code_block(text):
    if not text:
        return ""
    
    # First try to find JSON in code blocks
    match = re.search(r"```(?:json)?\s*\n?([\s\S]*?)```", text)
    if match:
        return match.group(1).strip()
    
    # If no code block found, try to find JSON-like content
    # Look for content that starts with { and ends with }
    json_match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', text)
    if json_match:
        return json_match.group(0).strip()
    
    # If still no match, return the original text stripped
    return text.strip()


async def call_mock_llm_api(mock_client: httpx.AsyncClient, gpt_obj: dict, user_obj: dict):
    """Call the mock LLM API and return a response compatible with OpenAI format"""
    try:
        call_id = user_obj["callId"]
        logger.info(f"{call_id} Using mock LLM API for testing")

        # Prepare the request for mock API
        mock_request = {
            "model": gpt_obj["model"],
            "messages": gpt_obj["messages"],
            "stream": gpt_obj.get("stream", True),
            "temperature": gpt_obj.get("temperature", 0.4)
            # Note: Intentionally excluding tools to bypass function calls in testing
        }

        if not mock_request["stream"]:
            # Non-streaming request (for SMART_IVR)
            response = await mock_client.post("/chat/completions", json=mock_request)
            response.raise_for_status()
            return MockNonStreamingResponse(response.json())
        else:
            # Streaming request - collect all chunks first
            async with mock_client.stream("POST", "/chat/completions", json=mock_request) as response:
                response.raise_for_status()

                # Process the streaming response and collect all chunks
                chunks = []
                async for line in response.aiter_lines():
                    line = line.decode('utf-8') if isinstance(line, bytes) else line
                    if line.startswith("data: "):
                        data = line[6:]  # Remove "data: " prefix
                        if data.strip() == "[DONE]":
                            break
                        try:
                            chunk_data = json.loads(data)
                            chunks.append(MockChunk(chunk_data))
                        except json.JSONDecodeError:
                            continue

                return MockStreamingResponseSync(chunks)

    except Exception as e:
        logger.error(f"{call_id} Error calling mock LLM API: {e}")
        raise


# Mock response classes to match OpenAI API structure
class MockNonStreamingResponse:
    """Mock response object that mimics OpenAI non-streaming response"""
    def __init__(self, response_data: dict):
        self.choices = [MockChoice(choice) for choice in response_data["choices"]]
        self.usage = MockUsage(response_data.get("usage"))


class MockChoice:
    def __init__(self, choice_data: dict):
        self.message = MockMessage(choice_data["message"])


class MockMessage:
    def __init__(self, message_data: dict):
        self.content = message_data["content"]


class MockUsage:
    def __init__(self, usage_data: dict = None):
        if usage_data is None:
            # Handle case where usage_data is None
            self.prompt_tokens = 0
            self.completion_tokens = 0
            self.prompt_tokens_details = MockPromptTokensDetails({})
        else:
            self.prompt_tokens = usage_data.get("prompt_tokens", 0)
            self.completion_tokens = usage_data.get("completion_tokens", 0)
            self.prompt_tokens_details = MockPromptTokensDetails(usage_data.get("prompt_tokens_details", {}))


class MockPromptTokensDetails:
    def __init__(self, details: dict = None):
        if details is None:
            self.cached_tokens = 0
        else:
            self.cached_tokens = details.get("cached_tokens", 0)


class MockStreamingResponseSync:
    """Simple mock streaming response that works with sync iteration"""
    def __init__(self, chunks):
        self.chunks = chunks

    def __iter__(self):
        """Regular iterator for sync context"""
        return iter(self.chunks)


class MockChunk:
    """Mock chunk object that mimics OpenAI streaming chunk"""
    def __init__(self, chunk_data: dict):
        self.choices = [MockChunkChoice(choice) for choice in chunk_data["choices"]]
        # Always create MockUsage, but pass None if no usage data (MockUsage handles this)
        self.usage = MockUsage(chunk_data.get("usage"))


class MockChunkChoice:
    def __init__(self, choice_data: dict):
        self.delta = MockDelta(choice_data["delta"])


class MockDelta:
    def __init__(self, delta_data: dict):
        self.content = delta_data.get("content")
        self.tool_calls = delta_data.get("tool_calls")  # Always None for testing mode



async def handle_three_tier_service(user_query: str, user_obj: dict, gpt_obj: dict, azure_client, model_name: str):
    """
    Handle 3-tier service for PA calls.
    
    Args:
        user_query: User's query string
        user_obj: User call record object
        gpt_obj: GPT request object
        azure_client: Azure OpenAI client
        model_name: Model name
        
    Returns:
        tuple: (response, tier_used, complete_string, function_name, function_args, cached_wav_path)
    """
    try:
        # Get 3-tier service
        three_tier_service = get_three_tier_service()
        if not three_tier_service:
            logger.warning("3-tier service not available, using normal LLM flow")
            response = azure_client.chat.completions.create(**gpt_obj)
            return response, None, None, None, None
        
        # Extract call context
        call_id = user_obj["callId"]
        assistant_id = user_obj["assistantId"]
        service_type = user_obj["serviceType"]
        voice_code = user_obj["voiceCode"]
        voice_name = user_obj["voiceName"]  # Complete voice name (e.g., 'hi-IN-SwaraNeural')
        tts_style = user_obj["ttsStyle"]
        provider = user_obj["provider"]
        gender = user_obj["gender"]
        is_translate = user_obj["isTranslate"]
        
        # Extract system prompt from gpt_obj
        system_prompt = ""
        if gpt_obj.get('messages') and len(gpt_obj['messages']) > 0:
            for msg in gpt_obj['messages']:
                if msg.get('role') == 'system':
                    system_prompt = msg.get('content', '')
                    break
        
        # Process through 3-tier service
        three_tier_result = await three_tier_service.process_query(
            user_query=user_query,
            call_context={
                "call_id": str(call_id) if call_id is not None else "",
                "assistant_id": str(assistant_id) if assistant_id is not None else "",
                "service_type": str(service_type) if service_type is not None else "Personal_Assistant",
                "voice_code": str(voice_code) if voice_code is not None else "",
                "voice_name": str(voice_name) if voice_name is not None else "",
                "tts_style": str(tts_style) if tts_style is not None else "",
                "provider": str(provider) if provider is not None else "",
                "gender": str(gender) if gender is not None else "",
                "is_translate": bool(is_translate) if is_translate is not None else False,
                "llm_client": azure_client,
                "model_name": model_name,
                "system_prompt": system_prompt,
                "messages": gpt_obj.get('messages', [])  # Include full conversation history
            },
            assistant_id=assistant_id,
            call_id=call_id,
            llm_client=azure_client
        )
        
        if three_tier_result:
            response = three_tier_result.get('response')
            tier_used = three_tier_result.get('tier_used')
            complete_string = three_tier_result.get('complete_string')
            function_name = three_tier_result.get('function_name')
            function_args = three_tier_result.get('function_args')
            confidence_score = three_tier_result.get('confidence_score', 0.0)
            
            logger.info(f"3-tier result: Tier {tier_used}, Function: {function_name}, Confidence: {confidence_score}, Complete String: '{complete_string[:50] if complete_string else 'None'}...'")
            logger.debug(f"Full three_tier_result: {three_tier_result}")
            
            # Handle Tier 1 direct cache hits
            if tier_used == 1:
                logger.info(f"Using cached response from Tier {tier_used}")
                cached_wav_path = three_tier_result.get('cached_wav_path')
                if cached_wav_path:
                    logger.info(f"Using cached TTS file: {cached_wav_path}")
                # Return the actual response text instead of None to prevent build-up prompt
                return None, tier_used, three_tier_result.get('response', ''), function_name, function_args, cached_wav_path
            
            # Handle Tier 2 cached responses (use_cached function call)
            elif tier_used == 2 and function_name == 'use_cached':
                logger.info(f"Using cached response from Tier {tier_used}")
                return None, tier_used, complete_string, function_name, function_args, None
            
            # Handle Tier 2 fresh generation
            elif tier_used == 2 and function_name == 'fresh_generation':
                logger.info(f"Tier 2 fresh generation: {function_name}")
                return None, tier_used, complete_string, function_name, function_args, None
            
            # Handle Tier 2 other function calls
            elif tier_used == 2 and function_name and function_name not in ['use_cached', 'fresh_generation']:
                logger.info(f"Tier 2 function call: {function_name}")
                return None, tier_used, complete_string, function_name, function_args, None
            
            # Handle Tier 3 function calls (disconnect_service, handle_telemarketing_call, fresh_generation)
            elif tier_used == 3 and function_name:
                logger.info(f"Tier 3 function call: {function_name}")
                return None, tier_used, complete_string, function_name, function_args, None
            
            # Handle Tier 3 fresh generation (no function call, just content)
            elif tier_used == 3 and complete_string:
                logger.info(f"Tier {tier_used} fresh generation - using fresh_generation function call")
                return None, tier_used, complete_string, 'fresh_generation', json.dumps({'response': complete_string}), None
            
            # Handle Tier 2 fresh generation and other cases
            elif response is not None:
                logger.info(f"Tier {tier_used} fresh generation - proceeding with streaming")
                return response, tier_used, None, None, None, None
            elif tier_used == 3:
                logger.warning(f"Tier 3 returned empty complete_string, using normal LLM flow")
                response = azure_client.chat.completions.create(**gpt_obj)
                return response, None, None, None, None, None
            else:
                logger.warning("Unexpected 3-tier result, using normal LLM flow")
                response = azure_client.chat.completions.create(**gpt_obj)
                return response, None, None, None, None, None
        else:
            logger.warning("3-tier service returned None, using normal LLM flow")
            response = azure_client.chat.completions.create(**gpt_obj)
            return response, None, None, None, None, None
            
    except Exception as e: 
        logger.error(f"Error in 3-tier service handling: {e}")
        # Fallback to normal LLM flow
        response = azure_client.chat.completions.create(**gpt_obj)
        return response, None, None, None, None, None


async def handle_smart_ivr_processing(response, user_obj, req_id, currentMessageId, provider, gender, 
                                     voice_code, call_id, tts_style, language, assistant_id, tts_manager, response_id):
    """
    Handle SMART_IVR service processing logic.
    
    Args:
        response: LLM response object
        user_obj: User call record object
        req_id: Request ID
        currentMessageId: Current message ID
        provider: TTS provider
        gender: Voice gender
        voice_code: Voice code
        call_id: Call ID
        tts_style: TTS style
        language: Language
        assistant_id: Assistant ID
        tts_manager: TTS manager instance
        response_id: Response ID
        
    Returns:
        tuple: (complete_response, function_name, function_arguments, function_id, prompt_tokens, completion_tokens, cached_tokens)
    """
    try:
            # Handle non-streaming response
            currentNodeId = user_obj["current_node_id"]
            logger.info(f"getting next node_id from llm for current_node_id, {currentNodeId}")
            complete_response = response.choices[0].message.content
            if not complete_response:
                logger.error(f"Empty response from LLM for req_id {req_id}")
                return None, None, None, None, 0, 0, 0
            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
            # When parsing the LLM response:
            cleaned_response = extract_json_from_code_block(complete_response)
            try:
                response_dict = json.loads(cleaned_response)
                # Now you can extract node_id as before
                node_id = response_dict.get("node_id")
            except json.JSONDecodeError as json_error:
                logger.error(f"Failed to parse LLM response as JSON for req_id {req_id}: {json_error}")
                logger.error(f"Cleaned response: {cleaned_response}")
                # Return a default response indicating parsing failure
                return complete_response, None, None, None, 0, 0, 0

            # Ensure response_dict is properly defined
            if not response_dict:
                logger.error(f"Empty response_dict for req_id {req_id}")
                return complete_response, None, None, None, 0, 0, 0

            user_input = response_dict.get("user_input")
            input_confirmed = response_dict.get("input_confirmed")
            response_json = {}  # Initialize response_json

            # Check if node_id contains comma-separated node IDs
            if node_id and ',' in str(node_id):
                logger.info(f"Found multiple node IDs in LLM response: {node_id}")
                node_ids = [nid.strip() for nid in str(node_id).split(',')]
                clarification_message = response_dict.get("clarification_message")
                if clarification_message:
                    logger.info(f"Processing confirmation message for node IDs {node_ids}: {clarification_message}")
                    
                    # Search for existing clarification message with clarification message + node ID matching
                    cached_wav_path = None
                    cached_clarification_message = None
                    try:
                        from service.pa_vector_manager import get_vector_manager
                        vector_manager = get_vector_manager()
                        
                        if vector_manager:
                            # Search by clarification message for better semantic matching
                            existing_clarifications = await vector_manager.search_similar_queries(
                                query=clarification_message,  # Search by actual clarification message
                                top_k=10,  # Get more results to find exact match
                                service_type="SMART_IVR",
                                voice_name=voice_code
                            )
                            
                            # Find match with both clarification message similarity AND exact node ID match
                            exact_match = None
                            if existing_clarifications and len(existing_clarifications) > 0:
                                for clarification in existing_clarifications:
                                    metadata = clarification.get('metadata', {})
                                    stored_node_ids = metadata.get('node_ids', [])
                                    stored_clarification = metadata.get('response', '')
                                    confidence = clarification.get('confidence', 0.0)
                                    
                                    # Check for exact node ID match (order doesn't matter)
                                    if set(node_ids) == set(stored_node_ids):
                                        # Additional check: clarification message should be semantically similar
                                        if confidence >= 0.75:  # Hardcoded threshold for clarification message similarity
                                            exact_match = clarification
                                            logger.info(f"Found exact match: node_ids {node_ids} == {stored_node_ids}, clarification similarity: {confidence:.2f}")
                                            break
                                        else:
                                            logger.debug(f"Node IDs match but clarification message similarity too low: {confidence:.2f} < 0.75")
                                    else:
                                        logger.debug(f"Node IDs don't match: {node_ids} != {stored_node_ids}")
                            
                            if exact_match:
                                metadata = exact_match.get('metadata', {})
                                cached_wav_path = metadata.get('tts_file_path', '')
                                cached_clarification_message = metadata.get('response', '')
                                
                                if cached_wav_path and cached_wav_path.strip():
                                    logger.info(f"Found exact clarification match for node IDs {node_ids}, reusing cached TTS: {cached_wav_path}")
                                    
                                    # Send the cached clarification message
                                    message_response = MessageResponse(
                                        callId=call_id,
                                        chunk=cached_clarification_message,
                                        isEndChunk=False,
                                        transcript=cached_wav_path,
                                        messageId=messageId,
                                        eventType=""
                                    )
                                    await send_chat_chunk_callback_socket(
                                        sid=user_obj["socketId"],
                                        data=message_response.dict()
                                    )
                                    
                                    # Send end chunk
                                    message_response = MessageResponse(
                                        callId=call_id,
                                        chunk="",
                                        isEndChunk=True,
                                        transcript="",
                                        messageId=messageId,
                                        eventType=""
                                    )
                                    await send_chat_chunk_callback_socket(
                                        sid=user_obj["socketId"],
                                        data=message_response.dict()
                                    )
                                    
                                    # Use first node_id and return
                                    node_id = node_ids[0]
                                    user_obj["currentNodeId"] = node_id
                                    set_user_call_record(str(req_id), user_obj)
                                    return complete_response, None, None, None, response.usage.prompt_tokens, response.usage.completion_tokens, response.usage.prompt_tokens_details.cached_tokens
                                        
                    except Exception as e:
                        logger.error(f"Error searching for existing clarification message: {e}")
                    
                    # If no cached clarification found, proceed with generating new one
                    logger.info(f"No existing clarification found for node IDs {node_ids}, generating new TTS")
                    
                    # Generate audio for clarification_message
                    audio_msg = generate_transcript_based_on_provider(provider, gender, clarification_message, voice_code, call_id, tts_style, language, assistant_id)
                    
                    # Convert TTS chunk to WAV file for ALL services
                    wav_path = None
                    if tts_manager and response_id:
                        try:
                            wav_path = await tts_manager.convert_chunk_to_wav(
                                base64_chunk=audio_msg,
                                call_id=call_id,
                                response_id=response_id
                            )
                            # Update transcript to send WAV path instead of base64
                            audio_msg = wav_path
                            logger.debug(f"Converted clarification_message TTS chunk to WAV: {wav_path}")
                        except Exception as e:
                            logger.error(f"Failed to convert clarification_message TTS chunk to WAV: {e}")
                            # Fallback to original transcript
                    
                    # Store clarification message metadata for vector DB storage at call_end
                    if clarification_message and wav_path:
                        try:
                            # Extract user query from messages
                            user_query = ""
                            messages = user_obj.get("llmMessage", [])
                            if messages:
                                for message in reversed(messages):
                                    if message.get("role") == "user":
                                        user_query = message.get("content", "")
                                        break
                            
                            # Create metadata for caching (same structure as fresh_generation)
                            searchable_query = f"Multiple node selection: {', '.join(node_ids)}"
                            clarification_metadata = {
                                "assistant_id": str(assistant_id),
                                "call_id": str(call_id),
                                "service_type": "SMART_IVR",  # SMART_IVR service type
                                "voice_code": voice_code,
                                "tts_style": tts_style,
                                "provider": user_obj.get("provider", ""),
                                "gender": user_obj.get("gender", ""),
                                "is_translate": user_obj.get("isTranslate", False),
                                "response_id": f"clarification_{int(time.time() * 1000)}",
                                "tier_used": 3,
                                "confidence_score": 0.8,  # Perfect confidence for exact clarification messages  
                                "generation_time": 0.0,
                                "token_usage": {
                                    "prompt_tokens": 0,
                                    "completion_tokens": 0,
                                    "total_tokens": 0
                                },
                                "model_name": user_obj.get("llmModel", "gpt-4"),  # Use actual model name from user_obj
                                "query": searchable_query,  # Searchable query
                                "response": clarification_message,
                                "tts_file_path": wav_path if wav_path else "",  # Use actual WAV path if available
                                "timestamp": time.time(),
                                "node_ids": node_ids,  # Store the comma-separated node IDs
                                "function_name": None
                            }
                            
                            # Add to vector metadata cache
                            if "vector_metadata_cache" not in user_obj:
                                user_obj["vector_metadata_cache"] = []
                            
                            user_obj["vector_metadata_cache"].append(clarification_metadata)
                            
                            # Update user call record in memory cache
                            set_user_call_record(str(req_id), user_obj)
                            
                            logger.info(f"Cached clarification message metadata for call end storage: {call_id} with {len(node_ids)} node IDs")
                            
                        except Exception as e:
                            logger.error(f"Failed to cache clarification message metadata: {e}")
                    
                    # Send the audio message through socket
                    message_response = MessageResponse(
                        callId=call_id,
                        chunk=clarification_message,
                        isEndChunk=False,
                        transcript=audio_msg,
                        messageId=messageId,
                        eventType=""
                    )
                    logger.info(f"{call_id} Sending matched_text audio -> {message_response.__repr__()}")
                    await send_chat_chunk_callback_socket(
                        sid=user_obj["socketId"],
                        data=message_response.dict()
                    )
                    
                    # Send end chunk to signify completion
                    message_response = MessageResponse(
                        callId=call_id,
                        chunk="",
                        isEndChunk=True,
                        transcript="",
                        messageId=messageId,
                        eventType=""
                    )
                    await send_chat_chunk_callback_socket(
                        sid=user_obj["socketId"],
                        data=message_response.dict()
                    )
                    
                    # Use the first node_id for further processing
                    node_id = node_ids[0]
                    logger.info(f"Using first node_id for further processing: {node_id}")
                    user_obj["currentNodeId"] = node_id
                    set_user_call_record(str(req_id), user_obj)
                    return complete_response, None, None, None, response.usage.prompt_tokens, response.usage.completion_tokens, response.usage.prompt_tokens_details.cached_tokens

                else:
                    logger.warning(f"No clarification_message found for comma-separated node IDs: {node_ids}")
                    # Use the first node_id for further processing
                    node_id = node_ids[0]

            if len(user_input) > 0 and input_confirmed == "":
                logger.info(f"got input: {user_input} from user for current_node_id, {currentNodeId}")
                node_id = currentNodeId
                confirmation_message = response_dict.get("confirmation_message")
                if confirmation_message:
                    # Generate audio for confirmation message
                    audio_msg = generate_transcript_based_on_provider(provider, gender, confirmation_message, voice_code, call_id, tts_style, language, assistant_id)
                    
                    # Convert TTS chunk to WAV file for ALL services
                    if tts_manager and response_id:
                        try:
                            wav_path = await tts_manager.convert_chunk_to_wav(
                                base64_chunk=audio_msg,
                                call_id=call_id,
                                response_id=response_id
                            )
                            # Update transcript to send WAV path instead of base64
                            audio_msg = wav_path
                            logger.debug(f"Converted confirmation TTS chunk to WAV: {wav_path}")
                        except Exception as e:
                            logger.error(f"Failed to convert confirmation TTS chunk to WAV: {e}")
                            # Fallback to original transcript
                    
                    # Send the audio message through socket like other TTS chunks
                    message_response = MessageResponse(
                        callId=call_id,
                        chunk=confirmation_message,
                        isEndChunk=False,
                        transcript=audio_msg,
                        messageId=messageId,
                        eventType=""
                    )
                    logger.info(f"{call_id} Sending confirmation audio -> {message_response.__repr__()}")
                    await send_chat_chunk_callback_socket(
                        sid=user_obj["socketId"],
                        data=message_response.dict()
                    )
                    
                    # Send end chunk to signify completion
                    message_response = MessageResponse(
                        callId=call_id,
                        chunk="",
                        isEndChunk=True,
                        transcript="",
                        messageId=messageId,
                        eventType=""
                    )
                    await send_chat_chunk_callback_socket(
                        sid=user_obj["socketId"],
                        data=message_response.dict()
                    )
                
                return complete_response, None, None, None, response.usage.prompt_tokens,response.usage.completion_tokens,response.usage.prompt_tokens_details.cached_tokens


            logger.info(f"next node_id received from llm, {node_id}")

            # Get nodes data early since it's needed in multiple code paths
            try:
                path_finder_flat_array_json = get_assistant_details_by_id(user_obj["assistantId"])["path_finder_json"]
                flat_array = json.loads(path_finder_flat_array_json)
                nodes = flat_array["nodes"]
            except (KeyError, json.JSONDecodeError) as e:
                logger.error(f"Failed to get or parse path_finder_json for assistant {user_obj['assistantId']}: {e}")
                return complete_response, None, None, None, 0, 0, 0

            if str(node_id) == "-1":
                response_json = {
                    "node_id": currentNodeId,
                    "action": "RETRY",
                    "isSmartIvrEnabled": True,
                    "input": ""
                }
            elif input_confirmed == "success":
                logger.info(f'got confirmation for input: {user_input} from user for current_node_id, {currentNodeId}')
                next_dc_node_id = IVRPathAnalysisService.get_next_dc_node_id(nodes,currentNodeId)
                logger.info(f'Next DigitCollection node_id: {next_dc_node_id} for current_node_id: {currentNodeId}')
                response_json = {
                    "node_id": next_dc_node_id,
                    "action": "DIGITCOLLECT",
                    "isSmartIvrEnabled": True,
                    "input": user_input
                }
            elif input_confirmed == "failure":
                logger.info(f'input: {user_input} not confirmed from user for current_node_id, {currentNodeId}')
                response_json = {
                    "node_id": currentNodeId,
                    "action": "PLAY",
                    "isSmartIvrEnabled": False,
                    "input": ""
                }
            else:
                path_with_all_non_skippables = IVRPathAnalysisService.find_all_paths(nodes, node_id)

                user_last_path = user_obj["user_path"]
                
                node_map = build_node_type_map(nodes)

                logger.info(f"path with non-skippables, {path_with_all_non_skippables} from current_node_id, {currentNodeId}, to next_node_id, {node_id}")
                next_node_id, final_path = IVRPathAnalysisService.get_node_before_next_non_skippable_with_history(path_with_all_non_skippables,user_last_path, currentNodeId, node_map)
                

                # Prepare the response JSON based on next_node_id
                logger.info(f"final path , {final_path} and next_node_id, {next_node_id}")

                user_obj["user_path"] = '->'.join(f"'{nid}'" if not node_map.get(nid, {}).get('is_skippable', True) else str(nid) for nid in final_path)
                response_json = {
                    "node_id": next_node_id,
                    "action": "PLAY",
                    "isSmartIvrEnabled": True,
                    "input": ""
                }
            
            # Check if response_json is empty
            if not response_json:
                logger.warning(f"{call_id} response_json is empty, skipping socket message. node_id: {node_id}, input_confirmed: {input_confirmed}, user_input: {user_input}")
                # Update current_node_id even if no response to send
                user_obj["currentNodeId"] = node_id
                # Serialize back to JSON string
                # PERFORMANCE FIX: Update user call record in memory instead of Redis
                set_user_call_record(str(req_id), user_obj)
                return complete_response, None, None, None, response.usage.prompt_tokens,response.usage.completion_tokens,response.usage.prompt_tokens_details.cached_tokens

            response_str = json.dumps(response_json)

            # Send the complete response in the chunk
            message_response = MessageResponse(
                callId=call_id,
                chunk=response_str,  # Send the stringified JSON as the chunk
                isEndChunk=True,
                transcript="",
                messageId=messageId,
                eventType=ServiceType.SMART_IVR.value
            )
            logger.info(f"{call_id} Sending response -> {message_response.__repr__()}")
            await send_chat_chunk_callback_socket(
                sid=user_obj["socketId"],
                data=message_response.dict()
            )
            # Update current_node_id
            user_obj["currentNodeId"] = node_id

            # PERFORMANCE FIX: Update user call record in memory instead of Redis
            set_user_call_record(str(req_id), user_obj)
            return complete_response, None, None, None, response.usage.prompt_tokens,response.usage.completion_tokens,response.usage.prompt_tokens_details.cached_tokens

    except Exception as e:
        logger.error(f"Error in SMART_IVR processing: {e}")
        return None, None, None, None, 0, 0, 0


async def call_gpt_stream(model_name: str, req_id: str, is_function_call=False):
    logger.secure(f"call_gpt_stream called for {req_id}")
    
    # Tiktoken encoding will be set after getting model from database configuration
    # PERFORMANCE FIX: Use helper function for CDR retrieval
    cdr_data = get_cdr_data(req_id)
    if not cdr_data:
        logger.info(f"No CDR data found in Redis for req_id: {req_id}")
        return None, None, None, None, 0, 0, 0

    # Get TTS Manager (auto-initializes if needed)
    tts_manager = get_tts_manager()
    response_id = None
        

    try:
        function_id = ""
        # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
        user_obj = get_user_call_record(str(req_id))
        if user_obj is None:
            logger.info(f"User call record not found in memory for req_id: {req_id}")
            return None, None, None, None, 0, 0, 0
        user_messages = user_obj["llmMessage"]
        call_id = user_obj["callId"]
        event_type = user_obj["eventType"]
        currentMessageId = user_obj["currentMessageId"]
        assistant_id = user_obj["assistantId"]
        tts_style = user_obj["ttsStyle"]
        voice_code = user_obj["voiceCode"]
        is_translate = user_obj["isTranslate"]
        provider = user_obj["provider"]
        gender = user_obj["gender"]
        service_type = user_obj["serviceType"]
        chunk_timestamp = time.time()

        # Generate response ID for this call (all services)
        if tts_manager:
            response_id = f"resp_{int(datetime.now().timestamp() * 1000)}"
            logger.info(f"Generated response_id {response_id} for call {call_id}")

        # Get model name from database configuration instead of hardcoded values
        azure_client, db_model_name = get_llm_client_config_for_request(str(assistant_id))

        # Handle tiktoken encoding based on database model name
        if db_model_name and db_model_name.startswith("gpt-4.1-mini"):
            encoding = tiktoken.get_encoding("o200k_base")
        elif db_model_name:
            try:
                encoding = tiktoken.encoding_for_model(db_model_name)
            except KeyError:
                logger.warning(f"Unknown model {db_model_name} for tiktoken, using default encoding")
                encoding = tiktoken.get_encoding("cl100k_base")  # Default for GPT-4
        else:
            logger.warning("No model name available, using default tiktoken encoding")
            encoding = tiktoken.get_encoding("cl100k_base")  # Default for GPT-4

        # Use database cached model name or fallback to user object or default
        model_name = db_model_name or user_obj["llmModel"] or "gpt-4"
        tools = user_obj["tools"]
        language = user_obj["languageCode"]
        gpt_response_stream = user_obj["gpt_response_stream"]
        gpt_obj = {
            "model": model_name,
            "messages": user_messages,
            "stream": gpt_response_stream
        }

        if is_function_call:
            gpt_obj = {
                "model": model_name,
                "messages": user_messages,
                "stream": gpt_response_stream
            }
        elif not is_function_call and tools:
            # Extract tools_supported array from tools object
            tools_array = tools.get("tools_supported", []) if isinstance(tools, dict) else tools
            gpt_obj = {"model": model_name, "messages": user_messages, "stream": gpt_response_stream, "tools": tools_array,
                       "tool_choice": "auto", "temperature": 0.4}

        logger.debug(f"{call_id} tools: {tools}, final gpt object: {gpt_obj}")
        try:
            if TESTING_MODE and mock_client:
                # Use mock LLM API in testing mode
                response = await call_mock_llm_api(mock_client, gpt_obj, user_obj)
                logger.info(f"{call_id} Mock API response received")
            else:
                # Check if 3-tier service should be used for PA
                three_tier_enabled = os.getenv('THREE_TIER_LLM_ENABLED', 'false').lower() == 'true'
                
                if three_tier_enabled:
                    logger.info(f"Using 3-tier service for service type: {service_type}")
                    
                    # Extract user query from messages
                    user_query = ""
                    if user_messages and len(user_messages) > 0:
                        for message in reversed(user_messages):
                            if message.get("role") == "user":
                                user_query = message.get("content", "")
                                break
                    
                    if user_query:
                        # Handle 3-tier service
                        logger.info(f"3-tier service processing query: '{user_query[:50]}...'")
                        response, tier_used, complete_string, function_name, function_args, cached_wav_path = await handle_three_tier_service(
                            user_query, user_obj, gpt_obj, azure_client, model_name
                        )
                        
                        # Return the result - function calling system will handle it
                        return complete_string, function_name, function_args, None, 0, 0, 0
                    else:
                        logger.warning("No user query found, using normal LLM flow")
                        response = azure_client.chat.completions.create(**gpt_obj)
                else:
                    # Use the Azure OpenAI client obtained from multi-client configuration
                    response = azure_client.chat.completions.create(**gpt_obj)
                    logger.info(f"Complete Response from Azure API for assistant {assistant_id} using model {model_name}")
                    
                    # Cache metadata for fresh learning regardless of 3-tier flag
                    try:
                        # Extract user query from messages
                        user_query = ""
                        if user_messages and len(user_messages) > 0:
                            for message in reversed(user_messages):
                                if message.get("role") == "user":
                                    user_query = message.get("content", "")
                                    break
                        
                        if user_query and service_type == ServiceType.PA.value:
                            # Create metadata for caching
                            metadata = {
                                "assistant_id": str(assistant_id),
                                "call_id": str(call_id),
                                "service_type": "Personal_Assistant",
                                "voice_code": user_obj.get("voiceCode", "en-US-AvaNeural"),
                                "voice_name": user_obj.get("voiceName", "en-US-AvaNeural"),
                                "tts_style": user_obj.get("ttsStyle", "chat"),
                                "provider": user_obj.get("provider", ""),
                                "gender": user_obj.get("gender", ""),
                                "is_translate": user_obj.get("isTranslate", False),
                                "response_id": f"resp_{int(time.time() * 1000)}",
                                "tier_used": 0,  # Standard LLM processing
                                "confidence_score": 0.8,  # Default confidence for fresh generation
                                "generation_time": 0.0,
                                "function_name": None,  # Normal generation, no function call
                                "token_usage": {
                                    "prompt_tokens": 0,
                                    "completion_tokens": 0,
                                    "total_tokens": 0
                                },
                                "llm_client": None,  # Will be set by the service
                                "model_name": model_name,
                                "query": user_query,
                                "response": "",  # Will be updated when response is generated
                                "tts_file_path": "",  # Will be updated when TTS is generated
                                "timestamp": time.time()
                            }
                            
                            # Add to vector metadata cache
                            if "vector_metadata_cache" not in user_obj:
                                user_obj["vector_metadata_cache"] = []
                            
                            user_obj["vector_metadata_cache"].append(metadata)
                            
                            # Update user call record in memory cache
                            from utils.memory_cache_manager import set_user_call_record
                            set_user_call_record(str(call_id), user_obj)
                            
                            logger.info(f"Cached standard LLM metadata for call end storage: {call_id}")
                    except Exception as e:
                        logger.error(f"Failed to cache standard LLM metadata: {e}")


            await send_alarm(alarm_type='Azure_OpenAI_API', remarks=f"{'Mock' if TESTING_MODE else 'Multi-client Azure'} OpenAI API working fine", status='clear', assistant_id=user_obj.get('assistantId'))
        except Exception as e:
            await send_alarm(alarm_type='Azure_OpenAI_API', remarks=str(e), status='raise', assistant_id=user_obj.get('assistantId'))
            raise


        if user_obj["serviceType"] == ServiceType.SMART_IVR.value:
            return await handle_smart_ivr_processing(
                response, user_obj, req_id, currentMessageId, provider, gender, 
                voice_code, call_id, tts_style, language, assistant_id, tts_manager, response_id
            )


        function_name = None
        function_arguments = ''
        continious_string = ""
        complete_string = ""
        count = 1
        for chunk in response:
            # Fetch CDR data from Redis
            call_cdr_key = f"{req_id}_cdr"
            # PERFORMANCE FIX: Use helper function for CDR retrieval
            cdr_data = get_cdr_data(req_id)
            if not cdr_data:
                return None, None, None, None, 0, 0, 0
            user_call_cdr_record = UserCallCDR(**cdr_data)

            # Safe access to chunk content - check if choices and content exist
            current_chunk_content = None
            if (chunk.choices and len(chunk.choices) > 0 and
                chunk.choices[0].delta and
                hasattr(chunk.choices[0].delta, 'content')):
                current_chunk_content = chunk.choices[0].delta.content

            logger.debug(f"average output token are {user_call_cdr_record.avg_output_token} for call id {req_id} and question count is {user_call_cdr_record.question_count}")
                
            # Check if chunk.usage is None before accessing tokens
            if chunk.usage:
                user_call_cdr_record.total_input_token += chunk.usage.prompt_tokens
                user_call_cdr_record.total_output_token += chunk.usage.completion_tokens
                
                # Validate question_count to prevent zero division
                validate_and_fix_question_count(user_call_cdr_record, req_id)
                
                # Safe calculation for avg_input_token
                user_call_cdr_record.avg_input_token = safe_calculate_moving_average(
                    current_avg=user_call_cdr_record.avg_input_token,
                    new_value=chunk.usage.prompt_tokens,
                    count=user_call_cdr_record.question_count,
                    req_id=req_id
                )
                
                # Safe calculation for avg_output_token
                user_call_cdr_record.avg_output_token = safe_calculate_moving_average(
                    current_avg=user_call_cdr_record.avg_output_token,
                    new_value=chunk.usage.completion_tokens,
                    count=user_call_cdr_record.question_count,
                    req_id=req_id
                )
            else:
                # Log if chunk.usage is None and skip token updates
                # Note: encoding is already set at the beginning of function based on database model

                # Debug invalid messages
                for message in user_messages:
                    if "content" not in message or not isinstance(message["content"], str):
                        logger.debug(f"Skipping invalid message: {message}")

                # Safely compute input tokens
                input_tokens = len(encoding.encode(str(message["content"]))) 
                logger.debug(f"input token are {input_tokens} for call id {req_id}")
                user_call_cdr_record.total_input_token += input_tokens
                logger.debug(f"total input token are {user_call_cdr_record.total_input_token} for call id {req_id}")
                
                # Validate question_count to prevent zero division
                validate_and_fix_question_count(user_call_cdr_record, req_id)
                
                # Safe calculation for avg_input_token (CRITICAL FIX FOR ERROR SOURCE)
                user_call_cdr_record.avg_input_token = safe_calculate_moving_average(
                    current_avg=user_call_cdr_record.avg_input_token,
                    new_value=input_tokens,
                    count=user_call_cdr_record.question_count,
                    req_id=req_id
                )
                logger.debug(
                    f"{call_id} chunk.usage is None, skipping token usage updates. "
                    f"Average input token: {user_call_cdr_record.avg_input_token}call id: {req_id}, question count: {user_call_cdr_record.question_count}"
                )
            # Batch CDR updates - only update every 3 chunks or on special conditions
            should_update = (count == 1 or count % 3 == 0 or chunk.usage is not None)
            if should_update:
                update_cdr_record_with_expiration(req_id, user_call_cdr_record)
            tts_time = time.time()
            # Log chunk content for debugging - safe access
            if (chunk.choices and len(chunk.choices) > 0 and
                chunk.choices[0].delta and
                hasattr(chunk.choices[0].delta, 'content')):
                chunk_content = chunk.choices[0].delta.content
                logger.debug(f"{call_id} chunk content -> {chunk_content},chunk content repr -> {chunk_content.__repr__()}")
            else:
                logger.debug(f"{call_id} chunk has no content or invalid structure")

            # Check if the user has interrupted the call
            # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
            user_obj = get_user_call_record(str(req_id))
            if user_obj is None:
                return None, None, None, None, 0, 0, 0
            if user_obj["interrupt"]:
                logger.info(f"{call_id} interrupted")
                user_obj["processing"] = False
                user_obj["listening"] = True
                user_obj["speaking"] = False
                # PERFORMANCE FIX: Update user call record in memory instead of Redis
                set_user_call_record(str(req_id), user_obj)
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                break  # Exit the loop if interrupted

            # Process the chunk content - safe access to prevent IndexError
            current_gpt_chunk = None
            if (chunk.choices and len(chunk.choices) > 0 and
                chunk.choices[0].delta and
                hasattr(chunk.choices[0].delta, 'content')):
                current_gpt_chunk = chunk.choices[0].delta.content

            if current_gpt_chunk:
                logger.debug(f"{call_id} current gpt chunk count -> {count}")
                if count < 2:
                    break_punctuation = [',', '!', ':', '.', '?', '|', '।', '፧', '፨']  # For the first two messages
                else:
                    break_punctuation = ['.', '?', '।', '፧', '፨']  # After the first two messages

                if any(punc in current_gpt_chunk for punc in break_punctuation):
                    continious_string += current_gpt_chunk
                    complete_string += current_gpt_chunk
                    continious_string = re.sub(r'\n+', ' ', continious_string)
                    if count == 1:
                        call_cdr_key = f"{req_id}_cdr"
                        logger.secure(
                                f"{call_id} time taken to tts for first chunk ------> {(time.time() - tts_time) * 1000:.2f} ms")
                        # PERFORMANCE FIX: Use helper function for CDR retrieval
                        cdr_data = get_cdr_data(req_id)
                        if not cdr_data:
                            return None, None, None, None, 0, 0, 0
                        user_call_cdr_record = UserCallCDR(**cdr_data)
                        # Validate question_count to prevent zero division
                        validate_and_fix_question_count(user_call_cdr_record, req_id)
                        
                        # Safe calculation for avg_time_first_chunk_generation
                        avg_first_chunk_time = safe_calculate_moving_average(
                            current_avg=user_call_cdr_record.avg_time_first_chunk_generation,
                            new_value=(time.time() - tts_time),
                            count=user_call_cdr_record.question_count,
                            req_id=req_id
                        )
                        user_call_cdr_record.avg_time_first_chunk_generation = avg_first_chunk_time
                        user_call_cdr_record.total_time_first_chunk_generation = (
                                    user_call_cdr_record.total_time_first_chunk_generation + (time.time() - tts_time)
                            )
                        # Force update for first chunk critical metrics
                        update_cdr_record_with_expiration(req_id, user_call_cdr_record, force_immediate=True)
                        logger.debug(
                            f"{call_id} time taken to generate 1st chunk -- {continious_string} ------> {(time.time() - chunk_timestamp) * 1000:.2f} ms")
                        call_cdr_key = f"{req_id}_cdr"
                        # PERFORMANCE FIX: Use helper function for CDR retrieval
                        cdr_data = get_cdr_data(req_id)
                        if not cdr_data:
                            return None, None, None, None, 0, 0, 0
                        user_call_cdr_record = UserCallCDR(**cdr_data)
                        output_tokens = len(encoding.encode(continious_string))
                        logger.debug(f"output token are {output_tokens} for call id {req_id}")
                        user_call_cdr_record.total_output_token += output_tokens
                        logger.secure(f"total output token are {user_call_cdr_record.total_output_token} for call id {req_id}")
                        
                        # Validate question_count to prevent zero division
                        validate_and_fix_question_count(user_call_cdr_record, req_id)
                        
                        # Safe calculation for avg_output_token
                        user_call_cdr_record.avg_output_token = safe_calculate_moving_average(
                            current_avg=user_call_cdr_record.avg_output_token,
                            new_value=output_tokens,
                            count=user_call_cdr_record.question_count,
                            req_id=req_id
                        )
                        # Batch this update since it's not critical timing info
                        update_cdr_record_with_expiration(req_id, user_call_cdr_record)
                    else:
                        logger.info(
                            f"{call_id} time taken to generate chunk {count} -- {continious_string} ------> {(time.time() - chunk_timestamp) * 1000:.2f} ms")

                    discarded_string = ""
                    if len(continious_string.split()) >= 1:
                        if current_gpt_chunk in [",", "."]:
                            logger.info(f"{call_id} continious_string before split -> {continious_string}")
                            rev_arr = continious_string.split(" ")
                            logger.info(f"{call_id} rev_arr -> {rev_arr}")
                            logger.info(f"{call_id} rev_arr[-1] -> {rev_arr[-1]}")
                            if check_before_or_after_comma_is_number(rev_arr[-1]):
                                discarded_string = " " + rev_arr[-1]
                                continious_string = ' '.join(rev_arr[0:-1])
                                logger.info(f"{call_id} discarded_string -> {discarded_string}, continious_string -> {continious_string}")

                    chunk_timestamp = time.time()
                    continious_string = continious_string.strip()
                    if continious_string is not None and continious_string != "":
                        tts_time = time.time()
                        transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(
                            voice_code,
                            continious_string,
                            call_id, event_type, tts_style, provider, gender, is_translate)

                        # Convert TTS chunk to WAV file for ALL services
                        if tts_manager and response_id:
                            try:
                                wav_path = await tts_manager.convert_chunk_to_wav(
                                    base64_chunk=transcript,
                                    call_id=call_id,
                                    response_id=response_id
                                )
                                # Update transcript to send WAV path instead of base64
                                transcript = wav_path
                                logger.debug(f"Converted TTS chunk to WAV: {wav_path}")
                                
                                # Update cached metadata with TTS file path
                                try:
                                    if service_type == ServiceType.PA.value:
                                        user_obj = get_user_call_record(str(call_id))
                                        if user_obj and "vector_metadata_cache" in user_obj and user_obj["vector_metadata_cache"]:
                                            # Update the most recent cached metadata with TTS file path
                                            latest_metadata = user_obj["vector_metadata_cache"][-1]
                                            latest_metadata["tts_file_path"] = wav_path
                                            logger.info(f"Updated cached metadata with TTS file path: {wav_path}")
                                            
                                            # Update user call record in memory cache
                                            set_user_call_record(str(call_id), user_obj)
                                except Exception as e:
                                    logger.error(f"Error updating cached metadata with TTS file path: {e}")
                            except Exception as e:
                                logger.error(f"Failed to convert TTS chunk to WAV: {e}")
                                # Fallback to original transcript

                        if count == 1:
                            logger.secure(
                                f"{call_id} time taken to tts for first chunk ------> {(time.time() - tts_time) * 1000:.2f} ms")

                        else:
                            logger.secure(
                                f"{call_id} time taken to tts for chunk {count} ------> {(time.time() - tts_time) * 1000:.2f} ms")
                        # reset tts timer
                        tts_time = time.time()

                        messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                        current_chunk = current_chunk.replace("معين", "مُعين")
                        message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                                                           isEndChunk=False, transcript=transcript,
                                                           messageId=messageId, eventType=event_type)
                        logger.info(f"{call_id} Sending message response -> {message_response.__repr__()}")
                        await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                              data=message_response.dict())
                    continious_string = ""
                    continious_string += discarded_string
                    logger.info(f"{call_id} Last cont string -> {continious_string}")
                    count += 1
                    continue
                else:
                    continious_string += current_gpt_chunk
                    complete_string += current_gpt_chunk
            # Safe access to tool calls - check if choices, delta, and tool_calls exist
            if (chunk.choices and len(chunk.choices) > 0 and
                chunk.choices[0].delta and
                chunk.choices[0].delta.tool_calls and
                len(chunk.choices[0].delta.tool_calls) > 0):

                tool_call = chunk.choices[0].delta.tool_calls[0]
                if tool_call.function and tool_call.function.name:
                    logger.secure(f"function name-----> {tool_call.function.name}")
                    function_name = tool_call.function.name
                    function_id = tool_call.id
                if tool_call.function and tool_call.function.arguments:
                    logger.debug(f"function arguments ----> {tool_call.function.arguments}")
                    function_arguments += tool_call.function.arguments

        if continious_string is not None and continious_string != "":
            if user_obj["interrupt"]:
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                return complete_string, None, None, None, 0, 0, 0
            logger.info(
                f"{call_id} - time taken to generate chunk {continious_string} in ------> {(time.time() - chunk_timestamp) * 1000:.2f} ms")
            voice_code = user_obj["voiceCode"]
            tts_time = time.time()
            transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(voice_code,
                                                                                        continious_string,
                                                                                        call_id, event_type, tts_style,
                                                                                        provider, gender,
                                                                                        is_translate)

            # Convert final TTS chunk to WAV file for ALL services
            if tts_manager and response_id:
                try:
                    wav_path = await tts_manager.convert_chunk_to_wav(
                        base64_chunk=transcript,
                        call_id=call_id,
                        response_id=response_id
                    )
                    # Update transcript to send WAV path instead of base64
                    transcript = wav_path
                    logger.debug(f"Converted final TTS chunk to WAV: {wav_path}")
                    
                    # Update cached metadata with TTS file path
                    try:
                        if service_type == ServiceType.PA.value:
                            user_obj = get_user_call_record(str(call_id))
                            if user_obj and "vector_metadata_cache" in user_obj and user_obj["vector_metadata_cache"]:
                                # Update the most recent cached metadata with TTS file path
                                latest_metadata = user_obj["vector_metadata_cache"][-1]
                                latest_metadata["tts_file_path"] = wav_path
                                logger.info(f"Updated cached metadata with final TTS file path: {wav_path}")
                                
                                # Update user call record in memory cache
                                set_user_call_record(str(call_id), user_obj)
                    except Exception as e:
                        logger.error(f"Error updating cached metadata with final TTS file path: {e}")
                except Exception as e:
                    logger.error(f"Failed to convert final TTS chunk to WAV: {e}")
                    # Fallback to original transcript

            logger.info(
                f"{call_id} time taken to tts chunk number {count} -- {convert_wav_to_base64} ------> {(time.time() - tts_time) * 1000:.2f} ms")
            currentMessageId = user_obj["currentMessageId"]
            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
            current_chunk = current_chunk.replace("معين", "مُعين")
            message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                                               isEndChunk=False, transcript=transcript, messageId=messageId,
                                               eventType=event_type)
            logger.info(f"{call_id} Sending message response -> {message_response.__repr__()}")
            await send_chat_chunk_callback_socket(sid=user_obj["socketId"], data=message_response.dict())

        elif continious_string == "" and function_name is None:
            if user_obj["interrupt"]:
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                return complete_string, None, None, None, 0, 0, 0
            currentMessageId = user_obj["currentMessageId"]
            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
            message_response = MessageResponse(callId=call_id, chunk="",
                                               isEndChunk=True, transcript="", messageId=messageId,
                                               eventType=event_type)
            logger.info(f"{call_id} Sending message response -> {message_response.__repr__()}")
            await send_chat_chunk_callback_socket(sid=user_obj["socketId"], data=message_response.dict())


        # Process response end for ALL services
        if tts_manager and response_id:
            try:
                # Process response end: concatenate all chunks
                complete_path = await tts_manager.process_response_end(call_id, response_id)
                if complete_path:
                    logger.info(f"Complete response WAV file created: {complete_path}")
                    
                    # TTS file path will be stored in vector DB at call end
                    logger.info(f"TTS file path {complete_path} will be stored in vector DB at call end")
            except Exception as e:
                logger.error(f"Failed to process response end: {e}")

        # Update cached metadata with complete response for fresh learning
        try:
            if complete_string and service_type == ServiceType.PA.value:
                # Get user call record to update cached metadata
                user_obj = get_user_call_record(str(call_id))
                if user_obj and "vector_metadata_cache" in user_obj and user_obj["vector_metadata_cache"]:
                    # Update the most recent cached metadata with complete response
                    latest_metadata = user_obj["vector_metadata_cache"][-1]
                    latest_metadata["response"] = complete_string
                    logger.info(f"Updated cached metadata with complete response for call {call_id}")
                    
                    # Update user call record in memory cache
                    set_user_call_record(str(call_id), user_obj)
        except Exception as e:
            logger.error(f"Error updating cached metadata with complete response: {e}")
        
        return complete_string, function_name, function_arguments, function_id, 0, 0, 0
    except Exception as e:
        try:
            # PERFORMANCE FIX: Use helper function for CDR retrieval in exception handler
            if tts_manager:
                response_id = f"resp_{int(datetime.now().timestamp() * 1000)}"
                logger.info(f"Generated response_id {response_id} for call {req_id}")
            cdr_data = get_cdr_data(req_id)
            if not cdr_data:
                return None, None, None, None, 0, 0, 0
            user_call_cdr_record = UserCallCDR(**cdr_data)
            user_call_cdr_record.gpt_failure_counts+=1
            # Force immediate update for failure scenarios
            update_cdr_record_with_expiration(req_id, user_call_cdr_record, force_immediate=True)
            logger.warning(f"Exception in call gpt stream - {e} for req_id - {req_id}", exc_info=True)
            # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
            user_call_record = get_user_call_record(str(req_id))
            if user_call_record is None:
                logger.debug(f"User call record not found in memory for req_id: {req_id}")
                return None, None, None, None, 0, 0, 0
            logger.debug(f"Updated UserCallCDR: {user_call_record}")
            event_type = user_call_record["eventType"]
            tts_style = user_call_record["ttsStyle"]
            voice_code = user_call_record["voiceCode"]
            is_translate = user_call_record["isTranslate"]
            provider = user_call_record["provider"]
            gender = user_call_record["gender"]
            lang = user_call_record.get("languageCode", "en").split("-")[0]
            service_type = user_call_record["serviceType"]
            if not user_call_record.get("socketId"):
                logger.error(f"No socketId found for req_id - {req_id}. Cannot send error message.", exc_info=True)
                return None, None, None, None, 0, 0, 0

            # Construct the error message with exception details
            sanitized_exception = str(e)  # Replace with actual sanitization logic if needed
            if service_type==ServiceType.PA.value:
                random_error_msg = random.choice(pa_random_responses)
            else:
                chunk_error_msg_template = config_language_response.get(f"{lang}_responses", {}).get("error_400_msg", [])
                if chunk_error_msg_template:
                    random_error_msg = random.choice(chunk_error_msg_template)
                else:
                    random_error_msg = "I am facing some issue. Please try again after some time."

            # Convert the error message to transcript and audio chunk
            transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(
                voice_code,
                random_error_msg,
                req_id,
                event_type,
                tts_style,
                provider,
                gender,
                is_translate
            )
            
            # Convert final TTS chunk to WAV file for ALL services
            if tts_manager and response_id:
                try:
                    wav_path = await tts_manager.convert_chunk_to_wav(
                        base64_chunk=transcript,
                        call_id=call_id,
                        response_id=response_id
                    )
                    # Update transcript to send WAV path instead of base64
                    transcript = wav_path
                    logger.debug(f"Converted final TTS chunk to WAV: {wav_path}")
                except Exception as e:
                    logger.error(f"Failed to convert final TTS chunk to WAV: {e}")

            # Prepare message IDs
            current_message_id = user_call_record.get("currentMessageId", "default_message_id")
            messageId = generate_dynamic_message_id(current_message_id, "Avatar")

            # Create and send the error message chunk
            sending_chunk = current_chunk + " "
            message_response = MessageResponse(
                callId=req_id,
                chunk=sending_chunk,
                isEndChunk=False,
                transcript=transcript,
                messageId=messageId,
                eventType=event_type
            )
            logger.info(f"call_id {req_id} - Sending message response - {message_response.__repr__()}")
            await send_chat_chunk_callback_socket(
                sid=user_call_record["socketId"],
                data=message_response.dict()
            )

            # Create and send the end chunk to signify completion
            message_response = MessageResponse(
                callId=req_id,
                chunk="",
                isEndChunk=True,
                transcript="",
                messageId=messageId,
                eventType=event_type
            )
            logger.info(f"call_id {req_id} - Sending end message response - {message_response.__repr__()}")
            await send_chat_chunk_callback_socket(
                sid=user_call_record["socketId"],
                data=message_response.dict()
            )

            # Update Redis to reflect the interruption
            user_call_record["processing"] = False
            user_call_record["listening"] = True
            user_call_record["speaking"] = False
            redis_client.set(req_id, json.dumps(user_call_record))

        except Exception as inner_e:
            logger.error(f"Exception in exception handler of call_gpt_stream - {inner_e} for req_id - {req_id}",exc_info=True)

        return None, None, None, None, 0, 0, 0


async def stream_handler(model_name, req_id):
    try:
        # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
        user_obj = get_user_call_record(str(req_id))
        if user_obj is None:
            logger.debug(f"User call record not found in memory for req_id: {req_id}")
            return None
        messages = user_obj['llmMessage']
        assistant_id = user_obj["assistantId"]
        user_call_obj = UserCallRecord(**user_obj)
        msg_id = user_call_obj.currentMessageId
        # PERFORMANCE FIX: Use helper function for CDR retrieval
        cdr_data = get_cdr_data(req_id)
        if not cdr_data:
            return
        user_call_cdr_record = UserCallCDR(**cdr_data)
        user_call_cdr_record.question_count += 1
        call_type = user_obj["eventType"]
        user_call_cdr_record.call_type = call_type
        cdr_call_messages = user_call_cdr_record.call_messages
        cdr_call_messages.append({
            "id": msg_id,  # Generate a unique ID for the message
            "senderId": "user",  # Use the sender_id from messages
            "body": messages[-1]["content"],  #REVERT to original working approach
            "contentType": "text",  # Assuming text content; adjust as needed
            "attachments": [],  # Assuming no attachments; adjust as needed
            "createdAt": get_current_time_iso()  # Set the current time in ISO format
        })
        user_call_cdr_record.call_messages = cdr_call_messages
        # Initial CDR setup - force immediate update
        update_cdr_record_with_expiration(req_id, user_call_cdr_record, force_immediate=True)
        try:
            start_time = time.time()
            # if assistant_id!='19':
            logger.secure(f"{req_id} Calling call_gpt_stream with model_name: {model_name}, req_id: {req_id}")
            complete_string, function_name, function_arguments, function_id, input_token, output_token, cached_token = await call_gpt_stream(model_name=model_name,
                                                                                                    req_id=req_id,
                                                                                                    is_function_call=False)

            logger.info(f"{req_id} Complete Response String -> {complete_string}")

            function_call_timer = time.time()
            if complete_string:
                response_time = int((time.time() - start_time) * 1000)
                # PERFORMANCE FIX: Use helper function for CDR retrieval
                cdr_data = get_cdr_data(req_id)
                if not cdr_data:
                    return None
                user_call_cdr_record = UserCallCDR(**cdr_data)
                user_call_cdr_record.answer_count=user_call_cdr_record.answer_count+1
                logger.secure(f"incremented value {user_call_cdr_record.answer_count}")
                
                # Validate answer_count to prevent zero division
                validate_and_fix_answer_count(user_call_cdr_record, req_id)
                
                # Safe calculation for avg_overall_response_time
                user_call_cdr_record.avg_overall_response_time = safe_calculate_moving_average(
                    current_avg=user_call_cdr_record.avg_overall_response_time,
                    new_value=response_time,
                    count=user_call_cdr_record.answer_count,
                    req_id=req_id
                )
                user_call_cdr_record.total_overall_response_time += response_time
                
                # Safe calculation for avg_normal_response_time
                user_call_cdr_record.avg_normal_response_time = safe_calculate_moving_average(
                    current_avg=user_call_cdr_record.avg_normal_response_time,
                    new_value=response_time,
                    count=user_call_cdr_record.answer_count,
                    req_id=req_id
                )
                user_call_cdr_record.total_normal_response_time += response_time
                logger.secure(f"Value for avg_overall_response_time {user_call_cdr_record.avg_overall_response_time}")
                # Force update for response completion metrics
                update_cdr_record_with_expiration(req_id, user_call_cdr_record, force_immediate=True)
                logger.secure(f"{req_id} I get a confirmation that it was not a function call")
                assistant_response = {"role": "assistant", "content": complete_string}

                # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
                user_call_record = get_user_call_record(str(req_id))
                if user_call_record is None:
                    logger.info("No active call")
                else:
                    event_type = user_call_record["eventType"]
                    current_message_id = user_call_record["currentMessageId"]
                    messageId = generate_dynamic_message_id(current_message_id, "Avatar")
                    user_call_record["llmMessage"].append(assistant_response)
                    adjusted_messages = adjust_messages_length(req_id, user_call_record["llmMessage"])
                    user_call_record["llmMessage"] = adjusted_messages
                    user_call_record["processing"] = False
                    # PERFORMANCE FIX: Update user call record in memory instead of Redis
                    set_user_call_record(str(req_id), user_call_record)
                    if len(user_call_record["userMessage"]) > 0:
                        logger.info("Hello 2xE")

                    message_response = MessageResponse(callId=req_id, chunk="",
                                                       isEndChunk=True, transcript="", messageId=messageId,
                                                       eventType=event_type)
                    logger.info(f"{req_id} Sending message response -> {message_response.__repr__()}")
                    await send_chat_chunk_callback_socket(sid=user_call_record["socketId"], data=message_response.dict())
                    
                    # Store response for learning (call_end equivalent for Tier 3) - ASYNC
                    three_tier_enabled = os.getenv('THREE_TIER_LLM_ENABLED', 'false').lower() == 'true'
                    if three_tier_enabled and user_call_record.get("serviceType") == ServiceType.PA.value and complete_string:
                        
                        async def _store_tier3_for_learning():
                            try:
                                from service.pa_three_tier_service import get_three_tier_service
                                three_tier_service = get_three_tier_service()
                                if three_tier_service:
                                    # Extract user query from messages
                                    user_query = ""
                                    messages = user_call_record.get("llmMessage", [])
                                    if messages:
                                        for message in reversed(messages):
                                            if message.get("role") == "user":
                                                user_query = message.get("content", "")
                                                break
                                    
                                    if user_query:
                                        # Create metadata for storage
                                        metadata = {
                                            "assistant_id": str(assistant_id),
                                            "call_id": str(req_id),
                                            "service_type": str(user_call_record.get("serviceType", "Personal_Assistant")),
                                            "voice_code": str(voice_code),
                                            "voice_name": str(user_call_record.get("voiceName", "")),
                                            "tts_style": str(tts_style),
                                            "provider": str(provider),
                                            "gender": str(gender),
                                            "is_translate": bool(is_translate),
                                            "response_id": f"resp_{int(datetime.now().timestamp() * 1000)}",
                                            "tier_used": 3,  # Tier 3 fresh generation
                                            "confidence_score": 0.0,
                                            "generation_time": 0.0,
                                            "function_name": None,  # Normal generation, no function call
                                            "token_usage": {
                                                "prompt_tokens": 0,
                                                "completion_tokens": 0,
                                                "total_tokens": 0
                                            },
                                            "llm_client": None,
                                            "model_name": "gpt-4"
                                        }
                                        
                                        # Cache metadata for call end storage (no immediate storage)
                                        logger.info(f"Cached Tier 3 response metadata for call end storage: {req_id}")
                            except Exception as e:
                                logger.error(f"Failed to store Tier 3 response for learning: {e}")
                        
                        # Start learning task in background (non-blocking)
                        asyncio.create_task(_store_tier3_for_learning())

                #user_call_cdr_record.answer_count += 1
                cdr_msg_id = msg_id.split("_")[0] + "_Avatar"
                cdr_call_messages.append({
                    "id": cdr_msg_id,  # Generate a unique ID for the message
                    "senderId": "eva",  # Use the sender_id from user_messages
                    "body": complete_string,  # The actual message content
                    "contentType": "text",  # Assuming text content; adjust as needed
                    "attachments": [],  # Assuming no attachments; adjust as needed
                    "createdAt": get_current_time_iso(),  # Set the current time in ISO format,
                    "language":user_call_cdr_record.language,
                    "inputToken":input_token,
                    "outputToken":output_token,
                    "cachedToken":cached_token
                })
                user_call_cdr_record.call_messages = cdr_call_messages
                # Force update for final response message
                update_cdr_record_with_expiration(req_id, user_call_cdr_record, force_immediate=True)
            if function_name and (function_name == "play_summary" or function_name == "play_story"):
                logger.info(f"{req_id} function name is {function_name}")
                # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
                user_call_record = get_user_call_record(str(req_id))
                if user_call_record is None:
                    return None
                event_type = user_call_record["eventType"]
                messages = user_call_record["llmMessage"]
                current_message_id = user_call_record["currentMessageId"]
                messageId = generate_dynamic_message_id(current_message_id, "Avatar")

                # Get LLM client configuration for this assistant
                azure_client, db_model_name = get_llm_client_config_for_request(str(assistant_id))
                function_returns = await execute_function_call(function_name=function_name, arguments=function_arguments,
                                                         call_id=req_id, assistant_id=assistant_id, llm_client=azure_client, model_name=db_model_name)
                append_asst_msg(messages=messages, function_id=function_id, function_name=function_name,
                                function_args=function_arguments)

                response_dict = json.loads(function_returns)
                audio_path = response_dict['path']
                audio_id = response_dict['audio_id']
                status = response_dict['status']
                logger.info(f"{req_id} audio path ----> {audio_path}, audio id ----> {audio_id} and status ----> {status}")
                transcript = convert_wav_to_base64(audio_path)
                message_response = MessageResponse(callId=req_id, chunk=f"{function_name}",
                                                   isEndChunk=False, transcript=transcript,
                                                   messageId=messageId,
                                                   eventType=event_type)
                logger.info(f"call_id {req_id} - Sending message response - {message_response.__repr__()}")
                await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                      data=message_response.dict())

                message_response = MessageResponse(callId=req_id, chunk="",
                                                   isEndChunk=True, transcript="",
                                                   messageId=messageId,
                                                   eventType=event_type)
                logger.info(f"call_id {req_id} - Sending message response - {message_response.__repr__()}")
                await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                      data=message_response.dict())
                append_tool_call_message(messages=messages, function_id=function_id, function_name=function_name,
                                         function_returns=function_returns)

                reg_message_obj = {"role": "assistant", "content": status}
                user_call_record["llmMessage"].append(reg_message_obj)
                # PERFORMANCE FIX: Update user call record in memory instead of Redis
                set_user_call_record(str(req_id), user_call_record)

            if function_name:
                user_call_cdr_record.tools_used += 1
                # Batch this update since it's not critical timing info
                update_cdr_record_with_expiration(req_id, user_call_cdr_record)
                logger.secure(
                    f"{req_id} time taken to return function call response ------> {time.time() - function_call_timer:.2f} seconds -- function name -- {function_name} , function arguments -- {function_arguments}")
                logger.secure(f" {req_id} Function name is [{function_name}]")
                # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
                user_call_record = get_user_call_record(str(req_id))
                if user_call_record is None:
                    return None
                event_type = user_call_record["eventType"]
                tts_style = user_call_record["ttsStyle"]
                voice_code = user_call_record["voiceCode"]
                is_translate = user_call_record["isTranslate"]
                provider = user_call_record["provider"]
                gender = user_call_record["gender"]

                prompt_category = user_call_record["prompt_category"]

                language = voice_code.split("-")[0]

                current_message_id = user_call_record["currentMessageId"]
                buildup_prompt_timer = time.time()

                if complete_string:
                    logger.secure(f"{req_id} complete string is not empty so not playing buildup prompt")
                else:
                    logger.secure(f"{req_id} complete string is empty so playing buildup prompt")
                    await get_buildup_prompt(prompt_category=prompt_category, call_id=req_id, language=language,
                                             event_type=event_type, tts_style=tts_style, voice_code=voice_code,
                                             sid=user_call_record["socketId"], is_translate=is_translate,
                                             current_message_id=current_message_id, provider=provider, gender=gender,
                                             function_name=function_name,service_type=user_call_record["serviceType"])
                    logger.secure(f"{req_id} time taken to get buildup prompt ------> {time.time() - buildup_prompt_timer:.2f} seconds")
                prompt_category = None
                user_call_record["prompt_category"] = prompt_category
                # PERFORMANCE FIX: Update user call record in memory instead of Redis
                set_user_call_record(str(req_id), user_call_record)

                messages = user_call_record["llmMessage"]
                
                # Set confidence score for standard LLM processing
                # For fresh generation, we'll use a default confidence score of 0.8
                # This will be updated by the LLM-based context analysis at call end
                confidence_score = 0.8

                logger.info(f"{req_id} function arguments before filtering ----> {function_arguments}, function_name----> {function_name}")
                
                filtered_args = function_args_check(function_name=function_name, function_arguments=function_arguments,
                                                    call_id=req_id)
                exempted_functions = ['get_all_complaints', 'get_all_resolved_complaints', 'get_all_incomplete_complaints']
                if filtered_args:
                    function_arguments = json.dumps(filtered_args)
                    logger.info(f"{req_id} function arguments after filtering ----> {function_arguments}")
                elif function_name in exempted_functions:
                    pass
                else:
                    raise ValueError(f"{req_id} function arguments are empty after filtering")

                # Get LLM client configuration for this assistant
                azure_client, db_model_name = get_llm_client_config_for_request(str(assistant_id))
                function_returns = await execute_function_call(function_name=function_name, arguments=function_arguments,
                                                         call_id=req_id, assistant_id=assistant_id, confidence_score=confidence_score, llm_client=azure_client, model_name=db_model_name)
                logger.debug(f"Function {function_name} returned: {function_returns} (type: {type(function_returns)})")
                if function_returns and "####STOP####" in function_returns:  # Check if key exists in the dictionary
                    transcript_value = function_returns["####STOP####"] 
                    message_response = MessageResponse(
                    callId=req_id,
                    chunk="####STOP####",
                    isEndChunk=False,
                    transcript=transcript_value,  
                    messageId="",
                    eventType="call"
                    )
                    logger.info(f"{req_id} Sending message response -> {message_response.__repr__()}")

                    await send_chat_chunk_callback_socket(
                        sid=user_obj["socketId"],
                        data=message_response.dict()
                    )
                    return

                if function_returns and "####TELE_MARKETING####" in function_returns:  # Check if key exists in the dictionary
                    transcript_value = function_returns["####TELE_MARKETING####"]
                    message_response = MessageResponse(
                        callId=req_id,
                        chunk="####TELE_MARKETING####",
                        isEndChunk=False,
                        transcript=transcript_value,
                        messageId="",
                        eventType="call"
                    )
                    logger.info(f"{req_id} Sending message response -> {message_response.__repr__()}")

                    await send_chat_chunk_callback_socket(
                        sid=user_obj["socketId"],
                        data=message_response.dict()
                    )
                    return

                if function_returns and "####USE_CACHED####" in function_returns:  # Check if key exists in the dictionary
                    transcript_value = function_returns["####USE_CACHED####"]
                    response_text = function_returns.get("response_text", "")
                    
                    # Update user messages with the cached response
                    if response_text:
                        try:
                            current_message_id = user_call_record["currentMessageId"]
                            messageId = generate_dynamic_message_id(current_message_id, "Avatar")
                            
                            # Create CDR format message for CDR system
                            cdr_assistant_response = {
                                "id": messageId,
                                "senderId": "assistant",
                                "body": response_text,
                                "contentType": "text",
                                "attachments": [],
                                "createdAt": datetime.now().isoformat() + "Z"
                            }
                            
                            # Create OpenAI format message for LLM array
                            llm_assistant_response = {
                                "role": "assistant",
                                "content": response_text
                            }
                            
                            # Append OpenAI format to LLM messages
                            user_call_record["llmMessage"].append(llm_assistant_response)
                            adjusted_messages = adjust_messages_length(req_id, user_call_record["llmMessage"])
                            user_call_record["llmMessage"] = adjusted_messages
                            set_user_call_record(str(req_id), user_call_record)
                            logger.info(f"{req_id} Updated user messages with cached response")
                        except Exception as e:
                            logger.error(f"Error updating user messages for cached response: {e}")
                    
                    message_response = MessageResponse(
                        callId=req_id,
                        chunk="",  # Empty chunk for cached response
                        isEndChunk=False,
                        transcript=transcript_value,
                        messageId="",
                        eventType="call"
                    )
                    logger.info(f"{req_id} Sending use_cached response -> {message_response.__repr__()}")

                    await send_chat_chunk_callback_socket(
                        sid=user_obj["socketId"],
                        data=message_response.dict()
                    )
                    
                    # Send end chunk
                    message_response = MessageResponse(
                        callId=req_id,
                        chunk="",
                        isEndChunk=True,
                        transcript="",
                        messageId="",
                        eventType="call"
                    )
                    await send_chat_chunk_callback_socket(
                        sid=user_obj["socketId"],
                        data=message_response.dict()
                    )
                    return

                if function_returns and "####FRESH_GENERATION####" in function_returns:  # Check if key exists in the dictionary
                    transcript_value = function_returns["####FRESH_GENERATION####"]
                    response_text = function_returns.get("response_text", "")
                    
                    # Update user messages with the fresh generation response
                    if response_text:
                        try:
                            current_message_id = user_call_record["currentMessageId"]
                            messageId = generate_dynamic_message_id(current_message_id, "Avatar")
                            
                            # Create CDR format message for CDR system
                            cdr_assistant_response = {
                                "id": messageId,
                                "senderId": "assistant",
                                "body": response_text,
                                "contentType": "text",
                                "attachments": [],
                                "createdAt": datetime.now().isoformat() + "Z"
                            }
                            
                            # Create OpenAI format message for LLM array
                            llm_assistant_response = {
                                "role": "assistant",
                                "content": response_text
                            }
                            
                            # Append OpenAI format to LLM messages
                            user_call_record["llmMessage"].append(llm_assistant_response)
                            adjusted_messages = adjust_messages_length(req_id, user_call_record["llmMessage"])
                            user_call_record["llmMessage"] = adjusted_messages
                            set_user_call_record(str(req_id), user_call_record)
                            logger.info(f"{req_id} Updated user messages with fresh generation response")
                        except Exception as e:
                            logger.error(f"Error updating user messages for fresh generation response: {e}")
                    
                    message_response = MessageResponse(
                        callId=req_id,
                        chunk="",  # Empty chunk for fresh generation
                        isEndChunk=False,
                        transcript=transcript_value,
                        messageId="",
                        eventType="call"
                    )
                    logger.info(f"{req_id} Sending fresh generation response -> {message_response.__repr__()}")

                    await send_chat_chunk_callback_socket(
                        sid=user_obj["socketId"],
                        data=message_response.dict()
                    )
                    
                    # Send end chunk
                    message_response = MessageResponse(
                        callId=req_id,
                        chunk="",
                        isEndChunk=True,
                        transcript="",
                        messageId="",
                        eventType="call"
                    )
                    await send_chat_chunk_callback_socket(
                        sid=user_obj["socketId"],
                        data=message_response.dict()
                    )
                    return

                append_asst_msg(messages=messages, function_id=function_id, function_name=function_name,
                                function_args=function_arguments)
                # Handle case where function returns None
                function_returns_safe = function_returns if function_returns is not None else "Function executed successfully"
                append_tool_call_message(messages=messages, function_id=function_id, function_name=function_name,
                                         function_returns=function_returns_safe)

                adjusted_messages = adjust_messages_length(req_id, messages)
                user_call_record["llmMessage"] = adjusted_messages
                # PERFORMANCE FIX: Update user call record in memory instead of Redis
                set_user_call_record(str(req_id), user_call_record)
                start_time = time.time()
                regular_response_new, function_name_new, function_arguments_new, function_id_new,input_token, output_token, cached_token = await call_gpt_stream(
                    model_name=model_name,
                    req_id=req_id,
                    is_function_call=True)
                if regular_response_new:
                    logger.info(f" {req_id} regular response --> {regular_response_new}")
                    response_time = int((time.time() - start_time) * 1000)
                    # PERFORMANCE FIX: Use helper function for CDR retrieval
                    cdr_data = get_cdr_data(req_id)
                    if not cdr_data:
                        return None
                    user_call_cdr_record = UserCallCDR(**cdr_data)
                    user_call_cdr_record.answer_count=user_call_cdr_record.answer_count+1
                    logger.secure(f"regular response answer incremented {user_call_cdr_record.answer_count}")
                    
                    # Validate answer_count to prevent zero division
                    validate_and_fix_answer_count(user_call_cdr_record, req_id)
                    
                    # Safe calculation for avg_overall_response_time
                    user_call_cdr_record.avg_overall_response_time = safe_calculate_moving_average(
                        current_avg=user_call_cdr_record.avg_overall_response_time,
                        new_value=response_time,
                        count=user_call_cdr_record.answer_count,
                        req_id=req_id
                    )
                    user_call_cdr_record.total_overall_response_time += response_time
                    
                    # Safe calculation for avg_normal_response_time
                    user_call_cdr_record.avg_normal_response_time = safe_calculate_moving_average(
                        current_avg=user_call_cdr_record.avg_normal_response_time,
                        new_value=response_time,
                        count=user_call_cdr_record.answer_count,
                        req_id=req_id
                    )
                    user_call_cdr_record.total_normal_response_time += response_time
                    logger.secure(f"Value for avg_overall_response_time {user_call_cdr_record.avg_overall_response_time}")
                    # Force update for response completion metrics
                    update_cdr_record_with_expiration(req_id, user_call_cdr_record, force_immediate=True)
                    cdr_msg_id = msg_id.split("_")[0] + "_Avatar"
                    cdr_call_messages.append({
                        "id": cdr_msg_id,  # Generate a unique ID for the message
                        "senderId": "eva",  # Use the sender_id from user_messages
                        "body": regular_response_new,  # The actual message content
                        "contentType": "text",  # Assuming text content; adjust as needed
                        "attachments": [],  # Assuming no attachments; adjust as needed
                        "createdAt": get_current_time_iso()  # Set the current time in ISO format
                    })
                    user_call_cdr_record.call_messages = cdr_call_messages
                    # Force update for message completion
                    update_cdr_record_with_expiration(req_id, user_call_cdr_record, force_immediate=True)
                    reg_message_obj = {"role": "assistant", "content": regular_response_new}
                    user_call_record["llmMessage"].append(reg_message_obj)
                    messageId = generate_dynamic_message_id(current_message_id, "Avatar")
                    message_response = MessageResponse(callId=req_id, chunk="",
                                                       isEndChunk=True, transcript="", messageId=messageId,
                                                       eventType=event_type)
                    logger.info(f"{req_id} Sending message response -> {message_response.__repr__()}")
                    await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                          data=message_response.dict())

                    adjusted_messages = adjust_messages_length(req_id, messages)
                    logger.debug(f"{req_id} - after final response: adjusted messages={adjusted_messages}, function name={function_name}")
                    if function_name in ["get_nearest_service_center"]:
                        user_call_cdr_record.rag_tool_use += 1
                        # Batch this update since it's not critical timing info
                        update_cdr_record_with_expiration(req_id, user_call_cdr_record)
                        remove_messages_in_range(adjusted_messages, 1, 2)
                        logger.debug(f"{req_id} - adjusted messages after removing function call- {adjusted_messages}")
                    user_call_record["llmMessage"] = adjusted_messages
                    # PERFORMANCE FIX: Update user call record in memory instead of Redis
                    set_user_call_record(str(req_id), user_call_record)
                elif function_name_new:
                    logger.info(f" [{req_id}] function call loop kill audio called")
                    response_time = int((time.time() - start_time) * 1000)
                    # PERFORMANCE FIX: Use helper function for CDR retrieval
                    cdr_data = get_cdr_data(req_id)
                    if not cdr_data:
                        return None
                    user_call_cdr_record = UserCallCDR(**cdr_data)
                    # Validate answer_count to prevent zero division
                    validate_and_fix_answer_count(user_call_cdr_record, req_id)
                    
                    # Safe calculation for avg_overall_response_time
                    user_call_cdr_record.avg_overall_response_time = safe_calculate_moving_average(
                        current_avg=user_call_cdr_record.avg_overall_response_time,
                        new_value=response_time,
                        count=user_call_cdr_record.answer_count,
                        req_id=req_id
                    )
                    user_call_cdr_record.total_normal_response_time += response_time
                    user_call_cdr_record.total_overall_response_time += response_time
                    
                    # Safe calculation for avg_normal_response_time
                    user_call_cdr_record.avg_normal_response_time = safe_calculate_moving_average(
                        current_avg=user_call_cdr_record.avg_normal_response_time,
                        new_value=response_time,
                        count=user_call_cdr_record.answer_count,
                        req_id=req_id
                    )

                    logger.secure(f"Value for avg_overall_response_time {user_call_cdr_record.avg_overall_response_time}")
                    # Force update for response completion metrics
                    update_cdr_record_with_expiration(req_id, user_call_cdr_record, force_immediate=True)
                    chunk = "I'm facing some issues. Can you try after some time or try asking your question again?"
                    # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
                    user_call_record = get_user_call_record(str(req_id))
                    if user_call_record is None:
                        return None
                    event_type = user_call_record["eventType"]
                    tts_style = user_call_record["ttsStyle"]
                    voice_code = user_call_record["voiceCode"]
                    base64_transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(voice_code,
                                                                                                chunk,
                                                                                                req_id,
                                                                                                event_type,
                                                                                                tts_style, provider, gender,
                                                                                                is_translate)
                    
                    # Convert to WAV file using TTS manager
                    try:
                        from service.pa_tts_manager import get_tts_manager
                        tts_manager = get_tts_manager()
                        if tts_manager:
                            response_id = f"error_{int(time.time() * 1000)}"
                            wav_path = await tts_manager.convert_chunk_to_wav(
                                base64_chunk=base64_transcript,
                                call_id=req_id,
                                response_id=response_id
                            )
                            transcript = wav_path
                            logger.info(f"Converted error TTS to WAV: {wav_path}")
                        else:
                            transcript = base64_transcript
                    except Exception as e:
                        logger.error(f"Failed to convert error TTS to WAV: {e}")
                        transcript = base64_transcript
                    
                    current_message_id = user_call_record["currentMessageId"]
                    messageId = generate_dynamic_message_id(current_message_id, "Avatar")
                    sending_chunk = current_chunk + " "
                    message_response = MessageResponse(callId=req_id, chunk=sending_chunk,
                                                       isEndChunk=True, transcript=transcript,
                                                       messageId=messageId,
                                                       eventType=event_type)
                    logger.info(f"[{req_id}] Sending message response -> {message_response.__repr__()}]")
                    await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                          data=message_response.dict())

        except Exception as e:
            logger.error(f"Exception in stream_handler while getting response from gpt: {e}\n{traceback.format_exc()}", exc_info=True)

    except Exception as e:
        logger.error(f"Exception in stream_handler: {e}", exc_info=True)
        # Set processing to False in case of an exception
        # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
        user_call_record = get_user_call_record(str(req_id))
        if user_call_record is None:
            logger.debug(f"User call record not found in memory for req_id: {req_id}")
            return
        user_call_record["processing"] = False
        # PERFORMANCE FIX: Update user call record in memory instead of Redis
        set_user_call_record(str(req_id), user_call_record)