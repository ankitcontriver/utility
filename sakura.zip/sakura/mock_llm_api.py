#!/usr/bin/env python3
"""
High-Performance Mock LLM API Server for Sakura Testing
Simulates OpenAI GPT-style streaming responses with 400-500 concurrent request capacity
"""

import asyncio
import json
import random
import time
import uuid
from datetime import datetime
from typing import Dict, List, Optional

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

# High-performance FastAPI configuration
app = FastAPI(title="Mock LLM API", version="1.0.0", docs_url="/docs")

# Enable CORS for cross-origin requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Realistic Eva responses for the 3 main transcripts (short as requested)
TRANSCRIPT_RESPONSES = {
    "hello": [
        "Hi! I'm Eva, your knowledge assistant. How can I help you today?",
        "Hello! Eva here, ready to assist with any questions you have.",
        "Hey there! I'm Eva and I'm here to help you with anything you need."
    ],
    "eva how are you": [
        "I'm doing great, thank you for asking! Ready to help you with anything.",
        "I'm wonderful, thanks! Always excited to help. How are you doing?",
        "Fantastic! I love helping out. What would you like to know today?"
    ],
    "i wanna know about the indian history": [
        "India has incredible history! From ancient Indus Valley to modern times. What period interests you?",
        "Indian history is fascinating! Ancient empires, Mughals, colonial era. Any specific time you'd like to explore?",
        "Amazing topic! Ancient kingdoms, great rulers like Ashoka, freedom struggle. Which era interests you most?"
    ]
}

# Short generic responses
GENERIC_RESPONSES = [
    "That's interesting! What would you like to know more about?",
    "Great question! Can you tell me more details?",
    "I'd be happy to help! What specific information do you need?",
    "Sure! Let me help you with that. What aspect interests you?",
    "Absolutely! What particular details would you like to know?"
]

class ChatCompletionRequest(BaseModel):
    model: str
    messages: List[Dict[str, str]]
    stream: bool = True
    temperature: Optional[float] = 0.4
    tools: Optional[List] = None
    tool_choice: Optional[str] = None

class Usage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    prompt_tokens_details: Optional[Dict] = None

# Global performance tracking
request_count = 0
active_requests = 0

@app.middleware("http")
async def track_requests(request, call_next):
    """Track concurrent requests for monitoring"""
    global active_requests, request_count
    active_requests += 1
    request_count += 1
    
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    
    active_requests -= 1
    
    # Log every 100 requests to monitor performance
    if request_count % 100 == 0:
        print(f"📊 Processed {request_count} requests | Active: {active_requests} | Last response: {process_time:.3f}s")
    
    return response

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy", 
        "timestamp": datetime.now().isoformat(),
        "active_requests": active_requests,
        "total_requests": request_count
    }

@app.post("/chat/completions")
async def create_chat_completion(request: ChatCompletionRequest):
    """Mock GPT chat completions endpoint with streaming support"""
    
    if not request.stream:
        # Handle non-streaming requests (for SMART_IVR)
        response_text = get_response_for_transcript(request.messages)
        return {
            "id": f"chatcmpl-{uuid.uuid4()}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": request.model,
            "choices": [{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": response_text
                },
                "finish_reason": "stop"
            }],
            "usage": {
                "prompt_tokens": estimate_tokens(" ".join([m.get("content", "") for m in request.messages])),
                "completion_tokens": estimate_tokens(response_text),
                "total_tokens": estimate_tokens(" ".join([m.get("content", "") for m in request.messages]) + response_text),
                "prompt_tokens_details": {"cached_tokens": random.randint(10, 100)}
            }
        }
    
    # Handle streaming requests
    return StreamingResponse(
        stream_chat_completion(request),
        media_type="text/plain",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Content-Type": "text/plain; charset=utf-8"
        }
    )

async def stream_chat_completion(request: ChatCompletionRequest):
    """Generate streaming chat completion response with load simulation"""
    
    try:
        # Get appropriate response
        response_text = get_response_for_transcript(request.messages)
        
        # Simulate load-based delays (0.5 to 3 seconds)
        # Higher active requests = higher chance of longer delay
        base_delay = random.uniform(0.5, 1.5)
        load_factor = min(active_requests / 100.0, 2.0)  # Max 2x multiplier for high load
        initial_delay = base_delay + (load_factor * random.uniform(0, 1.5))
        initial_delay = min(initial_delay, 3.0)  # Cap at 3 seconds
        
        await asyncio.sleep(initial_delay)
        
        # Split response into realistic chunks
        chunks = create_realistic_chunks(response_text)
        
        completion_id = f"chatcmpl-{uuid.uuid4()}"
        created_time = int(time.time())
        
        # Send chunks with realistic timing
        for i, chunk_text in enumerate(chunks):
            # Create the chunk response (exact format matching OpenAI)
            chunk_data = {
                "id": completion_id,
                "object": "chat.completion.chunk",
                "created": created_time,
                "model": request.model,
                "choices": [{
                    "index": 0,
                    "delta": {
                        "content": chunk_text
                    },
                    "finish_reason": None
                }]
            }
            
            # Add usage info to some chunks (mimicking real GPT behavior)
            if i == 0 or random.random() < 0.3:  # 30% chance for intermediate chunks
                usage_data = {
                    "prompt_tokens": estimate_tokens(" ".join([m.get("content", "") for m in request.messages])),
                    "completion_tokens": estimate_tokens("".join(chunks[:i+1])),
                    "total_tokens": estimate_tokens(" ".join([m.get("content", "") for m in request.messages]) + "".join(chunks[:i+1]))
                }
                
                # Add prompt_tokens_details only 50% of the time (more realistic)
                if random.random() < 0.5:
                    usage_data["prompt_tokens_details"] = {"cached_tokens": random.randint(10, 100)}
                
                chunk_data["usage"] = usage_data
            
            yield f"data: {json.dumps(chunk_data)}\n\n"
            
            # Add realistic delays between chunks with load simulation
            if i < len(chunks) - 1:
                chunk_delay = random.uniform(0.05, 0.15) + (load_factor * 0.05)
                await asyncio.sleep(min(chunk_delay, 0.3))
        
        # Send final chunk with finish_reason
        final_chunk = {
            "id": completion_id,
            "object": "chat.completion.chunk", 
            "created": created_time,
            "model": request.model,
            "choices": [{
                "index": 0,
                "delta": {},
                "finish_reason": "stop"
            }],
            "usage": {
                "prompt_tokens": estimate_tokens(" ".join([m.get("content", "") for m in request.messages])),
                "completion_tokens": estimate_tokens(response_text),
                "total_tokens": estimate_tokens(" ".join([m.get("content", "") for m in request.messages]) + response_text),
                "prompt_tokens_details": {"cached_tokens": random.randint(10, 100)}
            }
        }
        
        yield f"data: {json.dumps(final_chunk)}\n\n"
        yield "data: [DONE]\n\n"
        
    except Exception as e:
        # Error handling for streaming
        error_chunk = {
            "id": f"chatcmpl-{uuid.uuid4()}",
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": request.model,
            "choices": [{
                "index": 0,
                "delta": {},
                "finish_reason": "error"
            }]
        }
        yield f"data: {json.dumps(error_chunk)}\n\n"
        yield "data: [DONE]\n\n"

def get_response_for_transcript(messages: List[Dict[str, str]]) -> str:
    """Get appropriate response based on the user's message"""
    
    # Find the latest user message
    user_message = ""
    for message in reversed(messages):
        if message.get("role") == "user":
            user_message = message.get("content", "").strip().lower()
            break
    
    # Check for exact matches with the 3 main transcripts
    for transcript, responses in TRANSCRIPT_RESPONSES.items():
        if transcript in user_message:
            return random.choice(responses)
    
    # Check for partial matches
    if "hello" in user_message or "hi" in user_message or "namaste" in user_message:
        return random.choice(TRANSCRIPT_RESPONSES["hello"])
    elif "how are you" in user_message or "eva" in user_message:
        return random.choice(TRANSCRIPT_RESPONSES["eva how are you"])
    elif "indian history" in user_message or "india" in user_message or "history" in user_message:
        return random.choice(TRANSCRIPT_RESPONSES["i wanna know about the indian history"])
    
    # Return generic response for unknown inputs
    return random.choice(GENERIC_RESPONSES)

def create_realistic_chunks(text: str) -> List[str]:
    """Break text into realistic chunks matching GPT behavior"""
    
    words = text.split()
    chunks = []
    current_chunk = ""
    
    for i, word in enumerate(words):
        current_chunk += word
        
        # Determine if we should break the chunk (matching Sakura's logic)
        should_break = (
            # Break at punctuation (matching the break_punctuation logic)
            word.endswith((',', '!', ':', '.', '?', '|', '।', '፧', '፨')) or
            # Break every 15-20 words to simulate natural chunking
            (len(current_chunk.split()) >= random.randint(15, 20))
        )
        
        if should_break and current_chunk.strip():
            chunks.append(current_chunk)
            current_chunk = ""
        else:
            current_chunk += " "
    
    # Add any remaining text
    if current_chunk.strip():
        chunks.append(current_chunk.strip())
    
    # Ensure we have at least one chunk
    return chunks if chunks else [text]

def estimate_tokens(text: str) -> int:
    """Rough token estimation (1 token ≈ 4 characters)"""
    return max(1, len(text) // 4)

@app.get("/")
async def root():
    """Root endpoint with status"""
    return {
        "service": "Mock LLM API for Sakura Testing",
        "version": "1.0.0",
        "status": "running",
        "performance": {
            "active_requests": active_requests,
            "total_requests": request_count,
            "max_concurrent": "400-500 requests"
        },
        "endpoints": {
            "health": "/health",
            "chat_completions": "/chat/completions",
            "docs": "/docs"
        },
        "supported_transcripts": list(TRANSCRIPT_RESPONSES.keys())
    }

@app.get("/stats")
async def get_stats():
    """Performance statistics endpoint"""
    return {
        "active_requests": active_requests,
        "total_requests": request_count,
        "timestamp": datetime.now().isoformat()
    }

if __name__ == "__main__":
    print("🚀 Starting High-Performance Mock LLM API Server...")
    print("📝 Supported transcripts:", list(TRANSCRIPT_RESPONSES.keys()))
    print("⚡ Concurrent capacity: 400-500 requests")
    print("🔄 Response time: 0.5-3.0 seconds (load-based simulation)")
    print("🌐 Server will run on http://0.0.0.0:8001")
    
    # High-performance configuration for 400-500 concurrent requests
    try:
        # Try to use uvloop for better performance (optional)
        import uvloop
        uvloop.install()
        print("✅ Using uvloop for enhanced performance")
    except ImportError:
        print("⚠️  uvloop not available, using default event loop")
    
    uvicorn.run(
        "mock_llm_api:app",  # Import string required for multiple workers
        host="0.0.0.0", 
        port=8001,
        workers=8,  # Multiple workers for high concurrency
        log_level="info",
        access_log=False,  # Disable access logging for better performance
        limit_concurrency=600,  # Allow up to 600 concurrent connections
        limit_max_requests=10000,  # Restart workers after 10k requests to prevent memory leaks
    )
