#!/bin/bash

# Name of the Python script to run
SCRIPT_NAME="main.py"

# Find the PID of the running script
PID=$(pgrep -f "$SCRIPT_NAME")

if [ -n "$PID" ]; then
  echo "Stopping the currently running instance of $SCRIPT_NAME (PID: $PID)..."
  kill -9 $PID
  echo "Stopped successfully."
else
  echo "No running instance of $SCRIPT_NAME found."
fi

# Start the script with nohup
echo "Starting $SCRIPT_NAME..."
nohup python3 $SCRIPT_NAME > /dev/null 2>&1 &

# Get the new PID
NEW_PID=$!
echo "$SCRIPT_NAME started with PID: $NEW_PID"
