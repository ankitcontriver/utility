from response.showGenericResponse import GenericResponse


class showAssistantItem:
    def __init__(self, id, name, role, description, imageUrl, assistantCategory):
        self.id = id
        self.name = name
        self.role = role
        self.description = description
        self.imageUrl = imageUrl
        self.assistantCategory = assistantCategory

    def __repr__(self):
        return f"showAssistantItem(id={self.id},name={self.name},assistantRole={self.role},description = {self.description},imageUrl={self.imageUrl}, assistantCategory={self.assistantCategory})"


class showAssistents(GenericResponse):
    def __init__(self, status, statusCode, message, data: list[showAssistantItem]):
        super().__init__(statusCode, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, statusCode: {self.statusCode}, message: {self.message}, data: {self.data}"


# class languageItem:
#     def __init__(self, language):
#         self.language = language

#     def __repr__(self):
#        return f"languageItem(language={self.language})"

class tempSAD:
    def __init__(self, id, name, role, languages, description, voice, interface):
        self.id = id
        self.name = name
        self.role = role
        self.description = description
        self.languages = languages
        self.voice = voice
        self.interface = interface

    def __repr__(self):
        return f"showAssistantItem(id={self.id},name={self.name},assistantRole={self.role}, languages = {self.languages}, description = {self.description},voice={self.voice},interface = {self.interface})"


class ShowAssistantDetails(GenericResponse):
    def __init__(self, status, statusCode, message, info: tempSAD):
        super().__init__(statusCode, status, message)
        self.info = info

    def __repr__(self):
        return f"status: {self.status}, statusCode: {self.statusCode}, message: {self.message}, info: {self.info}"
