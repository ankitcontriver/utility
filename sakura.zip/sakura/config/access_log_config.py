"""
Access log configuration for HTTP requests.
"""
import os
import logging
from logging.handlers import TimedRotatingFileHandler

def setup_access_logger():
    """
    Setup access logger similar to main logger but for HTTP requests.
    Returns the access logger instance.
    """
    default_log_path = "logs/sakura.log"
    log_file_path = os.environ.get("LOG_FILE_PATH", default_log_path)
    log_dir = os.path.dirname(log_file_path)
    
    if not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)
    
    access_log_file = os.path.join(log_dir, "access.log")
    
    # Create access logger
    access_logger = logging.getLogger("access")
    access_logger.setLevel(logging.INFO)
    
    # Remove existing handlers
    access_logger.handlers.clear()
    
    # Create file handler with same rotation as main logger
    handler = TimedRotatingFileHandler(
        access_log_file,
        when="H",
        interval=1,
        backupCount=5,
        encoding="utf-8"
    )
    
    # Use same format as main logger
    formatter = logging.Formatter("%(asctime)s - %(message)s")
    handler.setFormatter(formatter)
    
    access_logger.addHandler(handler)
    access_logger.propagate = False  # Don't send to root logger
    
    print(f"Access logger configured: {access_log_file}")
    return access_logger