from fastapi import APIRouter

from logger import get_logger
from models.request_models import TextToSpeechRequest
from service.tts_mapping_service import get_tts_model as get_tts_model_service
from service.tts_mapping_service import get_voice_list as get_voice_list_service
from service.tts_mapping_service import text_to_speech as text_to_speech_service

router = APIRouter()

logger = get_logger(__name__)


@router.get("/get_tts_model", tags=["TTS Mapping"])
def get_tts_model(language_id: str):
    logger.info(f"get_tts_model controller called")
    return get_tts_model_service(language_id)


@router.get("/get_voice_list", tags=["TTS Mapping"])
def get_voice_list(language_id: str, tts_model: str, country: str):
    logger.info(f"get_voice_list controller called")
    return get_voice_list_service(language_id, tts_model, country)


@router.post("/text_to_speech", tags=["TTS Mapping"])
async def text_to_speech(tts_request: TextToSpeechRequest):
    logger.info(f"text_to_speech controller called")
    return await text_to_speech_service(tts_request)
