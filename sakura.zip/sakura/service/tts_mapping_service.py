from config.database_config import SessionLocal
from logger import get_logger
from models.request_models import TextToSpeechRequest
from repository.tts_repository import get_tts_models_repository, get_voice_list_repository
from response.GetTTSModelResponse import GetTTSModelResponse, GetTTSModel
from response.GetVoiceListResponse import GetVoiceListResponse, GetVoiceList
from response.TextToSpeechResponse import TextToSpeechResponse
from utils.llm_util import generate_transcript_based_on_provider

logger = get_logger(__name__)


def get_tts_model(language_id: str):
    logger.info("get_tts_model service called")
    logger.info(f"get_tts_model request Language : {language_id}")
    db = SessionLocal()
    response = None
    try:
        tts_models = get_tts_models_repository(db, language_id)
        logger.info(f"tts_models : {tts_models}")
        if tts_models is None or len(tts_models) == 0:
            response = GetTTSModelResponse(status="Failed", status_code=400, message="TTS Model List not found",
                                           data=[])
        else:
            seen_models = set()
            unique_models = []

            for model in tts_models:
                if model.tts_model_name not in seen_models:
                    seen_models.add(model.tts_model_name)
                    unique_models.append(GetTTSModel(
                        id=model.id,
                        tts_model_name=model.tts_model_name
                    ))

            response = GetTTSModelResponse(
                status="Success",
                status_code=200,
                message="TTS model list retrieved successfully",
                data=unique_models
            )
    except Exception as e:
        logger.error(f"Error in get_tts_model service : {e} ")
        response = GetTTSModelResponse(status="Failed", status_code=400, message="Error in get_tts_model service",
                                       data=[])
    finally:
        db.close()
    logger.info(f"get_tts_model response : {response}")
    return response


def get_voice_list(language_id: str, tts_model: str, country: str):
    logger.info("get_voice_list service called")
    logger.info(f"get_voice_list request Language : {language_id}, TTS Model : {tts_model}, Country : {country}")
    db = SessionLocal()
    response = None
    try:
        voice_list = get_voice_list_repository(db, language_id, tts_model)
        logger.info(voice_list)
        if voice_list is None or len(voice_list) == 0:
            response = GetVoiceListResponse(status="Failed", status_code=400, message="Voice List not found", data=[])
        else:
            matched_voices = []
            other_voices = []

            # Separate voices into matched and unmatched lists
            for voice in voice_list:
                if voice.country_name == country:
                    matched_voices.append(voice)
                else:
                    other_voices.append(voice)

            # Combine matched voices followed by unmatched voices
            sorted_voices = matched_voices + other_voices

            # Prepare the response data
            voices = [
                GetVoiceList(
                    id=voice.id,
                    language_code=voice.language_code,
                    voice_name=voice.voice_name,
                    language_display_name=voice.language_display_name,
                    gender=voice.gender,
                    sample_text=voice.sample_voice_text
                ) for voice in sorted_voices
            ]

            response = GetVoiceListResponse(
                data=voices,
                status_code=200,
                status="Success",
                message="Voice list retrieved successfully"
            )
    except Exception as e:
        logger.error(f"Error in get_voice_list service : {e} ")
        # print(f"Error in get_voice_list service : {e} ")
        response = GetVoiceListResponse(status="Failed", status_code=400, message="Error in get_voice_list service",
                                        data=[])
    finally:
        db.close()
    logger.info(f"get_voice_list response : {response}")
    return response


async def text_to_speech(tts_request: TextToSpeechRequest):
    logger.info("text_to_speech service called")
    response = None

    try:
        logger.info(f"text_to_speech request : {tts_request}")

        # Generate base64 audio
        base64_audio = generate_transcript_based_on_provider(provider=tts_request.tts_model, gender=tts_request.gender,
                                                      chunk_text=tts_request.text, voice_code=tts_request.voice_name,
                                                      call_id="tts_req", tts_style="chat",
                                                      language=tts_request.language_code)

        # Convert to WAV file using TTS manager
        try:
            from service.pa_tts_manager import get_tts_manager
            import time
            tts_manager = get_tts_manager()
            if tts_manager:
                response_id = f"tts_mapping_{int(time.time() * 1000)}"
                wav_path = await tts_manager.convert_chunk_to_wav(
                    base64_chunk=base64_audio,
                    call_id="tts_req",
                    response_id=response_id
                )
                logger.info(f"Converted TTS mapping audio to WAV: {wav_path}")
                audio = wav_path
            else:
                logger.warning("TTS manager not available, using base64 audio")
                audio = base64_audio
        except Exception as e:
            logger.error(f"Failed to convert TTS mapping audio to WAV: {e}")
            audio = base64_audio

        response = TextToSpeechResponse(status_code=200, status="Success",
                                        message="Text to Speech model service call successful", data=audio)
    except Exception as e:
        logger.error(f"Error in text_to_speech service : {e} ")
        response = TextToSpeechResponse(status="Failed", status_code=400, message="Error in text_to_speech service",
                                        data=None)
    return response
