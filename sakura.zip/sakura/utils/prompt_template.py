intent_analyser_prompt = """
You're an Intent analyzer. I'll provide you with sentences or transcripts from the user, and you'll categorize them 
into four types: a) Incomplete, b) Nodding, c) Complete and Meaningful d) Interrupt.

Examples for all four:

Incomplete~ Hi, Who are
Nodding~ Alright, I understand.
Complete~ Okay, now tell me about the next book in the Harry Potter Series.
Interrupt~ Hold on.

Explanation for each category:

A sentence is considered incomplete when it lacks both grammatical and semantic meaning.
A sentence is classified as nodding when it's grammatically sound but doesn't necessitate a response as it merely 
acknowledges received information.
A sentence is categorized as complete when it's meaningful, prompts a response, and can be engaged with further.
A sentence is classified as an interrupt when it is trying to stop the ongoing conversation, which is usually evident 
from keywords like "Stop" or "Wait", etc.



You have to do this in all languages known to you.
"""

new_intent_analyser_prompt = """
You're an Intent analyzer. I'll provide you with sentences or transcripts from the user, and you'll categorize them 
into four types: a) Incomplete, b) Nodding, c) Complete and Meaningful d) Interrupt.

Examples for all four:

Incomplete~ Hi, Who are
Incomplete~ What is
Incomplete~ is your name?
Nodding~ Alright, I understand.
Nodding~ Got it. 
Nodding~ Okay.
Complete~ Okay, now tell me about the next book in the Harry Potter Series.
Complete~ What all can you do?
Complete~ Tell me the watch order for Monogatari Series.
Interrupt~ Hold on.
Interrupt~ Stop.
Interrupt~ Wait. Wait. Wait.


Explanation for each category:

A sentence is considered incomplete when it lacks both grammatical and semantic meaning.
A sentence is classified as nodding when it's grammatically sound but doesn't necessitate a response as it merely 
acknowledges received information.
A sentence is categorized as complete when it's meaningful, prompts a response, and can be engaged with further.
A sentence is classified as an interrupt when it is trying to stop the ongoing conversation, which is usually evident 
from keywords like "Stop" or "Wait", etc.

You will also receive also receive Voice Assistant's current state, whether it's in 
Listening State or Speaking State.

You have to classify sentences into Interrupt Class only when the Voice Assistant is in Speaking state,
else you have to classify sentences only into 3 classes : Complete, Incomplete or Nodding.


You have to do this in all languages known to you.

You'll only REPLY in ONE word only from below options.
You have 4 options:

Complete
Incomplete
Nodding
Interrupt
"""

speaking_state_intent_analyser = """
Task: Intent Analysis
As an Intent Analyzer, your role is to categorize user responses during interactions with a voice assistant. Each response should be classified into one of three categories based on the user's intent:

1. Interrupt: The user's response indicates a request to pause or stop the assistant's current speech.
2. Nodding: The user's response signifies understanding or agreement, typically short and affirmative.
3. Interrupt_with_Statement: The user's response includes a correction, clarification, or a new query directed at the 
assistant.
Response Requirement: You are required to respond with a single word indicating the category: "Interrupt", "Nodding", or "Interrupt_with_statement".

Examples:

Interrupt: "Stop.", "Wait.", "Hold on."
Nodding: "Alright, I understand.", "Got it.", "Okay."
Interrupt_with_statement: "Stop, I meant to ask about the distance between Gurugram and Mumbai, not Delhi to Mumbai.", "Wait, why are you telling me about Chandragupta II? I wanted to know about Chandragupta Maurya.", "Hold on, there's a city called Katihar in Bihar?", "Eva, I want to know about the Big Bang Theory.", "Okay, can you give me...", "Can you give me details of Shahrukh Khan?"

Explanation of Categories:

Interrupt: Requests the assistant to stop speaking and switch to listening mode.
Nodding: Simple acknowledgments that express agreement or understanding.
Interrupt with Statement: Responses that correct, clarify, rephrase a query, or introduce a new question.

Language Scope: Perform this task in all languages known to you.
"""

listening_state_intent_analyser = """
You're an Intent analyzer. I'll provide you with sentences or transcripts from the user, and you'll categorize them 
into 3 types: a) Incomplete, b) Nodding, c) Complete 
You'll have to understand the intent of user's sentence then  give me the desired result.
Examples for all 3:

Incomplete~ Hi, Who are
Incomplete~ What is
Incomplete~ is your name?
Nodding~ Alright, I understand.
Nodding~ Got it. 
Nodding~ Okay.
Complete~ Okay, now tell me about the next book in the Harry Potter Series.
Complete~ What all can you do?
Complete~ Tell me the watch order for Monogatari Series.


Explanation for each category:

A sentence is considered incomplete when it lacks both grammatical and semantic meaning.
A sentence is classified as nodding when it's grammatically sound but doesn't necessitate a response as it merely 
acknowledges received information.
A sentence is categorized as complete when it's meaningful, prompts a response, and can be engaged with further.

You have to do this in all languages known to you.

You are only supposed give responses in only 1 word. 
You have 3 options:

Complete
Incomplete
Nodding
"""

transcription_intent_analyser_prompt = """
Objective:

To accurately recognize and classify the generic intent of a user utterance, and to provide a confidence level for each identified intent.

Instructions:

	1.	Identify Speaker: Determine if the speaker is the user or the system. Mark user utterances with a “User:” prefix.
	2.	Capture Utterance: Transcribe the user’s spoken words as accurately as possible.
	3.	Identify Intent: Analyze the transcribed utterance and classify it into one of the following generic intents:
	•	Greeting
	•	Information Request
	•	Action Request
	•	Confirmation
	•	Denial
	•	Clarification
	•	Feedback
	•	Complaint
	•	Help
	•	Farewell
	•	Order
	•	Cancellation
	•	Appointment
	•	Status Check
	•	Account Management
	•	Navigation
	•	General Inquiry
	•	Reminder
	•	Update
	•	Recommendation
	4.	Confidence Level: Provide a confidence level for the identified intent. The confidence level should be a percentage between 0% and 100%, indicating the certainty of the classification.
	5.	Output Format: Return the recognized intent and confidence level in the following CSV format:	  Utterance,Intent,Confidence
"<transcribed utterance>","<recognized intent>","<confidence level>%" Special Considerations:
	•	Background Noise: Filter out non-verbal sounds and background noise as much as possible.
	•	Accents and Dialects: Adapt to different accents and dialects to ensure accurate transcription and intent recognition.
	•	Multiple Intents: If the utterance contains multiple intents, list each intent with its corresponding confidence level as separate rows.

Example:

User: Hello, I need help with my account balance. Can you check it for me?

Expected Output:Utterance,Intent,Confidence
"Hello, I need help with my account balance. Can you check it for me?","Help","95%" User: Thank you, that’s all.   Utterance,Intent,Confidence
"Thank you, that's all.","Farewell","98%
"""

opening_statement_prompt = """You're provided with the details of the Assistant. You've to create a opening message that can be used to start the conversation with the user. Opening message should be engaging and greetful to the user. Don't introduce yourself as assistant if possible ask your about How there day is going, etc.. Always, Include Assistant's name and should be one liner, 7-8 words. \n For Example - "Hello! I'm {assistant_name}. How can I help you today?" \n Hey! I am {assistant_name}. How can I assist you today? \n Hello! I'm {assistant_name}. How are you doing today?"""

no_reply_prompt = """ Above is the conversation history between user and assistant, along with system prompt (instructions) for the assistant. After certain time, now user is not replying to the assistant. So, the assistant will now take the lead and will initiate the conversation. The assistant will now ask the user a question or a normal message to keep the conversation going. So staying in context of the conversation history, generate a new message from assistant.
"""

call_sentiment_analyser_prompt = """Analyze the overall sentiment of the entire conversation between the user and the assistant. Identify the general sentiment as positive, negative, or neutral. Example Outputs - Positive, Negative, Neutral only and no explanation. \n Here’s the conversation: \n """

call_emotions_analyser_prompt = """Analyze the overall emotional tone of the following conversation between the user and the assistant. Identify the primary emotion(s) expressed by the user throughout the conversation (e.g., curiosity, satisfaction, frustration). Example output - One-Two Word Emotion only no explanation. \n Here’s the conversation: \n """

call_intent_analyser_prompt = """ Identify the main intent or objective of the user throughout the entire conversation with the assistant. Summarize the user's purpose (e.g., information-seeking, troubleshooting, casual interaction). Example output - One-Two Word Intent only no explanation. \n Here’s the conversation: \n  """

call_satisfaction_analyser_prompt = """Evaluate the user's satisfaction with the assistant's replies based on the entire conversation. Rate the user’s overall satisfaction percentage on a scale of 1 to 100 (1 being very dissatisfied, 100 being very satisfied). Reply only from 1-100 nothing else. \n Here’s the conversation: \n """

sh_opening_statement_prompt = """You're provided with the details of the Assistant. You've to create a opening message that can be used to start the conversation with the user. Opening message should be engaging and greetful to the user. Don't introduce yourself as assistant if possible ask your about How there day is going, etc.. Always, Include Assistant's name and should be one liner, 7-8 words. \n For Example - "Hello! I'm {assistant_name}. How can I help you today?" \n Hey! I am {assistant_name}. How can I assist you today? \n Hello! I'm {assistant_name}. How are you doing today?. You are also given the previous resolved complains of the user you are greeting. Inform the user of these complains after the opening message."""
