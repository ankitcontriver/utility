from response.GenericResponse import GenericResponse


class UserObject:
    def __init__(self, user_id, name, email):
        self.user_id = user_id
        self.name = name
        self.email = email

    def __repr__(self):
        return f"UserObject({self.user_id}, {self.name}, {self.email})"


class GetAllUserResponse(GenericResponse):
    def __init__(self, status_code, status, message, data: list[UserObject]):
        super().__init__(status_code=status_code, status=status, message=message)
        self.data = data

    def __repr__(self):
        return f"GetAllUserResponse({self.status_code}, {self.status}, {self.message}, {self.data})"
