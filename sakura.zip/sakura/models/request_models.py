from typing import Optional, Dict, Union, Any

from pydantic import BaseModel
from enums.call_enums import Event
from enums.audio_frequency_enums import AudioFrequencyEnum


class CallStartData(BaseModel):
    callId: Union[int,str]
    assistantId: Optional[str] = None
    gender: str
    languageCode: Optional[str] = "en-IN"
    voiceName: Optional[str] = "en-IN-NeerjaNeural"
    ttsModel: Optional[str] = "Azure"
    llmModel: Optional[str] = "gpt-3.5-turbo"
    isTranslate: Optional[bool] = False
    additionalInfo: Optional[str] = None
    email_id: Optional[str] = None
    country_code: Optional[str] = None
    ttsProvider: Optional[str] = None
    isSendEmail: Optional[bool] = None
    customMessage: Optional[str] = None
    assistantStyle: Optional[str] = "friendly"
    assistantName: Optional[str] = None
    aParty: Optional[str]=None
    bParty: Optional[str]=None
    userName: Optional[str] = None
    serviceType: Optional[str] = None
    questionPerCall: Optional[int] = None
    node_id: Optional[int] = None
    handleTelemarketingCalls: Optional[bool] = None
    telemarketingKeywords: Optional[Any] = None
    operator: Optional[str] = None
    country: Optional[str] = None


class MessageEvent(BaseModel):
    callId: Union[int,str]
    transcript: str
    startTime: int
    endTime: int
    messageId: Optional[str] = None
    langCode: Optional[str] = "en-IN"
    voiceName: Optional[str] = "en-IN-Wavenet-A"
    eventType: Optional[str] = Event.CALL.value
    node_id: Optional[int] = None


class MessageResponse(BaseModel):
    callId: Union[int,str]
    isEndChunk: bool
    transcript: str
    chunk: str
    messageId: Optional[str] = None
    eventType: Optional[str] = Event.CALL.value

    def __repr__(self):
        return (
            f"MessageResponse(callId={self.callId}, isEndChunk={self.isEndChunk}, "
            f"chunk={self.chunk}, transcript={self.transcript}, messageId={self.messageId}, eventType={self.eventType})"
        )


class IntentAnalyserRequest(BaseModel):
    callId: Union[int,str]
    transcript: str
    messageId: Optional[str] = None
    is_bot_speaking: bool


class TextToSpeechRequest(BaseModel):
    tts_model: str
    language_code: str
    voice_name: str
    gender: str
    text: str


class OrganizationNameRequest(BaseModel):
    organization_name: str
    sector: str
    email: str


class UserMappingRequest(BaseModel):
    email: str
    org_id: int


class UserMappingResponse(BaseModel):
    id: int
    email: str
    organization_name: str


class UpdateUserMappingResponse(BaseModel):
    id: int
    email: str
    organization_name: str


class UpdateOrganizationDetailRequest(BaseModel):
    agent_id: int
    org_id: int
    agent_type: str
    enterprise_data: str
    local_specs: str
    website: str
    website_summary: str
    parameters: Optional[Dict] = None


class SectorRequest(BaseModel):
    sector_name: str
    capabilities: Optional[str]


class UpdateSectorRequest(BaseModel):
    sector_name: str
    capabilities: Optional[str]


class AudioRequest(BaseModel):
    audio_map: dict[str, str]
    name: str
    frequency: AudioFrequencyEnum = AudioFrequencyEnum.DEFAULT.value
    language: str
    voice_name: str


class SingleAudioRequest(BaseModel):
    name: str
    text: str
    frequency: str
    language: str
    voice_code: str


class GetMenuRequest(BaseModel):
    user_type: str


class LoginRequest(BaseModel):
    email: str
    password: str
    ip: str


class SignUpRequest(BaseModel):
    name: str
    email: str
    contact_number: str


class UidLoginRequest(BaseModel):
    user_id: str
    ip: str


class CallLogsRequest(BaseModel):
    email: str
    call_duration: int
    call_logs: str
    ip: str
    browser_data: str
    config: str
    date: str


class ContactForm(BaseModel):
    id: int
    name: str
    email: str
    phone_number: str
    query_type: str
    message: str
    user_id: int

    def __repr__(self):
        return f"ContactForm({self.id}, {self.name}, {self.email}, {self.phone_number}, {self.query_type}, {self.message}, {self.user_id})"


class DemoFlowRequest(BaseModel):
    ip: str
    country: str


class ViniEventResponse(BaseModel):
    callId: int
    messageId: str
    eventType: str
    pageToNavigate: str

class LogLevelRequest(BaseModel):
    level: str
