class GenericResponse:
    def __init__(self, status_code, status, message):
        self.status_code = status_code
        self.status = status
        self.message = message

    def __repr__(self):
        return f"GenericResponse(status_code={self.status_code}, status={self.status}, message={self.message})"
