import json
import os
from typing import Dict, Any, Set

# Path to the JSON configuration file
CONFIG_FILE_PATH = os.path.join(os.path.dirname(__file__), 'ivr_path_config.json')

# Module-level cache for node_type -> config
_node_type_map = None

def load_config() -> Dict[str, Any]:
    """Load configuration from JSON file"""
    try:
        with open(CONFIG_FILE_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        # Return default configuration if file not found
        return {
            "non_skippable_config": {
                "Navigation": {
                    "is_skippable": False,
                    "land_before": 1,
                    "description": "Navigation node (non-skippable unless _VOICEPROMPT.wav present)"
                },
                "Url": {
                    "is_skippable": False,
                    "land_before": 1,
                    "description": "User input node"
                },
                "Db": {
                    "is_skippable": False,
                    "land_before": 1,
                    "description": "Database operation node"
                },
                "Processing": {
                    "is_skippable": False,
                    "land_before": 1,
                    "description": "Processing node"
                }
            },
            "default_config": {
                "is_skippable": True,
                "land_before": 1,
                "description": "Default node"
            }
        }
    except Exception as e:
        print(f"Error loading IVR path config: {e}")
        return {}

# Load configuration
_config = load_config()

def get_config():
      return _config

def build_node_type_map(nodes) -> Dict[str, Any]:
    """
    Given a flat_array (list of node dicts), return a node_map (node_id -> config dict)
    using the cached node_type map. Each entry includes type, land_before, is_skippable, and description.
    """
    node_type_map = get_node_type_map()
    return {
        node['id']: {
            'type': node['type'],
            'land_before': node_type_map.get(node['type'], node_type_map['__default__'])['land_before'],
            'is_skippable': node_type_map.get(node['type'], node_type_map['__default__'])['is_skippable'],
            'description': node_type_map.get(node['type'], node_type_map['__default__'])['description'],
        }
        for node in nodes
    }

# Build and cache node_type_map on module load
_node_type_map = dict(_config.get("non_skippable_config", {}))
_node_type_map['__default__'] = _config.get("default_config", {
    "is_skippable": True,
    "land_before": 1,
    "description": "Default node"
})

def get_node_type_map() -> Dict[str, Any]:
    """Return the cached node_type -> config map."""
    return _node_type_map

def get_land_before(node_type: str) -> int:
    """Get land_before value for a given node type"""
    non_skippable_config = _config.get("non_skippable_config", {})
    default_config = _config.get("default_config", {"land_before": 1})
    
    if node_type in non_skippable_config:
        return non_skippable_config[node_type].get("land_before", 1)
    return default_config.get("land_before", 1)

def get_is_skippable(node_type: str) -> bool:
    """Get is_skippable value for a given node type (before _VOICEPROMPT.wav check)"""
    non_skippable_config = _config.get("non_skippable_config", {})
    default_config = _config.get("default_config", {"is_skippable": True})
    
    if node_type in non_skippable_config:
        return non_skippable_config[node_type].get("is_skippable", True)
    return default_config.get("is_skippable", True)

def get_non_skippable_types() -> Set[str]:
    """Get set of node types that are non-skippable by default"""
    non_skippable_config = _config.get("non_skippable_config", {})
    return {node_type for node_type, config in non_skippable_config.items() 
            if not config.get("is_skippable", True)}

def reload_config():
    """Reload configuration from file (useful for runtime updates) and update node_type_map cache."""
    global _config, _node_type_map
    _config = load_config()
    _node_type_map = dict(_config.get("non_skippable_config", {}))
    _node_type_map['__default__'] = _config.get("default_config", {
        "is_skippable": True,
        "land_before": 1,
        "description": "Default node"
    }) 

def build_node_id_config_map(nodes) -> Dict[str, Any]:
    """
    Given a flat_array (list of node dicts), return a node_map (node_id -> config dict)
    using the cached node_type map. Each entry includes type, land_before, is_skippable, and description.
    """
    node_type_map = get_node_type_map()
    return {
        node['id']: {
            'type': node['type'],
            'land_before': node_type_map.get(node['type'], node_type_map['__default__'])['land_before'],
            'is_skippable': node_type_map.get(node['type'], node_type_map['__default__'])['is_skippable'],
            'description': node_type_map.get(node['type'], node_type_map['__default__'])['description'],
        }
        for node in nodes
    } 