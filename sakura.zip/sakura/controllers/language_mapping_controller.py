from fastapi import APIRouter
from service.language_mapping_service import get_voice_service

router = APIRouter()


@router.get("/get_voice", tags=["Language Mapping"])
def get_voice(lang_code: str):
    return get_voice_service(lang_code)
