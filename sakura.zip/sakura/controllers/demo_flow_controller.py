import traceback

from fastapi import APIRouter, HTTPException
from logger import get_logger

from models.request_models import DemoFlowRequest
from service.demo_flow_service import get_flow_details_service, get_questionnaire_service

logger = get_logger(__name__)

router = APIRouter()


@router.post("/get_flow_details", tags=["Demo Flow"])
def get_flow_details(demo_flow_request: DemoFlowRequest):
    try:
        logger.info(f"get_flow_details controller called request: {demo_flow_request}")
        response = get_flow_details_service(demo_flow_request)
        logger.info(f"get_flow_details controller response: {response}")
        return response
    except Exception as e:
        logger.error(f"Error in get_flow_details controller: {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/getQuestionnaire", tags=["Demo Flow"])
def introspect(assistant_id: int):
    logger.info(f"get_questionnaire controller called for assistant_id: {assistant_id}")
    return get_questionnaire_service(assistant_id)

