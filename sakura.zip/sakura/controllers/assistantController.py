from fastapi import APIRouter, HTTPException, Query

from logger import get_logger
from typing import Optional
from repository.assistant_repository import download_img
from service.assistantService import get_assistants_by_tenant_service, get_assistant_by_id_service, \
    update_assistant_service, update_assistant_xml_flow_service

router = APIRouter()
import traceback
from pydantic import BaseModel
logger = get_logger(__name__)

class Payload(BaseModel):
    role: str
    name: str
    languageId: str
    voiceId: str
    interfaceId: str


class UpdateXMLFlowRequest(BaseModel):
    short_code: str
    country: Optional[str] = None
    operator: Optional[str] = None
    xml_flow: str
    prompt_stt_mapping: Optional[str] = None


@router.get("/assistants", tags=['Assistants'])
def get_assistants(tenantId: str = Query(..., min_length=1)):
    """
    Retrieves assistants for a specific tenantId.
    Ensures tenantId is provided and not empty.
    """
    if not tenantId.strip():
        logger.info(f"Received request with empty tenantId: {tenantId}")
        raise HTTPException(status_code=400, detail="tenantId is required and cannot be empty.")

    logger.info(f"Received request to get assistants for tenantId: {tenantId}")
    try:
        result = get_assistants_by_tenant_service(tenantId)
        logger.info(f"Successfully retrieved assistants for tenantId: {tenantId}")
        return result
    except Exception as e:
        logger.error(f"Error fetching assistants for tenantId: {tenantId}. Error : {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/general/view", tags=['Assistants'])
def get_assistant(tenantId: str = Query(..., min_length=1), assistantId: str = Query(..., min_length=1)):
    """
    Retrieves a specific assistant based on tenantId and assistantId.
    Ensures both tenantId and assistantId are provided and not empty.
    """
    if not tenantId.strip() or not assistantId.strip():
        logger.info(f"Received request with empty tenantId: {tenantId} and assistantId: {assistantId}")
        raise HTTPException(status_code=400, detail="tenantId and assistantId are required and cannot be empty.")

    logger.info(f"Received request to view assistant with assistantId: {assistantId} for tenantId: {tenantId}")
    try:
        result = get_assistant_by_id_service(tenantId, assistantId)
        logger.info(f"Successfully retrieved assistant with assistantId: {assistantId} for tenantId: {tenantId}")
        return result
    except Exception as e:
        logger.error(
            f"Error fetching assistant with assistantId: {assistantId} for tenantId: {tenantId}. Error : {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.patch("/assistant/update", tags=['Assistants'])
def update_assistant(
    payload: Payload,
    tenant_id: str = Query(..., alias="tenantId"),  # Extract tenantId from query params
    assistant_id: str = Query(..., alias="assistantId"),  # Extract assistantId from query params
  # Extract the assistant details from the request body
):
    """
    Updates assistant details based on provided parameters.
    Ensures tenantId and assistantId are provided and valid.
    Payload contains assistant details (role, name, languageId, voiceId, interfaceId).
    """
    # Validate tenantId and assistantId
    if not tenant_id.strip() or not assistant_id.strip():
        logger.info(f"Received request with empty tenantId: {tenant_id} or assistantId: {assistant_id}")
        raise HTTPException(status_code=400, detail="tenantId and assistantId are required and cannot be empty.")
    
    if not payload.role.strip() or not payload.name.strip() or not payload.languageId.strip() or not payload.voiceId.strip() or not payload.interfaceId.strip():
        raise HTTPException(status_code=400, detail="Payload Arguments cannot be empty")
    # Extract values from the payload
    role = payload.role
    name = payload.name
    language_id = payload.languageId
    voice_id = payload.voiceId
    interface_id = payload.interfaceId

    logger.info(f"Received request to update assistant with assistantId: {assistant_id} for tenantId: {tenant_id}")
    
    try:
        # Assuming `update_assistant_service` is a function that processes the update
        result = update_assistant_service(
            tenant_id, assistant_id, role, name, language_id, voice_id, interface_id
        )
        logger.info(f"Successfully updated assistant with assistantId: {assistant_id} for tenantId: {tenant_id}")
        return result
    except Exception as e:
        logger.error(f"Error updating assistant with assistantId: {assistant_id} for tenantId: {tenant_id}. Error: {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="An error occurred while updating the assistant.")


@router.get("/assistant/get/image", tags=['Assistants'])
def download_file(id: int):
    return download_img(id)



@router.post("/assistant/update-xml-flow", tags=['Assistants'])
def update_xml_flow(request: UpdateXMLFlowRequest):
    """
    Updates the XML flow for an assistant based on client configuration.
    Country and operator are optional parameters.
    """
    try:
        logger.info(f"Received request to update XML flow for short_code: {request.short_code}")
        result = update_assistant_xml_flow_service(
            request.operator,
            request.country,
            request.short_code,
            request.xml_flow
        )
        
        # Map internal status codes to HTTP status codes
        if result["statusCode"] == 404:
            raise HTTPException(status_code=404, detail=result["message"])
        elif result["statusCode"] == 500:
            raise HTTPException(status_code=500, detail=result["message"])
            
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating XML flow: {e}",exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
