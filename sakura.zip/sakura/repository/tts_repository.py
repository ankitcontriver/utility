from sqlalchemy.orm import Session

from models.database_models import TTSLanguageMapping


def get_tts_models_repository(db: Session, language_id: str):
    return db.query(TTSLanguageMapping).filter(TTSLanguageMapping.language_id == language_id, TTSLanguageMapping.status == True).all()


def get_voice_list_repository(db: Session, language_id: str, tts_model_name: str):
    return db.query(TTSLanguageMapping).filter(TTSLanguageMapping.language_id == language_id, TTSLanguageMapping.tts_model_name == tts_model_name, TTSLanguageMapping.status == True).all()


def get_tts_language_mapping_by_voice_name(db: Session, voice_name: str) -> TTSLanguageMapping:
    return db.query(TTSLanguageMapping).filter(TTSLanguageMapping.voice_name == voice_name).first()


def get_voice_by_name(db: Session, voice_name: str):
    return db.query(TTSLanguageMapping.voice_name).filter(TTSLanguageMapping.language_display_name == voice_name).all()
