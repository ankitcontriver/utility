import os
import base64
import uuid
from typing import List, Optional, Dict
from datetime import datetime
import logging
from pydub import AudioSegment
import asyncio
from pathlib import Path
import threading
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)

class TTSManager:
    """
    Manages TTS file conversion and concatenation for all services.
    Handles base64 to WAV conversion and creates complete response files.
    Thread-safe for multiple concurrent calls.
    """
    
    def __init__(self, chunk_dir: str, complete_dir: str):
        self.chunk_dir = chunk_dir
        self.complete_dir = complete_dir
        
        # Create directories if they don't exist
        os.makedirs(self.chunk_dir, exist_ok=True)
        os.makedirs(self.complete_dir, exist_ok=True)
        
        # Thread-safe counters for each call
        self._call_counters = {}
        self._call_responses = {}  # Track active responses per call
        self._lock = threading.Lock()
        
        logger.info(f"TTSManager initialized with chunk_dir: {chunk_dir}, complete_dir: {complete_dir}")
    
    def _get_next_chunk_index(self, call_id: str, response_id: str) -> int:
        """Get next chunk index for a call/response pair (thread-safe)"""
        with self._lock:
            key = f"{call_id}_{response_id}"
            if key not in self._call_counters:
                self._call_counters[key] = 0
            self._call_counters[key] += 1
            return self._call_counters[key]
    
    def _reset_counters(self, call_id: str, response_id: str):
        """Reset counters for a call/response pair (thread-safe)"""
        with self._lock:
            key = f"{call_id}_{response_id}"
            if key in self._call_counters:
                del self._call_counters[key]
            if key in self._call_responses:
                del self._call_responses[key]
    
    def _add_chunk_path(self, call_id: str, response_id: str, chunk_path: str):
        """Add chunk path to response tracking (thread-safe)"""
        with self._lock:
            key = f"{call_id}_{response_id}"
            if key not in self._call_responses:
                self._call_responses[key] = []
            self._call_responses[key].append(chunk_path)
    
    def _get_chunk_paths(self, call_id: str, response_id: str) -> List[str]:
        """Get all chunk paths for a response (thread-safe)"""
        with self._lock:
            key = f"{call_id}_{response_id}"
            return self._call_responses.get(key, [])
    
    async def convert_chunk_to_wav(self, base64_chunk: str, call_id: str, response_id: str) -> str:
        """
        Convert base64 TTS chunk to WAV file with automatic chunk indexing.
        
        Args:
            base64_chunk: Base64 encoded audio data
            call_id: Unique call identifier
            response_id: Unique response identifier
            
        Returns:
            str: Path to the created WAV file
        """
        try:
            # Get next chunk index (thread-safe)
            chunk_index = self._get_next_chunk_index(call_id, response_id)
            
            # Generate unique filename
            timestamp = int(datetime.now().timestamp() * 1000)
            filename = f"{call_id}_{response_id}_chunk_{chunk_index}_{timestamp}.wav"
            file_path = os.path.join(self.chunk_dir, filename)
            
            # Decode base64 and write to file
            audio_data = base64.b64decode(base64_chunk)
            with open(file_path, 'wb') as f:
                f.write(audio_data)
            
            # Add chunk path to response tracking
            self._add_chunk_path(call_id, response_id, file_path)
            
            logger.debug(f"Converted chunk {chunk_index} for call {call_id}, response {response_id} to {file_path}")
            return file_path
            
        except Exception as e:
            logger.error(f"Failed to convert chunk for call {call_id}, response {response_id}: {e}")
            raise
    
    async def process_response_end(self, call_id: str, response_id: str) -> Optional[str]:
        """
        Process response end: concatenate all chunks for a specific response.
        This should be called when isEndChunk=True is received.
        
        Args:
            call_id: Unique call identifier
            response_id: Unique response identifier
            
        Returns:
            str: Path to complete WAV file, or None if processing fails
        """
        try:
            # Get all chunk paths for this response
            chunk_paths = self._get_chunk_paths(call_id, response_id)
            
            if not chunk_paths:
                logger.warning(f"No chunk paths found for call {call_id}, response {response_id}")
                return None
            
            # Concatenate chunks for this response
            complete_path = await self.concatenate_response_chunks(call_id, response_id, chunk_paths)
            
            # Reset counters after processing
            self._reset_counters(call_id, response_id)
            
            return complete_path
            
        except Exception as e:
            logger.error(f"Failed to process response end for call {call_id}, response {response_id}: {e}")
            return None
    
    async def concatenate_response_chunks(self, call_id: str, response_id: str, chunk_paths: List[str]) -> Optional[str]:
        """
        Concatenate audio chunks for a specific response into a complete WAV file.
        
        Args:
            call_id: Unique call identifier
            response_id: Unique response identifier
            chunk_paths: List of chunk file paths to concatenate
            
        Returns:
            str: Path to the complete WAV file, or None if concatenation fails
        """
        try:
            if not chunk_paths:
                logger.warning(f"No chunk paths provided for call {call_id}, response {response_id}")
                return None
            
            # Generate complete filename
            timestamp = int(datetime.now().timestamp() * 1000)
            complete_filename = f"{call_id}_{response_id}_complete_{timestamp}.wav"
            complete_path = os.path.join(self.complete_dir, complete_filename)
            
            # Concatenate audio chunks using pydub
            combined_audio = AudioSegment.empty()
            
            for chunk_path in chunk_paths:
                if os.path.exists(chunk_path):
                    try:
                        audio_segment = AudioSegment.from_wav(chunk_path)
                        combined_audio += audio_segment
                    except Exception as e:
                        logger.warning(f"Failed to process chunk {chunk_path}: {e}")
                        continue
            
            # Export combined audio
            combined_audio.export(complete_path, format="wav")
            
            logger.info(f"Concatenated {len(chunk_paths)} chunks for call {call_id}, response {response_id} to {complete_path}")
            return complete_path
            
        except Exception as e:
            logger.error(f"Failed to concatenate chunks for call {call_id}, response {response_id}: {e}")
            return None

# Global TTS Manager instance - Auto-initialized
tts_manager = None

def get_tts_manager() -> Optional[TTSManager]:
    """Get the global TTS Manager instance (auto-initializes if needed)"""
    global tts_manager
    
    if tts_manager is None:
        try:
            chunk_dir = os.getenv('TTS_CHUNK_DIR', '/tmp/stream/tts/chunks/')
            complete_dir = os.getenv('TTS_COMPLETE_DIR', '/tmp/stream/tts/complete/')
            tts_manager = TTSManager(chunk_dir, complete_dir)
            logger.info("TTS Manager auto-initialized successfully")
        except Exception as e:
            logger.error(f"Error auto-initializing TTS Manager: {e}")
            return None
    
    return tts_manager