from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List, Dict, Any
from pydantic import BaseModel
from datetime import datetime
import json
from logger import get_logger

router = APIRouter()
logger = get_logger(__name__)

class VectorSearchRequest(BaseModel):
    query: str
    top_k: int = 5
    voice_code: Optional[str] = None

class VectorEntryResponse(BaseModel):
    id: str
    query: str
    response: str
    confidence: float
    tts_file_path: str
    voice_code: str
    tts_style: str
    provider: str
    gender: str
    assistant_id: str
    call_id: str
    service_type: str
    response_id: str
    timestamp: str
    tier_used: int
    context: Dict[str, Any]
    generation_time: Optional[float]
    token_usage: Optional[Dict[str, Any]]
    clustering: Optional[Dict[str, Any]]

class VectorSearchResponse(BaseModel):
    results: List[VectorEntryResponse]
    total_found: int
    search_query: str
    timestamp: str

class VectorStatsResponse(BaseModel):
    total_entries: int
    collections: Dict[str, int]
    languages: Dict[str, int]
    voice_codes: Dict[str, int]
    timestamp: str

@router.get("/vector-db/search", response_model=VectorSearchResponse, tags=['Vector DB'])
async def search_vector_entries(
    query: str = Query(..., description="Search query"),
    top_k: int = Query(5, description="Number of results to return"),
    voice_code: Optional[str] = Query(None, description="Filter by voice code")
):
    """
    Search for similar vector entries in the database.
    """
    try:
        from service.pa_vector_manager import get_vector_manager
        
        vector_manager = get_vector_manager()
        if not vector_manager:
            raise HTTPException(status_code=503, detail="Vector manager not available")
        
        # Search for similar queries
        results = await vector_manager.search_similar_queries(
            query=query,
            top_k=top_k,
            voice_code=voice_code
        )
        
        # Convert results to response format
        vector_entries = []
        for result in results:
            metadata = result.get('metadata', {})
            vector_entries.append(VectorEntryResponse(
                id=result.get('id', ''),
                query=result.get('query', ''),
                response=metadata.get('response', ''),
                confidence=result.get('confidence', 0.0),
                tts_file_path=metadata.get('tts_file_path', ''),
                voice_code=metadata.get('voice_code', ''),
                tts_style=metadata.get('tts_style', ''),
                provider=metadata.get('provider', ''),
                gender=metadata.get('gender', ''),
                assistant_id=metadata.get('assistant_id', ''),
                call_id=metadata.get('call_id', ''),
                service_type=metadata.get('service_type', ''),
                response_id=metadata.get('response_id', ''),
                timestamp=str(metadata.get('timestamp', '')),
                tier_used=metadata.get('tier_used', 0),
                context=metadata.get('context', {}),
                generation_time=metadata.get('generation_time'),
                token_usage=metadata.get('token_usage'),
                clustering=metadata.get('clustering')
            ))
        
        return VectorSearchResponse(
            results=vector_entries,
            total_found=len(vector_entries),
            search_query=query,
            timestamp=str(datetime.now())
        )
        
    except Exception as e:
        logger.error(f"Error searching vector entries: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error searching vector entries: {str(e)}")

@router.get("/vector-db/entry/{vector_id}", response_model=VectorEntryResponse, tags=['Vector DB'])
async def get_vector_entry_by_id(
    vector_id: str,
    voice_code: Optional[str] = Query(None, description="Voice code to determine collection")
):
    """
    Get a specific vector entry by its ID.
    """
    try:
        from service.pa_vector_manager import get_vector_manager
        
        vector_manager = get_vector_manager()
        if not vector_manager:
            raise HTTPException(status_code=503, detail="Vector manager not available")
        
        # Search for the specific vector entry
        result = await vector_manager.search_by_vector_id(
            vector_id=vector_id,
            voice_code=voice_code
        )
        
        if not result:
            raise HTTPException(status_code=404, detail=f"Vector entry with ID {vector_id} not found")
        
        metadata = result.get('metadata', {})
        vector_entry = VectorEntryResponse(
            id=vector_id,
            query=metadata.get('query', ''),
            response=metadata.get('response', ''),
            confidence=result.get('confidence', 1.0),
            tts_file_path=metadata.get('tts_file_path', ''),
            voice_code=metadata.get('voice_code', ''),
            tts_style=metadata.get('tts_style', ''),
            provider=metadata.get('provider', ''),
            gender=metadata.get('gender', ''),
            assistant_id=metadata.get('assistant_id', ''),
            call_id=metadata.get('call_id', ''),
            service_type=metadata.get('service_type', ''),
            response_id=metadata.get('response_id', ''),
            timestamp=str(metadata.get('timestamp', '')),
            tier_used=metadata.get('tier_used', 0),
            context=metadata.get('context', {}),
            generation_time=metadata.get('generation_time'),
            token_usage=metadata.get('token_usage'),
            clustering=metadata.get('clustering')
        )
        
        return vector_entry
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting vector entry by ID: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error getting vector entry: {str(e)}")

@router.get("/vector-db/stats", response_model=VectorStatsResponse, tags=['Vector DB'])
async def get_vector_db_stats():
    """
    Get statistics about the vector database.
    """
    try:
        from service.pa_vector_manager import get_vector_manager
        
        vector_manager = get_vector_manager()
        if not vector_manager:
            raise HTTPException(status_code=503, detail="Vector manager not available")
        
        # Get collection statistics
        collections = {}
        languages = {}
        voice_codes = {}
        total_entries = 0
        
        # Get all language collections
        for lang, collection_name in vector_manager.language_collections.items():
            try:
                # Get collection info
                collection_info = vector_manager.client.get_collection(collection_name)
                collection_count = collection_info.points_count
                collections[collection_name] = collection_count
                languages[lang] = collection_count
                total_entries += collection_count
                
                # Get voice code distribution (sample from first 1000 points)
                if collection_count > 0:
                    points = vector_manager.client.scroll(
                        collection_name=collection_name,
                        limit=min(1000, collection_count)
                    )[0]
                    
                    for point in points:
                        voice_code = point.payload.get('voice_code', 'unknown')
                        voice_codes[voice_code] = voice_codes.get(voice_code, 0) + 1
                        
            except Exception as e:
                logger.warning(f"Error getting stats for collection {collection_name}: {e}")
                collections[collection_name] = 0
                languages[lang] = 0
        
        return VectorStatsResponse(
            total_entries=total_entries,
            collections=collections,
            languages=languages,
            voice_codes=voice_codes,
            timestamp=str(datetime.now())
        )
        
    except Exception as e:
        logger.error(f"Error getting vector DB stats: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error getting vector DB stats: {str(e)}")

@router.get("/vector-db/collections", tags=['Vector DB'])
async def get_collections():
    """
    Get all available collections in the vector database.
    """
    try:
        from service.pa_vector_manager import get_vector_manager
        
        vector_manager = get_vector_manager()
        if not vector_manager:
            raise HTTPException(status_code=503, detail="Vector manager not available")
        
        # Get all collections
        collections = vector_manager.client.get_collections()
        collection_list = []
        
        for collection in collections.collections:
            try:
                collection_info = vector_manager.client.get_collection(collection.name)
                collection_list.append({
                    "name": collection.name,
                    "points_count": collection_info.points_count,
                    "vector_size": collection_info.config.params.vectors.size,
                    "distance": collection_info.config.params.vectors.distance.value
                })
            except Exception as e:
                logger.warning(f"Error getting info for collection {collection.name}: {e}")
                collection_list.append({
                    "name": collection.name,
                    "points_count": "unknown",
                    "vector_size": "unknown",
                    "distance": "unknown"
                })
        
        return {
            "collections": collection_list,
            "total_collections": len(collection_list),
            "timestamp": str(datetime.now())
        }
        
    except Exception as e:
        logger.error(f"Error getting collections: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error getting collections: {str(e)}")

@router.get("/vector-db/entries", tags=['Vector DB'])
async def get_vector_entries(
    collection: Optional[str] = Query(None, description="Collection name"),
    limit: int = Query(10, description="Number of entries to return"),
    offset: int = Query(0, description="Offset for pagination")
):
    """
    Get vector entries from a specific collection with pagination.
    """
    try:
        from service.pa_vector_manager import get_vector_manager
        
        vector_manager = get_vector_manager()
        if not vector_manager:
            raise HTTPException(status_code=503, detail="Vector manager not available")
        
        # Determine collection to use
        if collection:
            collection_name = collection
        else:
            # Use the first available collection
            collection_name = list(vector_manager.language_collections.values())[0]
        
        # Get entries from collection
        points = vector_manager.client.scroll(
            collection_name=collection_name,
            limit=limit,
            offset=offset
        )[0]
        
        entries = []
        for point in points:
            payload = point.payload
            entries.append({
                "id": point.id,
                "query": payload.get('query', ''),
                "response": payload.get('response', ''),
                "tts_file_path": payload.get('tts_file_path', ''),
                "voice_code": payload.get('voice_code', ''),
                "assistant_id": payload.get('assistant_id', ''),
                "call_id": payload.get('call_id', ''),
                "timestamp": str(payload.get('timestamp', '')),
                "tier_used": payload.get('tier_used', 0),
                "confidence_score": payload.get('confidence_score', 0.0)
            })
        
        return {
            "entries": entries,
            "collection": collection_name,
            "limit": limit,
            "offset": offset,
            "total_returned": len(entries),
            "timestamp": str(datetime.now())
        }
        
    except Exception as e:
        logger.error(f"Error getting vector entries: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error getting vector entries: {str(e)}")

@router.delete("/vector-db/entry/{vector_id}", tags=['Vector DB'])
async def delete_vector_entry(
    vector_id: str,
    voice_code: Optional[str] = Query(None, description="Optional voice code to determine collection")
):
    """
    Delete a specific vector entry by its ID.
    """
    try:
        from service.pa_three_tier_service import get_three_tier_service
        three_tier_service = get_three_tier_service()
        if not three_tier_service or not three_tier_service.vector_manager:
            raise HTTPException(status_code=500, detail="Vector DB service not initialized")
        
        # Determine collection name
        vector_manager = three_tier_service.vector_manager
        if voice_code:
            # Extract language from voice code (e.g., "en-US-AvaNeural" -> "en")
            language = voice_code.split('-')[0] if '-' in voice_code else 'en'
            collection_name = vector_manager.language_collections.get(language, f"{vector_manager.base_collection_name}_{language}")
        else:
            # Default to English collection
            collection_name = vector_manager.language_collections.get('en', f"{vector_manager.base_collection_name}_en")
        
        # Check if collection exists
        collections = vector_manager.client.get_collections()
        existing_collection_names = [col.name for col in collections.collections]
        if collection_name not in existing_collection_names:
            raise HTTPException(status_code=404, detail=f"Collection '{collection_name}' not found")
        
        # Delete the vector entry
        success = vector_manager.client.delete(
            collection_name=collection_name,
            points_selector=[vector_id]
        )
        
        if success:
            logger.info(f"Successfully deleted vector entry {vector_id} from collection {collection_name}")
            return {"message": f"Vector entry {vector_id} deleted successfully", "timestamp": datetime.now()}
        else:
            raise HTTPException(status_code=500, detail="Failed to delete vector entry")
            
    except HTTPException:
        raise # Re-raise HTTPException
    except Exception as e:
        logger.error(f"Error deleting vector entry {vector_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {e}")
