import os
import json
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import asyncio
import re
from openai import OpenAI, AzureOpenAI

from service.pa_keyword_manager import get_keyword_manager
from service.pa_tts_manager import get_tts_manager
from service.pa_vector_manager import get_vector_manager
from config.language_tier_config_manager import get_language_tier_config_manager

logger = logging.getLogger(__name__)



class PAThreeTierService:
    def __init__(self, vector_manager, keyword_manager, tts_manager, llm_client):
        self.vector_manager = vector_manager
        self.keyword_manager = keyword_manager
        self.tts_manager = tts_manager
        self.llm_client = llm_client
        
        # Initialize language tier configuration manager only if 3-tier is enabled
        self.language_tier_config = None
        self.three_tier_enabled = os.getenv('THREE_TIER_LLM_ENABLED', 'false').lower() == 'true'
        
        if self.three_tier_enabled:
            self.language_tier_config = get_language_tier_config_manager()
            logger.info("3-tier system enabled - Language tier configuration loaded")
        else:
            logger.info("3-tier system disabled - Using standard LLM processing")
        
        # Configuration thresholds (fallback values - only used if 3-tier is disabled)
        self.tier1_min_confidence = float(os.getenv('THREE_TIER_TIER1_MIN_CONFIDENCE', '0.95'))
        self.tier2_min_confidence = float(os.getenv('THREE_TIER_TIER2_MIN_CONFIDENCE', '0.6'))
        
    async def process_query(self, user_query: str, call_context: dict, assistant_id: str, call_id: str, llm_client=None):
        """
        Process user query through 3-tier system with language-specific tier limits.
        
        Returns:
            dict: {
                'response': LLM streaming response (None for Tier 1, 2 cached),
                'tier_used': 1, 2, or 3,
                'complete_string': cached response string (Tier 1, 2 cached),
                'function_name': function name (use_cached, disconnect_service, etc.),
                'function_args': function arguments
            }
        """
        try:
            logger.info(f"Processing query through 3-tier system: {user_query}")
            
            # Check if 3-tier system is enabled
            if not self.three_tier_enabled or not self.language_tier_config:
                logger.info("3-tier system disabled - Using standard Tier 3 processing")
                return await self._tier3_fresh_generation(user_query, call_context, assistant_id, call_id)
            
            # Extract language code from call context
            lang_code = call_context.get('voice_code', 'en-US')
            if not lang_code:
                lang_code = call_context.get('languageCode', 'en-US')
            
            # Get language-specific tier configuration
            lang_config = self.language_tier_config.get_language_config(lang_code)
            max_tier = lang_config['max_tier']
            tier1_threshold = lang_config['tier1_min_confidence']
            tier2_threshold = lang_config['tier2_min_confidence']
            
            logger.info(f"Language {lang_code}: max_tier={max_tier}, tier1_threshold={tier1_threshold}, tier2_threshold={tier2_threshold}")
            
            # Search for similar queries in vector DB (service-voice-specific)
            service_type = call_context.get('service_type', 'Personal_Assistant')
            voice_name = call_context.get('voice_name')
            similar_queries = await self.vector_manager.search_similar_queries(
                query=user_query, 
                top_k=5,
                service_type=service_type,
                voice_name=voice_name
            )
            
            if not similar_queries:
                logger.info(f"No similar queries found for language {lang_code}")
                
                # Check if language allows Tier 3 (fresh generation)
                if max_tier >= 3:
                    logger.info(f"Using Tier 3 for language {lang_code} (no cached responses)")
                    return await self._tier3_fresh_generation(user_query, call_context, assistant_id, call_id)
                else:
                    # Language limited to lower tiers but no cached responses
                    logger.error(f"Language {lang_code} limited to tier {max_tier} but no cached responses available")
                    return await self._handle_no_response_available(lang_code, max_tier)
            
            # Get best match
            best_match = similar_queries[0]
            confidence = best_match.get('confidence', 0.0)
            
            logger.info(f"Best match confidence: {confidence} for language {lang_code}")
            
            # Apply language-specific tier limits
            # Tier 1: Direct cache hit (high confidence)
            if confidence >= tier1_threshold and max_tier >= 1:
                logger.info(f"Using Tier 1 for language {lang_code}: Direct cache hit")
                return await self._tier1_direct_cache(best_match, call_id)
            
            # Tier 2: LLM validation (medium confidence)
            elif confidence >= tier2_threshold and max_tier >= 2:
                logger.info(f"Using Tier 2 for language {lang_code}: LLM validation")
                return await self._tier2_llm_validation(
                    user_query, similar_queries, call_context, assistant_id, call_id, lang_config
                )
            
            # Tier 3: Fresh generation (low confidence)
            elif max_tier >= 3:
                logger.info(f"Using Tier 3 for language {lang_code}: Fresh generation")
                return await self._tier3_fresh_generation(user_query, call_context, assistant_id, call_id)
            
            # Language tier limit reached
            else:
                logger.error(f"Language {lang_code} tier limit {max_tier} reached with confidence {confidence}")
                return await self._handle_no_response_available(lang_code, max_tier)
                
        except Exception as e:
            logger.error(f"Error in 3-tier processing: {e}")
            # Fallback to Tier 3 if language allows it
            if self.three_tier_enabled and self.language_tier_config:
                lang_code = call_context.get('voice_code', 'en-US')
                lang_config = self.language_tier_config.get_language_config(lang_code)
                if lang_config['max_tier'] >= 3:
                    return await self._tier3_fresh_generation(user_query, call_context, assistant_id, call_id)
                else:
                    return await self._handle_no_response_available(lang_code, lang_config['max_tier'])
            else:
                # 3-tier disabled, use standard processing
                return await self._tier3_fresh_generation(user_query, call_context, assistant_id, call_id)
    
    async def _handle_no_response_available(self, lang_code: str, max_tier: int):
        """
        Handle case when no response is available due to language tier limits
        
        Args:
            lang_code: Language code
            max_tier: Maximum tier allowed for the language
            
        Returns:
            dict: Error response indicating no response available
        """
        logger.error(f"No response available for language {lang_code} (max_tier={max_tier})")
        
        return {
            'response': None,
            'tier_used': max_tier,
            'complete_string': '',
            'function_name': 'disconnect_service',
            'function_args': json.dumps({
                'parameter': f"I'm sorry, but I don't have a suitable response available for your query in {lang_code}. Please try again later or contact support."
            }),
            'confidence_score': 0.0,
            'error': f'No response available for language {lang_code} (max_tier={max_tier})'
        }
    
    async def _tier1_direct_cache(self, best_match: dict, call_id: str):
        """Tier 1: Direct cache hit - return use_cached function call"""
        try:
            vector_id = best_match.get('id')
            metadata = best_match.get('metadata', {})
            cached_response = metadata.get('response', '')
            cached_wav_path = metadata.get('tts_file_path', '')
            
            logger.info(f"Tier 1: Using cached response with confidence {best_match.get('confidence', 0)}")
            
            # Return use_cached function call with vector DB entry ID
            return {
                'response': cached_response,
                'tier_used': 1,
                'complete_string': '',
                'function_name': 'use_cached',
                'function_args': json.dumps({
                    'vector_id': vector_id,
                    'reason': 'Tier 1 direct cache hit',
                    'cached_wav_path': cached_wav_path
                }),
                'confidence_score': best_match.get('confidence', 0.0)
            }
            
        except Exception as e:
            logger.error(f"Error in Tier 1: {e}")
            raise
    
    async def _tier2_llm_validation(self, user_query: str, similar_queries: list, 
                                  call_context: dict, assistant_id: str, call_id: str, lang_config: dict):
        """Tier 2: LLM validation using function calling with language-specific behavior"""
        try:
            # Get assistant configuration with single cache call
            from cache.assistant_configuration_cache import get_assistant_details_by_id
            try:
                assistant_details = get_assistant_details_by_id(int(assistant_id))
                tier2_prompt = assistant_details.get('tier2_prompt', '') if assistant_details else ''
                tier2_tools = json.loads(assistant_details.get('tier2_tools', '[]')) if assistant_details else []
            except (ValueError, TypeError) as e:
                logger.warning(f"Invalid assistant_id format: {assistant_id}, error: {e}")
                tier2_prompt = ''
                tier2_tools = []
            
            # Use only dynamic tools from assistant configuration
            if not tier2_tools:
                logger.error(f"No tier2_tools configured for assistant {assistant_id}")            

            logger.info(f"Using tier2_tools for assistant {assistant_id}: {len(tier2_tools)} tools")
            
            # Create messages with function calling tools
            messages = await self._create_tier2_messages(user_query, similar_queries, call_context, assistant_id, tier2_prompt)
            
            # Use passed LLM client or get from context
            azure_client = call_context.get('llm_client')
            model_name = call_context.get('model_name', 'gpt-4')
            
            if not azure_client:
                raise Exception(f"No LLM client available for assistant {assistant_id}")
            
            # Create LLM request with function calling
            gpt_obj = {
                "model": model_name,
                "messages": messages,
                "stream": True,
                "tools": tier2_tools,
                "tool_choice": "auto",
                "temperature": 0.3
            }
            
            # Make streaming LLM call
            response = azure_client.chat.completions.create(**gpt_obj)
            
            # Process the streaming response to detect function calls
            function_name = None
            function_arguments = ''
            complete_string = ""
            
            for chunk in response:
                # Check for function calls in the chunk
                if (chunk.choices and len(chunk.choices) > 0 and
                    chunk.choices[0].delta and
                    chunk.choices[0].delta.tool_calls and
                    len(chunk.choices[0].delta.tool_calls) > 0):
                    
                    tool_call = chunk.choices[0].delta.tool_calls[0]
                    if tool_call.function and tool_call.function.name:
                        function_name = tool_call.function.name
                    if tool_call.function and tool_call.function.arguments:
                        function_arguments += tool_call.function.arguments
                
                # Collect content for fresh generation
                if (chunk.choices and len(chunk.choices) > 0 and
                    chunk.choices[0].delta and
                    hasattr(chunk.choices[0].delta, 'content') and
                    chunk.choices[0].delta.content):
                    complete_string += chunk.choices[0].delta.content
            
            # Handle function calls
            if function_name == 'use_cached':
                try:
                    # Parse function arguments
                    args = json.loads(function_arguments)
                    vector_id = args.get('vector_id')
                    reason = args.get('reason', 'LLM validated cached response')
                    
                    # Find the matching query by vector_id
                    matching_query = None
                    for query in similar_queries:
                        if query.get('id') == vector_id:
                            matching_query = query
                            break
                    
                    if matching_query:
                        metadata = matching_query.get('metadata', {})
                        cached_response = metadata.get('response', '')
                        cached_wav_path = metadata.get('tts_file_path', '')
                        
                        logger.info(f"Tier 2: Using LLM-validated cached response: {reason}")
                        
                        return {
                            'response': cached_response,
                            'tier_used': 2,
                            'complete_string': cached_response,
                            'function_name': 'use_cached',
                            'function_args': json.dumps({'vector_id': vector_id, 'reason': reason, 'cached_wav_path': cached_wav_path}),
                            'confidence_score': matching_query.get('confidence', 0.0)
                        }
                    else:
                        logger.warning(f"Vector ID {vector_id} not found in similar queries")
                        # Fallback to fresh generation
                        return await self._tier3_fresh_generation(user_query, call_context, assistant_id, call_id)
                        
                except Exception as e:
                    logger.error(f"Error processing use_cached function: {e}")
                    # Fallback to fresh generation
                    return await self._tier3_fresh_generation(user_query, call_context, assistant_id, call_id)
            
            elif function_name == 'fresh_generation':
                try:
                    # Parse function arguments
                    args = json.loads(function_arguments)
                    fresh_response = args.get('response', '')
                    
                    logger.info(f"Tier 2: LLM generated fresh response")
                    
                    return {
                        'response': fresh_response,
                        'tier_used': 2,
                        'complete_string': fresh_response,
                        'function_name': 'fresh_generation',
                        'function_args': json.dumps({'response': fresh_response}),
                        'confidence_score': 0.0  # Fresh generation has no confidence score
                    }
                except Exception as e:
                    logger.error(f"Error processing fresh_generation function: {e}")
                    # Fallback to Tier 3
                    return await self._tier3_fresh_generation(user_query, call_context, assistant_id, call_id)
            
            elif function_name in ['disconnect_service', 'handle_telemarketing_call']:
                logger.info(f"Tier 2: LLM requested function call: {function_name}")
                return {
                    'response': None,
                    'tier_used': 2,
                    'complete_string': '',
                    'function_name': function_name,
                    'function_args': function_arguments
                }
            
            # Fresh generation needed - check if language allows Tier 3
            max_tier = lang_config.get('max_tier', 3)
            if max_tier >= 3:
                logger.info("Tier 2: LLM requested fresh generation, using Tier 3")
                return await self._tier3_fresh_generation(user_query, call_context, assistant_id, call_id)
            else:
                # Language limited to Tier 2, but no cached response matches
                logger.error(f"Tier 2: Language limited to tier {max_tier}, no cached response matches")
                lang_code = call_context.get('voice_code', 'en-US')
                return await self._handle_no_response_available(lang_code, max_tier)
            
        except Exception as e:
            logger.error(f"Error in Tier 2: {e}")
            # Fallback to Tier 3 if language allows it
            max_tier = lang_config.get('max_tier', 3)
            if max_tier >= 3:
                return await self._tier3_fresh_generation(user_query, call_context, assistant_id, call_id)
            else:
                lang_code = call_context.get('voice_code', 'en-US')
                return await self._handle_no_response_available(lang_code, max_tier)
    
    def _normalize_messages_for_llm(self, messages: list) -> list:
        """
        Normalize messages to OpenAI format (role/content) from mixed CDR format (senderId/body)
        """
        normalized_messages = []
        
        for msg in messages:
            if isinstance(msg, dict):
                # Check if it's already in OpenAI format
                if 'role' in msg and 'content' in msg:
                    normalized_messages.append(msg)
                # Check if it's in CDR format and convert
                elif 'senderId' in msg and 'body' in msg:
                    sender_id = msg.get('senderId', '')
                    body = msg.get('body', '')
                    
                    # Map senderId to role
                    if sender_id == 'user':
                        role = 'user'
                    elif sender_id == 'assistant':
                        role = 'assistant'
                    elif sender_id == 'system':
                        role = 'system'
                    else:
                        # Skip unknown senderId types
                        logger.warning(f"Unknown senderId '{sender_id}' in message, skipping")
                        continue
                    
                    normalized_messages.append({
                        "role": role,
                        "content": body
                    })
                else:
                    # Skip messages that don't match either format
                    logger.warning(f"Message doesn't match expected format, skipping: {msg}")
                    continue
            else:
                logger.warning(f"Non-dict message found, skipping: {msg}")
                continue
        
        return normalized_messages

    async def _tier3_fresh_generation(self, user_query: str, call_context: dict, 
                                    assistant_id: str, call_id: str):
        """Tier 3: Fresh LLM generation"""
        try:
            logger.info("Tier 3: Generating fresh response")
            
            # Use passed LLM client or get from context
            azure_client = call_context.get('llm_client')
            model_name = call_context.get('model_name', 'gpt-4')
            
            if not azure_client:
                logger.error(f"No LLM client available for assistant {assistant_id}")
                return {
                    'response': None,
                    'tier_used': 3,
                    'complete_string': '',
                    'function_name': None,
                    'function_args': None,
                    'confidence_score': 0.8  # Default confidence for fresh generation
                }
            
            from cache.assistant_configuration_cache import get_assistant_details_by_id
            try:
                assistant_details = get_assistant_details_by_id(int(assistant_id))
                tools_supported_string = assistant_details.get('tools_supported', "")
                
                tools_supported = []
                if tools_supported_string:
                    tools_supported_string = tools_supported_string.strip().replace("'", '"')
                    tools_string = re.sub(r',\s*([\}\]])', r'\1', tools_supported_string)
                    try:
                        tools_supported_data = json.loads(tools_string)
                        tools_supported = tools_supported_data.get('tools_supported', [])
                    except json.JSONDecodeError as e:
                        logger.error(f"Error parsing tools_supported JSON: {e}")
                        tools_supported = []
            except (ValueError, TypeError) as e:
                logger.warning(f"Invalid assistant_id format: {assistant_id}, error: {e}")
                tools_supported = [] 
            # Prepare messages for LLM with full conversation history
            messages = call_context.get('messages', [])
            if not messages or len(messages) == 0:
                # Fallback if no conversation history
                messages = [
                    {"role": "system", "content": self._get_system_prompt(call_context)},
                    {"role": "user", "content": user_query}
                ]
            else:
                # Normalize messages to ensure proper OpenAI format
                messages = self._normalize_messages_for_llm(messages)
            
            logger.debug(f"Tier 3: Using {len(messages)} messages for LLM call (includes conversation history)")
            
            # Create LLM request
            gpt_obj = {
                "model": model_name,
                "messages": messages,
                "stream": True,
                "tools": tools_supported,
                "tool_choice": "auto", 
                "temperature": 0.7
            }
            
            # Log the LLM request body for debugging
            logger.debug(f"Tier 3 LLM Request Body: {gpt_obj}")
            
            # Make streaming LLM call
            response = azure_client.chat.completions.create(**gpt_obj)
            
            # Process the streaming response to detect function calls
            function_name = None
            function_arguments = ''
            complete_string = ""

            for chunk in response:
                # Check for function calls in the chunk
                if (chunk.choices and len(chunk.choices) > 0 and
                    chunk.choices[0].delta and
                    chunk.choices[0].delta.tool_calls and
                    len(chunk.choices[0].delta.tool_calls) > 0):
                    
                    tool_call = chunk.choices[0].delta.tool_calls[0]
                    if tool_call.function and tool_call.function.name:
                        function_name = tool_call.function.name
                    if tool_call.function and tool_call.function.arguments:
                        function_arguments += tool_call.function.arguments
                
                # Collect content for fresh generation
                if (chunk.choices and len(chunk.choices) > 0 and
                    chunk.choices[0].delta and
                    hasattr(chunk.choices[0].delta, 'content') and
                    chunk.choices[0].delta.content):
                    complete_string += chunk.choices[0].delta.content

            # Handle function calls
            if function_name in ['disconnect_service', 'handle_telemarketing_call']:
                logger.info(f"Tier 3: LLM requested function call: {function_name}")
                return {
                    'response': None,  # No streaming needed for function calls
                    'tier_used': 3,
                    'complete_string': '',
                    'function_name': function_name,
                    'function_args': function_arguments
                }
            elif function_name == 'fresh_generation':
                # Parse function arguments
                try:
                    args = json.loads(function_arguments)
                    fresh_response = args.get('response', '')
                    return {
                        'response': fresh_response,
                        'tier_used': 3,
                        'complete_string': fresh_response,
                        'function_name': 'fresh_generation',
                        'function_args': function_arguments
                    }
                except Exception as e:
                    logger.error(f"Error processing fresh_generation function: {e}")
                    # Fallback to content
                    pass
            
            logger.info(f"Tier 3: Fresh generation response created, length: {len(complete_string)}")
            
            return {
                'response': complete_string,  # Return the complete response
                'tier_used': 3,
                'complete_string': complete_string,
                'function_name': None,
                'function_args': None,
                'confidence_score': 0.8  # Default confidence for fresh generation
            }
            
        except Exception as e:
            logger.error(f"Error in Tier 3: {e}")
            return {
                'response': None,
                'tier_used': 3,
                'complete_string': '',
                'function_name': None,
                'function_args': None,
                'confidence_score': 0.8  # Default confidence for fresh generation
            }
    
    async def _create_tier2_messages(self, user_query: str, similar_queries: list, call_context: dict, assistant_id: str, tier2_prompt: str = '') -> list:
        """Create messages for Tier 2 LLM validation with function calling"""
        
        # Get the original PA system prompt from call context
        original_system_prompt = call_context.get('system_prompt', '')
        
        # Use tier2_prompt passed from _tier2_llm_validation
        
        # Get full conversation history from call context
        messages = call_context.get('messages', [])
        
        # Format similar queries for the prompt
        queries_text = ""
        for i, query in enumerate(similar_queries, 1):
            metadata = query.get('metadata', {})
            
            # Extract context information properly
            context_info = ""
            if 'context' in metadata:
                context = metadata['context']
                if isinstance(context, dict):
                    context_info = f"Urgency: {context.get('urgency', 'unknown')}, Formality: {context.get('formality', 'unknown')}, Sentiment: {context.get('sentiment', 'unknown')}, Intent: {context.get('intent', 'unknown')}"
                else:
                    context_info = str(context)
            else:
                context_info = "No context available"
            
            queries_text += f"""
Query {i} (ID: {query.get('id', 'unknown')}):
- Original Query: {query.get('query', '')}
- Response: {metadata.get('response', '')}
- Confidence: {query.get('confidence', 0):.2f}
- Context: {context_info}
- Voice Code: {metadata.get('voice_code', 'unknown')}
- TTS File: {metadata.get('tts_file_path', 'N/A')}
"""
        
        # Fetch default responses from vector DB
        default_responses_text = ""
        try:
            service_type = call_context.get('service_type', 'Personal_Assistant')
            voice_name = call_context.get('voice_name')
            
            logger.debug(f"Fetching default responses for service_type={service_type}, voice_name={voice_name}")
            
            # Search for default responses (now properly async)
            default_responses = await self.vector_manager.search_default_responses(
                service_type=service_type,
                voice_name=voice_name,
                limit=5
            )
            
            if default_responses:
                logger.info(f"Found {len(default_responses)} default responses for Tier 2")
                for i, default_resp in enumerate(default_responses, 1):
                    metadata = default_resp.get('metadata', {})
                    default_responses_text += f"""
Default Response {i} (ID: {default_resp.get('id', 'unknown')}):
- Category: {metadata.get('default_category', 'generic')}
- Response: {metadata.get('response', '')}
- Intent: {default_resp.get('analysis', {}).get('intent', 'default')}
- TTS File: {metadata.get('tts_file_path', 'N/A')}
"""
            else:
                logger.warning("No default responses found in vector DB")
                default_responses_text = "\nNo default responses available."
                
        except Exception as e:
            logger.error(f"Error fetching default responses: {e}")
            import traceback
            logger.error(traceback.format_exc())
            default_responses_text = "\nNo default responses available."
        
        # Use tier2_prompt passed from _tier2_llm_validation
        if tier2_prompt and tier2_prompt.strip():
            # Replace placeholders in custom prompt
            function_calling_instructions = tier2_prompt.replace('{queries_text}', queries_text)
            function_calling_instructions = function_calling_instructions.replace('{default_responses}', default_responses_text)
        else:
            # Fallback to default tier2 prompt when tier2_prompt is empty, null, or empty string
            function_calling_instructions = f"""You are a Tier 2 validation assistant for a Personal Assistant service.

CACHED RESPONSES AVAILABLE:
{queries_text}

DEFAULT RESPONSES:
{default_responses_text}

Your task is to select the most appropriate response from the cached responses or default responses above."""
        
        # Enhanced Tier 2 system prompt with function calling instructions
        system_prompt = function_calling_instructions
        
        # Debug log the context information being sent to Tier 2 LLM
        logger.debug(f"Tier 2 LLM Context - Found {len(similar_queries)} cached responses and {len(default_responses) if 'default_responses' in locals() else 0} default responses")
        for i, query in enumerate(similar_queries, 1):
            metadata = query.get('metadata', {})
            context = metadata.get('context', {})
            logger.debug(f"  Cached Response {i}: ID={query.get('id')}, Query='{query.get('query', '')[:30]}...', Context={context}")
        
        # Build messages with full conversation history
        tier2_messages = [{"role": "system", "content": system_prompt}]
        
        # Normalize and add conversation history (excluding system message)
        normalized_messages = self._normalize_messages_for_llm(messages)
        for msg in normalized_messages:
            if msg.get('role') != 'system':
                tier2_messages.append(msg)
                # Log assistant messages for debugging
                if msg.get('role') == 'assistant':
                    logger.debug(f"Tier 2: Including assistant message: {msg.get('content', '')[:50]}...")
        
        # Add current user query
        tier2_messages.append({"role": "user", "content": user_query})
        
        # Debug log the total message count
        logger.debug(f"Tier 2: Total messages for LLM: {len(tier2_messages)} (including system prompt)")
        
        return tier2_messages
    
    def _get_system_prompt(self, call_context: dict) -> str:
        """Get system prompt for Tier 3 fresh generation"""
        # Use the original PA system prompt from call context
        original_system_prompt = call_context.get('system_prompt', '')
        
        if original_system_prompt:
            return original_system_prompt
        else:
            # Fallback to basic prompt if no system prompt provided
            return """You are a Personal Assistant AI. Answer user queries professionally and helpfully."""
    
    async def store_new_response(self, query: str, response: str, tts_file_path: str, 
                               metadata: Dict = None, service_type: str = None, 
                               voice_name: str = None, function_name: str = None) -> str:
        """Store new LLM-generated responses in the vector DB"""
        try:
            logger.info(f"Storing new response for query: {query}")
            
            # Extract context analysis from metadata
            context_analysis = {
                "urgency": metadata.get("urgency", "medium"),
                "formality": metadata.get("formality", "professional"),
                "sentiment": metadata.get("sentiment", "neutral"),
                "intent": metadata.get("intent", "general")
            }
            
            # Extract performance metrics
            performance_metrics = {
                "confidence_score": metadata.get("confidence_score", 0.0),
                "generation_time": metadata.get("generation_time"),
                "token_usage": metadata.get("token_usage")
            }
            
            # Store in vector database
            vector_id = await self.vector_manager.store_response(
                query=query,
                response=response,
                tts_file_path=tts_file_path,
                metadata=metadata,
                context_analysis=context_analysis,
                performance_metrics=performance_metrics,
                service_type=service_type,
                voice_name=voice_name,
                function_name=function_name
            )
            
            # Learn keywords and get generalized query from LLM
            # Note: llm_client is not available in cached metadata, so we'll skip keyword learning for now
            # This will be handled at call end when we have access to the LLM client
            generalized_query = query  # Use original query as fallback
            
            # Update the stored query with generalized version if different
            if generalized_query != query:
                logger.debug(f"Updating vector DB entry with generalized query")
                voice_name = metadata.get('voice_name')
                await self.update_generalized_query(vector_id, generalized_query, voice_name)
            
            logger.info(f"Stored new response for future 3-tier use: {vector_id}")
            return vector_id
            
        except Exception as e:
            logger.error(f"Error storing new response: {e}")
            raise
    
    async def update_tts_file_path(self, vector_id: str, tts_file_path: str, voice_name: str = None) -> bool:
        """
        Update the TTS file path for an existing vector database entry.
        
        Args:
            vector_id: Vector database entry ID
            tts_file_path: New TTS file path
            voice_name: Voice name to determine collection (optional)
            
        Returns:
            bool: True if update successful, False otherwise
        """
        try:
            return await self.vector_manager.update_tts_file_path(vector_id, tts_file_path, voice_name)
        except Exception as e:
            logger.error(f"Error updating TTS file path for vector ID {vector_id}: {e}")
            return False

    async def update_generalized_query(self, vector_id: str, generalized_query: str, voice_name: str = None) -> bool:
        """
        Update the generalized query for an existing vector database entry.
        
        Args:
            vector_id: Vector database entry ID
            generalized_query: Generalized query to store
            voice_name: Voice name to determine collection (optional)
            
        Returns:
            bool: True if update successful, False otherwise
        """
        try:
            return await self.vector_manager.update_generalized_query(vector_id, generalized_query, voice_name)
        except Exception as e:
            logger.error(f"Error updating generalized query for vector ID {vector_id}: {e}")
            return False
    
    async def _learn_keywords_from_query(self, query: str, context_analysis: Dict, 
                                       llm_client=None, model_name: str = "gpt-4"):
        """
        Learn new keywords from the query and generate generalized query using LLM.
        Now includes LLM-based query generalization instead of person name removal.
        """
        try:
            logger.debug(f"Learning keywords and generalizing query: '{query[:50]}...'")
            
            # Get LLM-based keyword analysis and query generalization
            llm_analysis = await self._extract_keywords_and_generalize_query(
                query, llm_client, model_name
            )
            
            if llm_analysis:
                # Learn from LLM analysis
                await self.keyword_manager.learn_from_query(
                    query=query,
                    llm_analysis=llm_analysis.get('keywords', {})
                )
                
                # Store the generalized query for future use
                generalized_query = llm_analysis.get('generalized_query')
                if generalized_query and generalized_query != query:
                    logger.info(f"Query generalized: '{query}' -> '{generalized_query}'")
                    # The generalized query will be used in vector DB storage
                    return generalized_query
            
            return query  # Return original if generalization fails
            
        except Exception as e:
            logger.error(f"Error learning keywords and generalizing query: {e}")
            return query
    
    async def _extract_keywords_and_generalize_query(self, query: str, llm_client, model_name: str) -> Dict:
        """
        Use LLM to extract keywords and generalize query by replacing person names with placeholders.
        
        Args:
            query: User query to analyze
            llm_client: LLM client for API calls
            model_name: Model name to use
            
        Returns:
            Dictionary with keywords and generalized query
        """
        try:
            if not llm_client:
                logger.warning("No LLM client available for keyword extraction and query generalization")
                return None
            
            system_prompt = """You are a PA (Personal Assistant) keyword analyzer and query generalizer.

Your task is to:
1. Extract keywords from user queries (urgency, formality, sentiment, intent)
2. Generalize queries by replacing person names with [PERSON] placeholder
3. Return both keyword analysis and generalized query

IMPORTANT: 
- Replace ALL person names with [PERSON]
- Keep the query structure and meaning intact
- Be consistent with placeholder usage

Return ONLY valid JSON in this format:
{
    "keywords": {
        "urgency": "low|medium|high|critical",
        "formality": "casual|professional|formal", 
        "sentiment": "positive|neutral|negative",
        "intent": "availability|message|callback|meeting|emergency"
    },
    "generalized_query": "query with [PERSON] replacing names"
}"""

            user_message = f"Analyze and generalize this PA query: '{query}'"
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ]
            
            # Make LLM call
            response = llm_client.chat.completions.create(
                model=model_name,
                messages=messages,
                temperature=0.1,
                max_tokens=200
            )
            
            # Parse response
            response_content = response.choices[0].message.content.strip()
            logger.debug(f"LLM keyword/generalization response: {response_content}")
            
            # Parse JSON response
            try:
                analysis = json.loads(response_content)
                return analysis
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse LLM keyword analysis JSON: {e}")
                logger.error(f"Raw response: {response_content}")
                return None
                
        except Exception as e:
            logger.error(f"Error in LLM keyword extraction and query generalization: {e}")
            return None

# Global instance
pa_three_tier_service = None

def get_three_tier_service():
    """Get or create 3-tier service instance"""
    global pa_three_tier_service
    
    if pa_three_tier_service is None:
        try:
            # Get dependencies
            vector_manager = get_vector_manager()
            keyword_manager = get_keyword_manager()
            tts_manager = get_tts_manager()
            
            if not all([vector_manager, keyword_manager, tts_manager]):
                logger.error("Missing dependencies for 3-tier service")
                return None
            
            # Create service
            pa_three_tier_service = PAThreeTierService(
                vector_manager=vector_manager,
                keyword_manager=keyword_manager,
                tts_manager=tts_manager,
                llm_client=None  # Will be retrieved per request
            )
            
            logger.info("3-tier service initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize 3-tier service: {e}")
            return None
    
    return pa_three_tier_service

def initialize_three_tier_service():
    """Initialize the 3-tier service explicitly"""
    global pa_three_tier_service
    
    try:
        # Get dependencies
        vector_manager = get_vector_manager()
        keyword_manager = get_keyword_manager()
        tts_manager = get_tts_manager()
        
        if not all([vector_manager, keyword_manager, tts_manager]):
            logger.error("Missing dependencies for 3-tier service")
            return False
        
        # Create service
        pa_three_tier_service = PAThreeTierService(
            vector_manager=vector_manager,
            keyword_manager=keyword_manager,
            tts_manager=tts_manager,
            llm_client=None  # Will be retrieved per request
        )
        
        logger.info("3-tier service initialized successfully")
        return True
        
    except Exception as e:
        logger.error(f"Failed to initialize 3-tier service: {e}")
        return False