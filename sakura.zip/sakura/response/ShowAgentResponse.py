from response.ShowToolResponse import shortToolInfo
from response.showGenericResponse import GenericResponse


class showAgentItem(shortToolInfo):
    def __init__(self, id, name, toolList: list[shortToolInfo], description, status, documentLink, createdBy, createdOn,
                 updatedBy, updatedOn, state, flowUml):
        self.id = id
        self.name = name
        self.toolList = toolList
        self.description = description
        self.createdBy = createdBy
        self.createdOn = createdOn
        self.updatedBy = updatedBy
        self.updatedOn = updatedOn
        self.status = status
        self.documentLink = documentLink
        self.state = state
        self.flowUml = flowUml

    def __repr__(self):
        return f"showAgentItem(id={self.id}, agentName={self.name}, toolList={self.toolList},description={self.description},documentLink={self.documentLink},createdBy={self.createdBy}, createdOn ={self.createdOn},updateBy={self.updatedBy}, updateOn={self.updatedOn}, status={self.status}, state={self.state}, flowUml={self.flowUml})"


class showAgentResponse(GenericResponse):
    def __init__(self, status, statusCode, message, data: list[showAgentItem]):
        super().__init__(statusCode, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, statusCode: {self.statusCode}, message: {self.message}, data: {self.data}"


class updateAgentTempResponse(shortToolInfo):
    def __init__(self, id, agentName, data: list[shortToolInfo]):
        self.id = id
        self.agentName = agentName
        self.data = data

    def __repr__(self):
        return f"updateAgentTempResponse(id={self.id},agentName={self.agentName},data={self.data})"


class updateAgentResponse(GenericResponse):
    def __init__(self, status, statusCode, message, data: updateAgentTempResponse):
        super().__init__(statusCode, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, statusCode: {self.statusCode}, message: {self.message}, data: {self.data}"


class tmpUpdateStatus:
    def __init__(self, id, name, status):
        self.id = id
        self.name = name
        self.status = status

    def __repr__(self):
        return f"updateAgentTempResponse(id={self.id},name={self.name},status={self.status})"


class UpdateStatusResponse(GenericResponse):
    def __init__(self, status, statusCode, message, data: tmpUpdateStatus):
        super().__init__(statusCode, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, statusCode: {self.statusCode}, message: {self.message}, data: {self.data}"


class uploadDocResponse(GenericResponse):
    def __init__(self, status, statusCode, message, data: showAgentItem):
        super().__init__(statusCode, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, statusCode: {self.statusCode}, message: {self.message}, data: {self.data}"
