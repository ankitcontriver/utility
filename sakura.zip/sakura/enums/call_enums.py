from enum import Enum


class Event(Enum):
    CALL = 'call'
    CHAT = 'chat'

class ServiceType(Enum):
    PA = 'Personal_Assistant'
    SMART_IVR = 'SMART_IVR'
    ASK_ME = 'ASK_ME'