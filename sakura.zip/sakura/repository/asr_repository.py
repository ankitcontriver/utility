from sqlalchemy.orm import Session

from models.database_models import ASRCountryMapping


def get_asr_model(db: Session, language_id: str):
    return db.query(ASRCountryMapping).filter(ASRCountryMapping.language_id == language_id,
                                               ASRCountryMapping.status == True).all()


def get_asr_language(db: Session, language_id: str, country_name: str, asr_model_name: str):
    return db.query(ASRCountryMapping).filter(ASRCountryMapping.language_id == language_id,
                                              ASRCountryMapping.asr_name == asr_model_name, ASRCountryMapping.status == True).all()
