from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime

class ContextAnalysis(BaseModel):
    urgency: str  # high, medium, low
    formality: str  # formal, professional, casual
    sentiment: str  # positive, neutral, negative
    intent: str  # availability, message, meeting, callback, etc.

class TokenUsage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int

class ClusteringData(BaseModel):
    cluster_id: Optional[str] = None
    cluster_center_distance: Optional[float] = None

class PAVectorMetadata(BaseModel):
    """Metadata structure for PA responses stored in vector database"""
    
    # Core response data
    query: str
    normalized_query: str
    response: str
    tts_file_path: str
    
    # Call context
    assistant_id: str
    call_id: str
    service_type: str
    response_id: str
    timestamp: datetime
    
    # TTS configuration
    voice_code: str
    tts_style: str
    provider: str
    gender: str
    is_translate: bool = False
    
    # Context analysis
    context: ContextAnalysis
    
    # Performance metrics
    confidence_score: float
    tier_used: int  # 1, 2, or 3
    generation_time: Optional[float] = None
    token_usage: Optional[TokenUsage] = None
    
    # Clustering data
    clustering: Optional[ClusteringData] = None
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

class VectorDBPoint(BaseModel):
    """Complete vector database point structure"""
    id: str
    vector: List[float]
    payload: PAVectorMetadata