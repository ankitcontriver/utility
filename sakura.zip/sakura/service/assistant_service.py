from config.database_config import SessionLocal
from logger import get_logger
from cache.assistant_configuration_cache import get_assistant_config
from repository.user_assistant_repository import get_assistant_mapping_repository
from response.GetAssistantsResponse import GetAssistants, GetAssistantsResponse

logger = get_logger(__name__)


def get_assistants_service(email: str):
    logger.info(f"get_assistants_service called - email: {email}")
    db = SessionLocal()
    try:
        id_list = get_assistant_mapping_repository(db, email)
        logger.debug(f"id_list: {id_list}")
        if len(id_list) == 0:
            assistants = get_assistant_config([], True)
        else:
            assistants = get_assistant_config(id_list[0][0].split(","), id_list[0][1])
        
        # Check if we got any assistants from cache
        if not assistants:
            logger.warning(f"No assistants found for email: {email}")
            return GetAssistantsResponse(
                status_code=200, 
                status="Successful",
                message="No assistants available at the moment", 
                data=[]
            )
        
        # Map each assistant dict to your GetAssistants response model
        assistant_list = [
            GetAssistants(
                assistant_id=assistant["assistant_id"],
                description=assistant["description"],
                female_picture_url=assistant["female_picture_url"],
                male_picture_url=assistant["male_picture_url"],
                name=assistant["name"],
                role=assistant["role"]
            ) for assistant in assistants
        ]
        
        response = GetAssistantsResponse(
            status="Successful", 
            status_code=200,
            message=f"Assistant List Retrieved Successfully ({len(assistant_list)} assistants)", 
            data=assistant_list
        )
        
        logger.info(f"Successfully retrieved {len(assistant_list)} assistants for email: {email}")
        return response
        
    except Exception as e:
        logger.error(f"Error in get_assistants_service: {e}", exc_info=True)
        return GetAssistantsResponse(
            status_code=500, 
            status="Internal Server Error",
            message=f"Error while Retrieving Assistants : {e}", 
            data=[]
        )
    finally:
        db.close()
