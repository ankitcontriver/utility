from enum import Enum


class ScrapeStatus(Enum):
    PROCESSING = "Processing"
    PROCESSED = "Processed"
    FAILED = "Failed to Scrape"
    SECURITY_PROCESSING = "Security Processing"
