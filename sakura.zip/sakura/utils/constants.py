from response.GetMenuResponse import Menu

home = Menu(id=1, title="Home", path="/eva")
about = Menu(id=2, title="About", path="/about")
contact = Menu(id=3, title="Get in Touch", path="/contact-us")
demo = Menu(id=4, title="Schedule Demo", path="https://calendly.com/eva-o8kf/30min")
login = Menu(id=5, title="Login", path="/login")
obd = Menu(id=6, title="Send OBD", path="/send-obd")
gen_link = Menu(id=7, title="Generate Link", path="/generate-link")

menu_map = {
    "ut_unauth_users": [home, about, contact, demo, login],
    "ut_non_bng_users": [home, about, contact, demo],
    "ut_bng_users": [home, about, obd, gen_link],
    "all": [home, about, contact, demo, login, obd, gen_link]
}