import os
import json
import logging
from typing import Dict, List, Optional
from datetime import datetime
import asyncio
import threading

logger = logging.getLogger(__name__)

class PAKeywordManager:
    """
    Manages self-learning keyword dictionaries for PA service.
    Handles urgency, formality, sentiment, and intent keywords with auto-learning.
    """
    
    def __init__(self, config_file_path: str):
        self.config_file_path = config_file_path
        self.keywords = {}
        self._lock = threading.Lock()
        self._load_keywords()
    
    def _load_keywords(self):
        """Load keywords from JSON config file"""
        try:
            if os.path.exists(self.config_file_path):
                with open(self.config_file_path, 'r', encoding='utf-8') as f:
                    self.keywords = json.load(f)
                logger.info(f"Loaded keywords from {self.config_file_path}")
            else:
                # Initialize with default keywords
                self.keywords = {
                    "keywords": {
                        "urgency": {
                            "high": ["urgent", "emergency", "immediately", "asap", "critical", "important", "right away", "now"],
                            "medium": ["soon", "today", "this afternoon", "when possible", "timely"],
                            "low": ["whenever", "sometime", "no rush", "when convenient"]
                        },
                        "formality": {
                            "formal": ["sir", "madam", "would you kindly", "i would appreciate", "could you please"],
                            "professional": ["please", "thank you", "could you", "would you", "i need to"],
                            "casual": ["hey", "hi", "yeah", "wanna", "can't", "don't", "gonna"]
                        },
                        "sentiment": {
                            "positive": ["great", "excellent", "wonderful", "amazing", "fantastic", "perfect"],
                            "neutral": ["okay", "fine", "alright", "sure", "yes", "no"],
                            "negative": ["bad", "terrible", "awful", "horrible", "disappointed", "frustrated"]
                        },
                        "intent": {
                            "meeting": ["meeting", "schedule", "book", "appointment", "calendar", "time"],
                            "message": ["message", "tell", "inform", "notify", "let know", "pass along"],
                            "callback": ["call back", "callback", "return call", "phone back", "reach out"],
                            "availability": ["available", "free", "busy", "occupied", "around", "here"]
                        }
                    }
                }
                self._save_keywords()
                logger.info("Initialized with default keywords")
        except Exception as e:
            logger.error(f"Error loading keywords: {e}")
            self.keywords = {"keywords": {}}
    
    def _save_keywords(self):
        """Save keywords to JSON config file"""
        try:
            with open(self.config_file_path, 'w', encoding='utf-8') as f:
                json.dump(self.keywords, f, indent=2, ensure_ascii=False)
            logger.debug("Keywords saved to config file")
        except Exception as e:
            logger.error(f"Error saving keywords: {e}")
    
    def analyze_query_keywords(self, query: str) -> Dict[str, str]:
        """
        Analyze query and extract keyword categories.
        
        Args:
            query: User query text
            
        Returns:
            Dictionary with keyword analysis results
        """
        query_lower = query.lower()
        result = {
            "urgency": "low",
            "formality": "professional", 
            "sentiment": "neutral",
            "intent": "message"
        }
        
        # Analyze urgency
        for level, keywords in self.keywords["keywords"]["urgency"].items():
            if any(keyword in query_lower for keyword in keywords):
                result["urgency"] = level
                break
        
        # Analyze formality
        for level, keywords in self.keywords["keywords"]["formality"].items():
            if any(keyword in query_lower for keyword in keywords):
                result["formality"] = level
                break
        
        # Analyze sentiment
        for level, keywords in self.keywords["keywords"]["sentiment"].items():
            if any(keyword in query_lower for keyword in keywords):
                result["sentiment"] = level
                break
        
        # Analyze intent
        for intent, keywords in self.keywords["keywords"]["intent"].items():
            if any(keyword in query_lower for keyword in keywords):
                result["intent"] = intent
                break
        
        # Person name detection removed - now handled by LLM-based query generalization
        
        return result
    
    async def learn_from_query(self, query: str, llm_analysis: Dict[str, str] = None):
        """
        Learn new keywords from user query and LLM analysis.
        
        Args:
            query: User query text
            llm_analysis: Optional LLM-provided keyword analysis
        """
        try:
            with self._lock:
                # Learn from LLM analysis if provided
                if llm_analysis:
                    for category, value in llm_analysis.items():
                        if category in self.keywords["keywords"] and isinstance(value, str):
                            if value not in self.keywords["keywords"][category]:
                                self.keywords["keywords"][category].append(value)
                                logger.info(f"Learned new {category} keyword: {value}")
                
                # Person names learning removed - query generalization now handled by LLM
                
                # Save updated keywords
                self._save_keywords()
                
        except Exception as e:
            logger.error(f"Error learning from query: {e}")
    
    def get_keywords(self) -> Dict:
        """Get current keywords dictionary"""
        return self.keywords
    
    def get_keyword_count(self) -> Dict[str, int]:
        """Get count of keywords in each category"""
        counts = {}
        for category, keywords in self.keywords["keywords"].items():
            counts[category] = len(keywords)
        return counts

# Global Keyword Manager instance
pa_keyword_manager = None

def get_keyword_manager() -> Optional[PAKeywordManager]:
    """Get the global Keyword Manager instance (auto-initializes if needed)"""
    global pa_keyword_manager
    
    if pa_keyword_manager is None:
        try:
            config_file = os.getenv('PA_KEYWORDS_CONFIG_FILE', 'pa_keywords_config.json')
            pa_keyword_manager = PAKeywordManager(config_file)
            logger.info("Keyword Manager auto-initialized successfully")
        except Exception as e:
            logger.error(f"Error auto-initializing Keyword Manager: {e}")
            return None
    
    return pa_keyword_manager