lang_configs = {
    "lang_mappings": {
        "en-IN": {
            "text_lang_code": "en",
            "speech_lang_code": "en-IN",
            "voice_code": "en-IN-Neural2-D"
        },
        "ja-JP": {
            "text_lang_code": "ja",
            "speech_lang_code": "ja-JP",
            "voice_code": "ja-JP-Wavenet-A"
        },
        "pa-IN": {
            "text_lang_code": "pa",
            "speech_lang_code": "pa-IN",
            "voice_code": "pa-IN-Wavenet-B"
        },
        "hi-IN": {
            "text_lang_code": "hi",
            "speech_lang_code": "hi-IN",
            "voice_code": "hi-IN-Neural2-D"
        },
        "ps-AF": {
            "text_lang_code": "hi",
            "speech_lang_code": "hi-IN",
            "voice_code": "hi-IN-Neural2-D"
        },
        "ta-IN": {
            "text_lang_code": "ta",
            "speech_lang_code": "ta-IN",
            "voice_code": "ta-IN-Standard-A"
        }
    }
}
