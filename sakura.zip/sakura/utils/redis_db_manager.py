"""
Redis Database Manager for Performance Optimization
Separates different types of operations across Redis databases to prevent interference
"""

import redis
import os
from logger import get_logger

logger = get_logger(__name__)

class RedisDBManager:
    """
    Manages multiple Redis database connections for performance optimization
    
    DB=0: Main user call records + time-critical utterance/wait keys
    DB=2: Heavy CDR operations (isolated from timing-critical operations)  
    DB=3: Key expiration events (separate from both main and CDR operations)
    """
    
    def __init__(self):
        self.redis_host = os.getenv('REDIS_HOST', 'localhost')
        self.redis_port = int(os.getenv('REDIS_PORT', 6379))
        self.redis_password = os.getenv('REDIS_PASSWORD', None)
        
        # Initialize connections
        self.main_db = self._create_connection(1)      # Main operations (utterance keys)
        self.cdr_db = self._create_connection(2)       # CDR operations  
        self.expiry_db = self._create_connection(1)    # Expiry events (same as main)
        
        logger.info("RedisDBManager initialized - DB1=Main/Expiry, DB2=CDR")
    
    def _create_connection(self, db_num):
        """Create Redis connection for specific database"""
        try:
            logger.info(f"Initializing Redis client on db={db_num}")
            
            # Create connection pool kwargs - only include password if set
            pool_kwargs = {
                'host': self.redis_host,
                'port': self.redis_port,
                'db': db_num,
                'decode_responses': True,
                'max_connections': 300,  # Match existing scaled pooling
                'retry_on_timeout': True,
                'retry_on_error': [redis.exceptions.ConnectionError, redis.exceptions.TimeoutError],
                'socket_keepalive': True,
                'socket_keepalive_options': {},
                'socket_connect_timeout': 5,
                'socket_timeout': 10,
                'health_check_interval': 60
            }
            
            if self.redis_password:
                pool_kwargs['password'] = self.redis_password
            
            # Create connection using the same pattern as existing config
            conn = redis.Redis(
                host=self.redis_host,
                port=self.redis_port,
                db=db_num,
                decode_responses=True,  # Match existing config
                # Use same connection pool pattern as existing config
                connection_pool=redis.ConnectionPool(**pool_kwargs)
            )
            
            # Test connection
            conn.ping()
            logger.info(f"Redis DB{db_num} connection established with scaled pooling (300 connections)")
            return conn
        except Exception as e:
            logger.error(f"Failed to connect to Redis DB{db_num}: {e}")
            raise
    
    def get_main_client(self):
        """Get main Redis client (DB=1) for user records and timing-critical keys"""
        return self.main_db
    
    def get_cdr_client(self):
        """Get CDR Redis client (DB=2) for heavy CDR operations"""
        return self.cdr_db
    
    def get_expiry_client(self):
        """Get expiry Redis client (DB=1) for key expiration events"""
        return self.expiry_db

# Global instance - initialized lazily to avoid logger initialization timing issues
_redis_manager = None

class LazyRedisManager:
    """Lazy wrapper for Redis manager to avoid early initialization"""
    
    def __init__(self):
        self._manager = None
    
    def _get_manager(self):
        if self._manager is None:
            self._manager = RedisDBManager()
        return self._manager
    
    def get_main_client(self):
        return self._get_manager().get_main_client()
    
    def get_cdr_client(self):
        return self._get_manager().get_cdr_client()
    
    def get_expiry_client(self):
        return self._get_manager().get_expiry_client()

# Global lazy instance
redis_manager = LazyRedisManager()
