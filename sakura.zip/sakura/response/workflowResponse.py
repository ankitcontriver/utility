class GenericResponse:
    def __init__(self, statusCode, status, message):
        self.statusCode = statusCode
        self.status = status
        self.message = message

    def __repr__(self):
        return f"GenericResponse(statusCode={self.statusCode}, status={self.status}, message={self.message})"
    
    
class shortToolInfo:
    def __init__(self, id, name, description, status):
        self.id = id
        self.name = name
        self.description= description
        self.status = status
    
    def __repr__(self):
        return f"shortToolInfo(id:{self.id}, name : {self.name}, description:{self.description},status:{self.status})"
    
    
class showAgentItem(shortToolInfo):
    def __init__(self,id, name, toolList: list[shortToolInfo], description,status,documentLink,createdBy,createdOn,updatedBy,updatedOn,state, flowUml):
        self.id = id
        self.name = name
        self.toolList = toolList
        self.description = description
        self.createdBy = createdBy
        self.createdOn = createdOn
        self.updatedBy = updatedBy
        self.updatedOn =updatedOn
        self.status= status
        self.documentLink= documentLink
        self.state = state
        self.flowUml = flowUml
    
    def __repr__(self):
        return f"showAgentItem(id={self.id}, agentName={self.name}, toolList={self.toolList},description={self.description},documentLink={self.documentLink},createdBy={self.createdBy}, createdOn ={self.createdOn},updateBy={self.updatedBy}, updateOn={self.updatedOn}, status={self.status}, state={self.state}, flowUml={self.flowUml})"
    
class uploadDocResponse(GenericResponse):
    def __init__(self, status, statusCode, message, data:showAgentItem):
        super().__init__(statusCode, status, message)
        self.data = data
    
    def __repr__(self):
        return f"status: {self.status}, statusCode: {self.statusCode}, message: {self.message}, data: {self.data}"