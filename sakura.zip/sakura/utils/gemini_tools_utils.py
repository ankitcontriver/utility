gemini_tools = [
    {
        "function_declarations": [
            {
                "name": "web_search",
                "description": "Perform a web search to retrieve information about recent events. This function is optimized for finding the latest news and updates related to the specified query.",
                "parameters": {
                    "type_": "OBJECT",
                    "properties": {
                        "query": {
                            "type_": "STRING",
                            "description": "The search query string focused on recent events or news topics."
                        }
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "get_time",
                "description": "Retrieve the current time for a specified time zone.",
                "parameters": {
                    "type_": "OBJECT",
                    "properties": {
                        "time_zone": {
                            "type_": "STRING",
                            "description": "The location to get the current time for. This should be a recognizable time zone identifier."
                        }
                    },
                    "required": ["time_zone"]
                }
            }
        ]
    }
]
