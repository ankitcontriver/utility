#!/usr/bin/env python3
"""
Language Tier Configuration Manager

This module manages language-specific tier limits and confidence thresholds
for the 3-tier Personal Assistant system. It loads configuration from a JSON file
and provides cached access to language-specific settings.
"""

import os
import json
import logging
from typing import Dict, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

class LanguageTierConfigManager:
    """Manages language-specific tier configurations and confidence thresholds"""
    
    def __init__(self, config_file_path: Optional[str] = None):
        """
        Initialize the configuration manager
        
        Args:
            config_file_path: Path to the JSON configuration file
        """
        if config_file_path is None:
            # Default path relative to this file
            current_dir = Path(__file__).parent
            config_file_path = current_dir / "language_tier_config.json"
        
        self.config_file_path = config_file_path
        self.config = None
        
        # Check if 3-tier system is enabled before loading configuration
        self.three_tier_enabled = os.getenv('THREE_TIER_LLM_ENABLED', 'false').lower() == 'true'
        
        if self.three_tier_enabled:
            self._load_configuration()
            logger.info("Language tier configuration loaded (3-tier system enabled)")
        else:
            logger.info("Language tier configuration skipped (3-tier system disabled)")
            self._set_default_config()
    
    def _load_configuration(self) -> None:
        """Load configuration from JSON file"""
        try:
            if not os.path.exists(self.config_file_path):
                logger.error(f"Configuration file not found: {self.config_file_path}")
                self._set_default_config()
                return
            
            with open(self.config_file_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
            
            # Validate configuration structure
            self._validate_config()
            
            logger.info(f"Language tier configuration loaded successfully from {self.config_file_path}")
            logger.info(f"Configured languages: {list(self.config.get('language_configs', {}).keys())}")
            
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in configuration file: {e}")
            self._set_default_config()
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            self._set_default_config()
    
    def _validate_config(self) -> None:
        """Validate the configuration structure"""
        required_keys = ['default_max_tier', 'default_confidence_thresholds']
        for key in required_keys:
            if key not in self.config:
                raise ValueError(f"Missing required configuration key: {key}")
        
        # Validate default confidence thresholds
        thresholds = self.config['default_confidence_thresholds']
        required_thresholds = ['tier1_min_confidence', 'tier2_min_confidence']
        for threshold in required_thresholds:
            if threshold not in thresholds:
                raise ValueError(f"Missing required threshold: {threshold}")
        
        # Validate language-specific configurations
        for lang_code, lang_config in self.config.get('language_configs', {}).items():
            if 'max_tier' not in lang_config:
                raise ValueError(f"Missing max_tier for language {lang_code}")
            if not isinstance(lang_config['max_tier'], int) or not (1 <= lang_config['max_tier'] <= 3):
                raise ValueError(f"Invalid max_tier for language {lang_code}: must be 1, 2, or 3")
    
    def _set_default_config(self) -> None:
        """Set default configuration when file is missing or invalid"""
        logger.warning("Using default language tier configuration")
        self.config = {
            "default_max_tier": 3,
            "default_confidence_thresholds": {
                "tier1_min_confidence": 0.8,
                "tier2_min_confidence": 0.5
            },
            "language_configs": {}
        }
    
    def get_max_tier(self, lang_code: str) -> int:
        """
        Get the maximum tier allowed for a language
        
        Args:
            lang_code: Language code (e.g., 'en-US', 'ps-AF')
            
        Returns:
            Maximum tier (1, 2, or 3)
        """
        if not self.three_tier_enabled or not self.config:
            return 3  # Default to Tier 3 when 3-tier is disabled
        
        lang_configs = self.config.get('language_configs', {})
        if lang_code in lang_configs:
            return lang_configs[lang_code]['max_tier']
        
        return self.config.get('default_max_tier', 3)
    
    def get_confidence_thresholds(self, lang_code: str) -> Tuple[float, float]:
        """
        Get confidence thresholds for a language
        
        Args:
            lang_code: Language code (e.g., 'en-US', 'ps-AF')
            
        Returns:
            Tuple of (tier1_min_confidence, tier2_min_confidence)
        """
        if not self.three_tier_enabled or not self.config:
            return (0.8, 0.5)  # Default thresholds when 3-tier is disabled
        
        lang_configs = self.config.get('language_configs', {})
        if lang_code in lang_configs:
            lang_config = lang_configs[lang_code]
            tier1_threshold = lang_config.get('tier1_min_confidence', 
                                            self.config['default_confidence_thresholds']['tier1_min_confidence'])
            tier2_threshold = lang_config.get('tier2_min_confidence',
                                            self.config['default_confidence_thresholds']['tier2_min_confidence'])
            return (tier1_threshold, tier2_threshold)
        
        # Use default thresholds
        default_thresholds = self.config.get('default_confidence_thresholds', {})
        return (default_thresholds.get('tier1_min_confidence', 0.8),
                default_thresholds.get('tier2_min_confidence', 0.5))
    
    def get_language_config(self, lang_code: str) -> Dict:
        """
        Get complete configuration for a language
        
        Args:
            lang_code: Language code (e.g., 'en-US', 'ps-AF')
            
        Returns:
            Dictionary containing max_tier and confidence thresholds
        """
        max_tier = self.get_max_tier(lang_code)
        tier1_threshold, tier2_threshold = self.get_confidence_thresholds(lang_code)
        
        return {
            'max_tier': max_tier,
            'tier1_min_confidence': tier1_threshold,
            'tier2_min_confidence': tier2_threshold
        }
    
    def is_language_configured(self, lang_code: str) -> bool:
        """
        Check if a language has specific configuration
        
        Args:
            lang_code: Language code
            
        Returns:
            True if language has specific configuration, False otherwise
        """
        if not self.config:
            return False
        
        return lang_code in self.config.get('language_configs', {})
    
    def get_configured_languages(self) -> list:
        """
        Get list of all configured languages
        
        Returns:
            List of language codes with specific configurations
        """
        if not self.config:
            return []
        
        return list(self.config.get('language_configs', {}).keys())
    
    def reload_configuration(self) -> None:
        """Reload configuration from file"""
        logger.info("Reloading language tier configuration")
        self._load_configuration()


# Global instance for easy access
_language_tier_config_manager = None

def get_language_tier_config_manager() -> LanguageTierConfigManager:
    """Get the global language tier configuration manager instance"""
    global _language_tier_config_manager
    if _language_tier_config_manager is None:
        _language_tier_config_manager = LanguageTierConfigManager()
    return _language_tier_config_manager

def get_max_tier(lang_code: str) -> int:
    """Convenience function to get max tier for a language"""
    return get_language_tier_config_manager().get_max_tier(lang_code)

def get_confidence_thresholds(lang_code: str) -> Tuple[float, float]:
    """Convenience function to get confidence thresholds for a language"""
    return get_language_tier_config_manager().get_confidence_thresholds(lang_code)

def get_language_config(lang_code: str) -> Dict:
    """Convenience function to get complete language configuration"""
    return get_language_tier_config_manager().get_language_config(lang_code)
