from response.GenericResponse import GenericResponse


class GetLLMModel:
    def __init__(self, llm_model_name, llm_model_display_name, llm_model_provider, tool_call_support):
        self.llm_model_name = llm_model_name
        self.llm_model_display_name = llm_model_display_name
        self.llm_model_provider = llm_model_provider
        self.tool_call_support = tool_call_support

    def __repr__(self):
        return f'llm_model_name : {self.llm_model_name}, llm_model_display_name : {self.llm_model_display_name}, llm_model_provider: {self.llm_model_provider}, tool_call_support: {self.tool_call_support}'


class GetLLMModelResponse(GenericResponse):
    def __init__(self, status, status_code, message, data: list[GetLLMModel]):
        super().__init__(status_code=status_code, status=status, message=message)
        self.data = data

    def __repr__(self):
        return f'status : {self.status}, status_code : {self.status_code}, message : {self.message}, data : {self.data}'
