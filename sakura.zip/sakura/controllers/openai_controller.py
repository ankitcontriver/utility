import os

from logger import get_logger
from dotenv import load_dotenv
from openai import OpenAI

logger = get_logger(__name__)

load_dotenv()

api_key = os.getenv('OPENAI_API_KEY')

client = OpenAI()


def analyze_conversation_chunk(appended_chunk):
    system_prompt = """

        you are a pro at analyzing statements , I will pass you a string , you just have to return wheather that string is a valid / complete statement in itself or not

    you just have to respond in yes or no

    example :

    Question : Hi there, I recently purchased the SmartWidget 3000, and I'm having trouble setting it up. It won't sync with my smartphone app. Any suggestions on how to troubleshoot this problem?
    Answer : yes

    Question : Hi there How
    Answer : no

    Question: Why there is
    Answer : no

    Question: Tomorrow will be
    Answer: no

    Question: What time does the library close on Fridays, and is it open on weekends?
    Answer: no

    Question: I am facing issues on my phone
    Answer: yes

    Question: What time is it supposed to rain today?
    Answer: yes

    Question: Can dogs eat choclate
    Answer: yes

    Question: Hi How are you
    Answer: yes

    Question: What are you doing today ?
    Answer: yes

    Question: Any plans for today
    Answer: yes

    Question: What is your fantasy
    Answer: yes

    Question: Ummmm....
    Answer: no

    Question: Evaa....
    Answer: no


    your answer should be strictly in one word , either yes or no

    your answer should never be like this
    Answer:yes

    you should answer strictly in 1 word , either yes or no


    """

    # Create the completion request
    try:
        completion = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": f"Question : {appended_chunk}",
                },
            ],
        )

        # Extract and return the model's response
        return completion.choices[0].message
    except Exception as e:
        logger.error(f"Error in analyze_conversation_chunk in openai_controller.py: {e}", exc_info=True)
        raise RuntimeError(f"Error in analyze_conversation_chunk")
