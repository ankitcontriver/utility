from sqlalchemy import desc
from sqlalchemy.orm import Session

from models.database_models import CDRTable


def get_all_cdr_tables(db: Session):
    """Retrieve all CDR tables from the database."""
    return db.query(CDRTable).order_by(desc(CDRTable.createdOn)).all()


def get_cdr_table_by_call_id(db: Session, call_id: str):
    """Retrieve a CDR table by call ID."""
    return db.query(CDRTable).filter(CDRTable.callId == call_id).order_by(desc(CDRTable.createdOn)).first()
