import json
import traceback

from config.country_prompt_config_genric import country_prompts
from models.database_models import OrganizationNames, UserDetails
from sqlalchemy.orm import Session
from collections import defaultdict
from logger import get_logger

logger = get_logger(__name__)


def get_non_null_data(db: Session, table1_class, table2_class, columns1: list, columns2: list, col2_headings,
                      primary_key2: dict,
                      model_id: int, country_code: str, values: dict, dict1: dict):
    """
    Fetch non-NULL values from specified columns of a row, format them as 'label: value',
    and return the formatted string. If no row is found with the primary key, fallback to the secondary key.
    :param db: SQLAlchemy session
    :param table1_class: SQLAlchemy model class for the first table
    :param table2_class: SQLAlchemy model class for the second table
    :param columns1: List of column names to check for non-NULL values
    :param columns2: List of column names to check for non-NULL values
    :param primary_key2: Dictionary containing the primary key to identify the row
    :param model_id: Model ID
    :param country_code: Country code
    :param values: A dictionary of values to substitute into the template
    :param dict1: Additional dictionary for values
    :return: Formatted string of non-NULL column values with custom labels
    """
    try:
        def fetch_row(table_class, key, column_list):
            query = db.query(*[getattr(table_class, col) for col in column_list]).filter_by(**key).first()
            return query._asdict() if query else {}

        result = {'name': None, 'company': None, 'prompt': None}

        fetch_from_default_prompts, fetch_from_extra_columns, parameters_from_extra_columns, parameters_from_default_prompts = None, None, None, None

        dict2, dict3 = {}, {}

        primary_key1 = {"agent_id": primary_key2.get("agent_id"), "model_id": model_id}
        fetch_from_default_prompts = fetch_row(table1_class, primary_key1, columns1)

        if fetch_from_default_prompts:
            parameters_from_default_prompts = fetch_row(table1_class, primary_key1, ["parameters"]).get('parameters')
            if parameters_from_default_prompts:
                dict3 = parameters_from_default_prompts

        if primary_key2.get("org_id") != -2:
            fetch_from_extra_columns = fetch_row(table2_class, primary_key2, columns2)
            parameters_from_extra_columns = fetch_row(table2_class, primary_key2, ["parameters"])

        if not fetch_from_extra_columns:
            fallback_key = {'agent_id': primary_key2.get("agent_id"),
                            'organization_name': 'default'
                            }
            fetch_from_extra_columns = fetch_row(table2_class, fallback_key, columns2)
            parameters_from_extra_columns = fetch_row(table2_class, fallback_key, ["parameters"])

        if parameters_from_extra_columns:
            dict2 = parameters_from_extra_columns.get('parameters')

        dict2.update({k: v for k, v in dict3.items() if k not in dict2 or not dict2[k]})
        dict1.update({k: v for k, v in dict2.items() if k not in dict1 or not dict1[k]})
        values.update({k: v for k, v in dict1.items() if k not in values or not values[k]})

        if "name" in values:
            result["name"] = values.get("name")

        if "company" in values:
            result["company"] = values.get("company")

        formatted_string = "Adopt the agent personality defined in PERSONALITY section and answer user queries by staying in the ROLE defined to you. You should follow BEHAVIOUR section to always stay in behaviour section and your capabilities are defined in CAPABILITIES section. Always look for DO_DONTS before answering user questions. If any Additional Info, Plans, FAQs are present then try to look for answers to user's query in it."

        value = country_prompts.get(country_code)
        if value:
            formatted_string += f"\nPERSONALITY: \n\n{value}\n\n"
        else:
            logger.warning(f"The key '{country_code}' does not exist in the dictionary.")
            return result

        if fetch_from_default_prompts:
            formatted_data = [f"{column.upper()}: \n\n{fetch_from_default_prompts[column]}\n" for column in columns1 if
                              fetch_from_default_prompts.get(column) is not None]
            formatted_string += '\n'.join(formatted_data)
        else:
            logger.info("No matching row found in table default_prompts!!")
            return result

        if fetch_from_extra_columns:
            formatted_data = [f"{col2_headings[column]}: \n\n{fetch_from_extra_columns[column]}\n" for column in
                              columns2 if
                              fetch_from_extra_columns.get(column) is not None]
            formatted_string += '\n'.join(formatted_data)

        # Create a defaultdict using your values dictionary
        final_values = defaultdict(str, values)

        try:
            # Use format_map to safely format the string with the available values
            formatted_string = formatted_string.format_map(final_values)
        except KeyError as e:
            logger.error(f"Missing key: {e.args[0]}", exc_info=True)
            return result

        result["prompt"] = formatted_string.format(**values)
        return result
    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)
        return


def get_org_id_by_email(db: Session, email_id: str):
    """
    Fetch the domain_name for a given email_id from the table.
    :param db: SQLAlchemy session
    :param email_id: The email_id to look up
    :return: The domain_name corresponding to the given email_id
    """
    result = db.query(UserDetails).filter(UserDetails.email_id == email_id).first()
    if result:
        return result.org_id
    else:
        logger.info("No matching email_id found!")
        return -2


def main():
    logger.debug("Hi")


if __name__ == "__main__":
    main()
