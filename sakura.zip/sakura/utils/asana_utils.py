import json
import traceback

import requests

from logger import get_logger

logger = get_logger(__name__)

API_TOKEN = "2/1208433227176136/1208683921965655:b3eec70bf1e1a93936687b7e0a66df9a"

projects = ["1208683990611783"]
project_id = "1208683990611783"
Section_id = "1208683990611784"


def get_complaint_details(call_id, assistant_id, complaint_id: str):
    task_gid = complaint_id 
    """get details for particular task"""
    task_url = f"https://app.asana.com/api/1.0/tasks/{task_gid}"
    comments_url = f"https://app.asana.com/api/1.0/tasks/{task_gid}/stories"

    headers = {
        'accept': 'application/json',
        'authorization': f'Bearer {API_TOKEN}'
    }

    try:
        # Fetch task details
        task_response = requests.get(task_url, headers=headers, timeout=10)
        task_response.raise_for_status()
        task_data = task_response.json()

        # Fetch comments (stories) for the task
        comments_response = requests.get(comments_url, headers=headers, timeout=10)
        comments_response.raise_for_status()
        comments_data = comments_response.json()

        # Combine task details and comments
        combined_data = {
            "task_details": task_data.get("data", {}),
            "comments": comments_data.get("data", [])
        }

        # Return the combined data in pretty-printed JSON format
        return json.dumps(combined_data, indent=2)

    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred in get_complaint_details(): {http_err}")
    except requests.exceptions.ConnectionError as conn_err:
        logger.error(f"Connection error occurred in get_complaint_details(): {conn_err}")
    except requests.exceptions.Timeout as timeout_err:
        logger.error(f"Timeout error occurred in get_complaint_details(): {timeout_err}")
    except requests.exceptions.RequestException as req_err:
        logger.error(f"An error occurred in get_complaint_details(): {req_err}")
    except ValueError as json_err:
        logger.error(f"JSON decoding failed in get_complaint_details(): {json_err}")
    except Exception as err:
        logger.error(f"An unexpected error occurred in get_complaint_details(): {err}")
        raise

    return "Error: Unable to get_complaint details"


def get_all_complaints(call_id, assistant_id, project_id="1208683990611783"):
    # URL to get tasks in the specified project
    tasks_url = f"https://app.asana.com/api/1.0/projects/{project_id}/tasks?opt_fields=completed,name,memberships.section.name"
    headers = {
        'accept': 'application/json',
        'authorization': f'Bearer {API_TOKEN}'
    }

    try:
        # Get all tasks in the project
        response = requests.get(tasks_url, headers=headers, timeout=10)
        response.raise_for_status()
        tasks_data = response.json()

        # Collect all tasks and fetch comments for each
        tasks_with_comments = []
        for task in tasks_data['data']:
            task_info = {
                "task_details": task,
                "comments": []
            }

            # Fetch comments (stories) for each task
            comments_url = f"https://app.asana.com/api/1.0/tasks/{task['gid']}/stories"
            comments_response = requests.get(comments_url, headers=headers, timeout=10)
            comments_response.raise_for_status()
            comments_data = comments_response.json()

            # Add comments to the task info
            task_info["comments"] = comments_data.get("data", [])
            tasks_with_comments.append(task_info)

        # Return combined task details with comments as JSON
        return json.dumps(tasks_with_comments, indent=2)

    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred in get_all_complaints_with_comments(): {http_err}")
    except requests.exceptions.ConnectionError as conn_err:
        logger.error(f"Connection error occurred in get_all_complaints_with_comments(): {conn_err}")
    except requests.exceptions.Timeout as timeout_err:
        logger.error(f"Timeout error occurred in get_all_complaints_with_comments(): {timeout_err}")
    except requests.exceptions.RequestException as req_err:
        logger.error(f"An error occurred in get_all_complaints_with_comments(): {req_err}")
    except ValueError as json_err:
        logger.error(f"JSON decoding failed in get_all_complaints_with_comments(): {json_err}")
    except Exception as err:
        logger.error(f"An unexpected error occurred in get_all_complaints_with_comments(): {err}")
        raise

    return "Error: Unable to retrieve complaints and comments"


def create_complaint(call_id, assistant_id, subject, description):
    name = subject
    notes = description
    url = "https://app.asana.com/api/1.0/tasks"
    headers = {
        'accept': 'application/json',
        'authorization': f'Bearer {API_TOKEN}',
        'content-type': 'application/json'
    }
    payload = {
        "data": {
            "name": name,
            "notes": notes,
            "projects": projects
        }
    }
    try:

        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        task_data = response.json()
        task_id = task_data["data"]["gid"]

        # Move the created task to the specified section
        add_task_to_section(task_id)

        logger.info(f"Task {task_id} moved to the specified section.")

        # Return the task data as JSON
        return json.dumps(task_data, indent=2)

    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred in create_complaint(): {http_err}")
    except requests.exceptions.ConnectionError as conn_err:
        logger.error(f"Connection error occurred in create_complaint(): {conn_err}")
    except requests.exceptions.Timeout as timeout_err:
        logger.error(f"Timeout error occurred in create_complaint(): {timeout_err}")
    except requests.exceptions.RequestException as req_err:
        logger.error(f"An error occurred in create_complaint(): {req_err}")
    except ValueError as json_err:
        logger.error(f"JSON decoding failed in create_complaint(): {json_err}")
    except Exception as err:
        logger.error(f"An unexpected error occurred in create_complaint(): {err}")
        raise

    return "Error: Unable to create complaint"


def add_task_to_section(task_id):
    url = f"https://app.asana.com/api/1.0/sections/{Section_id}/addTask"
    headers = {
        'accept': 'application/json',
        'authorization': f'Bearer {API_TOKEN}',
        'content-type': 'application/json'
    }
    payload = {
        "data": {
            "task": task_id
        }
    }

    response = requests.post(url, headers=headers, json=payload)
    response.raise_for_status()  # Check for any request errors

    if response.status_code == 200:
        logger.info(f"Complaint with {task_id} added to section new")
    else:
        logger.info(f"Unable to add complaint with {task_id} to the section new")

# ------------------------------------------------------------------------------


def get_all_incomplete_complaints(call_id, assistant_id, Section_id=1208683990611784):
    """fetching all tasks with comments from resolved section"""
    # URL to get tasks in the specified section
    tasks_url = f"https://app.asana.com/api/1.0/sections/{Section_id}/tasks?opt_fields=completed,name"
    headers = {
        'accept': 'application/json',
        'authorization': f'Bearer {API_TOKEN}'
    }

    try:
        # Get all tasks in the section
        response = requests.get(tasks_url, headers=headers, timeout=10)
        response.raise_for_status()  # Raise an error for bad responses
        tasks_data = response.json()

        # Collect all tasks and fetch comments for each
        tasks_with_comments = []
        for task in tasks_data['data']:
            task_info = {
                "task_details": task,
                "comments": []
            }

            # Fetch comments (stories) for each task
            comments_url = f"https://app.asana.com/api/1.0/tasks/{task['gid']}/stories"
            comments_response = requests.get(comments_url, headers=headers, timeout=10)
            comments_response.raise_for_status()  # Raise an error for bad responses
            comments_data = comments_response.json()

            # Add comments to the task info
            task_info["comments"] = comments_data.get("data", [])
            tasks_with_comments.append(task_info)

        # Return combined task details with comments as JSON
        return json.dumps(tasks_with_comments, indent=2)

    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred in get_all_incomplete_complaints(): {http_err}")
    except requests.exceptions.ConnectionError as conn_err:
        logger.error(f"Connection error occurred in get_all_incomplete_complaints(): {conn_err}")
    except requests.exceptions.Timeout as timeout_err:
        logger.error(f"Timeout error occurred in get_all_incomplete_complaints(): {timeout_err}")
    except requests.exceptions.RequestException as req_err:
        logger.error(f"An error occurred in get_all_incomplete_complaints(): {req_err}")
    except ValueError as json_err:
        logger.error(f"JSON decoding failed in get_all_incomplete_complaints(): {json_err}")
    except Exception as err:
        logger.error(f"An unexpected error occurred in get_all_incomplete_complaints(): {err}")
        raise

    return "Error: Unable to retrieve complaints and comments"


def get_all_resolved_complaints(call_id, assistant_id, Section_id=1208683990611788):
    """fetching all tasks with comments from resolved section"""
    # URL to get tasks in the specified section
    tasks_url = f"https://app.asana.com/api/1.0/sections/{Section_id}/tasks?opt_fields=completed,name"
    headers = {
        'accept': 'application/json',
        'authorization': f'Bearer {API_TOKEN}'
    }

    try:
        # Get all tasks in the section
        response = requests.get(tasks_url, headers=headers, timeout=10)
        response.raise_for_status()  # Raise an error for bad responses
        tasks_data = response.json()

        # Collect all tasks and fetch comments for each
        tasks_with_comments = []
        for task in tasks_data['data']:
            task_info = {
                "task_details": task,
                "comments": []
            }

            # Fetch comments (stories) for each task
            comments_url = f"https://app.asana.com/api/1.0/tasks/{task['gid']}/stories"
            comments_response = requests.get(comments_url, headers=headers, timeout=10)
            comments_response.raise_for_status()  # Raise an error for bad responses
            comments_data = comments_response.json()

            # Add comments to the task info
            task_info["comments"] = comments_data.get("data", [])
            tasks_with_comments.append(task_info)

        # Return combined task details with comments as JSON
        move_tasks_between_sections()
        return json.dumps(tasks_with_comments, indent=2)

    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred in get_all_resolved_complaints(): {http_err}",exc_info=True)
    except requests.exceptions.ConnectionError as conn_err:
        logger.error(f"Connection error occurred in get_all_resolved_complaints(): {conn_err}",exc_info=True)
    except requests.exceptions.Timeout as timeout_err:
        logger.error(f"Timeout error occurred in get_all_resolved_complaints(): {timeout_err}",exc_info=True)
    except requests.exceptions.RequestException as req_err:
        logger.error(f"An error occurred in get_all_resolved_complaints(): {req_err}",exc_info=True)
    except ValueError as json_err:
        logger.error(f"JSON decoding failed in get_all_resolved_complaints(): {json_err}",exc_info=True)
    except Exception as err:
        logger.error(f"An unexpected error occurred in get_all_resolved_complaints(): {err}",exc_info=True)
        raise

    return "Error: Unable to retrieve complaints and comments"


# ---------------------------------------------------------------------------------

def move_tasks_between_sections(source_section_id=1208683990611788, target_section_id=1208683990611789):
    # URL to get tasks in the source section
    tasks_url = f"https://app.asana.com/api/1.0/sections/{source_section_id}/tasks?opt_fields=completed,name"
    headers = {
        'accept': 'application/json',
        'authorization': f'Bearer {API_TOKEN}'
    }

    try:
        # Get all tasks in the source section
        response = requests.get(tasks_url, headers=headers, timeout=10)
        response.raise_for_status()  # Raise an error for bad responses
        tasks_data = response.json()

        # Loop through tasks and move each task to the target section
        for task in tasks_data['data']:
            task_gid = task['gid']
            move_task_to_section(task_gid, target_section_id)

        # Return success message
        return f"All tasks from section {source_section_id} have been moved to section {target_section_id}."

    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred in move_tasks_between_sections(): {http_err}")
    except requests.exceptions.ConnectionError as conn_err:
        logger.error(f"Connection error occurred in move_tasks_between_sections(): {conn_err}")
    except requests.exceptions.Timeout as timeout_err:
        logger.error(f"Timeout error occurred in move_tasks_between_sections(): {timeout_err}")
    except requests.exceptions.RequestException as req_err:
        logger.error(f"An error occurred in move_tasks_between_sections(): {req_err}")
    except ValueError as json_err:
        logger.error(f"JSON decoding failed in move_tasks_between_sections(): {json_err}")
    except Exception as err:
        logger.error(f"An unexpected error occurred in move_tasks_between_sections(): {err}")
        raise

    return "Error: Unable to retrieve tasks and move them."


def move_task_to_section(task_gid, target_section_id):
    # URL to add task to the target section
    move_url = f"https://app.asana.com/api/1.0/sections/{target_section_id}/addTask"
    headers = {
        'accept': 'application/json',
        'authorization': f'Bearer {API_TOKEN}',
        'content-type': 'application/json'
    }
    payload = {
        "data": {
            "task": task_gid
        }
    }

    try:
        # Send request to move the task to the target section
        response = requests.post(move_url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()  # Raise an error for bad responses

        if response.status_code == 200:
            logger.info(f"Task {task_gid} successfully moved to section {target_section_id}.")
        else:
            logger.error(f"Failed to move task {task_gid} to section {target_section_id}.")
    except requests.exceptions.RequestException as req_err:
        logger.error(f"Failed to move task {task_gid} to section {target_section_id}: {req_err}")
        
