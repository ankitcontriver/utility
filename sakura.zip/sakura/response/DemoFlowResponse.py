from response.GenericResponse import GenericResponse


class DemoFlowParameters:
    def __init__(self, language_code, language_name, asr_model, asr_language_id, tts_model, tts_language_id, voice_id,
                 gender):
        self.language_code = language_code
        self.language_name = language_name
        self.asr_model = asr_model
        self.asr_language_id = asr_language_id
        self.tts_model = tts_model
        self.tts_language_id = tts_language_id
        self.voice_id = voice_id
        self.gender = gender

    def __repr__(self):
        return f"language_code: {self.language_code}, language_name: {self.language_name}, asr_model: {self.asr_model}, asr_language_id: {self.asr_language_id,} tts_model: {self.tts_model}, tts_language_id: {self.tts_language_id},  voice_id: {self.voice_id}, gender: {self.gender}"


class DemoFlowConfigParameters:
    def __init__(self, llm_model, country_name, country_code, demo_organisation_name, lang_params: list[DemoFlowParameters]):
        self.llm_model = llm_model
        self.country_name = country_name
        self.country_code = country_code
        self.demo_organisation_name = demo_organisation_name
        self.lang_params = lang_params

    def __repr__(self):
        return f"llm_model: {self.llm_model}, country_name: {self.country_name}, country_code: {self.country_code}, demo_organisation_name: {self.demo_organisation_name}, lang_params: {self.lang_params}"


class DemoFlowResponse(GenericResponse):
    def __init__(self, status_code, status, message, data: DemoFlowConfigParameters):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return f"status_code: {self.status_code}, status: {self.status}, message: {self.message}, data: {self.data}"
