from response.GenericResponse import GenericResponse


class UrlObject:
    def __init__(self, id, url, count, login_track, email):
        self.id = id
        self.url = url
        self.count = count
        self.login_track = login_track
        self.email = email

    def __repr__(self):
        return f"id = {self.id}, email = {self.email}, url = {self.url}, count = {self.count}, login_track = {self.login_track}"


class GetAllUrlResponse(GenericResponse):
    def __init__(self, status, status_code, message, data: list[UrlObject]):
        super().__init__(status_code=status_code, status=status, message=message)
        self.data = data

    def __repr__(self):
        return f"status = {self.status}, status_code = {self.status_code}, message = {self.message}, data = {self.data}"


class GetUrlResponse(GenericResponse):
    def __init__(self, status, status_code, message, data: UrlObject):
        super().__init__(status_code=status_code, status=status, message=message)
        self.data = data

    def __repr__(self):
        return f"status = {self.status}, status_code = {self.status_code}, message = {self.message}, data = {self.data}"
