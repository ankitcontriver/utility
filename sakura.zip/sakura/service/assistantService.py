from logger import get_logger
import json
from repository.assistant_repository import get_assistants_by_tenant, get_assistant_by_id, \
    update_assistant_configuration
from response.AssistantResponse import showAssistantItem, showAssistents, tempSAD, ShowAssistantDetails
from typing import Optional
from config.database_config import SessionLocal
from repository.assistant_config_repository import update_assistant_config
from repository.client_config_repository import get_client_config_id, get_assistant_id_by_client_config
from service.xml_stt_service import XMLSTTProcessor
from cache.assistant_configuration_cache import load_cache,get_assistant_details_by_id
from service.xml_to_flat_array_service import XMLToFlatArrayConverter
from collections import Counter, defaultdict
from config.ivr_path_config import get_config


logger = get_logger(__name__)


def get_assistants_by_tenant_service(tenantId: str):
    try:
        logger.info(f"Fetching assistants for tenantId: {tenantId}")
        assistants = get_assistants_by_tenant(tenantId)

        if assistants is not None:
            assistant_data = [
                showAssistantItem(
                    id=assistant.id,
                    name=assistant.assistantName,
                    role=assistant.assistantRole,
                    description=assistant.assistantDescription,
                    imageUrl=assistant.assistantImageUrl,
                    assistantCategory= assistant.assistantCategory
                )
                for assistant in assistants
            ]

            response = showAssistents(
                statusCode=200,
                status="success",
                message=f"Assistants found for tenantId {tenantId}",
                data=assistant_data
            )
            logger.info(f"Successfully retrieved {len(assistant_data)} assistants for tenantId: {tenantId}")
        else:
            logger.info(f"No assistants found for tenantId: {tenantId}")
            response = showAssistents(
                statusCode=701,
                status="Success",
                message=f"No Assistants found for tenantId {tenantId}",
                data=[]
            )
    except Exception as e:
        logger.error(f"Exception occurred while fetching assistants for tenantId: {tenantId} - {e}",exc_info=True)
        response = showAssistents(
            statusCode=702,
            status="Failed",
            message="Failed to fetch assistants for the tenant",
            data=[]
        )
    finally:
        logger.info(f"Database connection closed for tenantId: {tenantId}")
        return response


def get_assistant_by_id_service(tenantId: str, assistantId: str):
    try:
        logger.info(f"Fetching assistant details for tenantId: {tenantId}, assistantId: {assistantId}")
        assistant = get_assistant_by_id(int(assistantId))

        if assistant is not None:
            assistant_data = tempSAD(
                id=assistant.id,
                name=assistant.assistantName,
                role=assistant.assistantRole,
                description=assistant.assistantDescription,
                languages=assistant.assistantLanguage,
                voice=assistant.assistantVoice,
                interface=assistant.assistantInterface,
            )

            response = ShowAssistantDetails(
                statusCode=200,
                status="success",
                message="Assistant found",
                info=assistant_data
            )
            logger.info(f"Successfully retrieved details for assistantId: {assistantId}")
        else:
            logger.info(f"No assistant found for assistantId: {assistantId}")
            response = ShowAssistantDetails(
                statusCode=901,
                status="Success",
                message=f"No Assistant found for tenantId {tenantId}",
                info = []
            )
    except Exception as e:
        logger.error(f"Exception occurred while fetching assistant details for assistantId: {assistantId} - {e}",exc_info=True)
        response = ShowAssistantDetails(
            statusCode=902,
            status="Failed",
            message="Failed to fetch assistant for the tenant",
            info=[]
        )
    finally:
        logger.info(f"Database connection closed for tenantId: {tenantId}, assistantId: {assistantId}")
        return response


def update_assistant_service(tenantId: str, assistant_id: int, userId: str, name: str = None,
                             assistantLanguage: str = None, assistantVoice: str = None, assistantInterface: str = None):
    try:
        logger.info(f"updating assistant for tenatntId: {tenantId} and assistantId: {assistant_id} ")
        assistant = update_assistant_configuration(assistant_id, userId, name, assistantLanguage, assistantVoice,
                                                   assistantInterface)

        if assistant is not None:
            assistant_data = tempSAD(
                id=assistant.id,
                name=assistant.assistantName,
                role=assistant.assistantRole,
                description=assistant.assistantDescription,
                languages=assistant.assistantLanguage,
                voice=assistant.assistantVoice,
                interface=assistant.assistantInterface,
            )

            response = ShowAssistantDetails(
                statusCode=200,
                status="success",
                message="Assistant found",
                info=assistant_data
            )
            logger.info(f"Successfully updated details for assistantId: {assistant_id}")
        else:
            logger.info(f"No assistant found for assistantId: {assistant_id}")
            response = ShowAssistantDetails(
                statusCode=901,
                status="Success",
                message=f"No Assistant found for tenantId {assistant_id}",
                info=[]
            )
    except Exception as e:
        logger.error(f"Exception occurred while fetching assistant details for assistantId: {assistant_id} - {e}",exc_info=True)
        response = ShowAssistantDetails(
            statusCode=902,
            status="Failed",
            message="Failed to fetch assistant for the tenant",
            info=[]
        )
    finally:
        logger.info(f"Database connection closed,, assistantId: {assistant_id}")
        return response



def update_assistant_xml_flow_service(operator: Optional[str], country: Optional[str], short_code: str, xml_flow: str):
    """
    Updates the XML flow for an assistant based on client configuration.
    If data is not found, returns 404 immediately.
    If data is found, returns 200 immediately and does processing in the background.
    """
    try:
        logger.info(f"Updating XML flow for short_code: {short_code}, operator: {operator}, country: {country}")
        # Create tenant_id by appending operator and country if both are provided
        tenant_id = None
        if operator and country:
            tenant_id = f"{operator}_{country}"
        # Get client config ID - if tenant_id is None, only filter by short_code
        client_config_id = get_client_config_id(short_code, tenant_id)
        if not client_config_id:
            return {
                "statusCode": 404,
                "status": "Failed",
                "message": f"No client configuration found for short_code: {short_code}" + (f" and tenant_id: {tenant_id}" if tenant_id else "")
            }
        # Get assistant ID mapped to this client
        assistant_id = get_assistant_id_by_client_config(client_config_id)
        if not assistant_id:
            return {
                "statusCode": 404,
                "status": "Failed",
                "message": f"No assistant mapped to client configuration ID: {client_config_id}"
            }
        # If both IDs are found, return 200 immediately and process in background
        def run_background_processing():
            try:
                # Get assistant configuration
                assistant_config = get_assistant_details_by_id(int(assistant_id))
                if not assistant_config:
                    logger.error(f"Assistant configuration not found for assistant_id: {assistant_id}")
                    return
                
                # Get lang_selection_via_asr flag from assistant configuration
                lang_selection_via_asr = assistant_config.get('lang_selection_via_asr', False)
                
                # Process XML with STT (only XML and STT processing)
                processor = XMLSTTProcessor()
                xml_stt_result = processor.process_xml_string(xml_flow, lang_selection_via_asr)
                
                # Create language mappings using the language processing service
                from config.language_mapping_config import create_language_mappings_from_ivr_stt_array
                
                # Create language mappings from the XML+STT result
                language_mappings_result = create_language_mappings_from_ivr_stt_array(xml_stt_result, lang_selection_via_asr)
                
                # Store the language mappings in the result
                llm_flat_array_result = language_mappings_result
                logger.info(f"Language mappings created: {list(language_mappings_result.get('language_mappings', {}).keys())}")
                
                # --- Generate more_generalized flat array ---
                converter = XMLToFlatArrayConverter()
                generalized_flat_array_result = converter.parse_xml_string_to_flat_array(xml_flow)
                config = get_config()
                log_ivr_flat_array_summary(generalized_flat_array_result['nodes'], config)
                db = SessionLocal()
                try:
                    update_assistant_config(db, assistant_id, json.dumps(llm_flat_array_result), json.dumps(generalized_flat_array_result))
                    load_cache()
                finally:
                    db.close()
            except Exception as e:
                logger.error(f"Error in background processing for update_assistant_xml_flow_service: {e}",exc_info=True)
        # Run the background processing in a separate thread (non-blocking)
        import threading
        threading.Thread(target=run_background_processing, daemon=True).start()
        return {
            "statusCode": 200,
            "status": "Success",
            "message": "Flat array json creation started from XML flow"
        }
    except Exception as e:
        logger.error(f"Error in update_assistant_xml_flow_service: {e}")
        return {
            "statusCode": 500,
            "status": "Failed",
            "message": f"Error updating XML flow: {str(e)}"
        }


def log_ivr_flat_array_summary(flat_array, config):
    logger = get_logger(__name__)

    total_nodes = len(flat_array)
    node_type_counts = Counter()
    nav_with_voiceprompt = 0
    nav_without_voiceprompt = 0
    nav_land_before = None
    nav_skippable_with = None
    nav_skippable_without = None

    # Build config lookup
    config_types = set(config.get("non_skippable_config", {}).keys())
    default_config = config.get("default_config", {"is_skippable": True, "land_before": 1})

    # For summary
    type_summary = defaultdict(lambda: {"count": 0, "is_skippable": None, "land_before": None, "source": "default"})

    for node in flat_array:
        node_type = node["type"]
        is_skippable = node["isSkippable"]
        land_before = node["land_before"]

        if node_type == "Navigation":
            promptfiles = node.get("promptfiles", [])
            if is_skippable:
                nav_with_voiceprompt += 1
                nav_land_before = land_before
                nav_skippable_with = is_skippable
            else:
                nav_without_voiceprompt += 1
                nav_land_before = land_before
                nav_skippable_without = is_skippable
        else:
            type_summary[node_type]["count"] += 1
            type_summary[node_type]["is_skippable"] = is_skippable
            type_summary[node_type]["land_before"] = land_before
            if node_type in config_types:
                type_summary[node_type]["source"] = "config"
            else:
                type_summary[node_type]["source"] = "default"

    logger.info("IVR Flat Array Summary:\n----------------------")
    logger.info(f"Total nodes: {total_nodes}\n")
    logger.info("Node Types:")

    # Navigation nodes
    logger.info(f"- Navigation (with _VOICEPROMPT.wav): count={nav_with_voiceprompt}, is_skippable={nav_skippable_with}, land_before={nav_land_before}")
    logger.info(f"- Navigation (without _VOICEPROMPT.wav): count={nav_without_voiceprompt}, is_skippable={nav_skippable_without}, land_before={nav_land_before}")

    # Other types
    for node_type, summary in type_summary.items():
        src = "" if summary["source"] == "config" else " (default)"
        logger.info(f"- {node_type}: count={summary['count']}, is_skippable={summary['is_skippable']}, land_before={summary['land_before']}{src}")
