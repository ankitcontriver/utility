from sqlalchemy.orm import Session

from models.database_models import Country, CountryLanguageMapping


def get_all_countries(db: Session):
    return db.query(Country).filter(Country.status).all()


def get_languages_for_country(db: Session, country_id: str):

    if country_id == "_ALL_":
        return db.query(CountryLanguageMapping).filter(CountryLanguageMapping.status).all()

    return db.query(CountryLanguageMapping).filter(CountryLanguageMapping.country_id == country_id, CountryLanguageMapping.status).all()
