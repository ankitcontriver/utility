from typing import Dict
import os
from config.database_config import SessionLocal
from logger import get_logger
from models.request_models import OrganizationNameRequest, SectorRequest
from repository.group_names_repository import get_organization_detail as get_organization_detail_repository, \
    upsert_organization_detail as upsert_organization_detail_repository, \
    get_unique_agents as get_unique_agents_repository, \
    get_sectors as get_sectors_repository, upsert_sector as upsert_sector_repository
from repository.group_names_repository import get_organization_names as get_organization_names_repository, \
    add_organization_name as add_organization_name_repository, \
    delete_organization as delete_organization_repository, get_organization_emails as get_organization_emails_repository
from repository.group_names_repository import get_user_mapping as get_user_mapping_repository, \
    update_user_mapping as update_user_mapping_repository
from repository.group_names_repository import update_organization_email as update_organization_email_repository
from response.GenericResponse import GenericResponse
from response.GetGroupNamesResponse import GetOrganizationName, GetUniqueAgentsResponse, UniqueAgent, GetSector, \
    GetSectorsResponse
from response.GetGroupNamesResponse import GetorganizationDetailResponse
from dotenv import load_dotenv

load_dotenv()

logger = get_logger(__name__)


def add_organization_name(organization_name_request: OrganizationNameRequest):
    logger.info(
        f"add_organization_name service called for organization_name: {organization_name_request.organization_name}, sector: {organization_name_request.sector}, email: {organization_name_request.email} ")
    db = SessionLocal()
    try:
        organization = add_organization_name_repository(db, organization_name_request.organization_name,
                                                        organization_name_request.sector,
                                                        organization_name_request.email)
        if organization:
            response = GenericResponse(status="Success", status_code=200,
                                       message="organization/email added successfully")
            response.data = [
                GetOrganizationName(org_id=organization.id, name=organization.organization_name,
                                    sector=organization.sector,
                                    emails=organization.emails)]
        else:
            response = GenericResponse(status="Failed", status_code=409,
                                       message=f"{organization_name_request.organization_name} - {organization_name_request.sector} sector already exists for {organization_name_request.email}")
    except Exception as e:
        response = GenericResponse(status="Failed", status_code=500, message=f"Internal Server Error: {e}")
    finally:
        db.close()
    return response


def get_organization_names(email_id: str):
    logger.info('get_organization_names service called for Email: {email_id}')
    db = SessionLocal()
    try:
        organizations = get_organization_names_repository(db, email_id)
        if organizations:
            data = [{
                "org_id": org.id,
                "organization_name": org.organization_name,
                "sector": org.sector
            } for org in organizations]
            response = GenericResponse(status="Success", status_code=200,
                                       message="Organization Names fetched successfully")
            response.data = data
        else:
            response = GenericResponse(status="Failed", status_code=404, message="No organizations found")
    except Exception as e:
        response = GenericResponse(status="Failed", status_code=500, message=f"Internal Server Error: {e}")
    finally:
        db.close()
    return response


def delete_organization(organization_name: str, sector: str, email: str):
    logger.info(
        f'delete_organization_email service called for email:{email}, organization: {organization_name}, sector: {sector}')
    db = SessionLocal()
    try:
        success = delete_organization_repository(db, organization_name, sector, email)
        if success:
            response = GenericResponse(status="Success", status_code=200,
                                       message="Email removed successfully from the organization.")
        else:
            response = GenericResponse(status="Failed", status_code=404,
                                       message=f"Email does not exist in  ({organization_name} - {sector})")
    except Exception as e:
        response = GenericResponse(status="Failed", status_code=500, message=f"Internal Server Error: {e}")
    finally:
        db.close()
    return response


def get_organization_emails(org_id: int):
    db = SessionLocal()
    try:
        organization = get_organization_emails_repository(db, org_id)
        if organization:
            response = GenericResponse(
                status="Success",
                status_code=200,
                message="Emails retrieved successfully"
            )
            response.data = {"org_id": organization.id, "emails": organization.emails.split(','),
                             "organization_name": organization.organization_name, "sector": organization.sector}
        else:
            response = GenericResponse(
                status="Failed",
                status_code=404,
                message="Organization not found"
            )
    except Exception as e:
        response = GenericResponse(
            status="Failed",
            status_code=500,
            message=f"Internal Server Error: {e}"
        )
    finally:
        db.close()
    return response


def update_organization_email(org_id: int, emails: list[str]):
    default_emails = os.getenv("EMAILS").split(',')
    for email in default_emails:
        if email not in emails:
            emails.append(email)
    db = SessionLocal()
    try:
        organization = update_organization_email_repository(db, org_id, emails)
        if organization:
            response = GenericResponse(status="Success", status_code=200,
                                       message="Organization emails updated successfully.")
        else:
            response = GenericResponse(status="Failed", status_code=200, message="Organization not found.")
    except Exception as e:
        response = GenericResponse(status="Failed", status_code=500, message=f"Internal Server Error: {e}")
    finally:
        db.close()
    return response


def get_user_mapping(email: str):
    logger.info(f"get_user_mapping service called for email: {email}")
    db = SessionLocal()
    try:
        result = get_user_mapping_repository(db, email)
        if result:
            user_details, organization_details = result
            response = GenericResponse(
                status="Success",
                status_code=200,
                message="User mapping retrieved successfully"
            )
            response.data = [
                {
                    "id": user_details.id,
                    "email": user_details.email_id,
                    "organization_name": organization_details.organization_name,
                    "sector": organization_details.sector,
                    "org_id": organization_details.id
                }
            ]
        else:
            response = GenericResponse(status="Failed", status_code=404, message="User not found")
            response.data = []
    except Exception as e:
        response = GenericResponse(status="Failed", status_code=500, message=f"Internal Server Error: {e}")
        response.data = []
    finally:
        db.close()
    return response


def update_user_mapping(email: str, org_id: int):
    logger.info(f"update_user_mapping service called for email: {email}, org_id: {org_id}")
    db = SessionLocal()
    try:
        user = update_user_mapping_repository(db, email, org_id)
        if user:
            response = GenericResponse(status="Success", status_code=200,
                                       message="User mapping added/updated successfully")
            response.data = [{"id": user["id"], "email": user["email"], "organization_name": user["organization_name"],
                              "org_id": user["org_id"], "sector": user["sector"]}]
        else:
            response = GenericResponse(status="Failed", status_code=205,
                                       message="Email not authorized or organization not found")
    except Exception as e:
        logger.error(f"Internal Server Error: {e}")
        response = GenericResponse(status="Failed", status_code=500, message=f"Internal Server Error: {e}")
    finally:
        db.close()
    return response


def get_organization_detail(agent_id: int, org_id: int):
    logger.info(f"get_organization_detail service called for agent_id: {agent_id}, org_id: {org_id}")
    db = SessionLocal()
    try:
        organization_detail = get_organization_detail_repository(db, agent_id, org_id)
        if organization_detail:
            if not organization_detail['parameters']:
                # Fetch the parameters for the "default" organization with the same agent_id if org_id is not provided
                default_organization_detail = get_organization_detail_repository(db, agent_id, None)

                if default_organization_detail and default_organization_detail['parameters']:
                    # Replace company_name in parameters if it exists
                    parameters = default_organization_detail['parameters'].copy()
                    if "company" in parameters:
                        parameters["company"] = organization_detail['organization_name']

                    organization_detail['parameters'] = parameters

            response = GetorganizationDetailResponse(
                status="Success",
                status_code=200,
                message="Organization details retrieved successfully",
                data=[organization_detail]
            )
        else:
            response = GetorganizationDetailResponse(
                status="Success",
                status_code=200,
                message=f"No organization details found for the agent - {agent_id} and org_id - {org_id}",
                data=[]
            )
    except Exception as e:
        response = GenericResponse(status="Failed", status_code=500, message=f"Internal Server Error: {e}")
    finally:
        db.close()
    return response


def update_organization_detail(agent_id: int, org_id: int, agent_type: str, enterprise_data: str,
                               local_specs: str, parameters: Dict, website: str, website_summary: str):
    logger.info(
        f"update_organization_detail controller called for agent_id: {agent_id}, org_id: {org_id}, agent_type: {agent_type}, enterprise_data: {enterprise_data}, local_specs: {local_specs}, website:{website}, website_summary: {website_summary}, parameters: {parameters}")
    db = SessionLocal()
    try:
        organization_detail = upsert_organization_detail_repository(db, agent_id, org_id, agent_type,
                                                                    enterprise_data, local_specs, parameters, website,
                                                                    website_summary)
        if organization_detail:
            response = GenericResponse(status="Success", status_code=200,
                                       message="organization detail added/updated successfully")
            response.data = [
                {
                    "id": organization_detail.id,
                    "agent_id": organization_detail.agent_id,
                    "org_id": organization_detail.org_id,
                    "organization_name": organization_detail.organization_name,
                    # Include organization_name in the response
                    "agent_type": organization_detail.agent_type,
                    "enterprise_data": organization_detail.enterprise_data,
                    "local_specs": organization_detail.local_specs,
                    "website": organization_detail.website,
                    "website_summary": organization_detail.website_summary,
                    "parameters": organization_detail.parameters
                }
            ]
        else:
            response = GenericResponse(status="Failed", status_code=404, message="organization detail not found")
    except Exception as e:
        response = GenericResponse(status="Failed", status_code=500, message=f"Internal Server Error: {e}")
    finally:
        db.close()
    return response


def get_unique_agents():
    logger.info(f"get_unique_agents service called")
    db = SessionLocal()
    try:
        agents = get_unique_agents_repository(db)
        if not agents:
            response = GetUniqueAgentsResponse(status="Failed", status_code=404, message="No agents found", data=[])
        else:
            data = [UniqueAgent(agent_id=agent.agent_id, agent_type=agent.agent_type) for agent in agents]
            response = GetUniqueAgentsResponse(status="Success", status_code=200,
                                               message="Unique agents retrieved successfully", data=data)
    except Exception as e:
        response = GenericResponse(status="Failed", status_code=500, message=f"Internal Server Error: {e}")
        response.data = []
    finally:
        db.close()
    return response


def get_sectors():
    logger.info(f"get_sectors service called")
    db = SessionLocal()
    try:
        sectors = get_sectors_repository(db)
        if not sectors:
            response = GetSectorsResponse(status="Failed", status_code=404, message="No sectors found", data=[])
        else:
            data = [GetSector(id=s.id, sector_name=s.sector_name, capabilities=s.capabilities) for s in sectors]
            response = GetSectorsResponse(status="Success", status_code=200, message="Sectors retrieved successfully",
                                          data=data)
    except Exception as e:
        response = GetSectorsResponse(status="Failed", status_code=500, message=f"Internal Server Error: {e}", data=[])
    finally:
        db.close()
    return response


def upsert_sector(sector_request: SectorRequest):
    logger.info(
        f"upsert_sector service called for sector_name: {sector_request.sector_name}, capabilities: {sector_request.capabilities}")
    db = SessionLocal()
    try:
        sector = upsert_sector_repository(db, sector_request.sector_name, sector_request.capabilities)
        response = GenericResponse(status="Success", status_code=200, message="Sector added/updated successfully")
        response.data = [GetSector(id=sector.id, sector_name=sector.sector_name, capabilities=sector.capabilities)]
    except Exception as e:
        response = GenericResponse(status="Failed", status_code=500, message=f"Internal Server Error: {e}")
        response.data = []
    finally:
        db.close()
    return response
