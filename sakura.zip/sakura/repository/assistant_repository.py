import mimetypes
import os
from datetime import datetime

from fastapi import HTTPException
from fastapi.responses import Response
from sqlalchemy.exc import NoResultFound
from sqlalchemy.exc import SQLAlchemyError

from config.database_config import SessionLocal
from logger.__init__ import get_logger
from models.database_models import Assistant_Configuration, Language

logger = get_logger(__name__)


def get_assistants_by_tenant(tenantId: str):
    db = SessionLocal()
    try:
        logger.info(f"Fetching assistants for tenantId: {tenantId}")

        # Query the Assistant_Configuration table filtering by tenantId
        assistants = db.query(Assistant_Configuration).filter(Assistant_Configuration.tenantId == tenantId).all()

        if assistants:
            logger.info(f"Found {len(assistants)} assistants for tenantId: {tenantId}")
            return assistants
        else:
            logger.warning(f"No assistants found for tenantId: {tenantId}")
            return []

    except Exception as e:
        logger.error(f"Error occurred while fetching assistants for tenantId {tenantId}: {e}", exc_info=True)
        return []
    finally:
        db.close()


def get_assistant_by_id(assistant_id: int):
    """
    Retrieve an assistant entry by its ID.

    :param db: SQLAlchemy session object
    :param assistant_id: The ID of the assistant to retrieve
    :return: The assistant entry if found, otherwise None
    """
    db = SessionLocal()
    try:
        logger.info(f"Fetching assistant with ID: {assistant_id}")

        # Query the database for the entry with the given ID
        assistant = db.query(Assistant_Configuration).filter(Assistant_Configuration.id == assistant_id).one()

        logger.info(f"Assistant found with ID: {assistant_id}")
        return assistant
    except NoResultFound:
        logger.warning(f"No assistant found with ID: {assistant_id}")
        return None
    except Exception as e:
        logger.error(f"An error occurred while fetching assistant with ID {assistant_id}: {e}", exc_info=True)
        return None
    finally:
        db.close()


def get_langs_by_ids(db, ids_string: str):
    try:
        # Convert the input string to a list of integers
        ids_list = [int(id.strip()) for id in ids_string.split(',')]

        # Query the database for voices matching the IDs
        langs = db.query(Language).filter(Language.id.in_(ids_list)).all()

        # Prepare the result dictionary
        result = [{str(lang.id): lang.name} for lang in langs]

        return result

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)
        return []
    finally:
        db.close()


def download_img(assId):
    db = SessionLocal()
    try:
        # Fetch the SubAgentConfiguration entry for the given assistant_id
        assistant = db.query(Assistant_Configuration).filter(Assistant_Configuration.id == assId).first()
        if not assistant or not assistant.assistantImageUrl:
            raise HTTPException(status_code=404, detail="File not found for the provided assistant_id")

        # Define the file path from assistantImageUrl
        file_path = assistant.assistantImageUrl

        # Check if the file exists
        if not os.path.exists(file_path):
            raise HTTPException(status_code=404, detail="File does not exist on the server")

        # Detect the image MIME type
        mime_type, _ = mimetypes.guess_type(file_path)
        if not mime_type:
            mime_type = "application/octet-stream"  # Default in case MIME type is not detected

        # Read the file and send it as a response
        with open(file_path, "rb") as f:
            content = f.read()

        # Return the image as a response with inline content disposition
        return Response(
            content=content,
            media_type=mime_type,
            headers={"Content-Disposition": f"inline; filename={os.path.basename(file_path)}"}
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


def update_assistant_configuration(assistant_id: int, userId: str, name: str = None, assistantLanguage: str = None,
                                   assistantVoice: str = None, assistantInterface: str = None):
    db = SessionLocal()
    try:
        # Retrieve the assistant configuration by id
        assistant = db.query(Assistant_Configuration).filter(Assistant_Configuration.id == assistant_id).first()

        if not assistant:
            raise HTTPException(status_code=404, detail="Assistant not found")

        # Update fields if new values are provided
        if name is not None:
            assistant.assistantName = name
        if assistantLanguage is not None:
            assistant.assistantLanguage = assistantLanguage
        if assistantVoice is not None:
            assistant.assistantVoice = assistantVoice
        if assistantInterface is not None:
            assistant.assistantInterface = assistantInterface

        # Update updatedBy and updatedOn fields
        assistant.updatedBy = userId
        assistant.updatedOn = datetime.utcnow()  # Manually setting updatedOn to current datetime

        # Commit changes to the database
        db.commit()
        db.refresh(assistant)  # Refresh to get the updated values from the database
        return assistant

    except SQLAlchemyError as e:
        db.rollback()  # Roll back in case of an error
        raise HTTPException(status_code=500, detail=f"An error occurred while updating: {str(e)}")

    finally:
        db.close()

# def get_all_voices(db):
#     try:
#         # Query the database to get all voices
#         voices = db.query(Voice).all()

#         # Prepare the result as a list of dictionaries
#         result = [{"id": voice.id, "name": voice.name, "gender": voice.gender, "voiceType": voice.voiceType} for voice in voices]

#         return result

#     except Exception as e:
#         print(f"An error occurred: {e}")
#         return []

# def get_voices_by_ids(db, ids_string: str):
#     try:
#         # Convert the input string to a list of integers
#         ids_list = [int(id.strip()) for id in ids_string.split(',')]

#         # Query the database for voices matching the IDs
#         voices = db.query(Voice).filter(Voice.id.in_(ids_list)).all()

#         # Prepare the result dictionary
#         result = [{str(voice.id): voice.name} for voice in voices]

#         return result

#     except Exception as e:
#         print(f"An error occurred: {e}")
#         return []
