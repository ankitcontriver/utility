from fastapi import APIRouter
from service.country_mapping_service import get_country_list as get_country_list_service
from service.country_mapping_service import get_country_language as get_country_language_service
from logger import get_logger

router = APIRouter()
logger = get_logger(__name__)


@router.get("/get_country_list", tags=["Country Mapping"])
def get_country_list():
    logger.info("get_country_list controller called")
    return get_country_list_service()


@router.get("/get_country/language", tags=["Country Mapping"])
def get_country_language(country: str):
    logger.info("get_country_language controller called")
    return get_country_language_service(country)
