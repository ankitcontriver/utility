from sqlalchemy.orm import Session
from typing import Optional
from models.database_models import WhitelistedDomains


def get_domains(db: Session, domain: str):
    return db.query(WhitelistedDomains).filter(WhitelistedDomains.domain == domain, WhitelistedDomains.status).all()


def add_domain(db: Session, domain: str, name:Optional[str]):
    db.add(WhitelistedDomains(domain=domain, name=name))
    db.commit()


def remove_domain(db: Session, domain: WhitelistedDomains):
    domain.status = 0
    db.commit()
