import os
import time
import traceback

import requests
from dotenv import load_dotenv

from config.database_config import get_db
from logger import get_logger
from models.request_models import DemoFlowRequest
from repository.asr_repository import get_asr_model as get_asr_model_repository, \
    get_asr_language as get_asr_language_repository
from repository.country_repository import get_languages_for_country as get_languages_for_country_repo
from repository.question_repository import get_questionnaire
from repository.tts_repository import get_tts_models_repository, get_voice_list_repository
from response.DemoFlowResponse import DemoFlowParameters, DemoFlowConfigParameters, DemoFlowResponse
from response.GetASRModelResponse import GetASRModel
from response.GetTTSModelResponse import GetTTSModel
from response.QuestionnaireResponse import QuestionnaireResponse, Questionnaire, GenericResponse

load_dotenv()

logger = get_logger(__name__)

ipinfo_token = os.getenv("IPINFO_TOKEN")
demo_flow_llm_model = os.getenv("DEMO_FLOW_LLM_MODEL")
demo_org_name = os.getenv("DEMO_ORG_NAME")
demo_tts = os.getenv("DEMO_TTS")


def get_questionnaire_service(assistant_id):
    db = SessionLocal()
    try:
        logger.info(f"get_questionnaire_service called for: {assistant_id}")
        questionnaire = get_questionnaire(db, assistant_id)
        if questionnaire is None or questionnaire == [] or questionnaire[0].header is None or questionnaire[
            0].questions is None:
            return GenericResponse(status_code=201, status="SUCCESS",
                                   message=f"Questionnaire not found for assistant id: {assistant_id}")
        logger.info(f"questionnaire for assistant_id - {assistant_id}: {questionnaire}")

        data = Questionnaire(header=questionnaire[0].header, questions=questionnaire[0].questions)
        return QuestionnaireResponse(status_code=200, status="SUCCESS", message="Questionnaire fetched successfully",
                                     response=data)
    except Exception as e:
        logger.error(f"Error in get_questionnaire_service: {e}",exc_info=True)
        return GenericResponse(status_code=400, status="FAILURE", message="Internal Server Error")
    finally:
        db.close()


def get_flow_details_service(demo_flow_request: DemoFlowRequest):
    try:
        with get_db() as db:
            logger.info(f"get_flow_details_service called request: {demo_flow_request}")
            ip = demo_flow_request.ip
            country = demo_flow_request.country

            if country is None or country == "NA":
                country = get_country_from_ip(ip)
                logger.info(f"country from ip: {country}")

            #     get language list for the country

            languages = get_languages_for_country_repo(db, country)
            logger.info(f"languages: {languages}")

            if languages is None or len(languages) == 0:
                logger.info("Language List not found")
                return DemoFlowResponse(
                    status_code=200,
                    status="Success",
                    message="No languages available for the given country",
                    data=None
                )

            lang_params = []
            country_name = None
            for language in languages:
                language_id = language.language_id
                language_name = language.language_name
                country_name = language.country_name
                asr_model, asr_language_id = ger_asr_model_from_language_id(db, language_id, country)
                if asr_model is None or asr_language_id is None:
                    continue

                tts_model, voice_id, gender = get_tts_model_from_language_id(db, language_id, country)
                if tts_model is None or voice_id is None or gender is None:
                    continue

                # Create DemoFlowParameters for each language
                lang_param = DemoFlowParameters(
                    language_code=language_id,
                    language_name=language_name,
                    asr_model=asr_model,
                    asr_language_id=asr_language_id,
                    tts_model=tts_model,
                    tts_language_id=language_id,
                    voice_id=voice_id,
                    gender=gender
                )
                lang_params.append(lang_param)

        llm_model = demo_flow_llm_model

        # Create DemoFlowConfigParameters
        demo_flow_config = DemoFlowConfigParameters(
            llm_model=llm_model,
            lang_params=lang_params,
            country_code=country,
            country_name=country_name,
            demo_organisation_name=demo_org_name
        )

        # Create DemoFlowResponse
        demo_flow_response = DemoFlowResponse(
            status_code=200,
            status="Success",
            message="Flow details fetched successfully",
            data=demo_flow_config
        )

        logger.info(f"DemoFlowResponse: {demo_flow_response}")
        return demo_flow_response

    except Exception as e:
        logger.error(f"Error in get_flow_details_service: {e}",exc_info=True)


def ger_asr_model_from_language_id(db, language_id, country):
    asr_models = get_asr_model_repository(db, language_id)
    logger.info(f"asr_models: {asr_models}")
    seen_models = set()
    unique_models = []

    for model in asr_models:
        if model.asr_name not in seen_models:
            seen_models.add(model.asr_name)
            unique_models.append(GetASRModel(
                language_id=model.language_id,
                asr_model=model.asr_name
            ))

    logger.info(f"unique_models: {unique_models}")

    asr_model = None
    if unique_models is None or len(unique_models) == 0:
        logger.info("ASR Model List not found")
        return None, None

    if any(model.asr_model == "Azure" for model in unique_models):
        logger.info("Azure exists in unique_models")
        asr_model = "Azure"
    elif any(model.asr_model == "Google" for model in unique_models):
        logger.info("Google exists in unique_models")
        asr_model = "Google"

    logger.info(f"asr_model: {asr_model}")

    asr_languages = get_asr_language_repository(db, language_id, country, asr_model)
    logger.info(f"asr_languages : {asr_languages}")

    matched_languages = []
    other_languages = []

    # Separate languages into matched and unmatched lists
    for language in asr_languages:
        if language.country_id == country:
            matched_languages.append(language)
        else:
            other_languages.append(language)

    # Combine matched languages followed by unmatched languages
    sorted_languages = matched_languages + other_languages

    country_specific_language_id = None
    if sorted_languages is None or len(sorted_languages) == 0:
        logger.info("ASR Language List not found")
    else:
        logger.info(f"sorted_languages: {sorted_languages}")
        country_specific_language_id = sorted_languages[0].country_specific_language_id

    return asr_model, country_specific_language_id


def get_tts_model_from_language_id(db, language_id, country):
    priority_models = ["Azure", "Eleven-Labs", "Whisper"]
    if demo_tts == "Azure":
        priority_models = ["Azure", "Eleven-Labs", "Whisper"]
    elif demo_tts == "Whisper":
        priority_models = ["Whisper", "Eleven-Labs", "Azure"]
    elif demo_tts == "Eleven-Labs":
        priority_models = ["Eleven-Labs", "Whisper", "Azure"]

    tts_models = get_tts_models_repository(db, language_id)
    logger.info(f"tts_models : {tts_models}")

    seen_models = set()
    unique_models = []

    for model in tts_models:
        if model.tts_model_name not in seen_models:
            seen_models.add(model.tts_model_name)
            unique_models.append(GetTTSModel(
                id=model.id,
                tts_model_name=model.tts_model_name
            ))

    logger.info(f"unique_models: {unique_models}")
    tts_model = None

    if unique_models is None or len(unique_models) == 0:
        logger.info("TTS Model List not found")
        return None, None, None

    # Check if any of the models in priority order exist in unique_models
    for model_name in priority_models:
        if any(model.tts_model_name == model_name for model in unique_models):
            logger.info(f"{model_name} exists in unique_models")
            tts_model = model_name
            break
    else:
        # If none of the priority models exist, fallback to the first model in unique_models
        logger.info("None of the priority models exist in unique_models")
        tts_model = unique_models[0].tts_model_name

    logger.info(f"tts_model: {tts_model}")

    voice_list = get_voice_list_repository(db, language_id, tts_model)

    matched_voices = []
    other_voices = []

    # Separate voices into matched and unmatched lists
    for voice in voice_list:
        if voice.country_id == country:
            matched_voices.append(voice)
        else:
            other_voices.append(voice)

    # Combine matched voices followed by unmatched voices
    sorted_voices = matched_voices + other_voices

    voice_id = None
    gender = None
    if sorted_voices is None or len(sorted_voices) == 0:
        logger.info("Voice List not found")
    else:
        logger.info(f"sorted_voices: {sorted_voices}")
        # Check if any voice has the name "nova"

        if demo_tts == "Whisper":
            # Look for "nova" voice, otherwise fall back to the first voice in the sorted list
            nova_voice = next((voice for voice in sorted_voices if voice.voice_name.lower() == "nova"),
                              sorted_voices[0])
            voice_id = nova_voice.voice_name
            gender = nova_voice.gender
            logger.info(f"Using {'nova' if nova_voice.voice_name.lower() == 'nova' else 'default'} voice: {voice_id}")
        else:
            # Use the first voice in the sorted list for non-Whisper TTS
            voice_id = sorted_voices[0].voice_name
            gender = sorted_voices[0].gender
            logger.info(f"Using default voice: {voice_id}")

    return tts_model, voice_id, gender


def get_country_from_ip(ip):
    try:
        url = f"https://ipinfo.io/{ip}/json?token={ipinfo_token}"
        logger.info(f"get_country_from_ip request url: {url}")
        response = requests.get(url)

        if response.status_code == 200:
            data = response.json()
            logger.info(f"get_country_from_ip: {data}")
            return data.get('country', 'US')
        else:
            return f"Error: {response.status_code}"
    except Exception as e:
        logger.error(f"Error in get_country_from_ip: {e}",exc_info=True)
        return None
