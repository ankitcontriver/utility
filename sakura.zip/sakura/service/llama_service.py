import json
import re
import time
import os
import asyncio

from groq import Groq

from config.assistant_config import assistants
from utils.redis_db_manager import redis_manager
from utils.memory_cache_manager import get_user_call_record, set_user_call_record
from config.tts_config import voice_mappings
from controllers.audio_controller import generate_audio_azure, generate_audio_google
from enums.call_enums import Event
from logger import get_logger
from models.request_models import MessageResponse
from service.language_service import translate_transcript
from utils.chat_utils import send_chat_chunk_callback_socket
from utils.utils import adjust_messages_length
from utils.llm_util import generate_dynamic_message_id
from utils.alarm_utils import send_alarm

logger = get_logger(__name__)
# client = OpenAI()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY"),
)


random_responses = [
    "Sure, just a sec!!",
    "Sure thing, just a sec!",
    "Okay, give me a moment!",
    "Alright, let me check!",
    "Sure, give me a sec!",
    "Sure, hold on a bit!"
]


def check_before_or_after_comma_is_number(s):
    pattern = r'\d[,.]|[,.]\d'
    match = re.search(pattern, s)
    return bool(match)


def remove_emojis(text):
    emoji_pattern = re.compile(
        "["
        "\U0001F600-\U0001F64F"  # emoticons
        "\U0001F300-\U0001F5FF"  # symbols & pictographs
        "\U0001F680-\U0001F6FF"  # transport & map symbols
        "\U0001F700-\U0001F77F"  # alchemical symbols
        "\U0001F780-\U0001F7FF"  # Geometric Shapes Extended
        "\U0001F800-\U0001F8FF"  # Supplemental Arrows-C
        "\U0001F900-\U0001F9FF"  # Supplemental Symbols and Pictographs
        "\U0001FA00-\U0001FA6F"  # Chess Symbols
        "\U0001FA70-\U0001FAFF"  # Symbols and Pictographs Extended-A
        "\U00002702-\U000027B0"  # Dingbats
        "\U000024C2-\U0001F251"
        "]+",
        flags=re.UNICODE
    )

    emojis_present = bool(emoji_pattern.search(text))
    cleaned_text = emoji_pattern.sub(r'', text)
    return cleaned_text, emojis_present


async def convert_chunk_to_transcript_based_on_voice_code(voice_code, chunk, call_id, event_type, tts_style, tts_manager=None, response_id=None):
    logger.info(f"call_id {call_id} tts for chunk - {chunk}")
    transcript_time = time.time()
    voice_code_mapping = voice_mappings.get(voice_code)
    if chunk == "":
        return "", chunk
    if voice_code_mapping is not None:
        voice_code = voice_code
        speech_lang_code = voice_code_mapping["speech_code"]
        provider = voice_code_mapping["provider"]
    else:
        speech_lang_code = "en-IN"
        provider = "azure"
        voice_code = "en-IN-NeerjaNeural"
    language = speech_lang_code.split("-")[0]
    logger.info(f"Sending chunk in en - {chunk}")
    if language in ["pa"]:
        logger.info(f"call_id {call_id} - Language is {language}, Translating")
        translated_text = translate_transcript(chunk, "en", language)
        chunk = translated_text
    logger.info(f"call_id {call_id} - provider - {provider}, speech_lang_code - {speech_lang_code}, voice_code - {voice_code}")
    tts_chunk = chunk
    tts_chunk, emojis_present = remove_emojis(tts_chunk)
    tts_chunk = tts_chunk.replace("&", " and ")
    logger.info(f"call_id {call_id} tts for tts chunk {tts_chunk}, length - {len(tts_chunk)} emojis_present - {emojis_present}")
    if emojis_present and len(tts_chunk) == 1:
        logger.info(f"only Emoji present in chunk, returning")
        return "", chunk
    if event_type == Event.CALL.value:
        if provider == "google":
            gender = voice_code_mapping["gender"]
            base64_transcript = generate_audio_google(message=tts_chunk,
                                               language_code=speech_lang_code,
                                               voice_name=voice_code, gender=gender)
        else:
            base64_transcript = generate_audio_azure(text=tts_chunk, voice_name=voice_code,
                                              lang=speech_lang_code, tts_style=tts_style)
        
        # Convert to WAV file if TTS manager is available
        if tts_manager and response_id:
            try:
                wav_path = await tts_manager.convert_chunk_to_wav(
                    base64_chunk=base64_transcript,
                    call_id=call_id,
                    response_id=response_id
                )
                transcript = wav_path
                logger.info(f"Converted llama TTS chunk to WAV: {wav_path}")
            except Exception as e:
                logger.error(f"Failed to convert llama TTS chunk to WAV: {e}")
                transcript = base64_transcript
        else:
            transcript = base64_transcript
            
        logger.info(f"call_id {call_id} - time taken to transcript------> {(time.time() - transcript_time) * 1000:.2f} ms")
    else:
        transcript = ""

    return transcript, chunk


async def call_llama_stream(model_name: str, req_id: str):
    logger.info(f"call_llama_stream called for {req_id}")
    try:
        user_obj = get_user_call_record(str(req_id))
        if user_obj is None:
            return None
        user_messages = user_obj["llmMessage"]
        call_id = user_obj["callId"]
        event_type = user_obj["eventType"]
        currentMessageId = user_obj["currentMessageId"]
        assistant_id = user_obj["assistantId"]
        tts_style = user_obj["ttsStyle"]
        voice_code = user_obj["voiceCode"]
        chunk_timestamp = time.time()

        assistant_object = assistants.get(assistant_id)
        # model_name = assistants[assistant_id]["model_name"]
        model_name = os.getenv("GROQ_MODEL_NAME")
        logger.info(f"Using Assistant Id - {assistant_object}")
        llama_obj = {
            "model": model_name,
            "messages": user_messages,
            "stream": True
        }

        logger.info(f"Final llama object to be passed ------> {llama_obj}")
        try:
            response = client.chat.completions.create(**llama_obj)
            await send_alarm(alarm_type='Llama_API', remarks="Llama API working fine", status='clear', assistant_id=assistant_id)
        except Exception as e:
            logger.error(f"Exception in call_llama_stream - {e} for req_id - {req_id}",exc_info=True)
            await send_alarm(alarm_type='Llama_API', remarks=str(e), status='raise', assistant_id=assistant_id)
            raise

        continious_string = ""
        complete_string = ""
        count = 1

        for chunk in response:
            user_obj = get_user_call_record(str(req_id))
            if user_obj is None:
                return None
            if user_obj["interrupt"]:
                logger.info("Interrupting!!!")
                user_obj["processing"] = False
                user_obj["listening"] = True
                user_obj["speaking"] = False

                set_user_call_record(str(call_id), user_obj)
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                break
            current_llama_chunk = chunk.choices[0].delta.content
            if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
                if ((current_llama_chunk in [',', '!', ':', '.', '?', '|', '।']) or len(
                        continious_string.split()) >=
                        20):
                    continious_string += chunk.choices[0].delta.content
                    complete_string += chunk.choices[0].delta.content
                    logger.info(f"call_id {call_id} - time taken to generate chunk {continious_string} number {count} ------> {time.time() - chunk_timestamp * 1000:.2f} ms")

                    discarded_string = ""
                    if len(continious_string.split()) >= 4:
                        if current_llama_chunk in [",", "."]:
                            rev_arr = continious_string.split(" ")

                            if check_before_or_after_comma_is_number(rev_arr[-1]):
                                discarded_string = " " + rev_arr[-1]
                                continious_string = ' '.join(rev_arr[0:-1])

                        if current_llama_chunk not in ["।", "?", "!", ":", "-", ",", ".", "।"]:
                            relevant_array = continious_string.split()[0:-1]
                            striped_word = continious_string.split()[-1]
                            current_string = ' '.join(relevant_array)
                            continious_string = current_string
                            discarded_string += striped_word + " "

                        chunk_timestamp = time.time()
                        transcript, current_chunk = await convert_chunk_to_transcript_based_on_voice_code(
                            voice_code,
                            continious_string,
                            call_id, event_type, tts_style)

                        messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                        message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                                                           isEndChunk=False, transcript=transcript,
                                                           messageId=messageId, eventType=event_type)
                        logger.info(f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
                        await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                              data=message_response.dict())
                        continious_string = ""
                        continious_string += discarded_string
                        logger.info(f"call_id {call_id} - Last cont string - {continious_string}")
                        count += 1
                        continue
                    else:
                        logger.info(f"Continuous String length is less - {continious_string}")
                else:
                    continious_string += chunk.choices[0].delta.content
                    complete_string += chunk.choices[0].delta.content
        if continious_string is not None and continious_string != "":
            if user_obj["interrupt"]:
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                return complete_string
            logger.info(f"call_id {call_id} - time taken to generate chunk {continious_string} in ------> {time.time() - chunk_timestamp * 1000:.2f} ms")
            voice_code = user_obj["voiceCode"]
            transcript, current_chunk = await convert_chunk_to_transcript_based_on_voice_code(voice_code,
                                                                                        continious_string,
                                                                                        call_id, event_type, tts_style)
            currentMessageId = user_obj["currentMessageId"]
            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
            message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                                               isEndChunk=False, transcript=transcript, messageId=messageId,
                                               eventType=event_type)
            logger.info(f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
            await send_chat_chunk_callback_socket(sid=user_obj["socketId"], data=message_response.dict())

        elif continious_string == "":
            if user_obj["interrupt"]:
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                return complete_string
            currentMessageId = user_obj["currentMessageId"]
            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
            message_response = MessageResponse(callId=call_id, chunk="",
                                               isEndChunk=True, transcript="", messageId=messageId,
                                               eventType=event_type)
            logger.info(f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
            await send_chat_chunk_callback_socket(sid=user_obj["socketId"], data=message_response.dict())
        return complete_string
    except Exception as e:
        logger.error(f"Exception in call_llama_stream - {e} for req_id - {req_id}",exc_info=True)


async def stream_handler(model_name, req_id):
    try:
        complete_string = await call_llama_stream(model_name=model_name, req_id=req_id)

        logger.info(f"call_id - {req_id} Complete Response String - {complete_string}")
        if complete_string:
            logger.info(f"call_id - {req_id} I get a confirmation that it was a function call")
            assistant_response = {"role": "assistant", "content": complete_string}
            user_call_record = get_user_call_record(str(req_id))
            if user_call_record is None:
                logger.info(f"No active call")
            else:
                event_type = user_call_record["eventType"]
                currentMessageId = user_call_record["currentMessageId"]
                messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                user_call_record["llmMessage"].append(assistant_response)
                adjusted_messages = adjust_messages_length(req_id, user_call_record["llmMessage"])
                user_call_record["llmMessage"] = adjusted_messages
                user_call_record["processing"] = False
                set_user_call_record(req_id, user_call_record)
                if len(user_call_record["userMessage"]) > 0:
                    logger.info(f"Hello")

                message_response = MessageResponse(callId=req_id, chunk="",
                                                   isEndChunk=True, transcript="", messageId=messageId,
                                                   eventType=event_type)
                logger.info(f"call_id {req_id} Sending message response - {message_response.__repr__()}")
                await send_chat_chunk_callback_socket(sid=user_call_record["socketId"], data=message_response.dict())
            return complete_string
    except Exception as e:
        logger.error(f"Exception occurred in stream_handler - {e}",exc_info=True)


# ---------------------------------- Prompt -----------------------------------------

MyPrompt = """
    You are "Eva," a comprehensive knowledge assistant with a female persona. You should always show high empathy 
    toward the person you are talking to. You are always friendly and humorous, serving as both an assistant and a 
    friend to the user.

    **Strict Guidelines for Responses**:

    1. *Do Not Admit You're an AI*: Never admit that you are an AI assistant. If a question feels inappropriate to answer 
       or if you are incapable of answering it, say, "I am sorry. I can't answer that. Please, try asking another question."
       Never say, "I can't access real-time information" or "As per my last update."

    2. *Introduction*: Introduce yourself at the beginning of a conversation with no more than 15 words. Always introduce 
       yourself as 'Eva,' a comprehensive knowledge assistant.

    3. *Response Style*: Keep your responses human-like and brief (within 50 words). Always be cheerful and light-hearted.

    4. *Language*: Reply in the same language in which the question is asked.

    5. *Read-Aloud Friendly*: Your responses will be read aloud, so never include "*," "#," or ":". Also, give responses in
       the form "First, ...", "Second, ...", etc., instead of '1. ...','2. ...', etc.

    6. *Clarifications and Stopping*: Analyze the user's latest statement. If you think it's incomplete, ask the user for more
       clarification. If the user intends to 'STOP' the conversation, reply in '1-2' words ONLY, like "Okay." or "Sure." If the
       user continues asking questions after saying 'STOP,' continue the conversation and answer the query.

"""
