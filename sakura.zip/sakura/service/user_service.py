import base64
import os
import smtplib
import random
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from starlette.templating import Jinja2Templates
from config.database_config import SessionLocal
from response.GenericResponse import GenericResponse
from response.GetMenuResponse import GetMenuResponse
from response.SendLoginCredResponse import SendLoginCredResponse
from response.UidLoginResponse import UidLoginResponse
from repository.user_repository import get_user_by_email, login_user, add_user, delete_user, get_user, logout_user, save_user, get_all_users, get_user_by_id
from repository.url_trace_repository import upsert_url, find_by_url, get_all_urls, get_url_details, get_url_details_by_email
from repository.contact_form_repository import add_contact_form
from response.ContactUsResponse import ContactUsResponse, ContactUsObject
from models.request_models import GetMenuRequest, LoginRequest, SignUpRequest, UidLoginRequest, ContactForm
from response.LoginResponse import LoginResponse
from response.SignUpResponse import SignUpResponse
from response.CheckLoginResponse import CheckLoginResponse
from utils.constants import menu_map
from utils.utils import match_b64
from logger import get_logger
from dotenv import load_dotenv
from datetime import datetime
from models.database_models import User, UrlLoginDetails
from response.GetAllUrlResponse import UrlObject, GetAllUrlResponse, GetUrlResponse
from response.GetAllUserResponse import UserObject, GetAllUserResponse
from service.group_names_service import update_user_mapping

load_dotenv()

logger = get_logger(__name__)

templates = Jinja2Templates(directory="./templates")

server = os.getenv("SMTP_SERVER")
port = os.getenv("SMTP_PORT")
password = os.getenv("SMTP_PASSWORD")
auto_login = os.getenv("AUTO_LOGIN")
create_password = os.getenv("CREATE_PASS")


def get_menu_service(request: GetMenuRequest):
    try:
        logger.info(f"get menu service hit {request.user_type}")
        if request.user_type not in menu_map:
            return GetMenuResponse(status_code=200, status="Success", message="Kya Bhej Raha Bhai?", data=[])
        return GetMenuResponse(status_code=200, status="Success", message="Menus Received Successfully", data=menu_map.get(request.user_type))
    except Exception as e:
        logger.error(f"Error in get menu service: {e}")
        return GetMenuResponse(status_code=400, status="Error while fetching Menus", message=f"Error while fetching Menus : {e}", data=menu_map.get("all"))


def login_service(request: LoginRequest):
    db = SessionLocal()
    try:
        logger.info(f"login service hit {request.email}")
        user = get_user_by_email(db, request.email)
        if user is None:
            return GenericResponse(status_code=404, status="FAILED", message="User Not Found")
        if not user.is_enable:
            return GenericResponse(status_code=404, status="FAILED", message="User Not Enabled")
        if user and match_b64(request.password, user.password):
            logger.info(f"login successful for {request.email}")
            login_user(db, user, request.ip)
            uid = user.email
            logger.info(f"login successful for {uid}")
            response = LoginResponse(status_code=200, status="SUCCESS", message="Login Successful", data=user)
            return response
        logger.info(f"login failed for {request.email}")
        return GenericResponse(status_code=401, status="UNAUTHORIZED", message="Password does not match")
    except Exception as e:
        logger.error(f"Error in login service: {e}")


def sign_up_service(request: SignUpRequest):
    db = SessionLocal()
    try:
        logger.info(f"sign up service hit {request.email}")
        user = get_user_by_email(db, request.email)
        if user is not None:
            logger.info(f"Sign Up failed for email : {request.email}")
            return GenericResponse(status_code=409, status="CONFLICT", message="User Already Exists")
        new_user = add_user(db, request)
        if mail_new_user(new_user):
            logger.info(f"Sign Up Successful for {request.email}. Mail Sent.")
            return SignUpResponse(status_code=200, status="SUCCESS", message="Sign Up Successful", data=new_user.id)

        delete_user(db, new_user)
        return GenericResponse(status_code=400, status="FAILED", message=f"User Sign Up Failed. Please verify the email-id: {request.email} and try again.")
    except Exception as e:
        logger.error(f"Error in sign up service: {e}")


def mail_new_user(new_user: User):
    try:
        subject = "Create Password for Voice Assistant"
        body = create_password
        body = body.replace("$USERID$", base64.b64encode(str(new_user.id).encode('UTF-8')).decode('UTF-8'))
        body = body.replace("$EMAIL$", str(new_user.email))
        template = templates.get_template("signup_template.html")
        rendered_template = template.render(
            Link=body
        )
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = "eva@blackngreen.com"
        msg['To'] = new_user.email
        msg.attach(MIMEText(rendered_template, 'html'))
        logger.info("Email Attempt")
        with smtplib.SMTP(server, 587) as mail_server:
            mail_server.starttls()
            mail_server.login("eva@blackngreen.com", password)
            mail_server.sendmail(msg['From'], msg['To'], msg.as_string())
        logger.info(f"Email sent to {new_user.email} Successfully")
        return True
    except Exception as e:
        logger.error(f"Error in mail_new_user: {e}")
        return False


def check_login_service(user_id: int):
    db = SessionLocal()
    try:
        logger.info(f"check login service hit for user id ~ {user_id}")
        user = get_user(db, user_id)
        if user is None:
            return GenericResponse(status_code=404, status="FAILED", message="User Not Found")

        return CheckLoginResponse(status_code=200, status="SUCCESS", message=f"Check Login Status for User : {user.email}", data=user.is_active)
    except Exception as e:
        logger.error(f"Error in check_login_service: {e}")


def log_out_service(user_id: int):
    db = SessionLocal()
    try:
        logger.info(f"log out service hit for user id ~ {user_id}")
        user = get_user(db, user_id)
        if user is None:
            return GenericResponse(status_code=404, status="FAILED", message="User Not Found")
        logout_user(db, user)
        return GenericResponse(status_code=200, status="SUCCESS", message=f"Log Out Successful for email id ~ {user.email}")
    except Exception as e:
        logger.error(f"Error in log_out_service: {e}")


def upsert_password_service(user_id: int, passwd: str):
    db = SessionLocal()
    try:
        logger.info(f"upsert password service hit for user id ~ {user_id}")
        user = get_user(db, user_id)
        if user:
            user.password = base64.b64encode(passwd.encode('UTF-8')).decode()
            logger.info(f"Upsert Password Successful for user id ~ {user_id}")
            return True
        logger.info(f"Upsert Password Failed for user id ~ {user_id}")
        return False
    except Exception as e:
        logger.error(f"Error in upsert_password_service: {e}")


def uid_login_service(request: UidLoginRequest):
    db = SessionLocal()
    try:
        logger.info(f"uid_login service hit for email_id ~ {request.user_id}")
        # email_id = base64.b64decode(request.user_id).decode('UTF-8')
        user = get_user_by_id(db, request.user_id)
        if user and not user.is_enable:
            logger.info(f"User with key ~ {request.user_id} found to be disabled.")
            return GenericResponse(status_code=404, status="FAILED", message="User is Disabled")
        if user is not None:
            logger.info(f"Login by key successful for user: {user}")
            logged_in_user = login_user(db, user, request.ip)
            return UidLoginResponse(status_code=200, status="SUCCESS", message="User Logged in Successfully", data=logged_in_user.id)
        return GenericResponse(status_code=404, status="FAILED", message="User Not Found")
    except Exception as e:
        logger.error(f"Error in uid_login_service for email ID, {request.user_id} : {e}")
        return GenericResponse(status_code=400, status="Internal Server Error", message=f"Error in Uid Login Service : {e}")


def url_tracer(request: UidLoginRequest):
    db = SessionLocal()
    try:
        logger.info(f"url_tracer hit for email_id ~ {request.user_id}")
        base_url = auto_login
        url = base_url.replace("$USERID$", str(request.user_id))
        now = datetime.now()
        email = base64.b64decode(request.user_id).decode('utf-8')
        old_url = find_by_url(db, url)
        if old_url is not None:
            old_url.count = old_url.count + 1
            old_url.login_track = old_url.login_track + ", " + now.strftime('%Y-%m-%d %H:%M:%S')
        else:
            old_url = UrlLoginDetails()
            old_url.url = url
            old_url.login_track = now.strftime('%Y-%m-%d %H:%M:%S')
            old_url.count = 1
            old_url.email = email
        upsert_url(db, old_url)
    except Exception as e:
        logger.error(f"Error in url_tracer: {e}")


def forgot_password_service(email: str):
    db = SessionLocal()
    try:
        logger.info(f"forgot_password_service hit for email_id ~ {email}")
        user = get_user_by_email(db, email)
        if user is None:
            return GenericResponse(status_code=404, status="FAILED", message="User Not Found")
        mail_user(user)
    except Exception as e:
        logger.error(f"Error in forgot_password_service: {e}")


def mail_user(klutz_user: User):
    try:
        subject = "Update Password for Voice Assistant"
        body = create_password
        body = body.replace("$USERID$", base64.b64encode(str(klutz_user.id).encode('UTF-8')).decode('UTF-8'))
        body = body.replace("$EMAIL$", str(klutz_user.email))
        template = templates.get_template("reset_template.html")
        rendered_template = template.render(
            Link=body
        )
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = "eva@blackngreen.com"
        msg['To'] = klutz_user.email
        msg.attach(MIMEText(rendered_template, 'html'))
        logger.info(f"Forgot Password Email Attempt to email id ~ {User.email}")
        with smtplib.SMTP(server, 587) as mail_server:
            mail_server.starttls()
            mail_server.login("eva@blackngreen.com", password)
            mail_server.sendmail(msg['From'], msg['To'], msg.as_string())
        logger.info(f"Email sent to {klutz_user.email} Successfully")
        return True
    except Exception as e:
        logger.error(f"Error in mail_user: {e}")
        return False


def get_all_url_service():
    db = SessionLocal()
    try:
        logger.info(f"get_all_url_service hit")
        urls = get_all_urls(db)
        resp_data = []
        for url in urls:
            url_obj = UrlObject(id=url.id, url=url.url, login_track=url.login_track, count=url.count, email=url.email)
            resp_data.append(url_obj)
        return GetAllUrlResponse(status_code=200, status="SUCCESS", message="Data Fetched Successfully", data=resp_data)
    except Exception as e:
        logger.error(f"Error in get_all_url_service: {e}")
        return GenericResponse(status_code=400, status="Internal Server Error", message=f"Error in get_all_url_service : {e}")


def get_url_details_service(url: str):
    db = SessionLocal()
    try:
        logger.info(f"get_url_details_service hit")
        data = get_url_details(db, url)
        res_data = UrlObject(id=data.id, url=data.url, login_track=data.login_track, count=data.count, email=data.email)
        return GetUrlResponse(status="SUCCESS", status_code=200, message="Data Fetched Successfully", data=res_data)
    except Exception as e:
        logger.error(f"Error in get_url_details_service: {e}")
        return GenericResponse(status_code=400, status="Internal Server Error", message=f"Error in get_url_details_service : {e}")


def get_url_details_by_email_service(email: str):
    db = SessionLocal()
    try:
        logger.info(f"get_url_details_by_email_service hit")
        data = get_url_details_by_email(db, email)
        res_data = UrlObject(id=data.id, url=data.url, login_track=data.login_track, count=data.count, email=data.email)
        return GetUrlResponse(status="SUCCESS", status_code=200, message="Data Fetched Successfully", data=res_data)
    except Exception as e:
        logger.error(f"Error in get_url_details_by_email_service: {e}")
        return GenericResponse(status_code=400, status="Internal Server Error", message=f"Error in get_url_details_by_email_service : {e}")


def get_all_users_service():
    db = SessionLocal()
    try:
        logger.info(f"get_all_users_service hit")
        users = get_all_users(db)
        data =[]
        for user in users:
            user_object = UserObject(user_id=user.id, email=user.email, name=user.name)
            data.append(user_object)
        return GetAllUserResponse(status_code=200, status="SUCCESS", message="Data Fetched.", data=data)
    except Exception as e:
        logger.error(f"Error in get_all_users_service: {e}")
        return GenericResponse(status_code=400, status="Internal Server Error", message=f"Error in get_all_users_service : {e}")


def contact_service(req: ContactForm):
    db = SessionLocal()
    try:
        logger.info(f"contact_service hit")
        subject = "Contact Us Notification"
        template = templates.get_template("contact.html")
        rendered_template = template.render(
            From= req.email,
            name=req.name,
            c_no=req.phone_number,
            q_type=req.query_type,
            msg=req.message,
        )
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = "eva@blackngreen.com"
        msg['To'] = "eva@blackngreen.com"
        msg.attach(MIMEText(rendered_template, 'html'))
        logger.info(f"Contact Email Attempt to email ~ {req.email} and user id ~ {req.user_id}")
        with smtplib.SMTP(server, 587) as mail_server:
            mail_server.starttls()
            mail_server.login("eva@blackngreen.com", password)
            mail_server.sendmail(msg['From'], msg['To'], msg.as_string())
        data = add_contact_form(db, req)
        logger.info(f"Contact Us added to db at ~ {data.timestamp}")
        response = ContactUsObject(id=data.id, email=data.email, name=data.name, phone=data.phone, message=data.message, query_type=data.query_type, user_id=data.user_id, timestamp=data.timestamp)
        return ContactUsResponse(status_code=200, status="SUCCESS",message="Contact Us Notification Received Successfully",data=response)
    except Exception as e:
        logger.error(f"Error in contact_service: {e}")
        return GenericResponse(status_code=400, status="Internal Server Error", message=f"Error in contact_service : {e}")


def send_login_cred_service(email: str, name: str, language: str, voice: str, demo_flow: str, org: int, is_bng: bool):
    db = SessionLocal()
    try:
        logger.info(f"send_login_cred_service hit for email_id ~ {email}")
        base_url = auto_login
        default_password = "eva@12345"
        encoded_password = base64.b64encode(default_password.encode('UTF-8')).decode('UTF-8')
        user = get_user_by_email(db, email)
        if user is None:
            user = User()
            user.is_bng = is_bng
            user.email = email
            user.name = name
            user.password = encoded_password
            user.language = language
            user.voice = voice
            user.flow = demo_flow
            user.encoded_key = generate_encoded_key()
        else:
            user.language = language
            user.voice = voice
            user.flow = demo_flow
        save_user(db, user)
        link = base_url.replace("$USERID$", user.encoded_key)
        update_user_mapping(email, org)
        return SendLoginCredResponse(status_code=200, status="SUCCESS", message="User Registered Successfully", data=link)
    except Exception as e:
        logger.error(f"Error in send_login_cred_service: {e}")
        # print(f"Error in send_login_cred_service: {e}")


def generate_encoded_key():
    new_key = ""
    db = SessionLocal()
    while True:
        new_key = random_alphanumeric()
        if get_user_by_id(db, new_key) is None:
            break
    return new_key


def random_alphanumeric():
    char_set = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    response = ''.join(random.choice(char_set) for _ in range(5))
    return response
