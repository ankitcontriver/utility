from fastapi import APIRouter, HTTPException
from logger import get_logger
from cache.assistant_configuration_cache import load_cache
from cache.security_properties_cache import load_security_properties_cache
from service.multi_client_config_service import multi_client_manager
from pydantic import BaseModel
from datetime import datetime

router = APIRouter()
logger = get_logger(__name__)

class CacheReloadResponse(BaseModel):
    message: str
    status: str
    timestamp: str
    status_code: int = 200

@router.get("/reload_cache", tags=['Cache Management'])
def reload_cache():
    """
    Reloads both the assistant configuration cache and security properties cache from the database.
    """
    try:
        load_cache()
        logger.info("Assistant configuration cache reloaded successfully")
        load_security_properties_cache()
        logger.info("Security properties cache reloaded successfully")
        
        # Reload multi-client configuration cache
        multi_client_success = multi_client_manager.load_configurations()
        if multi_client_success:
            logger.info("Multi-client configuration cache reloaded successfully")
        else:
            raise HTTPException(status_code=500, detail="Failed to reload multi-client configurations")
        
        return CacheReloadResponse(
            message=" All caches reloaded successfully",
            status="success",
            timestamp=str(datetime.now()),
            status_code=200
        )
        
    except Exception as e:
        # All errors (including database connection failures) are already handled
        # by the cache functions with proper retry logic and alarms
        error_msg = f"Failed to reload caches: {str(e)}"
        logger.error(error_msg, exc_info=True)
        
        raise HTTPException(
            status_code=500, 
            detail="Internal Server Error: Failed to reload caches"
        )
