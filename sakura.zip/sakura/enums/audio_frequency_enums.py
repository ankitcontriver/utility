from enum import Enum


class AudioFrequencyEnum(Enum):
    DEFAULT = 16000
    LOW = 8000
