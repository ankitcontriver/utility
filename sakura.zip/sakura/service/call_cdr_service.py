import traceback

from dotenv import load_dotenv

from config.database_config import get_db
from logger import get_logger
from repository.cdr_table_repository import get_all_cdr_tables, get_cdr_table_by_call_id
from response.GetAllCdrResponse import CdrDetails, GetAllCdrResponse
from response.GetCdrResponse import CallCdrDetails, GetCdrResponse

load_dotenv()

logger = get_logger(__name__)


def get_call_details():
    try:
        with get_db() as db:
            logger.info(f"get_call_details service called")
            all_call_cdrs = get_all_cdr_tables(db)
            logger.debug(f"all_call_cdrs: {all_call_cdrs}")

            if all_call_cdrs is None or len(all_call_cdrs) == 0:
                logger.info("No CDR tables found")
                return GetAllCdrResponse(
                    status_code=200,
                    status="Success",
                    message="No CDRs found",
                    data=[]
                )

            cdr_data = [
                CdrDetails(
                    call_id=call.callId,
                    assistant_id=call.cdr.get("assistant_id"),
                    assistant_name=call.cdr.get("assistant_name"),
                    call_start_time=call.cdr.get("call_start_time"),
                    call_end_time=call.cdr.get("call_end_time"),
                    call_duration=call.cdr.get("call_duration"),
                    call_status=call.cdr.get("call_status"),
                    call_type=call.cdr.get("call_type"),
                    user_id=call.cdr.get("user_id"),
                    question_count=call.cdr.get("question_count"),
                    answer_count=call.cdr.get("answer_count"),
                    tools_used=call.cdr.get("tools_used"),
                    rag_tool_use=call.cdr.get("rag_tool_use"),
                    satisfaction_score=call.cdr.get("satisfaction_score"),
                    sentiment=call.cdr.get("sentiment"),
                    emotions=call.cdr.get("emotions"),
                    intent=call.cdr.get("intent")
                )
                for call in all_call_cdrs
            ]

            return GetAllCdrResponse(
                status_code=200,
                status="Success",
                message="CDRs found",
                data=cdr_data
            )

    except Exception as e:
        logger.error(f"Error in get_call_details service: {e}",exc_info=True)
        return GetAllCdrResponse(
            status_code=500,
            status="Failure",
            message="Internal Server Error",
            data=[]
        )


def get_call_cdr_by_call_id(call_id):
    try:
        with get_db() as db:
            logger.info(f"get_call_cdr_by_call_id service called")
            call_cdr = get_cdr_table_by_call_id(db, call_id)
            logger.info(f"call_cdr: {call_cdr}")

            if call_cdr is None:
                logger.info(f"No CDR found for call_id: {call_id}")
                return GetCdrResponse(
                    status_code=200,
                    status="Success",
                    message="No CDR found",
                    data=None
                )

            call_details = CallCdrDetails(
                call_id=call_cdr.callId,
                assistant_id=call_cdr.cdr.get("assistant_id"),
                assistant_name=call_cdr.cdr.get("assistant_name"),
                call_start_time=call_cdr.cdr.get("call_start_time"),
                call_end_time=call_cdr.cdr.get("call_end_time"),
                call_duration=call_cdr.cdr.get("call_duration"),
                call_status=call_cdr.cdr.get("call_status"),
                call_type=call_cdr.cdr.get("call_type"),
                user_id=call_cdr.cdr.get("user_id"),
                question_count=call_cdr.cdr.get("question_count"),
                answer_count=call_cdr.cdr.get("answer_count"),
                tools_used=call_cdr.cdr.get("tools_used"),
                rag_tool_use=call_cdr.cdr.get("rag_tool_use"),
                satisfaction_score=call_cdr.cdr.get("satisfaction_score"),
                sentiment=call_cdr.cdr.get("sentiment"),
                emotions=call_cdr.cdr.get("emotions"),
                intent=call_cdr.cdr.get("intent"),
                call_messages=call_cdr.callMessage  # Adding call messages directly
            )

            return GetCdrResponse(
                status_code=200,
                status="Success",
                message="CDR found",
                data=call_details
            )

    except Exception as e:
        logger.error(f"Error in get_call_cdr_by_call_id service: {e}",exc_info=True)
        return GetCdrResponse(
            status_code=500,
            status="Failure",
            message="Internal Server Error",
            data=None
        )
