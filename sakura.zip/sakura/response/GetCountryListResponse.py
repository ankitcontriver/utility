from response.GenericResponse import GenericResponse


class GetCountryList:
    def __init__(self, id, country_name, country_code):
        self.id = id
        self.country_name = country_name
        self.country_code = country_code

    def __repr__(self):
        return f"GetCountryList(id={self.id}, country_name={self.country_name}, country_code={self.country_code})"


class GetCountryListResponse(GenericResponse):
    def __init__(self, status_code, status, message, data: list[GetCountryList]):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return f"GetCountryListResponse(status_code={self.status_code}, status={self.status}, message={self.message}, data={self.data})"
