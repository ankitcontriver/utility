import json
import random
import re
import time
import os

import google.generativeai as genai
from openai import OpenAI

from config.assistant_config import assistants
from utils.redis_db_manager import redis_manager
from utils.memory_cache_manager import get_user_call_record, set_user_call_record
from logger import get_logger
from models.request_models import MessageResponse
from service.language_service import translate_transcript
from utils.chat_utils import send_chat_chunk_callback_socket
from utils.function_call_util_functions import execute_function_call
from utils.gemini_tools_utils import gemini_tools
from utils.llm_util import convert_chunk_to_transcript_based_on_voice_code, generate_dynamic_message_id
from utils.utils import adjust_messages_length
from utils.alarm_utils import send_alarm

logger = get_logger(__name__)
client = OpenAI()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))  # API key for testing purpose only

# PERFORMANCE FIX: Use separated Redis database for user records
# Using memory cache for user records instead of Redis

random_responses = [
    "Sure, just a sec!!",
    "Sure thing, just a sec!",
    "Okay, give me a moment!",
    "Alright, let me check!",
    "Sure, give me a sec!",
    "Sure, hold on a bit!"
]


def print_data(data: str, count):
    logger.info(f"print chunk number {count} ----> {data} ")


def check_before_or_after_comma_is_number(s):
    # Use regex to find a digit followed by a comma or a comma followed by a digit
    # pattern = r'\d,|,\d'
    pattern = r'\d[,.]|[,.]\d'
    match = re.search(pattern, s)
    return bool(match)


# same for all
def remove_emojis(text):
    emoji_pattern = re.compile(
        "["
        "\U0001F600-\U0001F64F"  # emoticons
        "\U0001F300-\U0001F5FF"  # symbols & pictographs
        "\U0001F680-\U0001F6FF"  # transport & map symbols
        "\U0001F700-\U0001F77F"  # alchemical symbols
        "\U0001F780-\U0001F7FF"  # Geometric Shapes Extended
        "\U0001F800-\U0001F8FF"  # Supplemental Arrows-C
        "\U0001F900-\U0001F9FF"  # Supplemental Symbols and Pictographs
        "\U0001FA00-\U0001FA6F"  # Chess Symbols
        "\U0001FA70-\U0001FAFF"  # Symbols and Pictographs Extended-A
        "\U00002702-\U000027B0"  # Dingbats
        "\U000024C2-\U0001F251"
        "]+",
        flags=re.UNICODE
    )

    emojis_present = bool(emoji_pattern.search(text))
    cleaned_text = emoji_pattern.sub(r'', text)
    return cleaned_text, emojis_present


async def call_gemini_stream(model_name: str, req_id: str, is_function_call=False):
    logger.info(f"call_gemini_stream called for {req_id}")
    try:
        function_id = ""
        user_obj = get_user_call_record(str(req_id))
        if user_obj is None:
            return None
        user_messages = user_obj["llmMessage"]
        logger.debug(f"User messages saved in redis - {user_messages}")
        call_id = user_obj["callId"]
        event_type = user_obj["eventType"]
        currentMessageId = user_obj["currentMessageId"]
        assistant_id = user_obj["assistantId"]
        tts_style = user_obj["ttsStyle"]
        voice_code = user_obj["voiceCode"]
        provider = user_obj["provider"]
        gender = user_obj["gender"]
        is_translate = user_obj["isTranslate"]
        chunk_timestamp = time.time()

        assistant_object = assistants.get(assistant_id)

        model_name = genai.GenerativeModel(os.getenv("GEMINI_MODEL_NAME"))

        logger.debug(f"Using Assistant Id - {assistant_object}")

        # Transform the role "system" message in user_messages to "model" format
        if user_messages:
            if user_messages[0].get("role") == "system":
                index_to_change = 0
                user_messages[index_to_change] = {
                    "role": "model",
                    "parts": [user_messages[index_to_change]["content"]]
                }

        try:
            if is_function_call:
                if user_messages:
                    if user_messages[1].get("role") == "assistant":
                        user_messages[1] = {
                            "role": "model",
                            "parts": [user_messages[1]["content"]]
                        }
                response = model_name.generate_content(user_messages, stream=True)
                await send_alarm(alarm_type='Gemini_API', remarks="Gemini API working fine", status='clear', assistant_id=assistant_id)
            elif not is_function_call:
                if user_messages:
                    if user_messages[1].get("role") == "assistant":
                        user_messages[1] = {
                            "role": "model",
                            "parts": [user_messages[1]["content"]]
                        }

                logger.debug(f"User message passing to gemini {user_messages}")
                response = model_name.generate_content(user_messages, tools=gemini_tools, stream=True)
                await send_alarm(alarm_type='Gemini_API', remarks="Gemini API working fine", status='clear', assistant_id=assistant_id)
        except Exception as api_exc:
            await send_alarm(alarm_type='Gemini_API', remarks=str(api_exc), status='raise', assistant_id=assistant_id)
            raise

        function_name = None
        function_arguments = ''
        continious_string = ""
        complete_string = ""
        count = 1
        # Process the continuous string# Process the continuous string# Process the continuous string# Process the continuous string
        special_pattern = re.compile(r'\$\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?')

        for chunk in response:
            user_obj = get_user_call_record(str(req_id))
            if user_obj is None:
                return None
            if user_obj["interrupt"]:
                logger.info("Interrupting!!!")
                user_obj["processing"] = False
                user_obj["listening"] = True
                user_obj["speaking"] = False
                set_user_call_record(str(call_id), user_obj)
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                break
            if hasattr(chunk, 'candidates') and chunk.candidates:
                for candidate in chunk.candidates:
                    if hasattr(candidate, 'content') and candidate.content is not None:
                        for part in candidate.content.parts:
                            if hasattr(part, 'function_call') and part.function_call:
                                function_call = part.function_call
                                function_name = function_call.name
                                function_arguments = {key: value for key, value in
                                                      function_call.args.items()} if function_call.args else {}
                                function_id = function_call.id if hasattr(function_call, 'id') else None

                                logger.info(f"Function: name={function_name}, arguments={function_arguments}, id={function_id}")

                            # elif hasattr(part, 'text'):
                            #     current_gpt_chunk = part.text
                            #     if ((current_gpt_chunk in [',', '!', ':', '.', '?', '|', '।']) or len(
                            #             continious_string.split()) >=
                            #             20):
                            #         continious_string += part.text
                            #         complete_string += part.text
                            #         print(
                            #             f"call_id {call_id} - time taken to generate chunk {continious_string} number {count} ------> "
                            #             f"{(time.time() - chunk_timestamp) * 1000:.2f} ms")

                            #         discarded_string = ""
                            #         if len(continious_string.split()) >= 4:
                            #             if current_gpt_chunk in [",", "."]:
                            #                 rev_arr = continious_string.split(" ")

                            #                 if check_before_or_after_comma_is_number(rev_arr[-1]):
                            #                     discarded_string = " " + rev_arr[-1]
                            #                     continious_string = ' '.join(rev_arr[0:-1])

                            #             if current_gpt_chunk not in ["।", "?", "!", ":", "-", ",", ".", "।"]:
                            #                 relevant_array = continious_string.split()[0:-1]
                            #                 striped_word = continious_string.split()[-1]
                            #                 current_string = ' '.join(relevant_array)
                            #                 continious_string = current_string
                            #                 discarded_string += striped_word + " "

                            #             chunk_timestamp = time.time()
                            #             transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(
                            #                 voice_code,
                            #                 continious_string,
                            #                 call_id, event_type, tts_style)

                            #             messageId = currentMessageId.split("_")[0] + "_Avatar"
                            #             message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                            #                                                isEndChunk=False, transcript=transcript,
                            #                                                messageId=messageId, eventType=event_type)
                            #             print(
                            #                 f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
                            #             await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                            #                                                   data=message_response.dict())
                            #             continious_string = ""
                            #             continious_string += discarded_string
                            #             print(f"call_id {call_id} - Last cont string - {continious_string}")
                            #             count += 1
                            #             continue
                            #         else:
                            #             print(f"Continuous String length is less - {continious_string}")
                            #     else:
                            #         continious_string += part.text
                            #         complete_string += part.text

                            elif hasattr(part, 'text'):
                                current_gpt_chunk = part.text
                                continious_string += part.text
                                complete_string += part.text
                                discarded_string = ""
                                logger.debug(
                                    f"call_id {call_id} - time taken to generate chunk {continious_string} number {count} ------> "
                                    f"{(time.time() - chunk_timestamp) * 1000:.2f} ms")
                                # Process the continuous string
                                while True:
                                    if special_pattern.search(continious_string):
                                        # If a special pattern is found, process the entire string in one go
                                        i = len(continious_string)
                                    else:
                                        # Find the index of the first occurrence of specific punctuation marks
                                        i = next((i for i, char in enumerate(continious_string) if
                                                  char in [',', '!', ':', '.', '?', '|', '।']), None)

                                    if i is not None:
                                        temp_continuos_string = continious_string[:i + 1]
                                        discarded_string = continious_string[i + 1:]

                                        # Check if the discarded part starts or ends with a number, if so, keep it intact
                                        if check_before_or_after_comma_is_number(
                                                temp_continuos_string) or check_before_or_after_comma_is_number(
                                            discarded_string):
                                            temp_continuos_string = continious_string  # Keep the entire string
                                            discarded_string = ""

                                        logger.debug(f"temp_continuos_string:-> {temp_continuos_string}")
                                        # print("discarded:", discarded)
                                        transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(
                                            voice_code, temp_continuos_string, call_id, event_type, tts_style, provider,
                                            gender, is_translate)
                                        messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                                        message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                                                                           isEndChunk=False, transcript=transcript,
                                                                           messageId=messageId, eventType=event_type)
                                        logger.info(f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
                                        await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                                              data=message_response.dict())

                                        continious_string = discarded_string
                                    else:
                                        # If no punctuation mark is found (i.e., i is None):
                                        words = continious_string.split()

                                        if len(words) > 20:
                                            # Split the string into chunks if it exceeds 15 words
                                            mid_point = 20
                                            temp_continuos_string = ' '.join(words[:mid_point])
                                            discarded_string = ' '.join(words[mid_point:])

                                            # Process the chunk for TTS
                                            continious_string = discarded_string

                                            transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(
                                                voice_code, temp_continuos_string, call_id, event_type, tts_style,
                                                provider, gender, is_translate)
                                            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                                            message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                                                                               isEndChunk=False, transcript=transcript,
                                                                               messageId=messageId,
                                                                               eventType=event_type)
                                            logger.info(f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
                                            await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                                                  data=message_response.dict())

                                        break  # Exit loop after processing

        if continious_string is not None and continious_string != "":
            if user_obj["interrupt"]:
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                return complete_string, None, None
            logger.debug(f"call_id {call_id} - time taken to generate chunk {continious_string} in ------> "
                  f"{(time.time() - chunk_timestamp) * 1000:.2f} ms")
            voice_code = user_obj["voiceCode"]
            transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(voice_code,
                                                                                        continious_string,
                                                                                        call_id, event_type, tts_style,
                                                                                        provider, gender, is_translate)
            currentMessageId = user_obj["currentMessageId"]
            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
            message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                                               isEndChunk=False, transcript=transcript, messageId=messageId,
                                               eventType=event_type)
            logger.info(f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
            await send_chat_chunk_callback_socket(sid=user_obj["socketId"], data=message_response.dict())

        elif continious_string == "" and function_name is None:
            if user_obj["interrupt"]:
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                return complete_string, None, None
            currentMessageId = user_obj["currentMessageId"]
            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
            message_response = MessageResponse(callId=call_id, chunk="",
                                               isEndChunk=True, transcript="", messageId=messageId,
                                               eventType=event_type)
            logger.info(f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
            await send_chat_chunk_callback_socket(sid=user_obj["socketId"], data=message_response.dict())
        return complete_string, function_name, function_arguments, function_id

    except Exception as e:
        logger.error(f"Exception in call_gemini_stream - {e} for req_id - {req_id}", exc_info=True)


async def gemini_stream_handler(model_name, req_id):
    try:
        complete_string, function_name, function_arguments, function_id = await call_gemini_stream(
            model_name=model_name,
            req_id=req_id,
            is_function_call=False)

        logger.debug(f"call_id - {req_id} Complete Response String - {complete_string}")
        if complete_string:
            logger.info(f"call_id - {req_id} I get a confirmation that it was not a function call")
            # assistant_response = {"role": "assistant", "content": complete_string}
            assistant_response = {"role": "model", "parts": [complete_string]}
            user_call_record = get_user_call_record(str(req_id))
            if user_call_record is None:
                logger.info("No active call")
            else:
                event_type = user_call_record["eventType"]
                currentMessageId = user_call_record["currentMessageId"]
                messageId = generate_dynamic_message_id(currentMessageId, "Avatar")

                # Transform the role "system" message in user_message["llmMessage"] to "model" format
                if user_call_record["llmMessage"]:
                    if user_call_record["llmMessage"][0].get("role") == "system":
                        index_to_change = 0
                        user_call_record["llmMessage"][index_to_change] = {
                            "role": "model",
                            "parts": [user_call_record["llmMessage"][index_to_change]["content"]]
                        }

                user_call_record["llmMessage"].append(assistant_response)
                adjusted_messages = adjust_messages_length(req_id, user_call_record["llmMessage"])
                user_call_record["llmMessage"] = adjusted_messages
                user_call_record["processing"] = False
                set_user_call_record(req_id, user_call_record)
                if len(user_call_record["userMessage"]) > 0:
                    logger.info("Hello")

                if not function_name:
                    message_response = MessageResponse(callId=req_id, chunk="",
                                                       isEndChunk=True, transcript="", messageId=messageId,
                                                       eventType=event_type)
                    logger.info(f"call_id {req_id} - Sending message response - {message_response.__repr__()}")
                    await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                          data=message_response.dict())

        if function_name:
            logger.info(f"call_id - {req_id} Function name is {function_name}")
            user_call_record = get_user_call_record(str(req_id))
            if user_call_record is None:
                return None
            event_type = user_call_record["eventType"]
            tts_style = user_call_record["ttsStyle"]
            voice_code = user_call_record["voiceCode"]
            provider = user_call_record["provider"]
            gender = user_call_record["gender"]
            is_translate = user_call_record["isTranslate"]
            language = voice_code.split("-")[0]
            currentMessageId = user_call_record["currentMessageId"]
            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
            if not complete_string:
                function_calling_chunk = random.choice(random_responses)
                translated_chunk = translate_transcript(function_calling_chunk, "en", language)
                transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(voice_code,
                                                                                            translated_chunk,
                                                                                            req_id,
                                                                                            event_type,
                                                                                            tts_style, provider, gender,
                                                                                            is_translate)
                sending_chunk = current_chunk + " "
                message_response = MessageResponse(callId=req_id, chunk=sending_chunk,
                                                   isEndChunk=False, transcript=transcript,
                                                   messageId=messageId,
                                                   eventType=event_type)
                logger.info(f"call_id {req_id} - Sending message response - {message_response.__repr__()}")
                await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                      data=message_response.dict())
            messages = user_call_record["llmMessage"]

            function_arguments = str(json.dumps(function_arguments))

            function_returns = execute_function_call(function_name=function_name, arguments=function_arguments)
            messages.append({"role": "user", "parts": ["Rewrite this:" + function_returns]})

            adjusted_messages = adjust_messages_length(req_id, messages)
            user_call_record["llmMessage"] = adjusted_messages
            set_user_call_record(req_id, user_call_record)

            regular_response_new, function_name_new, function_arguments_new, function_id_new = await call_gemini_stream(
                model_name=model_name,
                req_id=req_id,
                is_function_call=True)
            if regular_response_new:
                logger.debug(f"call_id - {req_id} regular response --> {regular_response_new}")
                reg_message_obj = {"role": "model", "parts": [complete_string]}
                user_call_record["llmMessage"].append(reg_message_obj)
                message_response = MessageResponse(callId=req_id, chunk="",
                                                   isEndChunk=True, transcript="", messageId=messageId,
                                                   eventType=event_type)
                logger.info(f"call_id {req_id} - Sending message response - {message_response.__repr__()}")
                await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                      data=message_response.dict())
                adjusted_messages = adjust_messages_length(req_id, messages)
                user_call_record["llmMessage"] = adjusted_messages
                set_user_call_record(req_id, user_call_record)
            elif function_name_new:
                logger.debug(f"call_id - {req_id} function call loop kill audio called")
                chunk = "I'm facing some issues. Can you try after some time or try asking your question again?"
                user_call_record = get_user_call_record(str(req_id))
                if user_call_record is None:
                    return None
                event_type = user_call_record["eventType"]
                tts_style = user_call_record["ttsStyle"]
                voice_code = user_call_record["voiceCode"]
                provider = user_call_record["provider"]
                gender = user_call_record["gender"]
                is_translate = user_call_record["isTranslate"]
                transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(voice_code,
                                                                                            chunk,
                                                                                            req_id,
                                                                                            event_type,
                                                                                            tts_style, provider, gender,
                                                                                            is_translate)
                currentMessageId = user_call_record["currentMessageId"]
                messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                sending_chunk = current_chunk + " "
                message_response = MessageResponse(callId=req_id, chunk=sending_chunk,
                                                   isEndChunk=True, transcript=transcript,
                                                   messageId=messageId,
                                                   eventType=event_type)
                logger.info(f"call_id {req_id} - Sending message response - {message_response.__repr__()}")
                await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                      data=message_response.dict())

    except Exception as e:
        logger.error(f"Exception occurred in gemini_stream_handler - {e}", exc_info=True)
