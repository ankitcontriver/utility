from pathlib import Path
import os

# CRITICAL FIX: Apply performance configuration FIRST, before any imports that read env vars
from performance_config import apply_high_performance_config, get_performance_recommendations
perf_config = apply_high_performance_config()

import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import time


from config.database_config import engine
from config.global_database_config import global_engine
from config.access_log_config import setup_access_logger
from controllers import api_v1_router
from service.redis_service import start_event_loop_in_thread
from utils.scalable_async_manager import get_async_manager
from utils.scalable_cdr_manager import force_flush_all_cdr
# CRITICAL: Import sockets module to trigger Redis optimization initialization
import sockets.sockets
from sockets.sockets import sio_app
from cache.assistant_configuration_cache import load_cache
from cache.security_properties_cache import load_security_properties_cache
from service.multi_client_config_service import initialize_multi_client_configuration
from logger import init_logger, get_logger
import threading
import sys
import traceback

# Initialize logger at module level
init_logger()
logger = get_logger(__name__)

# Initialize access logger
access_logger = setup_access_logger()

app = FastAPI(
    title="Sakura API",
    description="Backend API for Sakura backend developed by The Man, The Myth, The Legend - BabbarOP",
    version="0.1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add access logging middleware
@app.middleware("http")
async def access_log_middleware(request: Request, call_next):
    start_time = time.time()
    
    # Process the request
    response = await call_next(request)
    
    # Calculate processing time
    process_time = time.time() - start_time
    
    # Get client IP
    client_ip = request.client.host if request.client else "unknown"
    
    # Create log message in same format as Uvicorn access logs
    log_message = f'{client_ip} - "{request.method} {request.url.path} HTTP/1.1" {response.status_code} - {process_time:.3f}s'
    
    # Log to access.log file
    access_logger.info(log_message)
    
    return response


@app.get("/", tags=["Health Check"])
async def home():
    image_path = "./assets/img.jpeg"

    # Check if the file exists
    if not Path(image_path).is_file():
        raise HTTPException(status_code=404, detail="Image not found")

    # Return the image as a streaming response
    return FileResponse(image_path, media_type="image/jpeg")


app.include_router(api_v1_router)
app.mount("/", app=sio_app)


# generate_opening_msg_for_assistant_tts("1")

# CRITICAL: Force Redis initialization immediately at module level
logger.info("Initializing Redis optimizations...")
try:
    # Force sockets Redis initialization
    from sockets.sockets import initialize_redis_clients
    success = initialize_redis_clients()

    if success:
        logger.info("Redis optimization initialization completed")
    else:
        logger.error("Redis optimization initialization failed")

except Exception as e:
    logger.error(f"Redis initialization failed: {e}", exc_info=True)

@app.on_event("startup")
async def startup_event():
    # Store main event loop reference for thread-safe SocketIO operations
    import asyncio
    from utils.chat_utils import set_main_event_loop

    main_loop = asyncio.get_running_loop()
    set_main_event_loop(main_loop)
    logger.info("Main event loop reference stored for thread-safe SocketIO operations")

    # CRITICAL: Initialize memory cache expiry callbacks for deterministic timing
    try:
        from service.redis_service import initialize_memory_expiry_callbacks
        callback_success = initialize_memory_expiry_callbacks()
        if callback_success:
            logger.info("Memory cache expiry callbacks initialized")
        else:
            logger.error("Memory cache expiry callback initialization failed")
    except Exception as e:
        logger.error(f"MAIN: Memory cache callback initialization error: {e}", exc_info=True)

    # Start Redis subscription in a background thread
    start_event_loop_in_thread()


@app.on_event("shutdown")
def shutdown_event():
    logger.info("Application shutdown")

    # CRITICAL: Shutdown memory cache gracefully
    try:
        from utils.memory_cache_manager import shutdown_memory_cache
        shutdown_memory_cache()
        logger.info("Memory cache shutdown completed")
    except Exception as e:
        logger.error(f"Memory cache shutdown error: {e}", exc_info=True)


def print_thread_breakdown():
    total_threads = threading.active_count()
    thread_types = {}

    for thread in threading.enumerate():
        thread_type = thread.name.split('-')[0] if '-' in thread.name else thread.name
        thread_types[thread_type] = thread_types.get(thread_type, 0) + 1

    logger.info(f"Total threads: {total_threads}")
    for thread_type, count in sorted(thread_types.items()):
        if count > 1:
            logger.info(f"  {thread_type}: {count} threads")
        else:
            logger.info(f"  {thread_type}: {count} thread")




if __name__ == "__main__":
    logger.info("Sakura Application Starting...")

    # Log performance configuration and recommendations
    target_concurrent_calls = 100  # Expected load
    recommendations = get_performance_recommendations(target_concurrent_calls)
    logger.info(f"Performance Configuration: {len(recommendations)} optimizations applied for {target_concurrent_calls} concurrent calls")

    #create_tables()
    #logger.info("Tables created successfully.")
    load_cache()
    load_security_properties_cache()
    
    # Initialize multi-client configuration
    logger.info("Initializing multi-client configuration...")
    multi_client_success = initialize_multi_client_configuration()
    if multi_client_success:
        logger.info("Multi-client configuration initialized successfully")
    else:
        logger.error("Multi-client configuration initialization failed")
        logger.warning("System will operate without multi-client support")

    # Initialize TTS manager for all services
    logger.info("Initializing TTS manager...")
    try:
        from service.pa_tts_manager import get_tts_manager
        tts_manager = get_tts_manager()
        if tts_manager:
            logger.info("TTS manager initialized successfully")
        else:
            logger.error("TTS manager initialization failed")
            logger.warning("System will operate without TTS manager support")
    except Exception as e:
        logger.error(f"TTS manager initialization error: {e}", exc_info=True)
        logger.warning("System will operate without TTS manager support")

    # Initialize 3-tier RAG service for PA calls
    logger.info("Initializing 3-tier RAG service...")
    try:
        from service.pa_three_tier_service import initialize_three_tier_service
        three_tier_success = initialize_three_tier_service()
        if three_tier_success:
            logger.info("3-tier RAG service initialized successfully")
            
            # Log 3-tier service configuration
            three_tier_enabled = os.getenv('THREE_TIER_LLM_ENABLED', 'false').lower() == 'true'
            tier1_threshold = os.getenv('THREE_TIER_TIER1_MIN_CONFIDENCE', '0.95')
            tier2_threshold = os.getenv('THREE_TIER_TIER2_MIN_CONFIDENCE', '0.75')
            vector_db_host = os.getenv('THREE_TIER_VECTOR_DB_HOST', 'localhost')
            vector_db_port = os.getenv('THREE_TIER_VECTOR_DB_PORT', '6333')
            collection_name = os.getenv('THREE_TIER_COLLECTION_NAME', 'pa_responses')
            
            logger.info(f"3-tier RAG Configuration:")
            logger.info(f"   Enabled: {three_tier_enabled}")
            logger.info(f"   Tier 1 Threshold: {tier1_threshold}")
            logger.info(f"   Tier 2 Threshold: {tier2_threshold}")
            logger.info(f"   Vector DB: {vector_db_host}:{vector_db_port}")
            logger.info(f"   Collection: {collection_name}")
        else:
            logger.error("3-tier RAG service initialization failed")
            logger.warning("System will operate without 3-tier RAG support")
    except Exception as e:
        logger.error(f"3-tier RAG service initialization error: {e}", exc_info=True)
        logger.warning("System will operate without 3-tier RAG support")

    # Initialize async loop manager for Redis operations with new config
    async_manager = get_async_manager()
    async_manager.start()
    logger.info("AsyncIO loop manager initialized with enhanced configuration")

    # Added logging for verification
    import os
    logger.info(f" Verified Configuration:")
    logger.info(f"   ASYNC_NUM_LOOPS: {os.getenv('ASYNC_NUM_LOOPS')}")
    logger.info(f"   ASYNC_MAX_WORKERS_PER_LOOP: {os.getenv('ASYNC_MAX_WORKERS_PER_LOOP')}")
    logger.info(f"   Runtime loops: {async_manager.num_loops}")
    logger.info(f"   Runtime workers per loop: {async_manager.max_workers_per_loop}")
    logger.info(f"   Total AsyncLoop workers: {async_manager.num_loops * async_manager.max_workers_per_loop}")

    print_thread_breakdown()
    
    # Register cleanup on shutdown
    import atexit
    atexit.register(force_flush_all_cdr)
    atexit.register(async_manager.shutdown)
    
    logger.info("Sakura is ready to handle high-concurrency loads!")

    # Mark startup complete for connection logging optimization
    try:
        from sockets.sockets import mark_startup_complete
        mark_startup_complete()
    except Exception as e:
        logger.warning(f"Could not mark startup complete: {e}")

    uvicorn.run("main:app", reload=False, port=8400, host="0.0.0.0")