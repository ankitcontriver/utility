import redis
import socketio
import threading
from logger import get_logger

# Logger setup
logger = get_logger(__name__)

# Redis client and lock
_redis_client = None
_redis_lock = threading.Lock()
sio = None

def create_socketio_app():
    try:
        global sio
        if sio is None:
            sio = socketio.AsyncServer(async_mode="asgi", cors_allowed_origins=[])
        return sio
    except Exception as e:
        logger.error(f"Error while getting socket client in config.py, create_socketio_app() : {e}", exc_info=True)
        raise RuntimeError("Error while getting socket client")

def get_redis_client():
    try:
        global _redis_client
        with _redis_lock:
            if _redis_client is None:
                logger.info("Initializing optimized Redis client on db=2")
                _redis_client = redis.Redis(
                    host="localhost", 
                    port=6379, 
                    db=2, 
                    decode_responses=True,
                    # PERFORMANCE FIX: Scaled connection pooling for 200+ workers
                    connection_pool=redis.ConnectionPool(
                        host="localhost",
                        port=6379,
                        db=2,
                        decode_responses=True,
                        max_connections=300,  # Scaled up for 200+ AsyncLoop workers
                        retry_on_timeout=True,
                        retry_on_error=[redis.exceptions.ConnectionError, redis.exceptions.TimeoutError],
                        socket_keepalive=True,
                        socket_keepalive_options={},
                        socket_connect_timeout=5,  # Faster connection timeout
                        socket_timeout=10,         # Faster socket timeout  
                        health_check_interval=60   # Less frequent health checks
                    )
                )
                # Test the connection
                _redis_client.ping()
                logger.info("Redis client initialized with SCALED connection pooling (300 connections)")
            return _redis_client
    except Exception as e:
        logger.error(f"Error while getting redis client in config.py, get_redis_client(): {e}", exc_info=True)
        raise RuntimeError("Error while getting redis client")

def get_redis_pipeline():
    """Get Redis pipeline for batched operations - reduces round trips"""
    try:
        redis_client = get_redis_client()
        return redis_client.pipeline()
    except Exception as e:
        logger.error(f"Error creating Redis pipeline: {e}", exc_info=True)
        raise RuntimeError("Error creating Redis pipeline")


