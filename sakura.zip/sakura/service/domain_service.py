import os
import shutil
import subprocess
from config.database_config import SessionLocal
from logger import get_logger
from repository.domain_repository import get_domains, add_domain, remove_domain
from repository.tts_repository import get_voice_by_name
from response.GenericResponse import GenericResponse
from models.request_models import AudioRequest, SingleAudioRequest
from utils.utils import text_to_speech_azure
from fastapi.responses import FileResponse

logger = get_logger(__name__)


def check_domain_service(domain):
    logger.info(f"Check Domain Service called for {domain}")
    db = SessionLocal()
    response = None
    try:
        domains = get_domains(db, domain)
        if domains is None or len(domains) == 0:
            response = GenericResponse(status_code =201, status="Domain Not Found", message="Domain is not Whitelisted")
        else:
            response = GenericResponse(status_code=200, status="Success", message="Domain is Whitelisted")

    except Exception as e:
        logger.error(f"Error while checking Domain Service for {domain} : {e}")
        response = GenericResponse(status_code=400, status="Internal Server Error", message=f"Error while checking Domain: {e}")
    finally:
        db.close()
    return response


def add_domain_service(domain, name=None):
    db = SessionLocal()
    logger.info(f"Add Domain Service called for {domain}")
    response = None
    try:
        add_domain(db, domain, name)
        response = GenericResponse(status_code=200, status="Success", message="Domain Successfully Whitelisted")
    except Exception as e:
        logger.error(f"Error while adding Domain {domain} : {e}")
        response = GenericResponse(status_code=400, status="Internal Server Error", message=f"Error while adding Domain: {e}")
    finally:
        db.close()
    return response


def remove_domain_service(domain):
    db = SessionLocal()
    logger.info(f"Remove Domain Service called for {domain}")
    response = None
    try:
        domains = get_domains(db, domain)
        if domains is None or len(domains) == 0:
            logger.info(f"Domain Not Found")
        else:
            for domain in domains:
                remove_domain(db, domain)
            response = GenericResponse(status_code=200, status="Success", message="Domain Successfully Blacklisted")
    except Exception as e:
        logger.error(f"Error while removing Domain {domain} : {e}")
        response = GenericResponse(status_code=400, status="Internal Server Error", message=f"Error while Blacklisting Domain: {e}")
    finally:
        db.close()
    return response


def get_audio_zip_service(request: AudioRequest):
    db = SessionLocal()
    try:

        logger.info(f"Voice fetched: {get_voice_by_name(db, request.voice_name)}, for parameter: {request.voice_name}")
        voice = get_voice_by_name(db, request.voice_name)

        if len(voice) == 0:
            raise ValueError(f"No Such Voice Found: {request.voice_name}")
        voice_code = voice[0][0]

        if request.name is None or request.name.strip() == "":
            raise ValueError("Name cannot be empty or null")
        directory = f"./audio_zips/{request.name}"
        os.makedirs(directory, exist_ok=True)
        for category, prompt in request.audio_map.items():
            if category is None or category.strip() == "":
                raise ValueError("Key cannot be empty or null")
            filename = os.path.join(directory, f"{request.name.split('_')[0]}_{category}.wav")
            text_to_speech_azure(prompt, filename, "excited", voice_code)

        converted_directory = f"{directory}_Converted"
        os.makedirs(converted_directory, exist_ok=True)
        for file in os.listdir(directory):
            if file.endswith(".wav"):
                input_ = os.path.join(directory, file)
                output_ = os.path.join(converted_directory, file)
                command = [
                    'ffmpeg',
                    '-i', input_,
                    '-ar', f'{request.frequency}',
                    '-ac', '1',
                    '-acodec', 'pcm_s16le',
                    output_
                ]
                subprocess.run(command)
        shutil.make_archive(f"{request.name}_Converted", "zip", converted_directory)
        return FileResponse(f"{request.name}_Converted.zip", media_type="application/x-zip-compressed", filename=f"{request.name}_Converted.zip")
    except ValueError as ex:
        logger.error(f"Validation Error [NOT MY FAULT] : {ex}")
        return GenericResponse(status_code=400, status="Validation Error", message=f"Validation Error : {ex}")
    except Exception as e:
        logger.error(f"Error while converting audio file in get_audio_zip: {e}")
        return GenericResponse(status_code=500, status="Internal Server Error", message=f"Error while converting audio file in get_audio_zip: {e}")


def get_singular_audio_service(request: SingleAudioRequest):
    try:
        text_to_speech_azure(request.text, os.path.join("./audio_zips", f"{request.name}.wav"), "excited", request.voice_code)
        subprocess.run([
            'ffmpeg',
            '-i', os.path.join("./audio_zips", f"{request.name}.wav"),
            '-ar', f'{request.frequency}',
            '-ac', '1',
            '-acodec', 'pcm_s16le',
            os.path.join("./audio_zips", f"{request.name}_Converted.wav")
        ])
        return FileResponse(os.path.join("./audio_zips", f"{request.name}_Converted.wav"), media_type="audio/wav", filename=os.path.join("./audio_zips", f"{request.name}_Converted.wav"))
    except Exception as e:
        logger.error(f"Error while getting audio file in get_singular_audio_service: {e}")
        return GenericResponse(status_code=400, status="Error while generating audio", message=f"Error while getting audio file in get_singular_audio_service: {e}")
