import asyncio
import json
import re
import threading
import time
import traceback
from queue import Queue
from dotenv import load_dotenv

from openai import OpenAI
from openai.lib.streaming.chat import ChunkEvent
from pydantic import BaseModel, Field

from utils.redis_db_manager import redis_manager
from logger import get_logger
from models.request_models import MessageResponse, ViniEventResponse
from utils.chat_utils import send_chat_chunk_callback_socket
from utils.llm_util import tts_and_send_response, generate_dynamic_message_id
from utils.utils import adjust_messages_length, get_current_time_with_milliseconds
from utils.thread_pool import get_named_thread_pool

client = OpenAI()


logger = get_logger(__name__)

chunk_queue = Queue()
response_queue = Queue()
queue_processing_thread_started = False
last_chunk_received = False
queue_lock = threading.Lock()

END_OF_CHUNKS = "END_OF_CHUNKS"


def start_queue_processing_thread():
    global queue_processing_thread_started
    with queue_lock:
        if not queue_processing_thread_started:
            queue_processing_thread_started = True
            openai_executor = get_named_thread_pool(pool_name='openai_workers', max_workers=10)
            openai_executor.submit(process_chunk_queue)


def check_before_or_after_comma_is_number(s):
    try:
        pattern = r'\d[,.]|[,.]\d'
        match = re.search(pattern, s)
        return bool(match)
    except Exception as e:
        logger.error(f"Error in check_before_or_after_comma_is_number: {e}")
        return False


class ViniReply(BaseModel):
    r: str = Field(..., description="Response from Vini")
    p: str = Field(..., description="Page to navigate to")


async def call_vini(call_id):
    global last_chunk_received
    try:
        logger.info("Calling Vini")
        if redis_client.get(call_id) is None:
            return None
        user_obj = json.loads(redis_client.get(call_id))
        user_messages = user_obj["llmMessage"]
        start_time = time.time()
        complete_response = ""
        chunk_response = ""
        complete_response_chunk = ""
        response_completed = False
        page_navigate = False
        remaining_response = ""
        prev_json = ""
        event_type = user_obj["eventType"]
        currentMessageId = user_obj["currentMessageId"]
        tts_style = user_obj["ttsStyle"]
        voice_code = user_obj["voiceCode"]
        is_translate = user_obj["isTranslate"]
        provider = user_obj["provider"]
        gender = user_obj["gender"]
        socket_id = user_obj["socketId"]
        chunk_count = 0
        logger.info(f"User Messages for call_id - {call_id}: {user_messages}")
        logger.info(f"Calling llm for call_id - {call_id}: on time {get_current_time_with_milliseconds()}")
        with client.beta.chat.completions.stream(
                model="gpt-4o-2024-08-06",
                messages=user_messages,
                response_format=ViniReply, stream_options={"include_usage": True}, logprobs=None, top_p=0.001
        ) as stream:

            for chunk in stream:
                # logger.info(f"Raw Chunk for call_id - {call_id}: {chunk}")
                logger.info(f"Received Chunk for call_id - {call_id}: on time {get_current_time_with_milliseconds()}")
                if isinstance(chunk, ChunkEvent):

                    if not chunk:
                        logger.error("Received empty chunk. Skipping...")
                        continue

                    if not chunk.chunk or not chunk.chunk.choices:
                        logger.error("Chunk or choices not found. Skipping...")
                        continue

                    if chunk.type == 'chunk':

                        try:
                            chunk_dict = chunk.to_dict()

                            if 'snapshot' not in chunk_dict:
                                logger.error("Snapshot key not found in chunk. Chunk data: %s", chunk_dict)
                                continue

                            latest_snapshot = chunk_dict['snapshot']

                            if 'choices' not in latest_snapshot or not latest_snapshot['choices']:
                                logger.warning("No choices found in the snapshot. Skipping...")
                                continue

                            # latest_parsed = latest_snapshot['choices'][0]['message'].get('parsed', {})
                            latest_json = latest_snapshot['choices'][0]['message']['content']
                            latest_parsed = latest_snapshot['choices'][0]['message'].get('parsed', {})
                        except KeyError as e:
                            logger.error(f"KeyError encountered while processing the chunk: {e}")
                            logger.error(f"Chunk data: {chunk_dict}")
                            continue  # Skip this chunk if it is malformed

                        # Check for new keys in the parsed JSON
                        new_part = latest_json[len(prev_json):]
                        prev_json = latest_json

                        if 'r' in latest_parsed:
                            response_completed = True
                            if remaining_response:
                                chunk_queue.put((voice_code, remaining_response, call_id, event_type, tts_style,
                                                 provider, gender, is_translate, currentMessageId, socket_id))
                                remaining_response = ""
                                start_queue_processing_thread()

                        if '"r":"' in latest_json and not response_completed:
                            if new_part == '":"':
                                continue
                            chunk_response += new_part
                            complete_response += new_part
                            chunk_send_to_client, remaining_text = process_chunk(chunk_response, chunk_count)
                            remaining_response = remaining_text
                            if chunk_send_to_client:
                                # Offload TTS and response sending to a new thread
                                chunk_queue.put((voice_code, chunk_send_to_client, call_id, event_type, tts_style,
                                                 provider, gender, is_translate, currentMessageId, socket_id))
                                chunk_response = remaining_text
                                remaining_response = ""
                                chunk_count += 1
                                complete_response_chunk += chunk_send_to_client
                                start_queue_processing_thread()

                        # Handling 'p' key in the parsed JSON if it exists
                        if 'p' in latest_parsed and not page_navigate:
                            new_value = latest_parsed['p']
                            navigate_chunk = f"Navigate to Page: {new_value}"
                            logger.info(f"Navigate Chunk: {navigate_chunk}")
                            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                            message_response = ViniEventResponse(callId=call_id, messageId=messageId,
                                                                 eventType=event_type, pageToNavigate=new_value)
                            logger.info(f"{call_id} Sending message response -> {message_response.__repr__()}")
                            await send_chat_chunk_callback_socket(sid=socket_id, data=message_response.dict(),
                                                                  event='navigate')
                            page_navigate = True

        logger.info(f"Complete Response: {complete_response}")
        chunk_queue.put((voice_code, END_OF_CHUNKS, call_id, event_type, tts_style,
                         provider, gender, is_translate, currentMessageId, socket_id))
        start_queue_processing_thread()
        # message_response = MessageResponse(callId=call_id, chunk="",
        #                                    isEndChunk=True, transcript="", messageId=messageId,
        #                                    eventType=event_type)
        # logger.info(f"{call_id} Sending message response -> {message_response.__repr__()}")
        # await send_chat_chunk_callback_socket(sid=user_obj["socketId"], data=message_response.dict())
        assistant_response = {"role": "assistant", "content": complete_response_chunk}
        user_obj["llmMessage"].append(assistant_response)
        adjusted_messages = adjust_messages_length(call_id, user_obj["llmMessage"], 6)
        user_obj["llmMessage"] = adjusted_messages
        user_obj["processing"] = False
        redis_client.set(call_id, json.dumps(user_obj))
    except Exception as e:
        logger.error(f"Exception in call_vini - {e}",exc_info=True)
        if redis_client.get(call_id) is None:
            return None
        user_obj = json.loads(redis_client.get(call_id))
        user_obj["processing"] = False
        user_obj["listening"] = True
        user_obj["speaking"] = False
        adjusted_messages = adjust_messages_length(call_id, user_obj["llmMessage"], 6)
        user_obj["llmMessage"] = adjusted_messages
        redis_client.set(call_id, json.dumps(user_obj))


def process_chunk(text, chunk_count):
    # Define the punctuation sets based on the chunk count
    # print(f"Text: {text}")
    punctuation_first_two = [',', '!', ':', '.', '?', '|', '।', '፧', '፨']
    punctuation_after_two = ['.', '?', '।', '፧', '፨']

    # Select the appropriate punctuation set
    punctuation_set = punctuation_first_two if chunk_count < 2 else punctuation_after_two

    # Check for the first punctuation in the text
    for punct in punctuation_set:
        if punct in text:
            # Split the text on the first punctuation found
            index = text.find(punct)
            if check_before_or_after_comma_is_number(text[index - 1:index + 2]):
                continue
            parts = text.split(punct, 1)
            response = parts[0] + punct  # Include the punctuation in the response
            remaining_text = parts[1].strip() if len(parts) > 1 else ''
            return response, remaining_text

    # If no punctuation is found, return the entire text and an empty remaining text
    return '', text


def process_chunk_queue():
    logger.info(f"Processing chunk queue started at {get_current_time_with_milliseconds()}")
    global last_chunk_received, queue_processing_thread_started
    while True:
        try:
            # Get the next chunk details from the queue
            chunk_details = chunk_queue.get()
            if chunk_details is None:
                continue

            voice_code, chunk, call_id, event_type, tts_style, provider, gender, is_translate, currentMessageId, socket_id = chunk_details

            logger.info(f"Processing chunk for call_id - {call_id}: {chunk}")

            if chunk == END_OF_CHUNKS:
                logger.info(f"Received END_OF_CHUNKS. Stopping the queue processing thread.")
                last_chunk_received = True
                message_response = MessageResponse(callId=call_id, chunk="",
                                                   isEndChunk=True, transcript="",
                                                   messageId=generate_dynamic_message_id(currentMessageId, "Avatar"),
                                                   eventType=event_type)
                logger.info(f"{call_id} Sending message response -> {message_response.__repr__()}")
                asyncio.run(send_chat_chunk_callback_socket(sid=socket_id, data=message_response.dict()))
                with queue_lock:
                    queue_processing_thread_started = False
                return

            # Process the chunk using TTS and send response
            tts_and_send_response(voice_code, chunk, call_id, event_type, tts_style, provider, gender, is_translate,
                                  currentMessageId, socket_id)

        except Exception as e:
            logger.error(f"Exception while processing chunk queue: {e}",exc_info=True)


def get_structured_output(user_prompt: str, system_prompt: str, session_id):
    # ... existing code ...
    # Start the background thread for processing the queue
    executor = get_named_thread_pool(pool_name='openai_workers', max_workers=10)
    executor.submit(process_chunk_queue)
    try:
        loop = asyncio.get_running_loop()
        # If we're in an async context, use to_thread
        return asyncio.run_coroutine_threadsafe(asyncio.to_thread(response_queue.get), loop).result()
    except RuntimeError:
        # Not in an async context, safe to block
        return response_queue.get()
