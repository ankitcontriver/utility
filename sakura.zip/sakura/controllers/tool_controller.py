from fastapi import APIRouter, HTTPException, Query
from service.toolService import get_tools_by_assId_service,update_tool_status_service, update_tool_description_service
from response.ShowToolResponse import ToolListResponse, UpdateToolResponse, UpdateToolDescriptionResponse
from logger.__init__ import get_logger
import traceback
logger = get_logger(__name__)

router = APIRouter()


@router.get("/assistant/tools/view",  tags=['Tools'])
def get_tools_by_ass(tenantId: str = Query(..., min_length=1)):
    """
    Retrieves tools for a specific tenantId. 
    Ensures tenantId is provided and not empty.
    """
    if not tenantId.strip():
        raise HTTPException(status_code=400, detail="tenantId is required and cannot be empty.")
        
    logger.info(f"Received request to view tools for tenantId: {tenantId}")
    try:
        result = get_tools_by_assId_service(tenantId)
        logger.info(f"Successfully retrieved tools for tenantId: {tenantId}")
        return result
    except Exception as e:
        logger.error(f"Error fetching tools for tenantId: {tenantId}. Error : {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.patch("/tools/changeStatus", tags=['Tools'])
def update_tool_status(
    tenantId: str = Query(..., min_length=1),
    toolId: str = Query(..., min_length=1),
    userId: str = Query(..., min_length=1)
):
    """
    Changes the status of a tool based on tenantId, toolId, and userId.
    Ensures all parameters are provided and not empty.
    """
    if not (tenantId.strip() and toolId.strip() and userId.strip()):
        raise HTTPException(status_code=400, detail="tenantId, toolId, and userId are all required and cannot be empty.")

    logger.info(f"Received request to change status of toolId: {toolId} by userId: {userId} for tenantId: {tenantId}")
    try:
        result = update_tool_status_service(tenantId, toolId, userId)
        logger.info(f"Successfully changed status of toolId: {toolId} by userId: {userId} for tenantId: {tenantId}")
        return result
    except Exception as e:
        logger.error(f"Error changing status of toolId: {toolId} by userId: {userId} for tenantId: {tenantId}. Error : {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.patch("/tools/edit", tags=['Tools'])
def update_tool_description(
    tenantId: str = Query(..., min_length=1),
    toolId: str = Query(..., min_length=1),
    description: str = Query(..., min_length=1),
    userId: str = Query(..., min_length=1)
):
    """
    Updates the description of a tool based on tenantId, toolId, description, and userId.
    Ensures all parameters are provided and not empty.
    """
    if not (tenantId.strip() and toolId.strip() and description.strip() and userId.strip()):
        raise HTTPException(status_code=400, detail="tenantId, toolId, description, and userId are all required and cannot be empty.")
    
    logger.info(f"Received request to update description of toolId: {toolId} by userId: {userId} for tenantId: {tenantId}")
    try:
        result = update_tool_description_service(tenantId, toolId, description, userId)
        logger.info(f"Successfully updated description of toolId: {toolId} by userId: {userId} for tenantId: {tenantId}")
        return result
    except Exception as e:
        logger.error(f"Error updating description of toolId: {toolId} by userId: {userId} for tenantId: {tenantId}. Error : {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


