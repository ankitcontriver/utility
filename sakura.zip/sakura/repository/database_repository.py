from typing import List

from sqlalchemy.orm import Session

from models.database_models import Country, Language, ASRModel, TTSModel


def get_all_countries(db: Session):
    """Retrieve all countries from the database."""
    return db.query(Country).all()


def get_languages_by_country(db: Session, country_id=None):
    """Retrieve all languages for a specific country or all languages if no country is specified."""
    if country_id:
        return db.query(Language).filter(Language.country_id == country_id).all()
    else:
        return db.query(Language).all()


def get_asr_models_by_language_ids(db: Session, language_ids: List[int]):
    """Retrieve all ASR models for the specified language IDs."""
    if not isinstance(language_ids, list):
        language_ids = [language_ids]  # Ensure it's always a list
    return db.query(ASRModel).filter(ASRModel.language_id.in_(language_ids)).all()


def get_tts_models_by_language_id(db: Session, language_id):
    """Retrieve all TTS models for a specific language."""
    return db.query(TTSModel).filter(TTSModel.language_id == language_id).all()
