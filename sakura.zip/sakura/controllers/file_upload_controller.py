from fastapi import APIRouter, HTTPException, UploadFile, File
import os
from logger import get_logger
import shutil
from service.file_upload_service import upload_doc_service
import asyncio

logger = get_logger(__name__)

router = APIRouter()

# @router.patch("/upload_file",tags=["File Upload"])
# def upload_file(assistantId: int, file: UploadFile = File(...)):
    
#     TEMP_DIR = "workflow_docs"

# # Create temp directory if it doesn't exist
#     os.makedirs(TEMP_DIR, exist_ok=True)
#     # Check if the file is provided
#     if not file:
#         raise HTTPException(status_code=400, detail="No file uploaded")

#     # Generate a unique file path
#     file_path = os.path.join(TEMP_DIR, file.filename)
    
#     # Save the file to the temp directory
#     with open(file_path, "wb") as buffer:
#         shutil.copyfileobj(file.file, buffer)
        
#     return upload_doc_service(assistantId, file_path)

@router.patch("/upload_file", tags=["File Upload"])
def upload_file(assistantId: int, file: UploadFile = File(...)):
    TEMP_DIR = "workflow_docs"

    # Create temp directory if it doesn't exist
    os.makedirs(TEMP_DIR, exist_ok=True)

    # Check if the file is provided
    if not file:
        logger.error("No file uploaded")
        raise HTTPException(status_code=400, detail="No file uploaded")

    # Generate a unique file path
    file_path = os.path.join(TEMP_DIR, file.filename)

    # Save the file to the temp directory
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    try:
        logger.info(f"File {file.filename} uploaded successfully for assistantId = {assistantId}")

        # Call the service to process the uploaded document
        response = upload_doc_service(assistantId, file_path)

        # Check if the response indicates success
        if response.status == "success":
            return response
        else:
            raise HTTPException(status_code=response.status_code, detail=response.message)

    except Exception as e:
        logger.error(f"An error occurred while uploading the file: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

    finally:
        # Optionally, clean up the file after processing
        if os.path.exists(file_path):
            os.remove(file_path)  # Remove the file if you want to delete it after processing