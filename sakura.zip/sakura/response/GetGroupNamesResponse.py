from datetime import datetime
from typing import List, Optional

from response.GenericResponse import GenericResponse


class GetOrganizationName:
    def __init__(self, org_id: int, name: str, sector: str, emails: list):
        self.org_id = org_id
        self.name = name
        self.sector = sector
        self.emails = emails

    def __repr__(self):
        return f"org_id: {self.org_id}, name: {self.name}, sector: {self.sector}"


class GetOrganizationNamesResponse(GenericResponse):
    def __init__(self, status: str, status_code: int, message: str, data: list[GetOrganizationName]):
        super().__init__(status_code, status, message, data)

    def __repr__(self):
        return f"status: {self.status}, status_code: {self.status_code}, message: {self.message}, data: {self.data}"


class UserDetail:
    def __init__(self, id: int, email: str, organization_name: str, createdOn: datetime, updatedOn: datetime):
        self.id = id
        self.email = email
        self.organization_name = organization_name
        self.createdOn = createdOn
        self.updatedOn = updatedOn

    def __repr__(self):
        return (f"id: {self.id}, email: {self.email}, organization_name: {self.organization_name}, "
                f"createdOn: {self.createdOn}, updatedOn: {self.updatedOn}")


class UserDetailResponse(GenericResponse):
    def __init__(self, status: str, status_code: int, message: str, data: List[UserDetail]):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return (f"status: {self.status}, status_code: {self.status_code}, message: {self.message}, "
                f"data: {self.data}")


class GetorganizationDetail:
    def __init__(self, id: int, agent_id: int, domain_name: str, extras: dict, parameters: dict):
        self.id = id
        self.agent_id = agent_id
        self.domain_name = domain_name
        self.extras = extras
        self.parameters = parameters

    def __repr__(self):
        return (f"id: {self.id}, agent_id: {self.agent_id}, domain_name: {self.domain_name}, "
                f"extras: {self.extras}, parameters: {self.parameters}")


class GetorganizationDetailResponse(GenericResponse):
    def __init__(self, status: str, status_code: int, message: str, data: list[GetorganizationDetail]):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return (f"status: {self.status}, status_code: {self.status_code}, message: {self.message}, "
                f"data: {self.data}")


class UpdateorganizationDetailResponse(GenericResponse):
    def __init__(self, status: str, status_code: int, message: str, data: list[GetorganizationDetail]):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return (f"status: {self.status}, status_code: {self.status_code}, message: {self.message}, "
                f"data: {self.data}")


class UniqueAgent:
    def __init__(self, agent_id: int, agent_type: str):
        self.agent_id = agent_id
        self.agent_type = agent_type

    def __repr__(self):
        return f"agent_id: {self.agent_id}, agent_type: {self.agent_type}"


class GetUniqueAgentsResponse(GenericResponse):
    def __init__(self, status: str, status_code: int, message: str, data: list[UniqueAgent]):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, status_code: {self.status_code}, message: {self.message}, data: {self.data}"


class GetSector:
    def __init__(self, id: int, sector_name: str, capabilities: Optional[str]):
        self.id = id
        self.sector_name = sector_name
        self.capabilities = capabilities

    def __repr__(self):
        return f"id: {self.id}, sector_name: {self.sector_name}, capabilities: {self.capabilities}"


class GetSectorsResponse(GenericResponse):
    def __init__(self, status: str, status_code: int, message: str, data: List[GetSector]):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, status_code: {self.status_code}, message: {self.message}, data: {self.data}"
