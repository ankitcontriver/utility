#!/usr/bin/env python3
"""
Sakura Log Analyzer - Fixed Version
Comprehensive analysis tool with corrected patterns based on actual log format
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import re
import os
import json
from datetime import datetime, timedelta
from collections import Counter, defaultdict
from typing import Dict, List, Tuple, Any
import tempfile

# Page configuration
st.set_page_config(
    page_title="Sakura Log Analyzer - Fixed", 
    page_icon="📊", 
    layout="wide",
    initial_sidebar_state="expanded"
)

class SakuraLogAnalyzer:
    def __init__(self, test_mode=False):
        self.log_content = ""
        self.analysis_results = {}
        self.test_mode = test_mode
        
    def load_log_file(self, file_source: str, uploaded_file=None) -> bool:
        """Load log file from different sources"""
        try:
            if file_source == "server":
                log_path = "/logs/ivr/sakura/sakura.log"
                if os.path.exists(log_path):
                    with open(log_path, 'r', encoding='utf-8') as f:
                        self.log_content = f.read()
                    return True
                else:
                    st.error(f"Server log file not found at {log_path}")
                    return False
                    
            elif file_source == "local":
                log_path = "sakura.log"
                if os.path.exists(log_path):
                    with open(log_path, 'r', encoding='utf-8') as f:
                        self.log_content = f.read()
                    return True
                else:
                    st.error(f"Local log file not found: {log_path}")
                    return False
                    
            elif file_source == "upload" and uploaded_file:
                # Handle different file types
                if uploaded_file.name.endswith('.log') or uploaded_file.name.endswith('.txt'):
                    self.log_content = uploaded_file.getvalue().decode('utf-8')
                else:
                    self.log_content = uploaded_file.getvalue().decode('utf-8')
                return True
                
        except Exception as e:
            st.error(f"Error loading log file: {str(e)}")
            return False
        
        return False
    
    def extract_timestamps(self, lines: List[str]) -> List[datetime]:
        """Extract timestamps from log lines"""
        timestamps = []
        timestamp_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})'
        
        for line in lines:
            match = re.search(timestamp_pattern, line)
            if match:
                try:
                    timestamp_str = match.group(1)
                    # Parse timestamp (handle milliseconds)
                    dt = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
                    timestamps.append(dt)
                except:
                    continue
        return timestamps
    
    def extract_unique_call_message_ids(self) -> Dict[str, Any]:
        """Extract unique call_ids from call_message events"""
        unique_ids = set()
        timestamps = []
        call_id_timestamps = {}
        
        lines = self.log_content.split('\n')
        
        for line in lines:
            if 'call_message received' in line:
                # Extract timestamp
                timestamp_match = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})', line)
                # Extract call ID from JSON
                call_id_match = re.search(r'"callId":(\d+)', line)
                
                if timestamp_match and call_id_match:
                    timestamp_str = timestamp_match.group(1)
                    call_id = call_id_match.group(1)
                    
                    try:
                        timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
                        unique_ids.add(call_id)
                        call_id_timestamps[call_id] = timestamp
                        timestamps.append(timestamp)
                    except:
                        continue
        
        return {
            'unique_ids': sorted(list(unique_ids)),
            'timestamps': timestamps,
            'call_id_timestamps': call_id_timestamps
        }
    
    def analyze_concurrent_calls(self) -> Dict[str, Any]:
        """Analyze concurrent calls at different timestamps"""
        concurrent_data = {
            'timestamps': [],
            'concurrent_counts': [],
            'active_calls': []
        }
        
        lines = self.log_content.split('\n')
        
        # Track call starts and ends
        call_events = []
        
        for line in lines:
            timestamp_match = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})', line)
            if not timestamp_match:
                continue
            
            timestamp_str = timestamp_match.group(1)
            
            try:
                timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
            except:
                continue
            
            # Track call starts
            if 'call start for sid' in line:
                call_id_match = re.search(r'"callId":(\d+)', line)
                if call_id_match:
                    call_id = call_id_match.group(1)
                    call_events.append({
                        'timestamp': timestamp,
                        'event': 'start',
                        'call_id': call_id
                    })
            
            # Track call ends
            elif 'call_end received for' in line:
                call_id_match = re.search(r'(\d{13,})', line)
                if call_id_match:
                    call_id = call_id_match.group(1)
                    call_events.append({
                        'timestamp': timestamp,
                        'event': 'end',
                        'call_id': call_id
                    })
        
        # Sort events by timestamp
        call_events.sort(key=lambda x: x['timestamp'])
        
        # Calculate concurrent calls at each timestamp
        active_calls = set()
        
        for event in call_events:
            if event['event'] == 'start':
                active_calls.add(event['call_id'])
            elif event['event'] == 'end':
                active_calls.discard(event['call_id'])
            
            concurrent_data['timestamps'].append(event['timestamp'])
            concurrent_data['concurrent_counts'].append(len(active_calls))
            concurrent_data['active_calls'].append(list(active_calls.copy()))
        
        return concurrent_data
    
    def extract_errors(self) -> Dict[str, Any]:
        """Extract all errors and exceptions from logs"""
        error_data = {
            'errors': [],
            'error_counts': {},
            'error_types': {},
            'timestamps': [],
            'call_ids': []
        }
        
        lines = self.log_content.split('\n')
        
        for line in lines:
            timestamp_match = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})', line)
            
            # Look for various error patterns
            error_patterns = [
                (r'ERROR', 'ERROR'),
                (r'Exception', 'Exception'),
                (r'Traceback', 'Traceback'),
                (r'WARNING', 'WARNING'),
                (r'Failed', 'Failed'),
                (r'Error', 'Error'),
                (r'timeout', 'Timeout'),
                (r'HTTP/1\.1 [4-5]\d{2}', 'HTTP Error'),
                (r'ConnectionError', 'Connection Error'),
                (r'TimeoutError', 'Timeout Error'),
            ]
            
            for pattern, error_type in error_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    # Extract call ID if present
                    call_id_match = re.search(r'(\d{13,})', line)
                    call_id = call_id_match.group(1) if call_id_match else 'N/A'
                    
                    # Extract timestamp
                    timestamp = None
                    if timestamp_match:
                        try:
                            timestamp = datetime.strptime(timestamp_match.group(1), '%Y-%m-%d %H:%M:%S,%f')
                        except:
                            timestamp = None
                    
                    error_info = {
                        'timestamp': timestamp,
                        'call_id': call_id,
                        'error_type': error_type,
                        'message': line.strip()
                    }
                    
                    error_data['errors'].append(error_info)
                    error_data['error_types'][error_type] = error_data['error_types'].get(error_type, 0) + 1
                    error_data['error_counts'][line.strip()] = error_data['error_counts'].get(line.strip(), 0) + 1
                    
                    if timestamp:
                        error_data['timestamps'].append(timestamp)
                    if call_id != 'N/A':
                        error_data['call_ids'].append(call_id)
                    
                    break  # Don't double-count same line for multiple patterns
        
        return error_data
    
    def extract_unique_queries(self) -> Dict[str, Any]:
        """Extract all unique user queries that trigger LLM API calls"""
        query_data = {
            'unique_queries': [],
            'query_counts': {},
            'query_call_ids': {},
            'total_queries': 0
        }
        
        lines = self.log_content.split('\n')
        
        # Track queries from call_message events with transcripts
        for line in lines:
            if 'call_message received' in line and '"transcript":"' in line:
                # Extract transcript content
                transcript_match = re.search(r'"transcript":"([^"]*)"', line)
                call_id_match = re.search(r'"callId":(\d+)', line)
                
                if transcript_match and call_id_match:
                    transcript = transcript_match.group(1)
                    call_id = call_id_match.group(1)
                    
                    # Skip empty transcripts
                    if transcript and transcript.strip():
                        # Count unique queries
                        if transcript not in query_data['query_counts']:
                            query_data['unique_queries'].append(transcript)
                            query_data['query_counts'][transcript] = 0
                            query_data['query_call_ids'][transcript] = []
                        
                        query_data['query_counts'][transcript] += 1
                        query_data['query_call_ids'][transcript].append(call_id)
                        query_data['total_queries'] += 1
        
        # Sort queries by frequency
        sorted_queries = sorted(query_data['query_counts'].items(), key=lambda x: x[1], reverse=True)
        query_data['sorted_queries'] = sorted_queries
        
        return query_data

    def analyze_calls(self) -> Dict[str, Any]:
        """Analyze call-related metrics"""
        results = {}
        
        # 1. Number of calls (call starts)
        call_starts = re.findall(r'call start for sid', self.log_content)
        results['call_starts'] = len(call_starts)
        
        # 2. Number of call ends
        call_ends = re.findall(r'call_end received for', self.log_content)
        results['call_ends'] = len(call_ends)
        
        # 3. Number of call messages
        call_messages = re.findall(r'call_message received for', self.log_content)
        results['call_messages'] = len(call_messages)
        
        # 4. Unique call_ids for call_message events
        call_message_ids = self.extract_unique_call_message_ids()
        results['unique_call_message_ids'] = call_message_ids['unique_ids']
        results['call_message_id_count'] = len(call_message_ids['unique_ids'])
        results['call_message_timestamps'] = call_message_ids['timestamps']
        
        # 5. Distinct transcriptions
        transcript_pattern = r'call_message received for.*?"transcript":"([^"]*)"'
        transcripts = re.findall(transcript_pattern, self.log_content)
        transcript_counts = Counter(transcripts)
        results['transcripts'] = dict(transcript_counts)
        results['distinct_transcripts'] = len(transcript_counts)
        
        # 6. CDR created
        cdr_created = re.findall(r'CDR created successfully for call_id', self.log_content)
        results['cdr_created'] = len(cdr_created)
        
        # 7. User call messages analysis (corrected pattern)
        user_messages_pattern = r'call_id \d+ User Call messages: (\[.*?\])'
        user_messages = re.findall(user_messages_pattern, self.log_content, re.DOTALL)
        
        empty_messages = 0
        non_empty_messages = 0
        
        for msg in user_messages:
            try:
                parsed = json.loads(msg)
                # Check if array is empty or contains only empty/invalid messages
                if not parsed or parsed == []:
                    empty_messages += 1
                else:
                    # Check if messages have meaningful content
                    has_content = False
                    for message in parsed:
                        if isinstance(message, dict):
                            body = message.get('body', '').strip()
                            sender_id = message.get('senderId', '')
                            # Consider it has content if there's a non-empty body
                            if body and len(body) > 0:
                                has_content = True
                                break
                    
                    if has_content:
                        non_empty_messages += 1
                    else:
                        empty_messages += 1
            except json.JSONDecodeError:
                # If JSON parsing fails, still count it as a message attempt
                non_empty_messages += 1
            except Exception:
                continue
        
        results['user_messages_total'] = len(user_messages)
        results['user_messages_empty'] = empty_messages
        results['user_messages_with_data'] = non_empty_messages
        
        return results
    
    def analyze_api_calls(self) -> Dict[str, Any]:
        """Analyze API calls and timing"""
        results = {}
        
        # 7. LLM API calls (actual pattern from logs)
        llm_calls = re.findall(r'Calling call_gpt_stream', self.log_content)
        results['llm_api_calls'] = len(llm_calls)
        
        # 8. TTS API calls (based on TTS timing logs)
        tts_calls = re.findall(r'time taken to tts for first chunk', self.log_content)
        results['tts_api_calls'] = len(tts_calls)
        
        # 9. LLM API timing analysis (corrected patterns)
        llm_timing_data = self.extract_llm_timing_fixed()
        results['llm_timing'] = llm_timing_data
        
        # 10. TTS timing analysis (corrected patterns)
        tts_timing_data = self.extract_tts_timing_fixed()
        results['tts_timing'] = tts_timing_data
        
        return results
    
    def extract_llm_timing_fixed(self) -> Dict[str, Any]:
        """Extract LLM API timing based on actual log patterns (supports both regular and test mode)"""
        timing_data = {
            'response_times': [],
            'timestamps': [],
            'call_ids': [],
            'api_type': 'mock' if self.test_mode else 'real'
        }
        
        lines = self.log_content.split('\n')
        
        # Track LLM call starts and first responses
        llm_starts = {}
        
        for line in lines:
            timestamp_match = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})', line)
            if not timestamp_match:
                continue
            
            timestamp_str = timestamp_match.group(1)
            
            # Track LLM call starts - different patterns for test mode vs production
            if self.test_mode:
                # Test mode: "🧪 Using mock LLM API for testing"
                if '🧪 Using mock LLM API for testing' in line or 'Using mock LLM API for testing' in line:
                    call_id_match = re.search(r'(\d{13,})', line)
                    if call_id_match:
                        call_id = call_id_match.group(1)
                        try:
                            timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
                            llm_starts[call_id] = timestamp
                        except:
                            continue
            else:
                # Production mode: "Calling call_gpt_stream"
                if 'Calling call_gpt_stream' in line:
                    call_id_match = re.search(r'(\d{13,})', line)
                    if call_id_match:
                        call_id = call_id_match.group(1)
                        try:
                            timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
                            llm_starts[call_id] = timestamp
                        except:
                            continue
            
            # Track first response: "Sending message response" (same for both modes)
            if 'Sending message response' in line and 'isEndChunk=False' in line:
                for call_id, start_time in list(llm_starts.items()):
                    if call_id in line:
                        try:
                            end_time = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
                            response_time = (end_time - start_time).total_seconds()
                            
                            if response_time > 0 and response_time < 300:  # Sanity check
                                timing_data['response_times'].append(response_time)
                                timing_data['timestamps'].append(start_time)
                                timing_data['call_ids'].append(call_id)
                            
                            del llm_starts[call_id]
                            break
                        except:
                            continue
        
        # Calculate statistics
        if timing_data['response_times']:
            timing_data['avg_response_time'] = sum(timing_data['response_times']) / len(timing_data['response_times'])
            timing_data['min_response_time'] = min(timing_data['response_times'])
            timing_data['max_response_time'] = max(timing_data['response_times'])
        else:
            timing_data['avg_response_time'] = 0
            timing_data['min_response_time'] = 0
            timing_data['max_response_time'] = 0
        
        return timing_data
    
    def extract_tts_timing_fixed(self) -> Dict[str, Any]:
        """Extract TTS timing based on actual log patterns"""
        timing_data = {
            'response_times': [],
            'timestamps': [],
            'call_ids': []
        }
        
        lines = self.log_content.split('\n')
        
        # Pattern: "time taken to tts for first chunk ------> X.XX ms"
        for line in lines:
            if 'time taken to tts for first chunk' in line:
                timestamp_match = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})', line)
                call_id_match = re.search(r'(\d{13,})', line)
                time_match = re.search(r'time taken to tts for first chunk.*?(\d+\.?\d*)\s*ms', line)
                
                if timestamp_match and call_id_match and time_match:
                    try:
                        timestamp = datetime.strptime(timestamp_match.group(1), '%Y-%m-%d %H:%M:%S,%f')
                        call_id = call_id_match.group(1)
                        tts_time = float(time_match.group(1)) / 1000.0  # Convert ms to seconds
                        
                        if tts_time > 0 and tts_time < 10:  # Sanity check
                            timing_data['response_times'].append(tts_time)
                            timing_data['timestamps'].append(timestamp)
                            timing_data['call_ids'].append(call_id)
                    except:
                        continue
        
        # Calculate statistics
        if timing_data['response_times']:
            timing_data['avg_response_time'] = sum(timing_data['response_times']) / len(timing_data['response_times'])
            timing_data['min_response_time'] = min(timing_data['response_times'])
            timing_data['max_response_time'] = max(timing_data['response_times'])
        else:
            timing_data['avg_response_time'] = 0
            timing_data['min_response_time'] = 0
            timing_data['max_response_time'] = 0
        
        return timing_data
    
    def analyze_sakura_response_timing(self) -> Dict[str, Any]:
        """Analyze Sakura response timing: call_message to first response chunk"""
        timing_data = {
            'response_times': [],
            'timestamps': [],
            'call_ids': []
        }
        
        # Process all data (same as LLM/TTS timing functions)
        
        lines = self.log_content.split('\n')
        
        # Track call_message events with transcription
        message_starts = {}
        
        for line in lines:
            timestamp_match = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})', line)
            if not timestamp_match:
                continue
                
            timestamp_str = timestamp_match.group(1)
            
            # Track call_message received with transcript (actual pattern)
            if 'call_message received' in line and '"transcript":"' in line and '"transcript":""' not in line:
                # Extract call ID from JSON
                call_id_match = re.search(r'"callId":(\d+)', line)
                if call_id_match:
                    call_id = call_id_match.group(1)
                    try:
                        timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
                        message_starts[call_id] = timestamp
                    except:
                        continue
            
            # Track first response chunk (actual pattern)
            elif 'Sending message response' in line and 'isEndChunk=False' in line:
                for call_id, start_time in list(message_starts.items()):
                    if call_id in line:
                        try:
                            end_time = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
                            response_time = (end_time - start_time).total_seconds()
                            
                            if response_time > 0 and response_time < 120:  # Sanity check
                                timing_data['response_times'].append(response_time)
                                timing_data['timestamps'].append(start_time)
                                timing_data['call_ids'].append(call_id)
                            
                            del message_starts[call_id]
                            break
                        except:
                            continue
        
        # Calculate statistics
        if timing_data['response_times']:
            timing_data['avg_response_time'] = sum(timing_data['response_times']) / len(timing_data['response_times'])
            timing_data['min_response_time'] = min(timing_data['response_times'])
            timing_data['max_response_time'] = max(timing_data['response_times'])
        else:
            timing_data['avg_response_time'] = 0
            timing_data['min_response_time'] = 0
            timing_data['max_response_time'] = 0
        
        return timing_data
    
    def analyze_event_loops_and_redis(self) -> Dict[str, Any]:
        """Analyze event loop usage and Redis operations based on actual patterns"""
        results = {
            'event_loop_stats': {
                'total_operations': 0,
                'async_loops_used': [],
                'operations_per_loop': {},
                'timestamps': []
            },
            'redis_operations': {
                'total_operations': 0,
                'operation_types': {},
                'timestamps': [],
                'key_operations': [],
                'expiration_events': 0
            },
            'redis_expiry_timing': {
                'key_expiry_times': [],          # Time from SET to expiry message
                'processing_times': [],          # Time from expiry message to processing start
                'timestamps': [],
                'call_ids': [],
                'key_types': [],
                'avg_expiry_time': 0,
                'min_expiry_time': 0,
                'max_expiry_time': 0,
                'avg_processing_time': 0,
                'min_processing_time': 0,
                'max_processing_time': 0,
                'expiry_processing_times': []
            }
        }
        
        lines = self.log_content.split('\n')
        
        # Track Redis key lifecycle for timing analysis
        redis_set_tracking = {}      # key -> {'set_time': datetime, 'set_timestamp_ms': int, 'call_id': str, 'key_type': str}
        redis_expiry_tracking = {}   # key -> {'expiry_message_time': datetime}
        
        for line in lines:
            timestamp_match = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})', line)
            if not timestamp_match:
                continue
            
            timestamp_str = timestamp_match.group(1)
            try:
                timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
            except:
                continue
            
            # Analyze Event Loop usage (AsyncLoop-X pattern)
            async_loop_match = re.search(r'AsyncLoop-(\d+)', line)
            if async_loop_match:
                loop_id = int(async_loop_match.group(1))
                results['event_loop_stats']['async_loops_used'].append(loop_id)
                results['event_loop_stats']['timestamps'].append(timestamp)
                results['event_loop_stats']['total_operations'] += 1
                
                # Count operations per loop
                if loop_id not in results['event_loop_stats']['operations_per_loop']:
                    results['event_loop_stats']['operations_per_loop'][loop_id] = 0
                results['event_loop_stats']['operations_per_loop'][loop_id] += 1
            
            # Analyze CDR Manager Stats
            if 'CDR Manager Stats' in line:
                results['event_loop_stats']['timestamps'].append(timestamp)
            
            # TRACK Redis utterance key SET operations (UPDATED PATTERN - FOCUS ON UTTERANCE KEYS)
            # Pattern: "Key 1756450605087:utterance SET DIRECTLY in Redis at 1756450616270 with 500ms expiration"
            if 'SET DIRECTLY in Redis at' in line and 'with 500ms expiration' in line and ':utterance' in line:
                key_set_match = re.search(r'Key (\d+:utterance) SET DIRECTLY in Redis at (\d+) with 500ms expiration', line)
                if key_set_match:
                    redis_key = key_set_match.group(1)
                    set_timestamp_ms = int(key_set_match.group(2))
                    call_id = redis_key.split(':')[0]
                    key_type = 'utterance'  # Focusing specifically on utterance keys
                    
                    redis_set_tracking[redis_key] = {
                        'set_time': timestamp,
                        'set_timestamp_ms': set_timestamp_ms,
                        'call_id': call_id,
                        'key_type': key_type
                    }
                    
                    # Count as Redis operation
                    results['redis_operations']['total_operations'] += 1
                    results['redis_operations']['operation_types']['UTTERANCE_SET'] = results['redis_operations']['operation_types'].get('UTTERANCE_SET', 0) + 1
                    results['redis_operations']['timestamps'].append(timestamp)
                    results['redis_operations']['key_operations'].append(redis_key)
            
            # TRACK Redis utterance expiry message reception (UPDATED PATTERN - FOCUS ON UTTERANCE KEYS)
            # Pattern: "Received Redis message: {'type': 'pmessage', 'pattern': '__keyevent@1__:expired', 'channel': '__keyevent@1__:expired', 'data': '1756450605087:utterance'}"
            elif 'Received Redis message' in line and '__keyevent@1__:expired' in line and ':utterance' in line:
                expiry_message_match = re.search(r"'data': '(\d+:utterance)'", line)
                if expiry_message_match:
                    redis_key = expiry_message_match.group(1)
                    call_id = redis_key.split(':')[0]
                    key_type = 'utterance'  # Focusing specifically on utterance keys
                    
                    # Store expiry message time for processing delay calculation
                    redis_expiry_tracking[redis_key] = {
                        'expiry_message_time': timestamp
                    }
                    
                    # TIMING 1: Calculate utterance key expiry time (SET → expiry message)
                    if redis_key in redis_set_tracking:
                        set_info = redis_set_tracking[redis_key]
                        set_timestamp_ms = set_info['set_timestamp_ms']
                        
                        # Calculate expiry time from timestamps in logs
                        # Convert current timestamp to milliseconds to match set timestamp
                        current_timestamp_ms = int(timestamp.timestamp() * 1000)
                        expiry_time_ms = current_timestamp_ms - set_timestamp_ms
                        expiry_time_seconds = expiry_time_ms / 1000.0
                        
                        if expiry_time_seconds > 0 and expiry_time_seconds < 3600:  # Sanity check
                            results['redis_expiry_timing']['key_expiry_times'].append(expiry_time_seconds)
                            results['redis_expiry_timing']['timestamps'].append(set_info['set_time'])
                            results['redis_expiry_timing']['call_ids'].append(call_id)
                            results['redis_expiry_timing']['key_types'].append(key_type)
                        
                        # Remove from SET tracking to prevent duplicates
                        del redis_set_tracking[redis_key]
                    
                    # Count as Redis operation
                    results['redis_operations']['total_operations'] += 1
                    results['redis_operations']['operation_types']['UTTERANCE_EXPIRY_MESSAGE'] = results['redis_operations']['operation_types'].get('UTTERANCE_EXPIRY_MESSAGE', 0) + 1
                    results['redis_operations']['expiration_events'] += 1
                    results['redis_operations']['timestamps'].append(timestamp)
                    results['redis_operations']['key_operations'].append(redis_key)
            
            # TRACK Redis utterance processing start (UPDATED PATTERN - FOCUS ON UTTERANCE KEYS)
            # Pattern: "Key 1756450605087:utterance expired in Redis at 1756450616795"
            elif 'expired in Redis at' in line and ':utterance' in line:
                processing_start_match = re.search(r'Key (\d+:utterance) expired in Redis at (\d+)', line)
                if processing_start_match:
                    redis_key = processing_start_match.group(1)
                    processing_timestamp_ms = int(processing_start_match.group(2))
                    call_id = redis_key.split(':')[0]
                    key_type = 'utterance'  # Focusing specifically on utterance keys
                    
                    # TIMING 2: Calculate processing time (expiry message → processing start)
                    if redis_key in redis_expiry_tracking:
                        expiry_info = redis_expiry_tracking[redis_key]
                        expiry_message_time = expiry_info['expiry_message_time']
                        
                        # Calculate processing delay from log timestamps
                        processing_delay = (timestamp - expiry_message_time).total_seconds()
                        
                        if processing_delay >= 0 and processing_delay < 300:  # Sanity check
                            results['redis_expiry_timing']['processing_times'].append(processing_delay)
                            results['redis_expiry_timing']['expiry_processing_times'].append(expiry_message_time)
                        
                        # Remove from expiry tracking to prevent duplicates
                        del redis_expiry_tracking[redis_key]
                    
                    # Count as Redis operation
                    results['redis_operations']['total_operations'] += 1
                    results['redis_operations']['operation_types']['UTTERANCE_PROCESSING_START'] = results['redis_operations']['operation_types'].get('UTTERANCE_PROCESSING_START', 0) + 1
                    results['redis_operations']['timestamps'].append(timestamp)
                    results['redis_operations']['key_operations'].append(redis_key)
            
            # Handle other Redis operations for backward compatibility
            elif 'Key' in line and 'saved in Redis' in line:
                results['redis_operations']['total_operations'] += 1
                results['redis_operations']['operation_types']['SET_LEGACY'] = results['redis_operations']['operation_types'].get('SET_LEGACY', 0) + 1
                results['redis_operations']['timestamps'].append(timestamp)
                
                # Extract key pattern
                key_match = re.search(r'Key (\d+:\w+) saved', line)
                if key_match:
                    results['redis_operations']['key_operations'].append(key_match.group(1))
            
            elif 'Received Redis message' in line and '__keyevent@1__:expired' not in line:
                results['redis_operations']['total_operations'] += 1
                results['redis_operations']['operation_types']['MESSAGE_OTHER'] = results['redis_operations']['operation_types'].get('MESSAGE_OTHER', 0) + 1
                results['redis_operations']['timestamps'].append(timestamp)
        
        # Calculate Redis expiry timing statistics
        expiry_timing = results['redis_expiry_timing']
        
        # Key expiry time statistics (SET → expiry message)
        if expiry_timing['key_expiry_times']:
            expiry_timing['avg_expiry_time'] = sum(expiry_timing['key_expiry_times']) / len(expiry_timing['key_expiry_times'])
            expiry_timing['min_expiry_time'] = min(expiry_timing['key_expiry_times'])
            expiry_timing['max_expiry_time'] = max(expiry_timing['key_expiry_times'])
        else:
            expiry_timing['avg_expiry_time'] = 0
            expiry_timing['min_expiry_time'] = 0
            expiry_timing['max_expiry_time'] = 0
        
        # Processing time statistics (expiry message → processing start)
        if expiry_timing['processing_times']:
            expiry_timing['avg_processing_time'] = sum(expiry_timing['processing_times']) / len(expiry_timing['processing_times'])
            expiry_timing['min_processing_time'] = min(expiry_timing['processing_times'])
            expiry_timing['max_processing_time'] = max(expiry_timing['processing_times'])
        else:
            expiry_timing['avg_processing_time'] = 0
            expiry_timing['min_processing_time'] = 0
            expiry_timing['max_processing_time'] = 0
        
        return results
    
    def analyze_thread_performance(self) -> Dict[str, Any]:
        """Analyze thread wait/blocked states and response times"""
        results = {}
        
        # Thread performance indicators
        thread_metrics = {
            'wait_indicators': 0,
            'async_loops_active': len(set()),
            'cdr_operations': 0
        }
        
        lines = self.log_content.split('\n')
        async_loops_seen = set()
        
        for line in lines:
            # Count async loop usage as threading activity
            async_loop_match = re.search(r'AsyncLoop-(\d+)', line)
            if async_loop_match:
                async_loops_seen.add(int(async_loop_match.group(1)))
            
            # CDR operations as thread activity
            if 'CDR Manager Stats' in line:
                thread_metrics['cdr_operations'] += 1
        
        thread_metrics['async_loops_active'] = len(async_loops_seen)
        results['thread_metrics'] = thread_metrics
        
        # Response time analysis
        response_times = self.extract_response_times()
        results['response_times'] = response_times
        
        return results
    
    def extract_response_times(self) -> Dict[str, Any]:
        """Extract response timing data"""
        response_data = {
            'first_chunk_times': [],
            'full_response_times': [],
            'timestamps': []
        }
        
        lines = self.log_content.split('\n')
        
        # Track message to response timing
        message_times = {}
        
        for line in lines:
            timestamp_match = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})', line)
            if not timestamp_match:
                continue
                
            timestamp = timestamp_match.group(1)
            
            # Track call messages
            if 'call_message received' in line:
                call_id_match = re.search(r'"callId":(\d+)', line)
                if call_id_match:
                    call_id = call_id_match.group(1)
                    try:
                        dt = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S,%f')
                        message_times[call_id] = dt
                    except:
                        continue
            
            # Track responses (first chunk)
            elif 'Sending message response' in line and 'isEndChunk=False' in line:
                for call_id, start_time in list(message_times.items()):
                    if call_id in line:
                        try:
                            end_time = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S,%f')
                            response_time = (end_time - start_time).total_seconds()
                            response_data['first_chunk_times'].append(response_time)
                            response_data['timestamps'].append(start_time)
                            del message_times[call_id]  # Remove processed
                        except:
                            continue
        
        # Calculate statistics
        if response_data['first_chunk_times']:
            response_data['avg_first_chunk'] = sum(response_data['first_chunk_times']) / len(response_data['first_chunk_times'])
            response_data['min_first_chunk'] = min(response_data['first_chunk_times'])
            response_data['max_first_chunk'] = max(response_data['first_chunk_times'])
        
        return response_data
    
    def run_analysis(self) -> Dict[str, Any]:
        """Run complete log analysis"""
        if not self.log_content:
            return {}
        
        results = {}
        
        # Run all analysis modules
        results['calls'] = self.analyze_calls()
        results['apis'] = self.analyze_api_calls()
        results['performance'] = self.analyze_thread_performance()
        results['sakura_response_timing'] = self.analyze_sakura_response_timing()
        results['event_loops_redis'] = self.analyze_event_loops_and_redis()
        results['concurrent_calls'] = self.analyze_concurrent_calls()
        
        # NEW: Extract errors and unique queries
        results['errors'] = self.extract_errors()
        results['unique_queries'] = self.extract_unique_queries()
        
        # Add metadata including test mode info
        results['metadata'] = {
            'log_size': len(self.log_content),
            'log_lines': len(self.log_content.split('\n')),
            'analysis_time': datetime.now().isoformat(),
            'test_mode': self.test_mode,
            'api_mode': 'Mock LLM API' if self.test_mode else 'Real LLM API'
        }
        
        self.analysis_results = results
        return results

def create_executive_summary(results: Dict[str, Any]) -> None:
    """Create executive summary report for complete scenario analysis"""
    
    st.header("🎯 Executive Summary Report")
    st.markdown("*Comprehensive analysis for performance issue identification*")
    
    # Extract key metrics
    calls_data = results.get('calls', {})
    apis_data = results.get('apis', {})
    sakura_timing = results.get('sakura_response_timing', {})
    concurrent_data = results.get('concurrent_calls', {})
    event_redis = results.get('event_loops_redis', {})
    
    # Performance Assessment
    st.subheader("🚨 Performance Assessment")
    
    # Calculate performance indicators
    sakura_avg = sakura_timing.get('avg_response_time', 0)
    sakura_max = sakura_timing.get('max_response_time', 0)
    llm_avg = apis_data.get('llm_timing', {}).get('avg_response_time', 0)
    tts_avg = apis_data.get('tts_timing', {}).get('avg_response_time', 0)
    
    # Redis expiry performance indicators
    redis_expiry_data = event_redis.get('redis_expiry_timing', {})
    redis_processing_delay = redis_expiry_data.get('avg_processing_time', 0)
    redis_max_delay = redis_expiry_data.get('max_processing_time', 0)
    
    # Performance classification
    if sakura_avg == 0:
        performance_status = "🔍 No Data"
        performance_color = "blue"
        performance_desc = "Insufficient data for performance assessment"
    elif sakura_avg <= 2.0:
        performance_status = "✅ Excellent"
        performance_color = "green"
        performance_desc = "System performing optimally"
    elif sakura_avg <= 5.0:
        performance_status = "⚠️ Degraded"
        performance_color = "orange"
        performance_desc = "Performance degradation detected"
    else:
        performance_status = "🚨 Critical"
        performance_color = "red"
        performance_desc = "Severe performance issues detected"
    
    # Display overall status
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Overall Status", performance_status)
    with col2:
        if sakura_avg > 0:
            st.metric("Avg Response Time", f"{sakura_avg:.2f}s")
        else:
            st.metric("Avg Response Time", "N/A")
    with col3:
        if concurrent_data.get('concurrent_counts'):
            max_concurrent = max(concurrent_data['concurrent_counts'])
            st.metric("Peak Concurrent Load", max_concurrent)
        else:
            st.metric("Peak Concurrent Load", "N/A")
    
    st.markdown(f"**{performance_desc}**")
    
    # Root Cause Analysis
    st.subheader("🔍 Root Cause Analysis")
    
    # Calculate framework overhead
    framework_overhead = sakura_avg - llm_avg - tts_avg if all([sakura_avg, llm_avg, tts_avg]) else 0
    
    if framework_overhead > 0:
        st.error(f"**High Framework Overhead Detected: {framework_overhead:.2f}s**")
        st.write("**Potential Issues:**")
        if framework_overhead > 3.0:
            st.write("• 🚨 **CRITICAL:** Excessive framework processing time (>3s)")
            st.write("• 🔧 **Likely Cause:** Thread synchronization bottlenecks")
            st.write("• 🎯 **Focus:** AsyncLoop worker saturation or lock contention")
        elif framework_overhead > 1.0:
            st.write("• ⚠️ **WARNING:** Moderate framework overhead (1-3s)")
            st.write("• 🔧 **Likely Cause:** Resource contention or queue delays")
        else:
            st.write("• ℹ️ **INFO:** Minor framework overhead (<1s) - acceptable")
    else:
        st.success("✅ Framework overhead within acceptable range")
    
    # Redis Expiry Analysis
    st.write("**Redis Expiry Performance Analysis:**")
    if redis_processing_delay > 0:
        if redis_max_delay > 10.0:
            st.error(f"🚨 **CRITICAL REDIS BOTTLENECK:** Max processing delay {redis_max_delay:.2f}s")
            st.write("• 🔧 **ROOT CAUSE:** Thread pool explosion in Redis event handling")
            st.write("• 🎯 **IMMEDIATE FIX:** Eliminate background thread creation in sync_wrapper")
        elif redis_processing_delay > 2.0:
            st.warning(f"⚠️ **REDIS PERFORMANCE ISSUE:** Avg processing delay {redis_processing_delay:.2f}s")
            st.write("• 🔧 **LIKELY CAUSE:** AsyncLoop queue saturation")
            st.write("• 🎯 **OPTIMIZATION:** Remove processing locks, improve load balancing")
        elif redis_processing_delay > 0.5:
            st.info(f"ℹ️ **MODERATE REDIS DELAYS:** {redis_processing_delay:.2f}s average")
            st.write("• 🔧 **CAUSE:** Minor thread contention")
        else:
            st.success(f"✅ **GOOD REDIS PERFORMANCE:** {redis_processing_delay:.2f}s average delay")
            
        # Correlation with framework overhead
        if redis_processing_delay > 2.0 and framework_overhead > 3.0:
            st.error("🎯 **KEY INSIGHT:** Redis expiry delays correlate with framework overhead")
            st.write("• **This confirms:** Redis processing bottleneck is causing 10+ second delays")
            st.write("• **Solution:** Fix thread pool explosion → Reduce framework overhead")
    else:
        st.info("📊 **No Redis expiry data available for analysis**")
    
    # Performance Breakdown Analysis
    st.subheader("⚡ Performance Breakdown")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Timing Breakdown:**")
        if all([sakura_avg, llm_avg, tts_avg]):
            # Create performance breakdown chart
            breakdown_data = {
                'Component': ['LLM API', 'TTS API', 'Framework Overhead'],
                'Time (seconds)': [llm_avg, tts_avg, framework_overhead],
                'Percentage': [
                    (llm_avg / sakura_avg) * 100,
                    (tts_avg / sakura_avg) * 100,
                    (framework_overhead / sakura_avg) * 100
                ]
            }
            
            import plotly.express as px
            fig_breakdown = px.pie(
                values=breakdown_data['Time (seconds)'],
                names=breakdown_data['Component'],
                title="Response Time Breakdown"
            )
            st.plotly_chart(fig_breakdown, use_container_width=True)
            
            # Show percentage breakdown
            for i, component in enumerate(breakdown_data['Component']):
                percentage = breakdown_data['Percentage'][i]
                time_val = breakdown_data['Time (seconds)'][i]
                st.write(f"• {component}: {time_val:.2f}s ({percentage:.1f}%)")
        else:
            st.info("Insufficient timing data for breakdown analysis")
    
    with col2:
        st.write("**Load vs Performance Correlation:**")
        if concurrent_data.get('concurrent_counts') and sakura_timing.get('response_times'):
            # Analyze correlation between load and response time
            concurrent_counts = concurrent_data['concurrent_counts']
            response_times = sakura_timing['response_times']
            
            # Calculate correlation if we have enough data
            if len(concurrent_counts) > 1 and len(response_times) > 1:
                # Simple correlation analysis
                avg_concurrent = sum(concurrent_counts) / len(concurrent_counts)
                high_load_threshold = avg_concurrent * 1.5
                
                high_load_responses = []
                low_load_responses = []
                
                # This is a simplified correlation - in real scenario we'd match timestamps
                if len(response_times) >= 2:
                    mid_point = len(response_times) // 2
                    early_responses = response_times[:mid_point]
                    late_responses = response_times[mid_point:]
                    
                    early_avg = sum(early_responses) / len(early_responses)
                    late_avg = sum(late_responses) / len(late_responses)
                    
                    st.write(f"• Early responses avg: {early_avg:.2f}s")
                    st.write(f"• Late responses avg: {late_avg:.2f}s")
                    
                    if late_avg > early_avg * 1.5:
                        st.error("🚨 **Performance degradation over time detected**")
                        st.write("• System shows signs of resource exhaustion")
                        st.write("• Response times increase exponentially")
                    elif late_avg > early_avg * 1.2:
                        st.warning("⚠️ **Moderate performance degradation**")
                    else:
                        st.success("✅ **Stable performance over time**")
        else:
            st.info("Insufficient data for load correlation analysis")
    
    # System Resource Analysis
    st.subheader("🔧 System Resource Analysis")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.write("**AsyncLoop Analysis:**")
        event_stats = event_redis.get('event_loop_stats', {})
        operations_per_loop = event_stats.get('operations_per_loop', {})
        
        if operations_per_loop:
            total_ops = sum(operations_per_loop.values())
            num_loops = len(operations_per_loop)
            avg_ops_per_loop = total_ops / num_loops if num_loops > 0 else 0
            
            st.write(f"• Active Loops: {num_loops}")
            st.write(f"• Total Operations: {total_ops}")
            st.write(f"• Avg Ops/Loop: {avg_ops_per_loop:.1f}")
            
            # Check for load balancing issues
            if operations_per_loop:
                max_ops = max(operations_per_loop.values())
                min_ops = min(operations_per_loop.values())
                imbalance_ratio = max_ops / max(min_ops, 1)
                
                if imbalance_ratio > 3.0:
                    st.error(f"⚠️ **Load imbalance detected** (ratio: {imbalance_ratio:.1f})")
                elif imbalance_ratio > 1.5:
                    st.warning(f"⚠️ **Minor load imbalance** (ratio: {imbalance_ratio:.1f})")
                else:
                    st.success(f"✅ **Good load distribution** (ratio: {imbalance_ratio:.1f})")
        else:
            st.info("No AsyncLoop data available")
    
    with col2:
        st.write("**Redis Analysis:**")
        redis_stats = event_redis.get('redis_operations', {})
        redis_total = redis_stats.get('total_operations', 0)
        call_messages = calls_data.get('call_messages', 0)
        
        if redis_total > 0 and call_messages > 0:
            redis_per_message = redis_total / call_messages
            st.write(f"• Total Redis Ops: {redis_total}")
            st.write(f"• Ops per Message: {redis_per_message:.1f}")
            
            if redis_per_message > 10:
                st.warning("⚠️ **High Redis operation rate**")
                st.write("• Consider Redis optimization")
            elif redis_per_message > 5:
                st.info("ℹ️ **Moderate Redis usage**")
            else:
                st.success("✅ **Efficient Redis usage**")
                
            # Operation type analysis
            operation_types = redis_stats.get('operation_types', {})
            if operation_types:
                st.write("**Operation Types:**")
                for op_type, count in operation_types.items():
                    percentage = (count / redis_total) * 100
                    st.write(f"• {op_type}: {percentage:.1f}%")
        else:
            st.info("Insufficient Redis data")
    
    with col3:
        st.write("**Call Completion Analysis:**")
        call_starts = calls_data.get('call_starts', 0)
        call_ends = calls_data.get('call_ends', 0)
        call_messages = calls_data.get('call_messages', 0)
        
        if call_starts > 0:
            completion_rate = (call_ends / call_starts) * 100
            messages_per_call = call_messages / call_starts
            
            st.write(f"• Calls Started: {call_starts}")
            st.write(f"• Calls Completed: {call_ends}")
            st.write(f"• Completion Rate: {completion_rate:.1f}%")
            st.write(f"• Msgs per Call: {messages_per_call:.1f}")
            
            if completion_rate < 90:
                st.error("🚨 **Low completion rate**")
                st.write("• Possible system crashes or timeouts")
            elif completion_rate < 95:
                st.warning("⚠️ **Moderate completion rate**")
            else:
                st.success("✅ **Good completion rate**")
        else:
            st.info("No call data available")
    
    # Recommendations
    st.subheader("📋 Actionable Recommendations")
    
    recommendations = []
    priority_high = []
    priority_medium = []
    priority_low = []
    
    # High priority recommendations
    if sakura_avg > 5.0:
        priority_high.append("🚨 **CRITICAL:** Optimize AsyncLoop worker configuration - response times >5s")
        priority_high.append("🔧 **IMMEDIATE:** Investigate thread synchronization bottlenecks")
    
    if framework_overhead > 3.0:
        priority_high.append("🚨 **CRITICAL:** Reduce framework overhead - currently >3s per request")
        priority_high.append("🔧 **IMMEDIATE:** Review lock contention in ScalableAsyncManager")
    
    # Medium priority recommendations
    if operations_per_loop and max(operations_per_loop.values()) / max(min(operations_per_loop.values()), 1) > 2.0:
        priority_medium.append("⚠️ **OPTIMIZE:** Improve AsyncLoop load balancing")
    
    if redis_total > 0 and call_messages > 0 and (redis_total / call_messages) > 10:
        priority_medium.append("⚠️ **OPTIMIZE:** Reduce Redis operations per message")
    
    if sakura_avg > 2.0 and sakura_avg <= 5.0:
        priority_medium.append("⚠️ **TUNE:** Fine-tune performance settings for better response times")
    
    # Low priority recommendations
    if call_starts > 0 and (call_ends / call_starts) < 0.95:
        priority_low.append("ℹ️ **MONITOR:** Investigate call completion rate")
    
    priority_low.append("ℹ️ **MONITOR:** Set up continuous performance monitoring")
    priority_low.append("ℹ️ **DOCUMENT:** Document optimal configuration settings")
    
    # Display recommendations by priority
    if priority_high:
        st.error("**🚨 HIGH PRIORITY:**")
        for rec in priority_high:
            st.write(f"• {rec}")
    
    if priority_medium:
        st.warning("**⚠️ MEDIUM PRIORITY:**")
        for rec in priority_medium:
            st.write(f"• {rec}")
    
    if priority_low:
        st.info("**ℹ️ LOW PRIORITY:**")
        for rec in priority_low:
            st.write(f"• {rec}")
    
    # Summary conclusion
    st.subheader("📄 Executive Conclusion")
    
    if sakura_avg > 5.0:
        conclusion = """
        🚨 **CRITICAL PERFORMANCE ISSUE IDENTIFIED**
        
        The system is experiencing severe performance degradation with response times exceeding 5 seconds. 
        This indicates fundamental bottlenecks in the async processing pipeline, likely related to:
        - Thread synchronization issues
        - AsyncLoop worker saturation 
        - Resource contention under load
        
        **IMMEDIATE ACTION REQUIRED** to restore system performance.
        """
    elif sakura_avg > 2.0:
        conclusion = """
        ⚠️ **PERFORMANCE OPTIMIZATION NEEDED**
        
        The system shows signs of performance degradation under load. While functional, 
        response times are above optimal levels. Optimization of async processing and 
        load balancing could significantly improve user experience.
        
        **RECOMMENDED:** Implement performance optimizations within next maintenance window.
        """
    elif sakura_avg > 0:
        conclusion = """
        ✅ **SYSTEM PERFORMING WITHIN ACCEPTABLE RANGE**
        
        Overall system performance is acceptable, though monitoring for trends and 
        minor optimizations could provide additional benefits.
        
        **RECOMMENDED:** Continue monitoring and consider minor optimizations.
        """
    else:
        conclusion = """
        🔍 **INSUFFICIENT DATA FOR ASSESSMENT**
        
        Unable to perform comprehensive analysis due to insufficient timing data.
        
        **RECOMMENDED:** Ensure proper logging is enabled and re-run analysis with complete data.
        """
    
    st.markdown(conclusion)
    
    # Data Export for Further Analysis
    st.subheader("💾 Executive Summary Export")
    
    summary_report = {
        "executive_summary": {
            "performance_status": performance_status,
            "avg_response_time": sakura_avg,
            "framework_overhead": framework_overhead,
            "max_concurrent_load": max(concurrent_data.get('concurrent_counts', [0])),
            "recommendations": {
                "high_priority": priority_high,
                "medium_priority": priority_medium,
                "low_priority": priority_low
            },
            "conclusion": conclusion
        }
    }
    
    import json
    report_json = json.dumps(summary_report, indent=2, default=str)
    
    st.download_button(
        label="📄 Download Executive Summary",
        data=report_json,
        file_name=f"sakura_executive_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
        mime="application/json"
    )

def create_comprehensive_trend_graphs(analyzer: SakuraLogAnalyzer, results: Dict[str, Any]) -> None:
    """Create comprehensive trend analysis graphs"""
    
    st.header("📈 Comprehensive Trend Analysis")
    
    # First Row: API Response Times
    st.subheader("🔄 API Response Time Trends")
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**LLM API Response Time Trend**")
        
        llm_data = results['apis']['llm_timing']
        if llm_data['response_times'] and llm_data['timestamps']:
            # Create DataFrame for plotting
            df_llm = pd.DataFrame({
                'timestamp': llm_data['timestamps'],
                'response_time': llm_data['response_times']
            })
            
            # Sort by timestamp
            df_llm = df_llm.sort_values('timestamp')
            
            # Create trend line
            fig_llm = px.line(df_llm, x='timestamp', y='response_time', 
                             title='LLM API Response Time Over Time',
                             labels={'response_time': 'Response Time (seconds)', 'timestamp': 'Time'})
            
            # Add scatter points
            fig_llm.add_scatter(x=df_llm['timestamp'], y=df_llm['response_time'], 
                               mode='markers', name='API Calls', 
                               marker=dict(size=6, opacity=0.6))
            
            # Calculate and add trend line
            if len(df_llm) > 1:
                x_vals = list(range(len(df_llm)))
                y_vals = df_llm['response_time'].tolist()
                
                n = len(x_vals)
                sum_x = sum(x_vals)
                sum_y = sum(y_vals)
                sum_xy = sum(x * y for x, y in zip(x_vals, y_vals))
                sum_x2 = sum(x * x for x in x_vals)
                
                if n * sum_x2 - sum_x * sum_x != 0:
                    slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x)
                    intercept = (sum_y - slope * sum_x) / n
                    
                    trend_line = [slope * x + intercept for x in x_vals]
                    
                    fig_llm.add_scatter(x=df_llm['timestamp'], y=trend_line, 
                                       mode='lines', name='Trend', 
                                       line=dict(color='red', width=2, dash='dash'))
                    
                    trend_direction = "📈 Increasing" if slope > 0 else "📉 Decreasing"
                    st.metric("LLM Trend", trend_direction, f"{slope:.4f} sec/call")
            
            # Add concurrent calls information to the chart
            concurrent_data = results.get('concurrent_calls', {})
            if concurrent_data.get('timestamps'):
                # Add secondary y-axis for concurrent calls
                fig_llm_with_calls = make_subplots(specs=[[{"secondary_y": True}]])
                
                # Add LLM response times
                fig_llm_with_calls.add_trace(
                    go.Scatter(x=df_llm['timestamp'], y=df_llm['response_time'],
                              mode='lines+markers', name='LLM Response Time',
                              line=dict(color='blue')),
                    secondary_y=False
                )
                
                # Add concurrent calls data
                df_concurrent = pd.DataFrame({
                    'timestamp': concurrent_data['timestamps'],
                    'concurrent_count': concurrent_data['concurrent_counts']
                })
                
                fig_llm_with_calls.add_trace(
                    go.Scatter(x=df_concurrent['timestamp'], y=df_concurrent['concurrent_count'],
                              mode='lines', name='Concurrent Calls',
                              line=dict(color='red', dash='dot', width=2)),
                    secondary_y=True
                )
                
                fig_llm_with_calls.update_yaxes(title_text="Response Time (seconds)", secondary_y=False)
                fig_llm_with_calls.update_yaxes(title_text="Concurrent Calls", secondary_y=True)
                fig_llm_with_calls.update_layout(title="LLM Response Time vs Server Load", height=350)
                
                st.plotly_chart(fig_llm_with_calls, use_container_width=True)
            else:
                fig_llm.update_layout(height=350)
                st.plotly_chart(fig_llm, use_container_width=True)
            
            st.write(f"**Avg:** {llm_data['avg_response_time']:.2f}s | **Min:** {llm_data['min_response_time']:.2f}s | **Max:** {llm_data['max_response_time']:.2f}s")
        else:
            st.info("No LLM timing data available")
    
    with col2:
        st.write("**TTS API Response Time Trend**")
        
        tts_data = results['apis']['tts_timing']
        if tts_data['response_times'] and tts_data['timestamps']:
            # Create DataFrame for plotting
            df_tts = pd.DataFrame({
                'timestamp': tts_data['timestamps'],
                'response_time': tts_data['response_times']
            })
            
            # Sort by timestamp
            df_tts = df_tts.sort_values('timestamp')
            
            # Create trend line
            fig_tts = px.line(df_tts, x='timestamp', y='response_time', 
                             title='TTS API Response Time Over Time',
                             labels={'response_time': 'Response Time (seconds)', 'timestamp': 'Time'})
            
            # Add scatter points
            fig_tts.add_scatter(x=df_tts['timestamp'], y=df_tts['response_time'], 
                               mode='markers', name='TTS Calls', 
                               marker=dict(size=6, opacity=0.6, color='orange'))
            
            # Calculate and add trend line
            if len(df_tts) > 1:
                x_vals = list(range(len(df_tts)))
                y_vals = df_tts['response_time'].tolist()
                
                n = len(x_vals)
                sum_x = sum(x_vals)
                sum_y = sum(y_vals)
                sum_xy = sum(x * y for x, y in zip(x_vals, y_vals))
                sum_x2 = sum(x * x for x in x_vals)
                
                if n * sum_x2 - sum_x * sum_x != 0:
                    slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x)
                    intercept = (sum_y - slope * sum_x) / n
                    
                    trend_line = [slope * x + intercept for x in x_vals]
                    
                    fig_tts.add_scatter(x=df_tts['timestamp'], y=trend_line, 
                                       mode='lines', name='Trend', 
                                       line=dict(color='red', width=2, dash='dash'))
                    
                    trend_direction = "📈 Increasing" if slope > 0 else "📉 Decreasing"
                    st.metric("TTS Trend", trend_direction, f"{slope:.4f} sec/call")
            
            # Add concurrent calls information to the TTS chart
            concurrent_data = results.get('concurrent_calls', {})
            if concurrent_data.get('timestamps'):
                # Add secondary y-axis for concurrent calls
                fig_tts_with_calls = make_subplots(specs=[[{"secondary_y": True}]])
                
                # Add TTS response times
                fig_tts_with_calls.add_trace(
                    go.Scatter(x=df_tts['timestamp'], y=df_tts['response_time'],
                              mode='lines+markers', name='TTS Response Time',
                              line=dict(color='orange')),
                    secondary_y=False
                )
                
                # Add concurrent calls data
                df_concurrent = pd.DataFrame({
                    'timestamp': concurrent_data['timestamps'],
                    'concurrent_count': concurrent_data['concurrent_counts']
                })
                
                fig_tts_with_calls.add_trace(
                    go.Scatter(x=df_concurrent['timestamp'], y=df_concurrent['concurrent_count'],
                              mode='lines', name='Concurrent Calls',
                              line=dict(color='red', dash='dot', width=2)),
                    secondary_y=True
                )
                
                fig_tts_with_calls.update_yaxes(title_text="Response Time (seconds)", secondary_y=False)
                fig_tts_with_calls.update_yaxes(title_text="Concurrent Calls", secondary_y=True)
                fig_tts_with_calls.update_layout(title="TTS Response Time vs Server Load", height=350)
                
                st.plotly_chart(fig_tts_with_calls, use_container_width=True)
            else:
                fig_tts.update_layout(height=350)
                st.plotly_chart(fig_tts, use_container_width=True)
            
            st.write(f"**Avg:** {tts_data['avg_response_time']:.2f}s | **Min:** {tts_data['min_response_time']:.2f}s | **Max:** {tts_data['max_response_time']:.2f}s")
        else:
            st.info("No TTS timing data available")
    
    # Second Row: Sakura Response Time
    st.subheader("⚡ Sakura Response Time Trend")
    st.write("*Time from call_message received with transcription to first response chunk*")
    
    sakura_timing = results.get('sakura_response_timing', {})
    if sakura_timing.get('response_times') and sakura_timing.get('timestamps'):
        df_sakura = pd.DataFrame({
            'timestamp': sakura_timing['timestamps'],
            'response_time': sakura_timing['response_times']
        })
        
        df_sakura = df_sakura.sort_values('timestamp')
        
        # Create comprehensive Sakura response time chart
        fig_sakura = px.line(df_sakura, x='timestamp', y='response_time', 
                           title='Sakura End-to-End Response Time (Message → First Chunk)',
                           labels={'response_time': 'Response Time (seconds)', 'timestamp': 'Time'})
        
        fig_sakura.add_scatter(x=df_sakura['timestamp'], y=df_sakura['response_time'], 
                              mode='markers', name='Responses', 
                              marker=dict(size=8, opacity=0.7, color='green'))
        
        # Add trend line
        if len(df_sakura) > 1:
            x_vals = list(range(len(df_sakura)))
            y_vals = df_sakura['response_time'].tolist()
            
            n = len(x_vals)
            sum_x = sum(x_vals)
            sum_y = sum(y_vals)
            sum_xy = sum(x * y for x, y in zip(x_vals, y_vals))
            sum_x2 = sum(x * x for x in x_vals)
            
            if n * sum_x2 - sum_x * sum_x != 0:
                slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x)
                intercept = (sum_y - slope * sum_x) / n
                
                trend_line = [slope * x + intercept for x in x_vals]
                
                fig_sakura.add_scatter(x=df_sakura['timestamp'], y=trend_line, 
                                     mode='lines', name='Trend', 
                                     line=dict(color='red', width=3, dash='dash'))
        
        # Create enhanced chart with concurrent calls
        concurrent_data = results.get('concurrent_calls', {})
        if concurrent_data.get('timestamps'):
            # Add secondary y-axis for concurrent calls
            fig_sakura_with_calls = make_subplots(specs=[[{"secondary_y": True}]])
            
            # Add Sakura response times
            fig_sakura_with_calls.add_trace(
                go.Scatter(x=df_sakura['timestamp'], y=df_sakura['response_time'],
                          mode='lines+markers', name='Sakura Response Time',
                          marker=dict(size=8, opacity=0.7, color='green')),
                secondary_y=False
            )
            
            # Add concurrent calls data
            df_concurrent = pd.DataFrame({
                'timestamp': concurrent_data['timestamps'],
                'concurrent_count': concurrent_data['concurrent_counts']
            })
            
            fig_sakura_with_calls.add_trace(
                go.Scatter(x=df_concurrent['timestamp'], y=df_concurrent['concurrent_count'],
                          mode='lines', name='Concurrent Calls on Server',
                          line=dict(color='red', dash='dot', width=2)),
                secondary_y=True
            )
            
            fig_sakura_with_calls.update_yaxes(title_text="Response Time (seconds)", secondary_y=False)
            fig_sakura_with_calls.update_yaxes(title_text="Concurrent Calls", secondary_y=True)
            fig_sakura_with_calls.update_layout(
                title="Sakura End-to-End Response Time vs Server Load (Message → First Chunk)",
                height=400
            )
            
            st.plotly_chart(fig_sakura_with_calls, use_container_width=True)
        else:
            fig_sakura.update_layout(height=400)
            st.plotly_chart(fig_sakura, use_container_width=True)
        
        # Sakura response metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Avg Response Time", f"{sakura_timing['avg_response_time']:.2f}s")
        with col2:
            st.metric("Min Response Time", f"{sakura_timing['min_response_time']:.2f}s")
        with col3:
            st.metric("Max Response Time", f"{sakura_timing['max_response_time']:.2f}s")
        with col4:
            st.metric("Total Responses", len(sakura_timing['response_times']))
    else:
        st.info("No Sakura response timing data available")
    
    # Third Row: Redis Expiry Timing Analysis
    st.subheader("⏰ Redis Expiry Timing Analysis")
    st.write("*Redis key expiry timing (SET → expiry message) and processing time (expiry message → processing start)*")
    
    redis_expiry_data = results.get('event_loops_redis', {}).get('redis_expiry_timing', {})
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Redis Key Expiry Time Trends**")
        
        if redis_expiry_data.get('key_expiry_times') and redis_expiry_data.get('timestamps'):
            df_redis_expiry = pd.DataFrame({
                'timestamp': redis_expiry_data['timestamps'],
                'expiry_time': redis_expiry_data['key_expiry_times'],
                'call_id': redis_expiry_data['call_ids'],
                'key_type': redis_expiry_data['key_types']
            })
            
            df_redis_expiry = df_redis_expiry.sort_values('timestamp')
            
            # Create trend line for Redis key expiry times
            fig_redis_expiry = px.line(df_redis_expiry, x='timestamp', y='expiry_time', 
                                       title='Redis Key Expiry Time Over Time (SET → Expiry Message)',
                                       labels={'expiry_time': 'Key Expiry Time (seconds)', 'timestamp': 'Time'},
                                       hover_data=['call_id', 'key_type'])
            
            fig_redis_expiry.add_scatter(x=df_redis_expiry['timestamp'], y=df_redis_expiry['expiry_time'], 
                                         mode='markers', name='Key Expiry Events', 
                                         marker=dict(size=6, opacity=0.6, color='purple'))
            
            # Add trend line for Redis expiry times
            if len(df_redis_expiry) > 1:
                x_vals = list(range(len(df_redis_expiry)))
                y_vals = df_redis_expiry['expiry_time'].tolist()
                
                n = len(x_vals)
                sum_x = sum(x_vals)
                sum_y = sum(y_vals)
                sum_xy = sum(x * y for x, y in zip(x_vals, y_vals))
                sum_x2 = sum(x * x for x in x_vals)
                
                if n * sum_x2 - sum_x * sum_x != 0:
                    slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x)
                    intercept = (sum_y - slope * sum_x) / n
                    
                    trend_line = [slope * x + intercept for x in x_vals]
                    
                    fig_redis_expiry.add_scatter(x=df_redis_expiry['timestamp'], y=trend_line, 
                                                 mode='lines', name='Trend', 
                                                 line=dict(color='red', width=2, dash='dash'))
                    
                    trend_direction = "📈 Increasing" if slope > 0 else "📉 Decreasing"
                    st.metric("Expiry Time Trend", trend_direction, f"{slope:.4f} sec/key")
            
            fig_redis_expiry.update_layout(height=350)
            st.plotly_chart(fig_redis_expiry, use_container_width=True)
            
            st.write(f"**Avg Expiry Time:** {redis_expiry_data.get('avg_expiry_time', 0):.2f}s | **Min:** {redis_expiry_data.get('min_expiry_time', 0):.2f}s | **Max:** {redis_expiry_data.get('max_expiry_time', 0):.2f}s")
        else:
            st.info("No Redis key lifetime data available")
    
    with col2:
        st.write("**Redis Processing Time Analysis**")
        
        if redis_expiry_data.get('processing_times') and redis_expiry_data.get('expiry_processing_times'):
            df_redis_processing = pd.DataFrame({
                'timestamp': redis_expiry_data['expiry_processing_times'],
                'processing_time': redis_expiry_data['processing_times']
            })
            
            df_redis_processing = df_redis_processing.sort_values('timestamp')
            
            # Create trend line for Redis processing times
            fig_redis_processing = px.line(df_redis_processing, x='timestamp', y='processing_time', 
                                     title='Redis Processing Time Over Time (Expiry Message → Processing Start)',
                                     labels={'processing_time': 'Processing Time (seconds)', 'timestamp': 'Time'})
            
            fig_redis_processing.add_scatter(x=df_redis_processing['timestamp'], y=df_redis_processing['processing_time'], 
                                       mode='markers', name='Processing Events', 
                                       marker=dict(size=6, opacity=0.6, color='orange'))
            
            # Add trend line for processing times
            if len(df_redis_processing) > 1:
                x_vals = list(range(len(df_redis_processing)))
                y_vals = df_redis_processing['processing_time'].tolist()
                
                n = len(x_vals)
                sum_x = sum(x_vals)
                sum_y = sum(y_vals)
                sum_xy = sum(x * y for x, y in zip(x_vals, y_vals))
                sum_x2 = sum(x * x for x in x_vals)
                
                if n * sum_x2 - sum_x * sum_x != 0:
                    slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x)
                    intercept = (sum_y - slope * sum_x) / n
                    
                    trend_line = [slope * x + intercept for x in x_vals]
                    
                    fig_redis_processing.add_scatter(x=df_redis_processing['timestamp'], y=trend_line, 
                                               mode='lines', name='Trend', 
                                               line=dict(color='red', width=2, dash='dash'))
                    
                    trend_direction = "📈 Increasing" if slope > 0 else "📉 Decreasing"
                    st.metric("Processing Time Trend", trend_direction, f"{slope:.4f} sec/event")
            
            fig_redis_processing.update_layout(height=350)
            st.plotly_chart(fig_redis_processing, use_container_width=True)
            
            st.write(f"**Avg Processing Time:** {redis_expiry_data.get('avg_processing_time', 0):.2f}s | **Min:** {redis_expiry_data.get('min_processing_time', 0):.2f}s | **Max:** {redis_expiry_data.get('max_processing_time', 0):.2f}s")
        else:
            st.info("No Redis processing delay data available")
    
    # Fourth Row: Event Loop and Redis Operations Analysis  
    st.subheader("🔄 Event Loop & Redis Operations Analysis")
    
    event_redis_data = results.get('event_loops_redis', {})
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Event Loop Usage Trends**")
        
        event_stats = event_redis_data.get('event_loop_stats', {})
        
        # Event loop usage chart
        if event_stats.get('operations_per_loop'):
            loop_data = event_stats['operations_per_loop']
            fig_loops = px.bar(
                x=list(loop_data.keys()),
                y=list(loop_data.values()),
                title="Operations per AsyncLoop",
                labels={'x': 'AsyncLoop ID', 'y': 'Operations Count'}
            )
            fig_loops.update_layout(height=350)
            st.plotly_chart(fig_loops, use_container_width=True)
            
            st.write(f"**Total Operations:** {event_stats.get('total_operations', 0)}")
            st.write(f"**Active AsyncLoops:** {len(loop_data)}")
        else:
            st.info("No event loop performance data available")
    
    with col2:
        st.write("**Redis Operations Analysis**")
        
        redis_stats = event_redis_data.get('redis_operations', {})
        
        # Redis operations pie chart
        operation_types = redis_stats.get('operation_types', {})
        if operation_types:
            fig_redis_ops = px.pie(
                values=list(operation_types.values()),
                names=list(operation_types.keys()),
                title="Redis Operation Types"
            )
            fig_redis_ops.update_layout(height=350)
            st.plotly_chart(fig_redis_ops, use_container_width=True)
        else:
            st.info("No Redis operation type data available")
        
        # Redis metrics
        st.write(f"**Total Redis Operations:** {redis_stats.get('total_operations', 0)}")
        st.write(f"**Key Operations:** {len(redis_stats.get('key_operations', []))}")
        st.write(f"**Expiration Events:** {redis_stats.get('expiration_events', 0)}")

def display_analysis_results(results: Dict[str, Any]) -> None:
    """Display comprehensive analysis results"""
    
    if not results:
        st.error("No analysis results available")
        return
    
    # Summary metrics
    st.header("📊 Analysis Summary")
    
    # Key metrics row
    col1, col2, col3, col4, col5 = st.columns(5)
    
    calls_data = results.get('calls', {})
    apis_data = results.get('apis', {})
    
    with col1:
        st.metric("Total Calls Started", calls_data.get('call_starts', 0))
    with col2:
        st.metric("Total Calls Ended", calls_data.get('call_ends', 0))
    with col3:
        st.metric("Call Messages", calls_data.get('call_messages', 0))
    with col4:
        st.metric("Unique Call IDs", calls_data.get('call_message_id_count', 0))
    with col5:
        st.metric("LLM API Calls", apis_data.get('llm_api_calls', 0))
    
    # Enhanced metrics row
    col1, col2, col3, col4, col5 = st.columns(5)
    
    sakura_timing = results.get('sakura_response_timing', {})
    event_redis = results.get('event_loops_redis', {})
    redis_expiry_data = event_redis.get('redis_expiry_timing', {})
    
    with col1:
        st.metric("TTS API Calls", apis_data.get('tts_api_calls', 0))
    with col2:
        if sakura_timing.get('avg_response_time'):
            st.metric("Avg Sakura Response", f"{sakura_timing['avg_response_time']:.2f}s")
        else:
            st.metric("Avg Sakura Response", "N/A")
    with col3:
        redis_ops = event_redis.get('redis_operations', {}).get('total_operations', 0)
        st.metric("Redis Operations", redis_ops)
    with col4:
        event_ops = event_redis.get('event_loop_stats', {}).get('total_operations', 0)
        st.metric("Event Loop Ops", event_ops)
    with col5:
        async_loops = len(event_redis.get('event_loop_stats', {}).get('operations_per_loop', {}))
        st.metric("Active AsyncLoops", async_loops)
    
    # Redis expiry metrics row
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        redis_key_expirations = len(redis_expiry_data.get('key_expiry_times', []))
        st.metric("Redis Key Expirations", redis_key_expirations)
    with col2:
        if redis_expiry_data.get('avg_expiry_time'):
            st.metric("Avg Key Expiry Time", f"{redis_expiry_data['avg_expiry_time']:.2f}s")
        else:
            st.metric("Avg Key Expiry Time", "N/A")
    with col3:
        if redis_expiry_data.get('avg_processing_time'):
            st.metric("Avg Processing Time", f"{redis_expiry_data['avg_processing_time']:.2f}s")
        else:
            st.metric("Avg Processing Time", "N/A")
    with col4:
        if redis_expiry_data.get('max_processing_time'):
            st.metric("Max Processing Time", f"{redis_expiry_data['max_processing_time']:.2f}s")
        else:
            st.metric("Max Processing Time", "N/A")
    with col5:
        redis_expiry_events = len(redis_expiry_data.get('processing_times', []))
        st.metric("Expiry Processing Events", redis_expiry_events)
    
    # Concurrent calls metrics row
    col1, col2, col3, col4, col5 = st.columns(5)
    
    concurrent_data = results.get('concurrent_calls', {})
    
    with col1:
        if concurrent_data.get('concurrent_counts'):
            max_concurrent = max(concurrent_data['concurrent_counts'])
            st.metric("Peak Concurrent Calls", max_concurrent)
        else:
            st.metric("Peak Concurrent Calls", "N/A")
    with col2:
        if concurrent_data.get('concurrent_counts'):
            avg_concurrent = sum(concurrent_data['concurrent_counts']) / len(concurrent_data['concurrent_counts'])
            st.metric("Avg Concurrent Calls", f"{avg_concurrent:.1f}")
        else:
            st.metric("Avg Concurrent Calls", "N/A")
    with col3:
        completion_rate = (calls_data.get('call_ends', 0) / max(calls_data.get('call_starts', 1), 1)) * 100
        st.metric("Completion Rate", f"{completion_rate:.1f}%")
    with col4:
        if concurrent_data.get('timestamps'):
            test_duration = (max(concurrent_data['timestamps']) - min(concurrent_data['timestamps'])).total_seconds() / 60
            st.metric("Test Duration", f"{test_duration:.1f} min")
        else:
            st.metric("Test Duration", "N/A")
    with col5:
        # Call rate per minute
        if concurrent_data.get('timestamps') and calls_data.get('call_starts', 0) > 0:
            duration_minutes = (max(concurrent_data['timestamps']) - min(concurrent_data['timestamps'])).total_seconds() / 60
            call_rate = calls_data.get('call_starts', 0) / max(duration_minutes, 1)
            st.metric("Calls/Min", f"{call_rate:.1f}")
        else:
            st.metric("Calls/Min", "N/A")
    
    # Detailed sections with new tabs including errors and queries
    tabs = st.tabs([
        "📊 Executive Summary", 
        "📞 Call Analysis", 
        "🤖 API Analysis", 
        "⚡ Performance", 
        "🔄 Event Loops & Redis", 
        "❌ Errors & Issues", 
        "💬 User Queries", 
        "📝 Detailed Report"
    ])
    
    with tabs[0]:
        # Executive Summary Tab
        create_executive_summary(results)
    
    with tabs[1]:
        st.subheader("Call Flow Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Call Statistics:**")
            st.write(f"• Call Starts: {calls_data.get('call_starts', 0)}")
            st.write(f"• Call Ends: {calls_data.get('call_ends', 0)}")
            st.write(f"• Call Messages: {calls_data.get('call_messages', 0)}")
            st.write(f"• CDR Created: {calls_data.get('cdr_created', 0)}")
            
            # Calculate ratios
            call_msg_ratio = calls_data.get('call_messages', 0) / max(calls_data.get('call_starts', 1), 1)
            st.write(f"• Messages per Call: {call_msg_ratio:.2f}")
            
            # Unique call ID analysis
            st.write(f"• Unique Call IDs: {calls_data.get('call_message_id_count', 0)}")
            unique_ratio = calls_data.get('call_message_id_count', 0) / max(calls_data.get('call_starts', 1), 1)
            st.write(f"• Unique/Started Ratio: {unique_ratio:.2f}")
        
        with col2:
            st.write("**User Message Analysis:**")
            st.write(f"• Total User Messages: {calls_data.get('user_messages_total', 0)}")
            st.write(f"• Empty Messages: {calls_data.get('user_messages_empty', 0)}")
            st.write(f"• Messages with Data: {calls_data.get('user_messages_with_data', 0)}")
            
            # Compare with CDR
            cdr_count = calls_data.get('cdr_created', 0)
            user_msg_count = calls_data.get('user_messages_total', 0)
            st.write(f"• CDR vs User Messages: {cdr_count} CDRs, {user_msg_count} User Messages")
        
        # Transcriptions analysis
        st.subheader("📝 Transcription Analysis")
        
        transcripts = calls_data.get('transcripts', {})
        if transcripts:
            st.write(f"**Distinct Transcriptions: {calls_data.get('distinct_transcriptions', 0)}**")
            
            # Show top transcriptions
            sorted_transcripts = sorted(transcripts.items(), key=lambda x: x[1], reverse=True)
            for transcript, count in sorted_transcripts[:10]:
                st.write(f"• '{transcript}': {count} times")
        else:
            st.info("No transcription data found")
        
        # Unique Call IDs section
        st.subheader("🆔 Unique Call IDs for call_message Events")
        
        unique_call_ids = calls_data.get('unique_call_message_ids', [])
        if unique_call_ids:
            st.write(f"**Total Unique Call IDs: {len(unique_call_ids)}**")
            
            # Show call IDs in expandable section
            with st.expander("View All Unique Call IDs"):
                # Display in columns for better readability
                cols = st.columns(3)
                for i, call_id in enumerate(unique_call_ids):
                    with cols[i % 3]:
                        st.write(f"• {call_id}")
        else:
            st.info("No unique call IDs found for call_message events")
    
    with tabs[2]:
        st.subheader("API Performance Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**API Call Counts:**")
            st.write(f"• LLM API Calls: {apis_data.get('llm_api_calls', 0)}")
            st.write(f"• TTS API Calls: {apis_data.get('tts_api_calls', 0)}")
            
            # LLM timing
            llm_timing = apis_data.get('llm_timing', {})
            if llm_timing.get('response_times'):
                st.write(f"• LLM Avg Response: {llm_timing.get('avg_response_time', 0):.2f}s")
                st.write(f"• LLM Min Response: {llm_timing.get('min_response_time', 0):.2f}s")
                st.write(f"• LLM Max Response: {llm_timing.get('max_response_time', 0):.2f}s")
        
        with col2:
            st.write("**TTS Performance:**")
            tts_timing = apis_data.get('tts_timing', {})
            if tts_timing.get('response_times'):
                st.write(f"• TTS Avg Response: {tts_timing.get('avg_response_time', 0):.2f}s")
                st.write(f"• TTS Min Response: {tts_timing.get('min_response_time', 0):.2f}s")
                st.write(f"• TTS Max Response: {tts_timing.get('max_response_time', 0):.2f}s")
            else:
                st.info("TTS timing data not available")
    
    with tabs[3]:
        st.subheader("System Performance Analysis")
        
        perf_data = results.get('performance', {})
        thread_metrics = perf_data.get('thread_metrics', {})
        response_times = perf_data.get('response_times', {})
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Thread Performance:**")
            st.write(f"• Active AsyncLoops: {thread_metrics.get('async_loops_active', 0)}")
            st.write(f"• CDR Operations: {thread_metrics.get('cdr_operations', 0)}")
        
        with col2:
            st.write("**Response Times:**")
            first_chunk_times = response_times.get('first_chunk_times', [])
            if first_chunk_times:
                avg_first = sum(first_chunk_times) / len(first_chunk_times)
                st.write(f"• Avg First Chunk: {avg_first:.2f}s")
                st.write(f"• Min First Chunk: {min(first_chunk_times):.2f}s")
                st.write(f"• Max First Chunk: {max(first_chunk_times):.2f}s")
            else:
                st.info("Response time data not available")
        
        # Sakura-specific response timing
        st.subheader("⚡ Sakura Response Timing")
        sakura_timing = results.get('sakura_response_timing', {})
        if sakura_timing.get('response_times'):
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Avg Sakura Response", f"{sakura_timing['avg_response_time']:.2f}s")
            with col2:
                st.metric("Min Sakura Response", f"{sakura_timing['min_response_time']:.2f}s")
            with col3:
                st.metric("Max Sakura Response", f"{sakura_timing['max_response_time']:.2f}s")
        else:
            st.info("No Sakura response timing data available")
    
    with tabs[4]:
        st.subheader("Event Loops & Redis Operations")
        
        event_redis_data = results.get('event_loops_redis', {})
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Event Loop Statistics:**")
            event_stats = event_redis_data.get('event_loop_stats', {})
            st.write(f"• Total Operations: {event_stats.get('total_operations', 0)}")
            
            operations_per_loop = event_stats.get('operations_per_loop', {})
            if operations_per_loop:
                st.write(f"• Active AsyncLoops: {len(operations_per_loop)}")
                st.write("**Operations per Loop:**")
                for loop_id, count in operations_per_loop.items():
                    st.write(f"  • AsyncLoop-{loop_id}: {count} operations")
        
        with col2:
            st.write("**Redis Operations:**")
            redis_stats = event_redis_data.get('redis_operations', {})
            st.write(f"• Total Operations: {redis_stats.get('total_operations', 0)}")
            st.write(f"• Expiration Events: {redis_stats.get('expiration_events', 0)}")
            st.write(f"• Key Operations: {len(redis_stats.get('key_operations', []))}")
            
            # Operation types breakdown
            operation_types = redis_stats.get('operation_types', {})
            if operation_types:
                st.write("**Operation Types:**")
                for op_type, count in operation_types.items():
                    st.write(f"  • {op_type}: {count}")
        
        # Redis Expiry Timing Analysis Section
        st.subheader("⏰ Redis Expiry Timing Analysis")
        
        redis_expiry_data = event_redis_data.get('redis_expiry_timing', {})
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.write("**Key Expiry Time Statistics:**")
            if redis_expiry_data.get('key_expiry_times'):
                st.write(f"• Total Key Expirations: {len(redis_expiry_data['key_expiry_times'])}")
                st.write(f"• Avg Expiry Time: {redis_expiry_data.get('avg_expiry_time', 0):.2f}s")
                st.write(f"• Min Expiry Time: {redis_expiry_data.get('min_expiry_time', 0):.2f}s")
                st.write(f"• Max Expiry Time: {redis_expiry_data.get('max_expiry_time', 0):.2f}s")
                
                # Key type breakdown
                key_types = redis_expiry_data.get('key_types', [])
                if key_types:
                    from collections import Counter
                    key_type_counts = Counter(key_types)
                    st.write("**Key Types:**")
                    for key_type, count in key_type_counts.items():
                        st.write(f"  • {key_type}: {count} keys")
            else:
                st.info("No key expiry time data available")
        
        with col2:
            st.write("**Processing Time Statistics:**")
            if redis_expiry_data.get('processing_times'):
                st.write(f"• Total Processing Events: {len(redis_expiry_data['processing_times'])}")
                st.write(f"• Avg Processing Time: {redis_expiry_data.get('avg_processing_time', 0):.2f}s")
                st.write(f"• Min Processing Time: {redis_expiry_data.get('min_processing_time', 0):.2f}s")
                st.write(f"• Max Processing Time: {redis_expiry_data.get('max_processing_time', 0):.2f}s")
                
                # Performance classification
                max_time = redis_expiry_data.get('max_processing_time', 0)
                avg_time = redis_expiry_data.get('avg_processing_time', 0)
                
                if max_time > 10.0:
                    st.error(f"🚨 **CRITICAL:** Max processing time {max_time:.2f}s indicates severe bottlenecks")
                elif avg_time > 2.0:
                    st.warning(f"⚠️ **WARNING:** Avg processing time {avg_time:.2f}s indicates performance issues")
                elif avg_time > 0.5:
                    st.info(f"ℹ️ **INFO:** Moderate processing times detected ({avg_time:.2f}s avg)")
                else:
                    st.success(f"✅ **GOOD:** Low processing times ({avg_time:.2f}s avg)")
            else:
                st.info("No processing time data available")
        
        with col3:
            st.write("**Performance Insights:**")
            if redis_expiry_data.get('key_expiry_times') and redis_expiry_data.get('processing_times'):
                # Calculate performance ratios
                avg_expiry_time = redis_expiry_data.get('avg_expiry_time', 0)
                avg_processing_time = redis_expiry_data.get('avg_processing_time', 0)
                
                if avg_expiry_time > 0:
                    processing_ratio = (avg_processing_time / avg_expiry_time) * 100
                    st.write(f"• Processing/Expiry Time Ratio: {processing_ratio:.1f}%")
                    
                    if processing_ratio > 20:
                        st.error("🚨 **High processing overhead** relative to key expiry time")
                    elif processing_ratio > 10:
                        st.warning("⚠️ **Moderate processing overhead**")
                    else:
                        st.success("✅ **Low processing overhead**")
                
                # Timeline efficiency
                total_expiry_time = sum(redis_expiry_data['key_expiry_times'])
                total_processing_time = sum(redis_expiry_data['processing_times'])
                efficiency = ((total_expiry_time - total_processing_time) / max(total_expiry_time, 1)) * 100
                
                st.write(f"• Processing Efficiency: {efficiency:.1f}%")
                
                if efficiency < 80:
                    st.error("🚨 **Low efficiency:** Too much time spent in processing")
                elif efficiency < 90:
                    st.warning("⚠️ **Moderate efficiency:** Room for optimization")
                else:
                    st.success("✅ **High efficiency:** Good processing performance")
                
                # Expected vs Actual analysis
                st.write("**Expiry Time Analysis:**")
                if avg_expiry_time < 0.4:
                    st.error(f"🚨 **Keys expiring too early:** {avg_expiry_time:.2f}s (expected ~0.5s)")
                elif avg_expiry_time > 0.6:
                    st.warning(f"⚠️ **Keys expiring late:** {avg_expiry_time:.2f}s (expected ~0.5s)")
                else:
                    st.success(f"✅ **Expected expiry timing:** {avg_expiry_time:.2f}s (target ~0.5s)")
            else:
                st.info("Insufficient data for performance insights")
    
    with tabs[5]:
        st.subheader("❌ Errors & Issues Analysis")
        
        error_data = results.get('errors', {})
        
        if error_data.get('errors'):
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Error Summary:**")
                total_errors = len(error_data['errors'])
                st.write(f"• Total Errors: {total_errors}")
                
                # Error types breakdown
                error_types = error_data.get('error_types', {})
                if error_types:
                    st.write("**Error Types:**")
                    for error_type, count in error_types.items():
                        percentage = (count / total_errors) * 100
                        st.write(f"  • {error_type}: {count} ({percentage:.1f}%)")
            
            with col2:
                st.write("**Error Timeline:**")
                if error_data.get('timestamps'):
                    # Show error frequency over time
                    error_timestamps = error_data['timestamps']
                    if len(error_timestamps) > 1:
                        time_span = (max(error_timestamps) - min(error_timestamps)).total_seconds() / 60
                        error_rate = len(error_timestamps) / max(time_span, 1)
                        st.write(f"• Error Rate: {error_rate:.2f} errors/min")
                        st.write(f"• First Error: {min(error_timestamps).strftime('%H:%M:%S')}")
                        st.write(f"• Last Error: {max(error_timestamps).strftime('%H:%M:%S')}")
                    else:
                        st.write("• Single error event")
                else:
                    st.write("• No timestamp data available")
            
            # Top errors by frequency
            st.subheader("🔍 Most Frequent Errors")
            error_counts = error_data.get('error_counts', {})
            if error_counts:
                # Sort by frequency
                sorted_errors = sorted(error_counts.items(), key=lambda x: x[1], reverse=True)
                
                # Show top 10 errors
                for i, (error_msg, count) in enumerate(sorted_errors[:10]):
                    st.write(f"**{i+1}. Count: {count}**")
                    st.text(error_msg[:200] + "..." if len(error_msg) > 200 else error_msg)
                    st.write("---")
            
            # Error details table
            st.subheader("📋 Detailed Error Log")
            errors_list = error_data['errors']
            
            # Create DataFrame for better display
            error_df_data = []
            for error in errors_list[-50:]:  # Show last 50 errors
                error_df_data.append({
                    'Timestamp': error.get('timestamp').strftime('%H:%M:%S') if error.get('timestamp') else 'N/A',
                    'Call ID': error.get('call_id', 'N/A'),
                    'Type': error.get('error_type', 'Unknown'),
                    'Message': error.get('message', '')[:100] + "..." if len(error.get('message', '')) > 100 else error.get('message', '')
                })
            
            if error_df_data:
                import pandas as pd
                error_df = pd.DataFrame(error_df_data)
                st.dataframe(error_df, use_container_width=True, height=400)
        else:
            st.success("✅ No errors found in the log file!")
            st.info("This indicates clean system operation during the analysis period.")
    
    with tabs[6]:
        st.subheader("💬 User Queries Analysis")
        
        query_data = results.get('unique_queries', {})
        
        if query_data.get('unique_queries'):
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Query Summary:**")
                total_queries = query_data.get('total_queries', 0)
                unique_count = len(query_data.get('unique_queries', []))
                st.write(f"• Total Queries: {total_queries}")
                st.write(f"• Unique Queries: {unique_count}")
                
                if total_queries > 0:
                    uniqueness_ratio = (unique_count / total_queries) * 100
                    st.write(f"• Uniqueness Ratio: {uniqueness_ratio:.1f}%")
                    
                    if uniqueness_ratio > 80:
                        st.success("✅ High query diversity")
                    elif uniqueness_ratio > 50:
                        st.info("ℹ️ Moderate query diversity")
                    else:
                        st.warning("⚠️ Low query diversity (many repeated queries)")
            
            with col2:
                st.write("**API Mode Information:**")
                metadata = results.get('metadata', {})
                api_mode = metadata.get('api_mode', 'Unknown')
                test_mode = metadata.get('test_mode', False)
                
                if test_mode:
                    st.info(f"🧪 **{api_mode}** - Analyzing mock LLM responses")
                    st.write("• Mock API provides simulated responses")
                    st.write("• Response times: 0.5-3.0 seconds (simulated)")
                    st.write("• Queries processed by mock service")
                else:
                    st.info(f"🔴 **{api_mode}** - Analyzing real LLM responses")
                    st.write("• Real OpenAI/Azure API calls")
                    st.write("• Actual LLM processing and responses")
                    st.write("• Production query processing")
            
            # Query frequency analysis
            st.subheader("📊 Most Frequent User Queries")
            
            sorted_queries = query_data.get('sorted_queries', [])
            if sorted_queries:
                # Show detailed query list
                st.subheader("📋 Complete Query List with LLM API Calls")
                
                query_display_data = []
                for query, count in sorted_queries:
                    call_ids = query_data.get('query_call_ids', {}).get(query, [])
                    query_display_data.append({
                        'Query': query,
                        'Count': count,
                        'Percentage': f"{(count / total_queries) * 100:.1f}%",
                        'Sample Call IDs': ', '.join(call_ids[:3]) + ('...' if len(call_ids) > 3 else '')
                    })
                
                if query_display_data:
                    import pandas as pd
                    query_df = pd.DataFrame(query_display_data)
                    st.dataframe(query_df, use_container_width=True, height=500)
        else:
            st.info("📭 No user queries found in the log file")
            st.write("This might indicate:")
            st.write("• No call_message events with transcripts")
            st.write("• All transcripts were empty")
            st.write("• Log file doesn't contain query processing events")
    
    with tabs[7]:
        st.subheader("📝 Detailed Technical Report")
        
        # Raw data display
        st.write("**Complete Analysis Data:**")
        st.json(results)

def main():
    """Main Streamlit application"""
    
    st.title("🚀 Sakura Log Analyzer - Fixed")
    st.markdown("*Comprehensive analysis tool with corrected patterns based on actual log format*")
    
    # Sidebar for file input
    st.sidebar.header("📁 Log File Input")
    
    file_source = st.sidebar.radio(
        "Choose log file source:",
        ["server", "local", "upload"],
        format_func=lambda x: {
            "server": "🖥️ Server (/logs/ivr/sakura/sakura.log)",
            "local": "💻 Local (sakura.log)",
            "upload": "📤 Upload File"
        }[x]
    )
    
    uploaded_file = None
    if file_source == "upload":
        uploaded_file = st.sidebar.file_uploader(
            "Upload log file",
            type=['log', 'txt'],
            help="Upload your Sakura log file"
        )
    
    # Analysis controls
    st.sidebar.header("⚙️ Analysis Options")
    
    # Test mode toggle - NEW FEATURE
    test_mode = st.sidebar.checkbox(
        "🧪 Test Mode Analysis", 
        value=False,
        help="Enable this if the logs contain mock LLM API calls instead of real LLM API calls"
    )
    
    if test_mode:
        st.sidebar.info("🧪 Test Mode: Will analyze mock LLM API timing instead of real LLM API")
    else:
        st.sidebar.info("🔴 Production Mode: Will analyze real LLM API timing")
    
    auto_refresh = st.sidebar.checkbox("Auto-refresh analysis", value=False)
    show_raw_data = st.sidebar.checkbox("Show raw data", value=False)
    
    # Main analysis
    analyzer = SakuraLogAnalyzer(test_mode=test_mode)
    
    if st.sidebar.button("🔍 Analyze Logs", type="primary") or auto_refresh:
        with st.spinner("Loading and analyzing log file..."):
            success = analyzer.load_log_file(file_source, uploaded_file)
            
            if success:
                st.success("✅ Log file loaded successfully!")
                
                # Show file info
                log_size = len(analyzer.log_content)
                log_lines = len(analyzer.log_content.split('\n'))
                
                st.info(f"📄 Log file: {log_size:,} characters, {log_lines:,} lines")
                
                # Run analysis
                with st.spinner("Analyzing log data..."):
                    results = analyzer.run_analysis()
                
                if results:
                    # Display results
                    display_analysis_results(results)
                    
                    # Create enhanced trend graphs
                    create_comprehensive_trend_graphs(analyzer, results)
                    
                    # Enhanced graph explanations
                    st.header("📖 Analysis Explanations")
                    
                    with st.expander("🔄 LLM API Response Time Trend"):
                        st.write("""
                        **What it shows:** Response time of LLM API calls over time, tracking performance degradation.
                        
                        **🧪 Test Mode vs Production Mode:**
                        - **Test Mode:** Analyzes mock LLM API calls (🧪 Using mock LLM API for testing pattern)
                        - **Production Mode:** Analyzes real LLM API calls (Calling call_gpt_stream pattern)
                        - **Automatic Detection:** Mode is determined by the checkbox selection in Analysis Options
                        
                        **Key Insights:**
                        - **Trend Line (Red Dashed):** Shows whether response times are increasing or decreasing
                        - **Load Impact:** Increasing response times suggest system degradation under load
                        - **Optimal Range:** Response times should stay consistent (flat trend line)
                        - **Test Mode:** Simulated response times (0.5-3.0s) vs Real API response times
                        
                        **Performance Indicators:**
                        - ✅ **Good:** Flat or decreasing trend, consistent response times
                        - ⚠️ **Warning:** Slightly increasing trend, occasional spikes
                        - 🚨 **Critical:** Steep increasing trend, high variability
                        """)
                    
                    with st.expander("🎵 TTS API Response Time Trend"):
                        st.write("""
                        **What it shows:** Text-to-Speech processing times based on actual TTS timing logs.
                        
                        **Key Insights:**
                        - **TTS Performance:** Shows how TTS service responds under load
                        - **Audio Generation Time:** Time taken to synthesize speech from text
                        - **Service Stability:** Consistent times indicate stable TTS service
                        
                        **Optimization Opportunities:**
                        - High TTS times → Consider audio caching or pre-generation
                        - Increasing trend → TTS service may be overloaded
                        - Variable times → Network or service instability
                        """)
                    
                    with st.expander("⚡ Sakura Response Time Trend"):
                        st.write("""
                        **What it shows:** End-to-end Sakura response time from receiving a transcription to sending the first response chunk.
                        
                        **Key Metrics:**
                        - **Processing Time:** Complete time for Sakura to process user input
                        - **User Experience:** Direct measure of perceived response speed
                        - **System Health:** Overall system responsiveness indicator
                        
                        **Performance Analysis:**
                        - ✅ **Excellent:** < 2 seconds average response time
                        - ⚠️ **Good:** 2-5 seconds average response time
                        - 🚨 **Poor:** > 5 seconds average response time
                        
                        **This includes:** Transcription processing + LLM call + Response generation
                        """)
                    
                    with st.expander("⏰ Redis Utterance Key Expiry Timing Analysis"):
                        st.write("""
                        **🎯 Utterance Key Expiry Time Analysis (UPDATED - UTTERANCE FOCUS):**
                        - **Utterance Key Focus:** Specifically tracks ':utterance' keys only
                        - **Key Expiry Time:** Time from SET DIRECTLY to Redis expiry message received
                        - **Expected:** ~500ms (based on 500ms expiration setting)
                        - **Actual Measurement:** How long utterance keys actually take to expire
                        - **Pattern Tracked:** 'Key X:utterance SET DIRECTLY in Redis at Y with 500ms expiration' → 'Received Redis message: expired' (utterance only)
                        
                        **🎯 Utterance Processing Time Analysis (UPDATED - UTTERANCE FOCUS):**
                        - **Processing Time:** Time from expiry message received to processing start
                        - **Pattern Tracked:** 'Received Redis message: expired' (utterance) → 'Key X:utterance expired in Redis at Y'
                        - **System Health:** Fast processing indicates responsive AsyncLoop handling
                        - **Bottleneck Detection:** Delays show AsyncLoop or thread pool saturation
                        - **Utterance-specific Performance:** Focuses on key user interaction timing
                        
                        **Performance Indicators:**
                        - ✅ **Good Utterance Key Expiry:** 0.4-0.6s (close to 500ms target)
                        - ⚠️ **Warning:** Expiry times significantly off target (>±20%)
                        - 🚨 **Critical:** Processing times >2s indicate severe bottlenecks
                        
                        **🎯 NEW Utterance-Specific Insights:**
                        - **Utterance Key Expiry Accuracy:** Measures Redis performance for user utterances under load
                        - **Processing Time Spikes:** Direct indicator of 10+ second delays in utterance processing
                        - **Two-Stage Analysis:** Separates Redis timing from application processing for utterances
                        - **User Experience Impact:** Utterance key delays directly affect response times
                        
                        **Optimization Opportunities:**
                        - **Redis Timing Issues:** Check Redis server load and memory for utterance keys
                        - **Processing Delays:** Optimize AsyncLoop worker allocation for utterance handling
                        - **Thread Pool Management:** Eliminate processing locks in utterance key processing
                        - **Load Balancing:** Better distribution of utterance expiry events across workers
                        """)
                    
                    with st.expander("🔄 Event Loop & Redis Operations"):
                        st.write("""
                        **Event Loop Analysis:**
                        - **AsyncLoop Usage:** Distribution of operations across event loops
                        - **Load Balancing:** How well operations are distributed
                        - **Active Loops:** Number of AsyncLoops handling operations
                        
                        **Redis Operations Analysis:**
                        - **Operation Types:** SET, EXPIRE, MESSAGE operations
                        - **Key Operations:** Number of Redis key operations
                        - **Expiration Events:** Number of key expiration events
                        
                        **Optimization Indicators:**
                        - Uneven AsyncLoop distribution → Need better load balancing
                        - High Redis operations → Consider caching strategy optimization
                        - High expiration events → Check key TTL settings
                        """)
                    
                    # Download results
                    st.header("💾 Export Results")
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        # JSON export
                        json_str = json.dumps(results, indent=2, default=str)
                        st.download_button(
                            label="📄 Download JSON Report",
                            data=json_str,
                            file_name=f"sakura_analysis_fixed_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                            mime="application/json"
                        )
                    
                    with col2:
                        # CSV export for key metrics
                        try:
                            import io
                            csv_buffer = io.StringIO()
                            
                            # Create enhanced summary CSV
                            summary_data = {
                                'Metric': [
                                    'Call Starts', 'Call Ends', 'Call Messages', 'LLM API Calls', 'TTS API Calls',
                                    'Sakura Avg Response', 'Redis Operations', 'Event Loop Operations', 'Active AsyncLoops'
                                ],
                                'Value': [
                                    results['calls'].get('call_starts', 0),
                                    results['calls'].get('call_ends', 0),
                                    results['calls'].get('call_messages', 0),
                                    results['apis'].get('llm_api_calls', 0),
                                    results['apis'].get('tts_api_calls', 0),
                                    f"{results.get('sakura_response_timing', {}).get('avg_response_time', 0):.2f}s",
                                    results.get('event_loops_redis', {}).get('redis_operations', {}).get('total_operations', 0),
                                    results.get('event_loops_redis', {}).get('event_loop_stats', {}).get('total_operations', 0),
                                    len(results.get('event_loops_redis', {}).get('event_loop_stats', {}).get('operations_per_loop', {}))
                                ]
                            }
                            
                            df_summary = pd.DataFrame(summary_data)
                            csv_str = df_summary.to_csv(index=False)
                            
                            st.download_button(
                                label="📊 Download Fixed CSV Summary",
                                data=csv_str,
                                file_name=f"sakura_fixed_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                                mime="text/csv"
                            )
                        except Exception as e:
                            st.error(f"CSV export failed: {e}")
                    
                    if show_raw_data:
                        st.header("🔍 Raw Log Data (First 50KB)")
                        st.text(analyzer.log_content[:50000] + "..." if len(analyzer.log_content) > 50000 else analyzer.log_content)
                
                else:
                    st.error("❌ Analysis failed - no results generated")
            else:
                st.error("❌ Failed to load log file")
    
    else:
        st.info("👆 Select a log file source and click 'Analyze Logs' to begin")
        
        # Show enhanced analysis features
        st.header("🎯 Enhanced Analysis Features")
        
        analysis_features = {
            "📞 Call Metrics": [
                "Number of call starts/ends/messages",
                "Distinct transcriptions and frequency analysis",
                "CDR creation and correlation tracking",
                "User message analysis (empty vs data-filled)"
            ],
            "🤖 API Performance - ENHANCED": [
                "🧪 Test Mode Support: Mock LLM API vs Real LLM API analysis",
                "LLM API calls based on 'Calling call_gpt_stream' or '🧪 Using mock LLM API' patterns",
                "TTS API calls based on 'time taken to tts for first chunk' pattern", 
                "Response time analysis with actual log timing",
                "Performance degradation trend detection",
                "API mode detection and appropriate timing analysis"
            ],
            "⚡ Sakura Response Analysis - FIXED": [
                "End-to-end timing: call_message → Sending message response",
                "Real user experience measurement",
                "Processing time breakdown and analysis",
                "Response time trend with actual patterns"
            ],
            "🔄 Event Loop & Redis - ENHANCED": [
                "AsyncLoop-X pattern recognition and usage analysis",
                "🎯 Utterance Key Focus: Specific tracking of utterance key lifecycle",
                "Enhanced Redis key operations: SET DIRECTLY → expiry → processing",
                "Operation distribution across event loops",
                "Redis expiration event tracking with utterance key specialization"
            ],
            "⏰ Redis Utterance Key Timing - UPDATED": [
                "🎯 Utterance-specific key expiry time tracking (SET DIRECTLY → expiry message)",
                "Utterance key processing time analysis (expiry message → processing start)",
                "Accurate timing measurements for utterance keys only",
                "Expected vs actual expiry time analysis (target: 500ms)",
                "Two-stage performance analysis separating Redis and application timing",
                "Bottleneck identification for AsyncLoop and thread pool saturation",
                "Performance classification with avg/min/max statistics for utterance timing"
            ],
            "❌ Error Analysis - NEW": [
                "Comprehensive error extraction and categorization",
                "Error frequency analysis and trending",
                "Error type breakdown (ERROR, Exception, WARNING, etc.)",
                "Timeline analysis of error occurrence",
                "Top error messages by frequency",
                "Call ID correlation for error tracking",
                "Detailed error log with export functionality"
            ],
            "💬 User Query Analysis - NEW": [
                "Complete extraction of unique user queries from transcripts",
                "Query frequency analysis and ranking",
                "Query diversity metrics and assessment",
                "🧪 Test Mode vs Production Mode query processing indication",
                "LLM API call correlation with specific queries",
                "Call ID mapping for query traceability",
                "Query export for further analysis"
            ],
            "🧪 Test Mode Features - NEW": [
                "Toggle between Mock LLM API and Real LLM API analysis",
                "Automatic detection of test mode from log patterns",
                "Appropriate timing analysis based on API mode",
                "Mock API response time analysis (0.5-3.0s simulation)",
                "Test vs production comparison indicators",
                "API mode metadata tracking and display"
            ],
            "📊 Advanced Visualization": [
                "Multi-metric trend analysis with corrected data",
                "Load impact visualization",
                "Performance correlation analysis",
                "Real system health monitoring",
                "Error trend visualization",
                "Query frequency charts"
            ]
        }
        
        for category, features in analysis_features.items():
            with st.expander(category):
                for feature in features:
                    st.write(f"• {feature}")

if __name__ == "__main__":
    main()



