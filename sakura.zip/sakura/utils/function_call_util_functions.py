import json
import os
import random
import time
from math import radians, sin, cos, sqrt, atan2
from typing import Optional
from utils.redis_db_manager import redis_manager
import requests
from dotenv import load_dotenv
from requests.structures import CaseInsensitiveDict
from sklearn.metrics.pairwise import cosine_similarity
from models.redis_models import UserCallCDR, UserCallRecord
from config.dialog_location import locations
from config.service_centers_config import service_centers
from logger import get_logger
from utils.asana_utils import get_complaint_details, create_complaint, get_all_complaints, get_all_resolved_complaints, \
    get_all_incomplete_complaints
from controllers.audio_controller import  generate_audio_azure
from utils.utils import get_current_time_iso
from utils.scalable_cdr_manager import update_cdr_record_with_expiration
from utils.redis_hash_optimizer import RedisHashOptimizer
from utils.memory_cache_manager import get_user_call_record
from zoneinfo import ZoneInfo
from datetime import datetime, timedelta
from utils.alarm_utils import send_alarm, run_alarm_in_thread

logger = get_logger(__name__)

load_dotenv()
# Single Redis client for CDR operations only (DB=2)
redis_client = redis_manager.get_cdr_client()   # CDR operations (DB=2) 
cdr_hash_optimizer = RedisHashOptimizer(redis_client)  # All CDR operations use hash format only
COLLECTION_NAME = os.getenv("COLLECTION_NAME", "assistant_")
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
Google_Developer_Key = os.getenv("Google_Developer_Key")
News_Api_Key = os.getenv("News_Api_Key")
Weather_Api_Key = os.getenv("Weather_Api_Key")
BASE_PATH = os.getenv("BASE_PATH")
DIALOG_SL_CHECK_BALANCE_URL = os.getenv("DIALOG_SL_CHECK_BALANCE_URL")
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
jericho_get_busy_slots_url = os.getenv("JERICHO_GET_BUSY_SLOTS_URL")
days_to_add_for_checking_slots = int(os.getenv("BUSY_SLOTS_DAYS_TO_ADD", "2"))

PREDEFINED_NUMBERS = os.getenv("PREDEFINED_NUMBERS", "").split(",")

# Legacy environment variables - kept as fallback
perplexity_api_url = os.getenv("PERPLEXITY_API_URL")
perplexity_model_name = os.getenv("PERPLEXITY_MODEL_NAME")
perplexity_api_key = os.getenv("PERPLEXITY_API_KEY")

def get_perplexity_config(assistant_id: str):
    """Get Perplexity configuration from multi-client manager based on assistant_id"""
    try:
        # Local imports to avoid circular dependency
        from cache.assistant_configuration_cache import get_assistant_details_by_id
        from service.multi_client_config_service import multi_client_manager, get_op_co_key
        
        # Get operator and country from assistant configuration
        assistant_config = get_assistant_details_by_id(int(assistant_id))
        if not assistant_config:
            logger.warning(f"No assistant config found for assistant_id: {assistant_id}")
            return None, None, None
        
        operator = assistant_config.get('operator')
        country = assistant_config.get('country')
        
        if not operator or not country:
            logger.warning(f"Missing operator/country in assistant config for {assistant_id}")
            return None, None, None
        
        op_co = get_op_co_key(operator, country)
        perplexity_client = multi_client_manager.get_perplexity_client(op_co)
        
        if perplexity_client:
            logger.debug(f"Using multi-client Perplexity config for {op_co} (assistant: {assistant_id})")
            return perplexity_client.api_url, perplexity_client.api_key, perplexity_client.model
        else:
            logger.warning(f"No Perplexity client found for {op_co}, using fallback configuration")
            return None, None, None
            
    except Exception as e:
        logger.error(f"Error getting Perplexity config for assistant {assistant_id}: {e}")
        return None, None, None

geoapify_api_url= os.getenv("GEOAPIFY_API_URL")
geoapify_api_key = os.getenv("GEOAPIFY_API_KEY")

# CDR update function now uses scalable implementation

def safe_calculate_moving_average_util(current_avg: float, new_value: float, count: int, req_id: str = None) -> float:
    """
    Safely calculate moving average with zero division protection
    
    Args:
        current_avg: Current average value
        new_value: New value to add to the average
        count: Total count (question_count)
        req_id: Request ID for logging (optional)
    
    Returns:
        Updated moving average or the new_value if count is 0 or 1
    """
    try:
        if count <= 0:
            logger.warning(f"Zero or negative question_count ({count}) detected for req_id: {req_id}. Using new_value as average.")
            return new_value
        elif count == 1:
            # First calculation, return the new value
            return new_value
        else:
            # Standard moving average formula: ((avg * (n-1)) + new_value) / n
            return ((current_avg * (count - 1)) + new_value) / count
            
    except (ZeroDivisionError, TypeError, ValueError) as e:
        logger.error(f"Error calculating moving average for req_id {req_id}: {e}. Using new_value as fallback.")
        return new_value
    except Exception as e:
        logger.error(f"Unexpected error in moving average calculation for req_id {req_id}: {e}")
        return current_avg if current_avg is not None else new_value

def validate_and_fix_question_count_util(user_call_cdr_record, req_id: str = None) -> bool:
    """
    Validate and fix CDR record question_count to prevent division by zero
    
    Args:
        user_call_cdr_record: CDR record object
        req_id: Request ID for logging
        
    Returns:
        True if counts were valid, False if they were fixed
    """
    try:
        if hasattr(user_call_cdr_record, 'question_count'):
            if user_call_cdr_record.question_count <= 0:
                logger.warning(f"Invalid question_count ({user_call_cdr_record.question_count}) for req_id: {req_id}. Fixing to 1.")
                user_call_cdr_record.question_count = 1
                return False
        return True
    except Exception as e:
        logger.error(f"Error validating CDR counts for req_id {req_id}: {e}")
        if hasattr(user_call_cdr_record, 'question_count'):
            user_call_cdr_record.question_count = 1
        return False

async def disconnect_service(call_id, assistant_id, parameter=None):
    logger.info(f"[disconnecting call called for call_id ={call_id}, and assistant_id ={assistant_id}] Executing disconnect_service]")
    # PERFORMANCE FIX: Use memory cache instead of Redis for user record
    user_obj = get_user_call_record(str(call_id))
    if user_obj is None:
        return None
    voice_code = user_obj["voiceName"]
    assistant_id = user_obj["assistantId"]
    tts_style = user_obj["ttsStyle"]
    language_code = user_obj["languageCode"]
    
    # Generate TTS and convert to WAV file
    base64_transcript = generate_audio_azure(text=parameter, lang=language_code, voice_name=voice_code, tts_style=tts_style, assistant_id=assistant_id)
    
    # Convert to WAV file using TTS manager
    try:
        from service.pa_tts_manager import get_tts_manager
        tts_manager = get_tts_manager()
        if tts_manager:
            response_id = f"disconnect_{int(time.time() * 1000)}"
            wav_path = await tts_manager.convert_chunk_to_wav(
                base64_chunk=base64_transcript,
                call_id=call_id,
                response_id=response_id
            )
            logger.info(f"Converted disconnect TTS to WAV: {wav_path}")
            return {"####STOP####": wav_path}
        else:
            logger.warning("TTS manager not available, using base64 transcript")
            return {"####STOP####": base64_transcript}
    except Exception as e:
        logger.error(f"Failed to convert disconnect TTS to WAV: {e}")
        return {"####STOP####": base64_transcript}

async def handle_telemarketing_call(call_id, assistant_id, parameter=None):
    logger.info(f"[handle_telemarketing_call called for call_id ={call_id}, and assistant_id ={assistant_id}]")
    # PERFORMANCE FIX: Use memory cache instead of Redis for user record
    user_obj = get_user_call_record(str(call_id))
    if user_obj is None:
        return None
    voice_code = user_obj["voiceName"]
    assistant_id = user_obj["assistantId"]
    tts_style = user_obj["ttsStyle"]
    language_code = user_obj["languageCode"]
    
    # Generate TTS and convert to WAV file
    base64_transcript = generate_audio_azure(text=parameter, lang=language_code, voice_name=voice_code, tts_style=tts_style, assistant_id=assistant_id)
    
    # Convert to WAV file using TTS manager
    try:
        from service.pa_tts_manager import get_tts_manager
        tts_manager = get_tts_manager()
        if tts_manager:
            response_id = f"telemarketing_{int(time.time() * 1000)}"
            wav_path = await tts_manager.convert_chunk_to_wav(
                base64_chunk=base64_transcript,
                call_id=call_id,
                response_id=response_id
            )
            logger.info(f"Converted telemarketing TTS to WAV: {wav_path}")
            return {"####TELE_MARKETING####": wav_path}
        else:
            logger.warning("TTS manager not available, using base64 transcript")
            return {"####TELE_MARKETING####": base64_transcript}
    except Exception as e:
        logger.error(f"Failed to convert telemarketing TTS to WAV: {e}")
        return {"####TELE_MARKETING####": base64_transcript}

def get_busy_slots(call_id, assistant_id, parameter=None):
    logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] Executing get_busy_slots with parameter: {parameter}")
    url = jericho_get_busy_slots_url
    # PERFORMANCE FIX: Use memory cache instead of Redis for user record
    user_call_record_data = get_user_call_record(str(call_id))
    if user_call_record_data is None:
        return None
    user_call_record = UserCallRecord(**user_call_record_data)
    DATE_FORMAT = "%Y-%m-%dT%H:%M:%S"
    start_time = None
    end_time = None
    if parameter and isinstance(parameter, dict):
        start_time = parameter.get("startTime")
        end_time = parameter.get("endTime")
    if start_time and (not end_time or end_time.strip() == ""):
        start_dt = datetime.fromisoformat(start_time)
        end_dt = start_dt + timedelta(days=days_to_add_for_checking_slots)
        end_dt = end_dt.replace(hour=23, minute=59, second=59, microsecond=0)
        end_time = end_dt.strftime(DATE_FORMAT)
    if not start_time or start_time.strip() == "":
        start_dt = datetime.fromisoformat(get_current_time_iso())
        start_time = start_dt.strftime(DATE_FORMAT)
        end_dt = start_dt + timedelta(days=days_to_add_for_checking_slots)
        end_dt = end_dt.replace(hour=23, minute=59, second=59, microsecond=0)
        end_time = end_dt.strftime(DATE_FORMAT)
    payload = {
        "msisdn": user_call_record.bParty,
        "aparty": user_call_record.aParty,
        "startTime": start_time,
        "endTime": end_time
    }
    try:
        logger.info(f"Sending request to Jericho get_busy_slots - URL: {url}, Payload: {json.dumps(payload)}")
        response = requests.post(url, json=payload)
        run_alarm_in_thread(send_alarm(alarm_type='Jericho_get_busy_API', remarks="Jericho API working fine", status='clear', assistant_id=user_call_record.assistantId))
        response_data = response.json()
        logger.info(f"response received from jericho get_busy_slots api ----> {response_data}")
        return json.dumps(response_data["data"]["busyIntervals"])
    except Exception as e:
        logger.error(f"error occurred in get_busy_slots function call -----> {e}", exc_info=True)
        run_alarm_in_thread(send_alarm(alarm_type='Jericho_get_busy_API', remarks=str(e), status='raise', assistant_id=user_call_record.assistantId))
        return json.dumps({"type": "text", "text": "Error: Unable to get busy time slots"})

def web_search(call_id, assistant_id, query: str):
    logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] Executing web_search with query: {query}")
    
    # Try to get configuration from multi-client manager
    url, api_key, model_name = get_perplexity_config(str(assistant_id))
    
    # Fallback to environment variables if multi-client config not available
    if not url or not api_key:
        logger.info(f"Using fallback Perplexity configuration for assistant {assistant_id}")
        url = perplexity_api_url
        model_name = perplexity_model_name
        api_key = perplexity_api_key
        
        if not url or not api_key:
            logger.error(f"No Perplexity configuration available for assistant {assistant_id}")
            return json.dumps("Perplexity service unavailable for your region")
    
    # Use configured model or fallback model
    if not model_name:
        model_name = perplexity_model_name or "llama-3.1-sonar-small-128k-online"
    
    logger.info(f"Using Perplexity config: URL={url}, Model={model_name} for assistant {assistant_id}")
    payload = {
        "model": model_name,
        "messages": [
            {
                "role": "system",
                "content": "You have to answer each and every question , be precise and concise and answer in not more than 50 words"
            },
            {
                "role": "user",
                "content": query
            }
        ],
        "max_tokens": 200,
    }
    headers = {
        "accept": "application/json",
        "content-type": "application/json",
        "authorization": f"Bearer {api_key}"
    }
    start_time = time.time()
    call_cdr_key = f"{call_id}_cdr"
    try:
        try:
            response = requests.post(url, json=payload, headers=headers)
            run_alarm_in_thread(send_alarm(alarm_type='Perplexity_API', remarks="Perplexity API working fine", status='clear', assistant_id=assistant_id))
        except Exception as e:
            run_alarm_in_thread(send_alarm(alarm_type='Perplexity_API', remarks=str(e), status='raise'))
            raise
        logger.info(f"time taken by perplexity api ----> {time.time() - start_time} \n {response.text}")
        # CRITICAL FIX: Use hash retrieval for CDR data instead of JSON
        cdr_data = get_cdr_data(call_id)
        if cdr_data is None:
            logger.error(f"No CDR found for call_id: {call_id} in web_search")
            return None
        user_call_cdr_record = UserCallCDR(**cdr_data)
        user_call_cdr_record.total_web_response_time += time.time() - start_time
        user_call_cdr_record.total_perplexity_queries += 1
        
        # Validate question_count to prevent zero division
        validate_and_fix_question_count_util(user_call_cdr_record, call_id)
        
        # Safe calculation for avg_web_response_time
        web_response_time = time.time() - start_time
        user_call_cdr_record.avg_web_response_time = safe_calculate_moving_average_util(
            current_avg=user_call_cdr_record.avg_web_response_time,
            new_value=web_response_time,
            count=user_call_cdr_record.question_count,
            req_id=call_id
        )
        # Force immediate update for web search performance metrics
        update_cdr_record_with_expiration(call_id, user_call_cdr_record, force_immediate=True)
        response_data = response.json()
        assistant_content = response_data['choices'][0]['message']['content']
        logger.info(f"response received from perplexity search ----> {assistant_content}")
        return json.dumps(assistant_content)
    except Exception as e:
        logger.error(f"error occured in perplexity api -----> {e}",exc_info=True)


def get_time(call_id, assistant_id, time_zone: str):
    logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] Executing get_time with time_zone: {time_zone}")
    try:
        time_in_tz = datetime.now(ZoneInfo(time_zone))
        return time_in_tz.strftime('%Y-%m-%d %H:%M:%S')

    except Exception as err:
        logger.error(f"An unexpected error occurred in get_time function: {err}",exc_info=True)
        raise

    return "Error: Unable to get time"


def play_story(call_id, assistant_id, story_name):
    logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] Executing play_story with story_name: {story_name}")
    try:
        audio_path = ""
        audio_id = ""
        if story_name.lower() == "bude_siti" or story_name.lower() == "bude siti":
            audio_id = "1"
            audio_path = f"{BASE_PATH}/prompts/stories/bude_siti_complete.wav"
        elif story_name.lower() == "hantu_koshan" or story_name.lower() == "hantu koshan" or story_name.lower() == "hantu kosan" or story_name.lower() == "hantu_kosan":
            audio_id = "2"
            audio_path = f"{BASE_PATH}/prompts/stories/hantu_koshan_complete.wav"
        # add_audio_to_queue()

        data = {"type": "audio", "path": audio_path, "audio_id": audio_id, "status": f"playing {story_name} "}

        return json.dumps(data)
    except Exception as e:
        logger.error(f"Error in play_story: {e}",exc_info=True)
        return json.dumps({"type": "text", "text": "Error: Unable to play story"})


def play_summary(call_id, assistant_id, story):
    logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] Executing play_summary with story: {story}")
    try:
        audio_path = ""
        audio_id = ""
        summary = ""
        if story.lower() == "bude_siti" or story.lower() == "bude siti":
            audio_id = "3"
            audio_path = f"{BASE_PATH}/prompts/stories/bude_siti_summary.wav"
            summary = "Tentu saya punya cerita horor tentang 'Bude Siti'. Bude Siti, tetangga gue, keluar dari rumah gue dengan melayang.. Ternyata dia baru aja meninggal karena kecelakaan, dan adik gue gak bisa bedain Bude Siti udah jadi hantu.."
        elif story.lower() == "hantu_koshan" or story.lower() == "hantu koshan" or story.lower() == "hantu kosan" or story.lower() == "hantu_kosan":
            audio_id = "4"
            audio_path = f"{BASE_PATH}/prompts/stories/hantu_koshan_summary.wav"
            summary = "Saya pasti punya cerita horor tentang 'Hantu Koshan'. Ada hantu yang selalu mengintip dari jendela kamar mandiku, di kosan, badannya hancur dan mukanya gosong.",

        return json.dumps(
            {"type": "audio", "path": audio_path, "audio_id": audio_id, "status": f"summary played{summary}"})
    except Exception as e:
        logger.error(f"Error in play_summary: {e}",exc_info=True)
        return json.dumps({"type": "text", "text": "Error: Unable to play summary"})


def get_weather(call_id, assistant_id, location: str):
    logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] Executing get_weather with location: {location}")
    
    # Try to get configuration from multi-client manager
    url, api_key, model_name = get_perplexity_config(str(assistant_id))
    
    # Fallback to environment variables if multi-client config not available
    if not url or not api_key:
        logger.info(f"Using fallback Perplexity configuration for assistant {assistant_id}")
        url = perplexity_api_url
        model_name = perplexity_model_name
        api_key = perplexity_api_key
        
        if not url or not api_key:
            logger.error(f"No Perplexity configuration available for assistant {assistant_id}")
            return json.dumps("Weather service unavailable for your region")
    
    # Use configured model or fallback model
    if not model_name:
        model_name = perplexity_model_name or "llama-3.1-sonar-small-128k-online"
    
    logger.info(f"Using Perplexity config: URL={url}, Model={model_name} for assistant {assistant_id}")

    payload = {
        "model": model_name,
        "messages": [
            {
                "role": "system",
                "content": "You have to answer each and every question , be precise and concise. respond within 50 words",
            },
            {"role": "user", "content": f"weather of {location}"},
        ],
        "max_tokens": 200,
    }
    headers = {
        "accept": "application/json",
        "content-type": "application/json",
        "authorization": f"Bearer {api_key}",
    }

    try:
        response = requests.post(url, json=payload, headers=headers)
        run_alarm_in_thread(send_alarm(alarm_type='get_weather API', remarks="Weather API working fine", status='clear', assistant_id=assistant_id))
    except Exception as e:
        logger.error(f"Exception in get_weather function call:{e}",exc_info=True)
        run_alarm_in_thread(send_alarm(alarm_type='get_weather API', remarks=str(e), status='raise', assistant_id=assistant_id))
        raise
    logger.debug(response.text)

    response_data = response.json()
    # Accessing the 'content' of the assistant's message
    assistant_content = response_data["choices"][0]["message"]["content"]

    return json.dumps(assistant_content)


def check_balance(call_id, assistant_id, mobile_number):
    logger.info(
        f"[call_id={call_id}, assistant_id={assistant_id}] Executing check_balance with mobile_number: {mobile_number}")
    try:
        mobile_number = mobile_number.replace("-", "")
        if mobile_number in PREDEFINED_NUMBERS:
            # Return a random balance between 30 and 100 rupees
            return f"Balance: {random.randint(30, 100)} rupees"

        url = DIALOG_SL_CHECK_BALANCE_URL
        payload = {
            "message": {
                "type": "function-call",
                "call": "",
                "functionCall": {
                    "name": "checkBalance",
                    "parameters": {
                        "mobileNumber": mobile_number
                    }
                }
            }
        }

        logger.debug(f"payload ----> {payload}")
        # Sending the POST request
        response = requests.post(url, json=payload)
        response.raise_for_status()  # Raise an exception for HTTP errors

        logger.debug(f"response: status code = {response.status_code},json={response.json}")
        # Parsing the JSON response
        result = response.json().get("result")
        logger.info(f"result ----> {result}")
        if result:
            return f"Balance: {result}"
        else:
            return "Failed to retrieve balance. Please check the mobile number and try again."

    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred in check_balance(): {http_err}")
        return "Failed to retrieve balance. Please check the mobile number and try again."
    except requests.exceptions.ConnectionError as conn_err:
        logger.error(f"Connection error occurred in check_balance(): {conn_err}")
        return "Failed to retrieve balance. Please check the mobile number and try again."
    except requests.exceptions.Timeout as timeout_err:
        logger.error(f"Timeout error occurred in check_balance(): {timeout_err}")
        return "Failed to retrieve balance. Please check the mobile number and try again."
    except requests.exceptions.RequestException as req_err:
        logger.error(f"An error occurred in check_balance(): {req_err}")
        return "Failed to retrieve balance. Please check the mobile number and try again."
    except json.JSONDecodeError:
        logger.error("Failed to parse the response as JSON.")
        return "Failed to retrieve balance. Please check the mobile number and try again."
    except Exception as err:
        logger.error(f"An unexpected error occurred in check_balance(): {err}")
        return "Failed to retrieve balance. Please check the mobile number and try again."


def haversine(coordinate1, coordinate2):
    lat1 = coordinate1[0]
    lon1 = coordinate1[1]
    lat2 = coordinate2[0]
    lon2 = coordinate2[1]
    R = 6371.0  # Earth radius in kilometers
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)
    a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = R * c
    return distance


def nearest_location(location_coordinates):
    # location_coordinates = ast.literal_eval(location_coordinates)
    D = 1000000.000
    result = ""
    # Iterating over the dictionary
    for coordinates, address in service_centers.items():
        d = haversine(location_coordinates, coordinates)
        if d < D:
            D = d
            result = address
    return result


def geocoding(call_id, assistant_id, address):
    logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] Executing geocoding with address: {address}")
    base_url = f"{geoapify_api_url}/geocode/search"
    params = {
        'text': address,
        'lang': 'en',
        'limit': 5,
        'format': 'json',
        'apiKey': geoapify_api_key
    }

    response = requests.get(base_url, params=params)

    result = None

    if response.status_code == 200:
        data = response.json()
        if data['results']:
            latitude = data['results'][0]['lat']
            longitude = data['results'][0]['lon']
            result = (latitude, longitude)
            return nearest_location(result)
        else:
            return result
    else:
        return result


def geolocation():
    url = f"{geoapify_api_url}/ipinfo?&apiKey={geoapify_api_key}"

    # Set headers
    headers = CaseInsensitiveDict()
    headers["Accept"] = "application/json"

    # Make the GET request
    resp = requests.get(url, headers=headers)

    # Initialize the result dictionary
    result = None

    # Check the response status code
    if resp.status_code == 200:
        data = resp.json()
        # print(data)
        if 'location' in data:
            # Extract latitude and longitude
            latitude = data['location']['latitude']
            longitude = data['location']['longitude']
            result = (latitude, longitude)
            return nearest_location(result)
        else:
            return result
    else:
        logger.error(f"Error: Unable to fetch data. Status code: {resp.status_code}")
        return result


def get_nearest_service_center(call_id, assistant_id, location):
    logger.info(
        f"[call_id={call_id}, assistant_id={assistant_id}] Executing get_nearest_service_center with location: {location}")
    try:
        outlets = locations.get("outlets", None)
        service_center = locations.get("service_center", None)

        list_of_outlets_service_center = f"Dialog Outlets: {outlets} \n Dialog Bill Payment Center: {service_center}"

        return list_of_outlets_service_center

    except Exception as e:
        logger.error(f"Error in get_nearest_service_center: {e}",exc_info=True)
        return "Error: Unable to get nearest service center"


def get_balance(call_id, assistant_id, phone_number="123456789"):
    logger.info(
        f"[call_id={call_id}, assistant_id={assistant_id}] Executing get_balance with phone_number: {phone_number}")
    return f"The balance for {phone_number} is {random.uniform(0, 100)}"


def check_network_status(mobile_number, location=None):
    return json.dumps({
        "mobile_number": mobile_number,
        "location": location if location else "Default Area",
        "network_status": "no_issues",
        "last_outage": "2024-10-10",
        "outage_duration": "2 hours"
    })


def verify_security_questions(**args):
    return json.dumps({
        "mobile_number": args.get('mobile_number', ''),
        "verification_status": "success",
        "security_questions_passed": True
    })


def get_cdr_data(call_id: str) -> dict:
    """
    Retrieve CDR data from Redis using hash format only
    Returns dict or None if not found
    """
    if cdr_hash_optimizer:
        cdr_data = cdr_hash_optimizer.get_cdr_hash(call_id)
        if cdr_data:
            return cdr_data
        else:
            logger.warning(f"No CDR data found for call_id: {call_id}")
            return None
    
    logger.error(f"CDR hash optimizer not available for call_id: {call_id}")
    return None

async def use_cached(call_id: str, assistant_id: str, vector_id: str, reason: str = "", cached_wav_path: str = ""):
    """
    Handle use_cached function call from Tier 1 and Tier 2.
    This function retrieves the cached WAV file path and returns it for socket communication.
    
    Args:
        call_id: Call ID
        assistant_id: Assistant ID
        vector_id: Vector DB entry ID
        reason: Reason for using cached response
        cached_wav_path: Path to cached WAV file
        
    Returns:
        Dictionary with special key for socket communication
    """
    try:
        logger.info(f"Use cached for call {call_id}, vector_id: {vector_id}, reason: {reason}")
        
        # If cached_wav_path is provided, use it directly
        if cached_wav_path and os.path.exists(cached_wav_path):
            logger.info(f"Using provided cached WAV path: {cached_wav_path}")
            # Get the response text from vector DB for message update
            try:
                from service.pa_three_tier_service import get_three_tier_service
                three_tier_service = get_three_tier_service()
                if three_tier_service:
                    user_obj = get_user_call_record(str(call_id))
                    voice_name = user_obj.get("voiceName", "en-US-AvaNeural") if user_obj else "en-US-AvaNeural"
                    vector_entry = await three_tier_service.vector_manager.search_by_vector_id(
                        vector_id=vector_id,
                        voice_name=voice_name
                    )
                    if vector_entry:
                        metadata = vector_entry.get('metadata', {})
                        response_text = metadata.get('response', '')
                        return {"####USE_CACHED####": cached_wav_path, "response_text": response_text}
            except Exception as e:
                logger.error(f"Error getting response text for cached response: {e}")
            # Return WAV file path directly instead of base64
            return {"####USE_CACHED####": cached_wav_path}
        
        # Try to retrieve TTS file path from vector database
        try:
            from service.pa_three_tier_service import get_three_tier_service
            three_tier_service = get_three_tier_service()
            if three_tier_service:
                # Get user call record to determine voice code
                user_obj = get_user_call_record(str(call_id))
                voice_name = user_obj.get("voiceName", "en-US-AvaNeural") if user_obj else "en-US-AvaNeural"
                
                # Search for the vector entry to get the TTS file path
                vector_entry = await three_tier_service.vector_manager.search_by_vector_id(
                    vector_id=vector_id,
                    voice_name=voice_name
                )
                
                if vector_entry:
                    metadata = vector_entry.get('metadata', {})
                    tts_file_path = metadata.get('tts_file_path', '')
                    
                    if tts_file_path and os.path.exists(tts_file_path):
                        logger.info(f"Retrieved TTS file path from vector DB: {tts_file_path}")
                        # Return WAV file path directly instead of base64
                        return {"####USE_CACHED####": tts_file_path}
                    else:
                        logger.warning(f"TTS file path from vector DB is empty or file doesn't exist: {tts_file_path}")
                else:
                    logger.warning(f"Vector entry not found for vector_id: {vector_id}")
        except Exception as e:
            logger.error(f"Error retrieving TTS file path from vector DB: {e}")
        
        # If we can't retrieve the TTS file path, generate TTS for the cached response
        logger.warning(f"No cached WAV path available for vector_id: {vector_id}, generating TTS for cached response")
        
        try:
            # Get the cached response text from vector DB
            from service.pa_three_tier_service import get_three_tier_service
            three_tier_service = get_three_tier_service()
            if three_tier_service:
                # Get user call record to determine voice code
                user_obj = get_user_call_record(str(call_id))
                voice_name = user_obj.get("voiceName", "en-US-AvaNeural") if user_obj else "en-US-AvaNeural"
                
                # Search for the vector entry to get the response text
                vector_entry = await three_tier_service.vector_manager.search_by_vector_id(
                    vector_id=vector_id,
                    voice_name=voice_name
                )
                
                if vector_entry:
                    metadata = vector_entry.get('metadata', {})
                    cached_response = metadata.get('response', '')
                    
                    if cached_response:
                        logger.info(f"Generating TTS for cached response: {cached_response[:50]}...")
                        
                        # Generate TTS for the cached response
                        base64_transcript = generate_audio_azure(
                            text=cached_response, 
                            lang=user_obj.get("languageCode", "en-US"), 
                            voice_name=voice_code, 
                            tts_style=user_obj.get("ttsStyle", "chat"), 
                            assistant_id=assistant_id
                        )
                        
                        # Convert to WAV file using TTS manager
                        try:
                            from service.pa_tts_manager import get_tts_manager
                            tts_manager = get_tts_manager()
                            if tts_manager:
                                response_id = f"cached_{int(time.time() * 1000)}"
                                wav_path = await tts_manager.convert_chunk_to_wav(
                                    base64_chunk=base64_transcript,
                                    call_id=call_id,
                                    response_id=response_id
                                )
                                logger.info(f"Generated TTS for cached response: {wav_path}")
                                
                                # Update the TTS file path in vector DB for future use
                                try:
                                    success = await three_tier_service.update_tts_file_path(
                                        vector_id=vector_id,
                                        tts_file_path=wav_path,
                                        voice_name=voice_name
                                    )
                                    if success:
                                        logger.info(f"Updated TTS file path for cached response vector ID {vector_id}: {wav_path}")
                                    else:
                                        logger.warning(f"Failed to update TTS file path for cached response vector ID {vector_id}")
                                except Exception as e:
                                    logger.error(f"Error updating TTS file path for cached response: {e}")
                                
                                # Return WAV file path directly
                                return {"####USE_CACHED####": wav_path, "response_text": cached_response}
                            else:
                                logger.warning("TTS manager not available for cached response, using base64 transcript")
                                return {"####USE_CACHED####": base64_transcript, "response_text": cached_response}
                        except Exception as e:
                            logger.error(f"Failed to convert cached response TTS to WAV: {e}")
                            return {"####USE_CACHED####": base64_transcript, "response_text": cached_response}
                    else:
                        logger.error(f"No cached response text found for vector_id: {vector_id}")
                else:
                    logger.error(f"Vector entry not found for cached response vector_id: {vector_id}")
        except Exception as e:
            logger.error(f"Error generating TTS for cached response: {e}")
        
        # If all else fails, return error
        logger.error(f"No cached WAV path available for vector_id: {vector_id}")
        return None
        
    except Exception as e:
        logger.error(f"Error in use_cached: {e}")
        return None

async def fresh_generation(call_id: str, assistant_id: str, response: str, confidence_score: float = 0.0, llm_client=None, model_name: str = "gpt-4"):
    """
    Handle fresh generation from Tier 2 LLM.
    This function processes the fresh response generated by Tier 2 LLM,
    generates TTS, and returns the audio transcript for socket communication.
    
    Args:
        call_id: Call ID
        assistant_id: Assistant ID
        response: The fresh response text generated by LLM
        
    Returns:
        Dictionary with special key for socket communication
    """
    try:
        logger.info(f"Fresh generation for call {call_id}: {response[:50]}...")
        
        # Get user call record to access voice configuration
        user_obj = get_user_call_record(str(call_id))
        if user_obj is None:
            logger.error(f"No user call record found for call_id: {call_id}")
            return None
            
        # Extract voice configuration
        voice_code = user_obj["voiceName"]
        tts_style = user_obj["ttsStyle"]
        language_code = user_obj["languageCode"]
        
        # Generate TTS for the fresh response
        base64_transcript = generate_audio_azure(
            text=response, 
            lang=language_code, 
            voice_name=voice_code, 
            tts_style=tts_style, 
            assistant_id=assistant_id
        )
        
        # Convert to WAV file using TTS manager
        wav_path = None
        try:
            from service.pa_tts_manager import get_tts_manager
            tts_manager = get_tts_manager()
            if tts_manager:
                response_id = f"fresh_{int(time.time() * 1000)}"
                wav_path = await tts_manager.convert_chunk_to_wav(
                    base64_chunk=base64_transcript,
                    call_id=call_id,
                    response_id=response_id
                )
                if wav_path and wav_path.endswith('.wav'):
                    transcript = wav_path
                    logger.info(f"Converted fresh generation TTS to WAV: {wav_path}")
                else:
                    logger.warning(f"TTS conversion returned invalid path: {wav_path}, using base64")
                    transcript = base64_transcript
                    wav_path = None
            else:
                logger.warning("TTS manager not available, using base64 transcript")
                transcript = base64_transcript
        except Exception as e:
            logger.error(f"Failed to convert fresh generation TTS to WAV: {e}")
            transcript = base64_transcript
            wav_path = None
        
        # Cache the fresh response metadata for learning at call end
        try:
            # Extract user query from messages
            user_query = ""
            messages = user_obj.get("llmMessage", [])
            if messages:
                for message in reversed(messages):
                    if message.get("role") == "user":
                        user_query = message.get("content", "")
                        break
            
            # Create metadata for caching with the actual TTS file path
            logger.debug(f"Creating metadata with confidence_score: {confidence_score}")
            metadata = {
                "assistant_id": str(assistant_id),
                "call_id": str(call_id),
                "service_type": "Personal_Assistant",
                "voice_code": voice_code,
                "tts_style": tts_style,
                "provider": user_obj.get("provider", ""),
                "gender": user_obj.get("gender", ""),
                "is_translate": user_obj.get("isTranslate", False),
                "response_id": f"resp_{int(time.time() * 1000)}",
                "tier_used": 3,  # Tier 3 fresh generation
                "confidence_score": confidence_score,  # Use the passed confidence score
                "generation_time": 0.0,
                "token_usage": {
                    "prompt_tokens": 0,
                    "completion_tokens": 0,
                    "total_tokens": 0
                },
                "model_name": model_name,
                "query": user_query,
                "response": response,
                "tts_file_path": wav_path if wav_path else "",  # Use actual WAV path if available
                "timestamp": time.time()
            }
            
            # Store LLM client separately for context analysis (not in cache)
            metadata_for_analysis = metadata.copy()
            metadata_for_analysis["llm_client"] = llm_client
            
            logger.info(f"Metadata created for vector DB - Confidence: {metadata['confidence_score']}, Query: '{user_query[:30]}...', TTS: {wav_path}")
            
            # Add to vector metadata cache
            if "vector_metadata_cache" not in user_obj:
                user_obj["vector_metadata_cache"] = []
            
            user_obj["vector_metadata_cache"].append(metadata)
            
            # Update user call record in memory cache
            from utils.memory_cache_manager import set_user_call_record
            set_user_call_record(str(call_id), user_obj)
            
            logger.info(f"Cached fresh generation metadata for call end storage: {call_id}")
        except Exception as e:
            logger.error(f"Failed to cache fresh generation metadata: {e}")
        
        # Return with special key for fresh generation (similar to ####STOP#### for disconnect)
        return {"####FRESH_GENERATION####": transcript, "response_text": response}
        
    except Exception as e:
        logger.error(f"Error in fresh_generation: {e}")
        return None

available_functions = {
    "web_search": web_search,
    "get_time": get_time,
    "play_story": play_story,
    "play_summary": play_summary,
    "get_weather": get_weather,
    "check_balance": check_balance,
    "geocoding": geocoding,
    "get_nearest_service_center": get_nearest_service_center,
    "get_balance": get_balance,
    "get_complaint_details": get_complaint_details,
    "create_complaint": create_complaint,
    "get_all_complaints": get_all_complaints,
    "get_all_resolved_complaints": get_all_resolved_complaints,
    "get_all_incomplete_complaints": get_all_incomplete_complaints,
    "check_network_status": verify_security_questions,
    "check_network_status": check_network_status,
    "disconnect_service": disconnect_service,
    "handle_telemarketing_call": handle_telemarketing_call,
    "get_busy_slots": get_busy_slots,
    "use_cached": use_cached,
    "fresh_generation": fresh_generation,
}


async def execute_function_call(function_name, arguments, call_id, assistant_id, confidence_score=0.0, llm_client=None, model_name: str = "gpt-4"):
    # Get CDR data using hash format
    cdr_data = get_cdr_data(call_id)
    if cdr_data is None:
        logger.error(f"No CDR found for call_id: {call_id} in execute_function_call")
        return None
    user_call_cdr_record = UserCallCDR(**cdr_data)
    try:
        logger.info(
            f"[call_id={call_id}, assistant_id={assistant_id}] received arguments, function_name ----> {function_name}, function_arguments ----> {arguments}")
        function = available_functions.get(function_name, None)
        if function:
            arguments = json.loads(arguments)
            logger.debug(f"[call_id={call_id}, assistant_id={assistant_id}] parsed arguments ----> {arguments}")
            if(function_name =="disconnect_service"):
                results = await disconnect_service(call_id=call_id, assistant_id=assistant_id, parameter=arguments["parameter"])
                logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] results returned from function ----> {list(results.keys())}")
            elif(function_name == "handle_telemarketing_call"):
                results = await handle_telemarketing_call(call_id=call_id, assistant_id=assistant_id, parameter=arguments["parameter"])
                logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] results returned from function ----> {list(results.keys())}")
            elif(function_name == "get_busy_slots"):
                results = get_busy_slots(call_id=call_id, assistant_id=assistant_id, parameter=arguments)
                logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] results returned from function ----> {results}")
            elif(function_name == "use_cached"):
                results = await use_cached(call_id=call_id, assistant_id=assistant_id, vector_id=arguments["vector_id"], reason=arguments.get("reason", ""), cached_wav_path=arguments.get("cached_wav_path", ""))
                logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] results returned from use_cached ----> {results}")
            elif(function_name == "fresh_generation"):
                results = await fresh_generation(call_id=call_id, assistant_id=assistant_id, response=arguments["response"], confidence_score=confidence_score, llm_client=llm_client, model_name=model_name)
                logger.info(f"[call_id={call_id}, assistant_id={assistant_id}] results returned from fresh_generation ----> {results}")
            else:
                results = function(call_id=call_id, assistant_id=assistant_id, **arguments)
                logger.info(
                    f"[call_id={call_id}, assistant_id={assistant_id}] results returned from function ----> {results}")

        else:
            results = f"Error: function {function_name} does not exist"
            logger.warning(f"[call_id={call_id}, assistant_id={assistant_id}] {results}")
        return results
    except Exception as e:
        user_call_cdr_record.total_function_call_failure += 1
        logger.error(f"[call_id={call_id}, assistant_id={assistant_id}] Error in execute_function_call: {e}",exc_info=True)

    # if function_name == "disconnect_service":
    #     results = disconnect_service(call_id, assistant_id)
    # else:
    #     results = function(call_id=call_id, assistant_id=assistant_id, **arguments)