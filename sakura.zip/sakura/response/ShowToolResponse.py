from response.showGenericResponse import GenericResponse
from typing import List,Optional
from pydantic import BaseModel
from datetime import datetime

class ToolResponseItem:
    def __init__(self,id,name, description, createdBy, createdOn,updateBy,updateOn, status,state, defination):
        self.id = id
        self.name = name
        self.description = description
        self.createdBy= createdBy
        self.createdOn= createdOn
        self.updateBy=updateBy
        self.updateOn=updateOn
        self.status = status
        self.state = state
        self.defination = defination
    def __repr__(self):
        return f"ToolResponseItem(tooId={self.id}, toolName={self.name}, toolDescription={self.description},createdBy={self.createdBy}, createdOn={self.createdOn},updateBy={self.updateBy},updateOn={self.updateOn},status={self.status},state={self.state}, defination={self.defination})"

class ToolListResponse(GenericResponse):
    def __init__(self, status, statusCode, message, data: list[ToolResponseItem]):
        super().__init__(statusCode, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, statusCode: {self.statusCode}, message: {self.message}, data: {self.data}"
    


class shortToolInfo:
    def __init__(self, id, name, description, status):
        self.id = id
        self.name = name
        self.description= description
        self.status = status
    
    def __repr__(self):
        return f"shortToolInfo(id:{self.id}, name : {self.name}, description:{self.description},status:{self.status})"


class UpdateToolResponse(GenericResponse):
    def __init__(self, statusCode, status, message, data : shortToolInfo):
        super().__init__(statusCode, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, statusCode: {self.statusCode}, message: {self.message}, data = {self.data}"
    
class UpdateToolDescriptionResponse(GenericResponse):
    def __init__(self, statusCode, status, message, data : shortToolInfo):
        super().__init__(statusCode, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, statusCode: {self.statusCode}, message: {self.message}, data = {self.data}"