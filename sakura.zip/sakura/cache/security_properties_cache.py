from typing import Dict, Optional, List
from logger import get_logger
from repository.security_properties_repository import get_all_security_properties
import time
import os
from sqlalchemy.exc import OperationalError, DisconnectionError, DatabaseError, TimeoutError
from utils.alarm_utils import send_alarm, run_alarm_in_thread
from dotenv import load_dotenv

load_dotenv()

country = os.getenv('DEFAULT_COUNTRY')
operator = os.getenv('DEFAULT_OPERATOR')

# In-memory cache variables
security_properties_cache: Dict[str, Dict[str, str]] = {}

logger = get_logger(__name__)

def load_security_properties_cache():
    """
    Load security properties from global DB into memory cache as dict.
    Implements retry mechanism for database connection issues.
    Only sends alarms after all retries are exhausted.
    """
    from config.global_database_config import GlobalSessionLocal
    global security_properties_cache

    max_retries = 3
    delay = 1

    for attempt in range(max_retries):
        try:
            logger.info(f"Loading security properties cache from global DB, attempt {attempt + 1}/{max_retries}")

            db = GlobalSessionLocal()
            try:
                settings = get_all_security_properties(db)

                # Check if we actually got data
                if not settings:
                    logger.warning("No security properties found in global database")
                    # Clear existing cache
                    security_properties_cache = {}
                    logger.info("Security properties cache cleared due to no data available")
                    return

                # Convert SQLAlchemy objects to dict and index by operator_country
                security_properties_cache = {}
                for setting in settings:
                    key = f"{setting.operator}_{setting.country}"
                    if key not in security_properties_cache:
                        security_properties_cache[key] = {}
                    security_properties_cache[key][setting.prop_key] = setting.value

                logger.info(f"Security properties cache loaded successfully from global DB. {len(security_properties_cache)} operator_country combinations cached.")
                return  # Success - exit the retry loop

            finally:
                db.close()

        except (OperationalError, DisconnectionError, DatabaseError, TimeoutError) as e:
            error_type = type(e).__name__
            logger.warning(f"Global database connection error loading security properties cache (attempt {attempt + 1}/{max_retries}): {error_type}: {e}")

            if attempt < max_retries - 1:
                logger.info(f"Retrying in {delay * (2 ** attempt)}s... (attempt {attempt + 1}/{max_retries})")
                time.sleep(delay * (2 ** attempt))
                continue
            else:
                # All retries failed - clear cache and log error
                logger.error(f"All {max_retries} attempts failed due to global database connection issues. Clearing security properties cache.")
                security_properties_cache = {}
                logger.info("Security properties cache cleared due to global database connection failure")

                # Send alarm for database connection issues after all retries failed
                error_msg = f"Security properties cache load failed after {max_retries} retries: {str(e)}"
                logger.error(f"Sending DB_Connection alarm for global DB: {error_msg}")

                try:
                    run_alarm_in_thread(send_alarm(
                        country=country,
                        operator=operator,
                        alarm_type="DB_Connection",
                        remarks=f"Global DB: {error_msg}",
                        status="raise"
                    ))
                except Exception as alarm_error:
                    logger.error(f"Failed to send DB_Connection alarm for global DB: {alarm_error}")

                # Re-raise the exception so the controller can handle it
                raise

        except Exception as e:
            error_type = type(e).__name__
            logger.error(f"Unexpected error loading security properties cache from global DB (attempt {attempt + 1}/{max_retries}): {error_type}: {e}")

            if attempt < max_retries - 1:
                logger.info(f"Retrying in {delay * (2 ** attempt)}s... (attempt {attempt + 1}/{max_retries})")
                time.sleep(delay * (2 ** attempt))
                continue
            else:
                # All retries failed - clear cache and log error
                logger.error(f"All {max_retries} attempts failed. Clearing security properties cache and logging error.")
                security_properties_cache = {}
                logger.info("Security properties cache cleared due to load failure")

                # Re-raise the exception so the controller can handle it
                raise

def get_security_properties(operator: str, country: str) -> Optional[Dict[str, str]]:
    """
    Get security properties for specific operator and country from cache.
    Returns None if not found or cache is empty.
    """
    # Check if cache is loaded
    if not security_properties_cache:
        logger.warning("Security properties cache is empty")
        return None

    key = f"{operator}_{country}"
    settings = security_properties_cache.get(key)

    if settings:
        logger.debug(f"Found security properties for {key}: {list(settings.keys())}")
    else:
        logger.debug(f"No security properties found for {key}")

    return settings

def is_security_enabled(operator: str, country: str) -> bool:
    """
    Check if security is enabled for specific operator and country.
    Returns False if not found or cache is empty.
    """
    settings = get_security_properties(operator, country)
    if settings:
        is_enabled = settings.get('enableLogSecurity', 'false').lower() == 'true'
        logger.debug(f"Security enabled for {operator}_{country}: {is_enabled}")
        return is_enabled
    return False

def get_whitelisted_numbers(operator: str, country: str) -> List[str]:
    """
    Get whitelisted numbers for specific operator and country.
    Returns empty list if not found or cache is empty.
    """
    settings = get_security_properties(operator, country)
    if settings:
        whitelisted_str = settings.get('whitelistedNumbers', '')
        if whitelisted_str:
            # Split by comma and strip whitespace
            numbers = [num.strip() for num in whitelisted_str.split(',') if num.strip()]
            logger.debug(f"Found {len(numbers)} whitelisted numbers for {operator}_{country}")
            return numbers
    return []

def is_number_whitelisted(phone_number: str, operator: str, country: str) -> bool:
    """
    Check if a phone number is whitelisted for specific operator and country.
    Returns False if not found or cache is empty.
    """
    whitelisted_numbers = get_whitelisted_numbers(operator, country)
    if not whitelisted_numbers:
        return False

    # Normalize phone number for comparison
    normalized_number = phone_number.strip()

    # Check exact match only
    if normalized_number in whitelisted_numbers:
        logger.debug(f"Number {normalized_number} is whitelisted for {operator}_{country}")
        return True

    logger.debug(f"Number {normalized_number} is not whitelisted for {operator}_{country}")
    return False