from sqlalchemy.orm import Session
from models.database_models import AssistantConfiguration


def get_questionnaire(db: Session, assistant_id: int):
    return db.query(AssistantConfiguration).filter(AssistantConfiguration.assistant_id == assistant_id, AssistantConfiguration.status).all()
