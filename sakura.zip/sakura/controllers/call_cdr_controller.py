import traceback

from fastapi import APIRouter, HTTPException

from logger import get_logger
from service.call_cdr_service import get_call_details as get_call_details_service
from service.call_cdr_service import get_call_cdr_by_call_id as get_call_cdr_by_call_id_service

logger = get_logger(__name__)

router = APIRouter()


@router.get("/cdrs", tags=["Call Cdr"])
def get_call_details():
    try:
        logger.info("get_call_details controller called")
        response = get_call_details_service()
        logger.debug(f"get_call_details controller response: {response}")
        return response
    except Exception as e:
        logger.error(f"Error in get_call_details controller: {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/cdr", tags=["Call Cdr"])
def get_call_cdr_by_call_id(call_id: str):
    try:
        response = get_call_cdr_by_call_id_service(call_id)
        logger.info(f"get_call_cdr_by_call_id controller called for call_id - {call_id} with response: {response}")
        return response
    except Exception as e:
        logger.error(f"Error in get_call_cdr_by_call_id controller: {e}",exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")