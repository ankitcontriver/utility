import threading
import time
from typing import Dict, Any, Optional, Callable, OrderedDict
from collections import OrderedDict
import json
from dataclasses import dataclass
from logger import get_logger

logger = get_logger(__name__)

@dataclass
class CacheEntry:
    value: Any
    expires_at: float
    call_id: str
    key_type: str
    last_accessed: float
    lru_expired: bool = False

class BatchedMemoryCacheManager:
    """
    High-performance memory cache with batched expiry processing
    Replaces Redis for timing-critical utterance operations
    Features:
    - Configurable expiry timing (UTTERANCE_TIMER/INCOMP_UTTERANCE_TIMER env vars, 100Hz processing)
    - Safe LRU with expire-instead-of-delete
    - Thread-safe batched operations (max 5ms lock holds)
    - Zero message loss guarantee
    """
    
    def __init__(self, max_size: int = 15000):
        # Use OrderedDict for O(1) LRU operations
        self.cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self.max_size = max_size
        self.expiry_callbacks: Dict[str, Callable] = {}
        self.lock = threading.RLock()
        self.cleanup_thread = None
        self.shutdown_flag = threading.Event()
        
        # Batching configuration
        self.batch_size = 100           # Max entries per batch
        self.max_lock_time_ms = 3       # Max 3ms lock holds
        self.processing_frequency_ms = 10  # 100Hz processing
        
        # Performance statistics
        self.stats = {
            'sets': 0,
            'gets': 0,
            'hits': 0,
            'misses': 0,
            'natural_expires': 0,
            'lru_expires': 0,
            'evictions': 0,
            'memory_pressure_events': 0,
            'batch_operations': 0,
            'total_lock_time_ms': 0,
            'max_batch_size': 0,
            'callbacks_fired': 0
        }
        
    def start(self):
        """Start the batched expiry processing thread"""
        if self.cleanup_thread is None or not self.cleanup_thread.is_alive():
            self.cleanup_thread = threading.Thread(
                target=self._batched_expiry_processor,
                daemon=True,
                name="BatchedMemoryCacheExpiry"
            )
            self.cleanup_thread.start()
            logger.info(f"BatchedMemoryCache started: max_size={self.max_size}, batch_size={self.batch_size}, frequency={1000/self.processing_frequency_ms}Hz")
    
    def shutdown(self):
        """Shutdown the cache manager"""
        self.shutdown_flag.set()
        if self.cleanup_thread:
            self.cleanup_thread.join(timeout=1)
        stats = self.get_stats()
        logger.info(f"BatchedMemoryCache shutdown: {stats['sets']} sets, {stats['callbacks_fired']} callbacks, {stats['hit_rate_percent']:.1f}% hit rate")
    
    def set_with_expiry(self, key: str, value: Any, expiry_ms: int, 
                       call_id: str = None, key_type: str = "utterance") -> bool:
        """
        Set a key with millisecond-precision expiry
        Fast operation with minimal lock time
        """
        try:
            current_time = time.time()
            expires_at = current_time + (expiry_ms / 1000.0)
            
            lock_start = time.time()
            with self.lock:
                # Create new entry
                entry = CacheEntry(
                    value=value,
                    expires_at=expires_at,
                    call_id=str(call_id or key.split(':')[0]),
                    key_type=key_type,
                    last_accessed=current_time,
                    lru_expired=False
                )
                
                # Update existing key (move to end) or add new
                if key in self.cache:
                    del self.cache[key]  # Remove old position
                self.cache[key] = entry  # Add at end (most recent)
                
                self.stats['sets'] += 1
                
                # Safe LRU management
                self._enforce_size_limit_fast()
                
                # Track lock time
                lock_time_ms = (time.time() - lock_start) * 1000
                self.stats['total_lock_time_ms'] += lock_time_ms
            
            logger.debug(f"MemoryCache: Set {key} (expires in {expiry_ms}ms, type={key_type})")
            return True
            
        except Exception as e:
            logger.error(f"MemoryCache set error for {key}: {e}")
            return False
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache with LRU update and expiry check"""
        try:
            current_time = time.time()
            
            lock_start = time.time()
            with self.lock:
                self.stats['gets'] += 1
                
                if key not in self.cache:
                    self.stats['misses'] += 1
                    return None
                
                entry = self.cache[key]
                
                # Check if expired (natural OR LRU-forced)
                if current_time >= entry.expires_at:
                    self.stats['misses'] += 1
                    # Don't delete here - let background processor handle callback
                    return None
                
                # Update LRU order (move to end = most recent)
                entry.last_accessed = current_time
                self.cache.move_to_end(key)  # O(1) operation
                
                self.stats['hits'] += 1
                
                # Track lock time
                lock_time_ms = (time.time() - lock_start) * 1000
                self.stats['total_lock_time_ms'] += lock_time_ms
                
                return entry.value
                
        except Exception as e:
            logger.error(f"MemoryCache get error for {key}: {e}")
            return None
    
    def delete(self, key: str) -> bool:
        """Delete a key from cache"""
        try:
            with self.lock:
                if key in self.cache:
                    del self.cache[key]
                    logger.debug(f"MemoryCache: Deleted key {key}")
                    return True
                return False
        except Exception as e:
            logger.error(f"MemoryCache delete error for {key}: {e}")
            return False
    
    def exists(self, key: str) -> bool:
        """Check if key exists and is not expired"""
        return self.get(key) is not None
    
    def register_expiry_callback(self, key_type: str, callback: Callable):
        """Register callback for when keys of specific type expire"""
        self.expiry_callbacks[key_type] = callback
        logger.info(f"MemoryCache: Registered expiry callback for {key_type}")
    
    def _enforce_size_limit_fast(self):
        """
        Fast LRU enforcement - expire oldest keys instead of deleting
        Designed to complete within max_lock_time_ms
        """
        if len(self.cache) <= self.max_size:
            return
        
        current_time = time.time()
        keys_to_expire = len(self.cache) - self.max_size
        
        # Expire oldest keys (from front of OrderedDict)
        expired_count = 0
        for key in list(self.cache.keys()):
            if expired_count >= keys_to_expire:
                break
                
            entry = self.cache[key]
            
            # Only expire if not already expired
            if current_time < entry.expires_at:
                # Mark as LRU-expired
                entry.expires_at = current_time
                entry.lru_expired = True
                expired_count += 1
                self.stats['lru_expires'] += 1
        
        if expired_count > 0:
            self.stats['memory_pressure_events'] += 1
            logger.debug(f"MemoryCache: LRU expired {expired_count} keys (memory pressure)")
    
    def _batched_expiry_processor(self):
        """
        Batched background processor with guaranteed short lock holds
        Processes expired keys and triggers callbacks
        """
        logger.info("BatchedMemoryCache expiry processor started (100Hz)")
        
        while not self.shutdown_flag.is_set():
            try:
                batch_start = time.time()
                
                # Phase 1: Quick collection of expired entries (short lock)
                expired_batch = self._collect_expired_batch()
                
                # Phase 2: Process callbacks (no lock held)
                if expired_batch:
                    self._process_expired_callbacks(expired_batch)
                
                # Phase 3: Cleanup expired entries (short lock)
                if expired_batch:
                    self._cleanup_expired_entries(expired_batch)
                
                # Update stats
                if expired_batch:
                    self.stats['batch_operations'] += 1
                    self.stats['max_batch_size'] = max(self.stats['max_batch_size'], len(expired_batch))
                
                # Maintain 100Hz frequency (10ms intervals)
                batch_time = (time.time() - batch_start) * 1000
                sleep_time = max(0.001, (self.processing_frequency_ms - batch_time) / 1000)
                self.shutdown_flag.wait(sleep_time)
                
            except Exception as e:
                logger.error(f"BatchedMemoryCache expiry processor error: {e}")
                self.shutdown_flag.wait(0.1)
    
    def _collect_expired_batch(self):
        """
        Quickly collect expired entries with guaranteed short lock hold
        Returns list of (key, entry) tuples
        """
        expired_batch = []
        batch_start = time.time()
        current_time = time.time()
        
        try:
            with self.lock:
                batch_count = 0
                
                # Iterate through cache with time/size limits
                for key, entry in list(self.cache.items()):
                    # Time limit: max 3ms lock hold
                    if (time.time() - batch_start) * 1000 > self.max_lock_time_ms:
                        logger.debug(f"MemoryCache: Batch collection time limit reached ({batch_count} entries)")
                        break
                    
                    # Size limit: max batch_size entries
                    if batch_count >= self.batch_size:
                        logger.debug(f"MemoryCache: Batch size limit reached ({batch_count} entries)")
                        break
                    
                    # Check if expired
                    if current_time >= entry.expires_at:
                        expired_batch.append((key, entry))
                        batch_count += 1
                        
                        # Track expiry type for stats
                        if entry.lru_expired:
                            self.stats['lru_expires'] += 1
                        else:
                            self.stats['natural_expires'] += 1
                
                # Track actual lock time
                lock_time_ms = (time.time() - batch_start) * 1000
                self.stats['total_lock_time_ms'] += lock_time_ms
                
                if expired_batch:
                    logger.debug(f"MemoryCache: Collected {len(expired_batch)} expired entries (lock held {lock_time_ms:.1f}ms)")
                
        except Exception as e:
            logger.error(f"MemoryCache batch collection error: {e}")
        
        return expired_batch
    
    def _process_expired_callbacks(self, expired_batch):
        """
        Process expiry callbacks without holding any locks
        PERFORMANCE FIX: Use bounded thread pool instead of creating unlimited threads
        """
        if not hasattr(self, '_callback_executor'):
            # Initialize bounded thread pool on first use
            from concurrent.futures import ThreadPoolExecutor
            # Make thread count configurable via environment variable
            import os
            max_workers = int(os.getenv('MEMORY_CACHE_CALLBACK_THREADS', '100'))
            self._callback_executor = ThreadPoolExecutor(
                max_workers=max_workers,  # Configurable via MEMORY_CACHE_CALLBACK_THREADS env var
                thread_name_prefix="MemCacheCallback"
            )
            logger.info(f"MemoryCache: Initialized callback thread pool (max_workers={max_workers})")
        
        for key, entry in expired_batch:
            callback = self.expiry_callbacks.get(entry.key_type)
            if callback:
                try:
                    # CRITICAL FIX: Use bounded thread pool instead of unlimited thread creation
                    # This prevents thread explosion under heavy load
                    future = self._callback_executor.submit(
                        self._safe_callback_wrapper,
                        callback, entry.call_id, entry.key_type, key, entry.lru_expired
                    )
                    
                    # PERFORMANCE: Don't wait for callback completion (fire and forget)
                    # This prevents callback blocking from affecting cache performance
                    
                    self.stats['callbacks_fired'] += 1
                    
                except Exception as e:
                    logger.error(f"MemoryCache callback submission error for {key}: {e}")
                    self.stats['callback_errors'] = self.stats.get('callback_errors', 0) + 1
    
    def _safe_callback_wrapper(self, callback, call_id, key_type, key, was_lru_expired):
        """
        Safe wrapper for callback execution with error handling
        """
        try:
            if was_lru_expired:
                logger.debug(f"MemoryCache: Firing callback for LRU-expired key {key}")
            else:
                logger.debug(f"MemoryCache: Firing callback for naturally expired key {key}")
            
            # Execute the actual callback
            callback(call_id, key_type, key)
            
        except Exception as e:
            logger.error(f"MemoryCache callback execution error for {key}: {e}")
    
    def _cleanup_expired_entries(self, expired_batch):
        """
        Remove expired entries from cache (short lock)
        """
        if not expired_batch:
            return
        
        cleanup_start = time.time()
        
        try:
            with self.lock:
                removed_count = 0
                
                for key, entry in expired_batch:
                    if key in self.cache:
                        del self.cache[key]
                        removed_count += 1
                
                # Track lock time
                lock_time_ms = (time.time() - cleanup_start) * 1000
                self.stats['total_lock_time_ms'] += lock_time_ms
                
                if removed_count > 0:
                    logger.debug(f"MemoryCache: Cleaned up {removed_count} expired entries (lock held {lock_time_ms:.1f}ms)")
                
        except Exception as e:
            logger.error(f"MemoryCache cleanup error: {e}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive cache statistics"""
        with self.lock:
            total_ops = self.stats['gets'] + self.stats['sets']
            hit_rate = (self.stats['hits'] / max(self.stats['gets'], 1)) * 100
            total_expires = self.stats['natural_expires'] + self.stats['lru_expires']
            avg_lock_time = self.stats['total_lock_time_ms'] / max(total_ops, 1)
            
            return {
                **self.stats,
                'cache_size': len(self.cache),
                'max_size': self.max_size,
                'hit_rate_percent': round(hit_rate, 2),
                'total_expires': total_expires,
                'natural_expiry_percent': round((self.stats['natural_expires'] / max(total_expires, 1)) * 100, 1),
                'lru_expiry_percent': round((self.stats['lru_expires'] / max(total_expires, 1)) * 100, 1),
                'memory_usage_percent': round((len(self.cache) / self.max_size) * 100, 2),
                'avg_lock_time_ms': round(avg_lock_time, 3),
                'processing_frequency_hz': 1000 / self.processing_frequency_ms
            }
    
    def get_debug_info(self) -> Dict[str, Any]:
        """Get detailed debug information"""
        with self.lock:
            if not self.cache:
                return {'status': 'empty_cache'}
            
            # Get oldest and newest entries
            oldest_key = next(iter(self.cache))
            newest_key = next(reversed(self.cache))
            oldest_entry = self.cache[oldest_key]
            newest_entry = self.cache[newest_key]
            
            current_time = time.time()
            
            return {
                'cache_status': 'active',
                'oldest_key': oldest_key,
                'newest_key': newest_key,
                'oldest_call_id': oldest_entry.call_id,
                'newest_call_id': newest_entry.call_id,
                'oldest_remaining_ms': max(0, int((oldest_entry.expires_at - current_time) * 1000)),
                'newest_remaining_ms': max(0, int((newest_entry.expires_at - current_time) * 1000)),
                'age_range_seconds': round(newest_entry.last_accessed - oldest_entry.last_accessed, 3),
                'registered_callbacks': list(self.expiry_callbacks.keys())
            }

# Global instance
_batched_memory_cache = BatchedMemoryCacheManager()

def get_memory_cache() -> BatchedMemoryCacheManager:
    """Get the global batched memory cache instance"""
    return _batched_memory_cache

def start_memory_cache():
    """Start the batched memory cache expiry processor"""
    _batched_memory_cache.start()

def shutdown_memory_cache():
    """Shutdown the batched memory cache"""
    _batched_memory_cache.shutdown()

# In-memory storage for user call records (separate from cache)
_user_call_records: Dict[str, Dict] = {}
_user_records_lock = threading.RLock()

def set_user_call_record(call_id: str, record: Dict):
    """Store user call record in memory"""
    from logger import get_logger
    logger = get_logger(__name__)
    
    with _user_records_lock:
        _user_call_records[call_id] = record
        logger.debug(f"SET user call record {call_id} - total records: {len(_user_call_records)}")

def get_user_call_record(call_id: str) -> Optional[Dict]:
    """Retrieve user call record from memory"""
    from logger import get_logger
    logger = get_logger(__name__)
    
    with _user_records_lock:
        record = _user_call_records.get(call_id)
        if record is None:
            logger.debug(f"GET user call record {call_id} - NOT FOUND - current records: {list(_user_call_records.keys())}")
        else:
            logger.debug(f"GET user call record {call_id} - FOUND - total records: {len(_user_call_records)}")
        return record

def delete_user_call_record(call_id: str) -> bool:
    """Delete user call record from memory"""
    import traceback
    from logger import get_logger
    logger = get_logger(__name__)
    
    with _user_records_lock:
        if call_id in _user_call_records:
            # Log the deletion with stack trace to track where it's called from
            stack_trace = ''.join(traceback.format_stack()[-3:-1])  # Get last 2 stack frames
            logger.debug(f"DELETING user call record {call_id} - Called from: {stack_trace.strip()}")
            del _user_call_records[call_id]
            return True
        else:
            logger.debug(f"DELETE ATTEMPTED: user call record {call_id} not found - current records: {list(_user_call_records.keys())}")
            return False

def get_user_records_stats() -> Dict[str, Any]:
    """Get user call records statistics"""
    with _user_records_lock:
        return {
            'active_call_records': len(_user_call_records),
            'memory_usage_mb': len(str(_user_call_records)) / (1024 * 1024)
        }
