import json
import os
import random
import re
import time
import traceback

import anthropic
from dotenv import load_dotenv

from utils.redis_db_manager import redis_manager
from utils.memory_cache_manager import get_user_call_record, set_user_call_record
from logger import get_logger
from models.redis_models import UserCallCDR, UserCallRecord
from models.request_models import MessageResponse
from service.language_service import translate_transcript
from utils.chat_utils import send_chat_chunk_callback_socket
from utils.function_call_util_functions import execute_function_call, get_cdr_data
from utils.llm_util import convert_chunk_to_transcript_based_on_voice_code, generate_dynamic_message_id
from utils.utils import adjust_messages_length, remove_messages_in_range, get_current_time_iso
from utils.alarm_utils import send_alarm
from utils.scalable_cdr_manager import update_cdr_record_with_expiration
import asyncio

load_dotenv()

logger = get_logger(__name__)

client = anthropic.Anthropic(
    api_key=os.environ.get("ANTHROPIC_API_KEY"),
)

cdr_redis_client = redis_manager.get_cdr_client()   # CDR operations (DB=2)

random_responses = [
    "Sure, just a sec!!",
    "Sure thing, just a sec!",
    "Okay, give me a moment!",
    "Alright, let me check!",
    "Sure, give me a sec!",
    "Sure, hold on a bit!"
]

# CDR update function now uses scalable implementation

def check_before_or_after_comma_is_number(s):
    # Use regex to find a digit followed by a comma or a comma followed by a digit
    # pattern = r'\d,|,\d'
    pattern = r'\d[,.]\d'
    return bool(re.search(pattern, s))


async def call_claude_stream(model_name: str, req_id: str, is_function_call=False):
    logger.info(f"call_id {req_id} inside calling llm function using model_name - {model_name} ")
    try:
        function_id = ""
        # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
        user_obj = get_user_call_record(str(req_id))
        if user_obj is None:
            return None
        user_messages = user_obj["llmMessage"]
        call_id = user_obj["callId"]
        event_type = user_obj["eventType"]
        currentMessageId = user_obj["currentMessageId"]
        assistant_id = user_obj["assistantId"]
        tts_style = user_obj["ttsStyle"]
        voice_code = user_obj["voiceCode"]
        provider = user_obj["provider"]
        gender = user_obj["gender"]
        is_translate = user_obj["isTranslate"]
        claude_tools = user_obj['claude_tools']
        chunk_timestamp = time.time()
        system_prompt = user_messages[0]["content"]
        model_name = os.getenv("ANTHROPIC_MODEL_NAME")
        # model_name='claude-3-5-sonnet-20240620'
        user_messages = user_messages[2:]
        response = ""

        if claude_tools:
            tools = claude_tools
        else:
            tools = []

        try:
            if is_function_call:
                response = client.messages.create(
                    system=system_prompt,
                    model=model_name,
                    messages=user_messages,
                    max_tokens=500,
                    stream=True,
                    tools=tools
                )
                await send_alarm(alarm_type='Claude_API', remarks='Claude API working fine', status='clear', assistant_id=assistant_id)
                logger.info(f"user_messages: {user_messages}")
            elif not is_function_call:
                if user_messages:
                    if user_messages[-1].get("role") == "user":
                        user_messages[-1] = {
                            "role": "user",
                            "content": user_messages[-1]["content"]
                        }
                logger.info(f"user_messages: {user_messages}")
                response = client.messages.create(
                    system=system_prompt,
                    model=model_name,
                    messages=user_messages,
                    max_tokens=500,
                    stream=True,
                    tools=tools
                )
                await send_alarm(alarm_type='Claude_API', remarks='Claude API working fine', status='clear', assistant_id=assistant_id)

        except Exception as api_exc:
            await send_alarm(alarm_type= 'Claude_API', remarks=str(api_exc), status='raise', assistant_id=assistant_id)
            raise

        function_name = None
        function_arguments = ''
        continious_string = ""
        complete_string = ""
        count = 1

        for chunk in response:
            # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
            user_obj = get_user_call_record(str(req_id))
            if user_obj is None:
                return None
            if user_obj["interrupt"]:
                logger.info("Interrupting!!!")

                user_obj["processing"] = False
                user_obj["listening"] = True
                user_obj["speaking"] = False
                # PERFORMANCE FIX: Update user call record in memory instead of Redis
                set_user_call_record(str(req_id), user_obj)
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                break

            logger.debug(f"chunk ----> {chunk}")
            if chunk.type == 'content_block_start' and chunk.content_block.type == 'tool_use':
                function_name = chunk.content_block.name
                function_id = chunk.content_block.id
                logger.info(f"Function call detected : {function_name}")

            if chunk.type == 'content_block_delta' and hasattr(chunk.delta, 'text'):
                continious_string += chunk.delta.text
                complete_string += chunk.delta.text

                discarded_string = ""
                words_in_temp = continious_string.split()

                # Check if the word count exceeds 20
                if len(words_in_temp) > 20:
                    # Define the split point
                    mid_point = 20

                    # Split the string into a chunk of 20 words and the remaining part
                    temp_continuous_string = ' '.join(words_in_temp[:mid_point])
                    discarded_string = ' '.join(words_in_temp[mid_point:])

                    # Process the chunk for TTS
                    transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(
                        voice_code, temp_continuous_string, call_id, event_type, tts_style, provider, gender,
                        is_translate
                    )
                    messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                    message_response = MessageResponse(
                        callId=call_id, chunk=current_chunk, isEndChunk=False, transcript=transcript,
                        messageId=messageId, eventType=event_type
                    )
                    await send_chat_chunk_callback_socket(
                        sid=user_obj["socketId"], data=message_response.dict()
                    )

                    # Update continious_string with the discarded part for the next iteration
                    continious_string = discarded_string
                else:
                    # Check for punctuation and split if found, considering numbers
                    for i, char in enumerate(continious_string):
                        if char in '.,;!:?।፧፨።':
                            if check_before_or_after_comma_is_number(
                                    continious_string[:i + 1]):  # Check for numbers around punctuation
                                continue  # Skip splitting if number is present
                            temp_continuos_string = continious_string[:i + 1]
                            discarded_string = continious_string[i + 1:]
                            # Split if more than 20 words:
                            words_in_temp = temp_continuos_string.split()
                            if len(words_in_temp) > 20:
                                transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(
                                    voice_code,
                                    temp_continuos_string,
                                    call_id, event_type, tts_style, provider, gender, is_translate)

                                messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                                message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                                                                   isEndChunk=False, transcript=transcript,
                                                                   messageId=messageId, eventType=event_type)
                                logger.info(
                                    f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
                                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                                      data=message_response.dict())

                                # Keep the remaining words in discarded_string
                                discarded_string = " ".join(words_in_temp[20:]) + discarded_string
                            else:
                                if len(temp_continuos_string) > 4:
                                    transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(
                                        voice_code,
                                        temp_continuos_string,
                                        call_id, event_type, tts_style, provider, gender, is_translate)

                                    messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                                    message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                                                                       isEndChunk=False, transcript=transcript,
                                                                       messageId=messageId, eventType=event_type)
                                    logger.info(
                                        f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
                                    await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                                          data=message_response.dict())
                            continious_string = discarded_string
                            discarded_string = ""
                            break

            if chunk.type == "content_block_delta" and chunk.index == 1 and chunk.delta.partial_json != None:
                logger.info(chunk.delta.partial_json)
                function_arguments += chunk.delta.partial_json
                logger.info(f"Function call detected with argument: {function_arguments}")

        if continious_string is not None and continious_string != "":
            if user_obj["interrupt"]:
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                return complete_string, None, None
            logger.info(f"call_id {call_id} - time taken to generate chunk {continious_string} in ------> "
                        f"{(time.time() - chunk_timestamp) * 1000:.2f} ms")
            voice_code = user_obj["voiceCode"]
            transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(voice_code,
                                                                                        continious_string,
                                                                                        call_id, event_type, tts_style,
                                                                                        provider, gender, is_translate)
            currentMessageId = user_obj["currentMessageId"]
            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
            message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                                               isEndChunk=False, transcript=transcript, messageId=messageId,
                                               eventType=event_type)
            # print(f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
            await send_chat_chunk_callback_socket(sid=user_obj["socketId"], data=message_response.dict())

        elif continious_string == "" and function_name is None:
            if user_obj["interrupt"]:
                sock_data = {
                    "callId": req_id
                }
                await send_chat_chunk_callback_socket(sid=user_obj["socketId"],
                                                      data=sock_data, event='call_interrupt')
                return complete_string, None, None
            currentMessageId = user_obj["currentMessageId"]
            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
            message_response = MessageResponse(callId=call_id, chunk="",
                                               isEndChunk=True, transcript="", messageId=messageId,
                                               eventType=event_type)
            # print(f"call_id {call_id} - Sending message response - {message_response.__repr__()}")
            await send_chat_chunk_callback_socket(sid=user_obj["socketId"], data=message_response.dict())
        return complete_string, function_name, function_arguments, function_id

    except Exception as e:
        logger.info(f"Exception in call_claude_stream - {e} for req_id - {req_id}")


async def claude_stream_handler(model_name, req_id):
    try:
        # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
        user_call_record = get_user_call_record(str(req_id))
        if user_call_record is None:
            return None
        assistant_id = user_call_record["assistantId"]
        user_messages = user_call_record["llmMessage"]
        user_call_obj = UserCallRecord(**user_call_record)
        msg_id = user_call_obj.currentMessageId
        # CRITICAL FIX: Use hash retrieval for CDR data instead of JSON
        cdr_data = get_cdr_data(req_id)
        if cdr_data is None:
            logger.debug(f"No CDR found for req_id: {req_id} in claude_service")
            return
        user_call_cdr_record = UserCallCDR(**cdr_data)
        user_call_cdr_record.question_count += 1
        call_type = user_call_record["eventType"]
        user_call_cdr_record.call_type = call_type
        cdr_call_messages = user_call_cdr_record.call_messages
        # CRITICAL BUG FIX: Use actual user transcript instead of user_messages[-1] which could be system message
        user_transcript = " ".join(user_call_record.get("userMessage", [])) if user_call_record.get("userMessage") else "No user input"
        
        cdr_call_messages.append({
            "id": msg_id,  # Generate a unique ID for the message
            "senderId": "user",  # Use the sender_id from user_messages
            "body": user_transcript,  # FIXED: Use actual user transcript
            "contentType": "text",  # Assuming text content; adjust as needed
            "attachments": [],  # Assuming no attachments; adjust as needed
            "createdAt": get_current_time_iso()  # Set the current time in ISO format
        })
        user_call_cdr_record.call_messages = cdr_call_messages
        # save in redis
        update_cdr_record_with_expiration(req_id, user_call_cdr_record)
        complete_string, function_name, function_arguments, function_id = await call_claude_stream(
            model_name=model_name,
            req_id=req_id,
            is_function_call=False)

        logger.info(f"call_id - {req_id} Complete Response String - {complete_string}")
        if complete_string:
            logger.info(f"call_id - {req_id} I get a confirmation that it was not a function call")
            assistant_response = {"role": "assistant", "content": complete_string}
            # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
            user_call_record = get_user_call_record(str(req_id))
            if user_call_record is None:
                logger.info("No active call")
            else:
                event_type = user_call_record["eventType"]
                currentMessageId = user_call_record["currentMessageId"]
                messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                user_call_record["llmMessage"].append(assistant_response)
                adjusted_messages = adjust_messages_length(req_id, user_call_record["llmMessage"])
                user_call_record["llmMessage"] = adjusted_messages
                user_call_record["processing"] = False

                # PERFORMANCE FIX: Update user call record in memory instead of Redis
                set_user_call_record(str(req_id), user_call_record)
                if len(user_call_record["userMessage"]) > 0:
                    logger.info("Hello")

                if not function_name:
                    message_response = MessageResponse(callId=req_id, chunk="",
                                                       isEndChunk=True, transcript="", messageId=messageId,
                                                       eventType=event_type)
                    logger.info(f"call_id {req_id} - Sending message response - {message_response.__repr__()}")
                    await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                          data=message_response.dict())

            user_call_cdr_record.answer_count += 1
            cdr_msg_id = msg_id.split("_")[0] + "_Avatar"
            cdr_call_messages.append({
                "id": cdr_msg_id,  # Generate a unique ID for the message
                "senderId": "eva",  # Use the sender_id from user_messages
                "body": complete_string,  # The actual message content
                "contentType": "text",  # Assuming text content; adjust as needed
                "attachments": [],  # Assuming no attachments; adjust as needed
                "createdAt": get_current_time_iso()  # Set the current time in ISO format
            })
            user_call_cdr_record.call_messages = cdr_call_messages
            # save in redis
            update_cdr_record_with_expiration(req_id, user_call_cdr_record)
        if function_name:
            logger.info(f"call_id - {req_id} Function name is {function_name}")
            user_call_cdr_record.tools_used += 1
            update_cdr_record_with_expiration(req_id, user_call_cdr_record)
            # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
            user_call_record = get_user_call_record(str(req_id))
            if user_call_record is None:
                return None
            event_type = user_call_record["eventType"]
            tts_style = user_call_record["ttsStyle"]
            voice_code = user_call_record["voiceCode"]
            provider = user_call_record["provider"]
            gender = user_call_record["gender"]
            is_translate = user_call_record["isTranslate"]
            language = voice_code.split("-")[0]
            currentMessageId = user_call_record["currentMessageId"]
            messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
            if not complete_string:
                function_calling_chunk = random.choice(random_responses)
                translated_chunk = translate_transcript(function_calling_chunk, "en", language)
                transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(voice_code,
                                                                                            translated_chunk,
                                                                                            req_id,
                                                                                            event_type,
                                                                                            tts_style, provider, gender,
                                                                                            is_translate)
                sending_chunk = current_chunk + " "
                message_response = MessageResponse(callId=req_id, chunk=sending_chunk,
                                                   isEndChunk=False, transcript=transcript,
                                                   messageId=messageId,
                                                   eventType=event_type)
                logger.info(f"call_id {req_id} - Sending message response - {message_response.__repr__()}")
                await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                      data=message_response.dict())
            messages = user_call_record["llmMessage"]

            function_arguments_dump = function_arguments
            function_arguments_dict = json.loads(function_arguments)

            if complete_string:
                message = {
                    "role": "assistant",
                    "content": [
                        {
                            "type": "text",
                            "text": complete_string
                        }, {
                            "type": "tool_use",
                            "id": function_id,
                            "name": function_name,
                            "input": function_arguments_dict
                        }
                    ]

                }

                messages[-1] = message
            else:
                messages.append({
                    "role": "assistant",
                    "content": [{
                        "type": "tool_use",
                        "id": function_id,
                        "name": function_name,
                        "input": function_arguments_dict
                    }]
                })

            # function_returns = execute_function_call(function_name=function_name, arguments=function_arguments_dump)
            function_returns = execute_function_call(function_name=function_name, arguments=function_arguments_dump,
                                                     call_id=req_id, assistant_id=assistant_id)
            messages.append({
                "role": "user",
                "content": [{
                    "type": "tool_result",
                    "tool_use_id": function_id,
                    "content": function_returns,
                }]
            })

            adjusted_messages = adjust_messages_length(req_id, messages)
            logger.info(f"adjusted_messages before deletion of retreiver tool result: {adjusted_messages}")

            user_call_record["llmMessage"] = adjusted_messages
            # PERFORMANCE FIX: Update user call record in memory instead of Redis
            set_user_call_record(str(req_id), user_call_record)

            regular_response_new, function_name_new, function_arguments_new, function_id_new = await call_claude_stream(
                model_name=model_name,
                req_id=req_id,
                is_function_call=True)
            if regular_response_new:
                logger.info(f"call_id - {req_id} regular response --> {regular_response_new}")
                cdr_msg_id = msg_id.split("_")[0] + "_Avatar"
                cdr_call_messages.append({
                    "id": cdr_msg_id,  # Generate a unique ID for the message
                    "senderId": "eva",  # Use the sender_id from user_messages
                    "body": regular_response_new,  # The actual message content
                    "contentType": "text",  # Assuming text content; adjust as needed
                    "attachments": [],  # Assuming no attachments; adjust as needed
                    "createdAt": get_current_time_iso()  # Set the current time in ISO format
                })
                user_call_cdr_record.call_messages = cdr_call_messages
                # save in redis
                update_cdr_record_with_expiration(req_id, user_call_cdr_record)
                reg_message_obj = {"role": "assistant", "content": regular_response_new}
                user_call_record["llmMessage"].append(reg_message_obj)
                message_response = MessageResponse(callId=req_id, chunk="",
                                                   isEndChunk=True, transcript="", messageId=messageId,
                                                   eventType=event_type)
                logger.info(f"call_id {req_id} - Sending message response - {message_response.__repr__()}")
                await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                      data=message_response.dict())
                adjusted_messages = adjust_messages_length(req_id, messages)
                logger.info(f"{req_id} - adjusted messages after final response- {adjusted_messages}")
                logger.info(f"{req_id} - function name after final response- {function_name}")

                if function_name in ["get_nearest_service_center"]:
                    user_call_cdr_record.rag_tool_use += 1
                    update_cdr_record_with_expiration(req_id, user_call_cdr_record)
                    remove_messages_in_range(adjusted_messages, 1, 2)
                    logger.info(f"{req_id} - adjusted messages after removing function call- {adjusted_messages}")
                user_call_record["llmMessage"] = adjusted_messages
                # PERFORMANCE FIX: Update user call record in memory instead of Redis
                set_user_call_record(str(req_id), user_call_record)
            elif function_name_new:
                logger.info(f"call_id - {req_id} function call loop kill audio called")
                chunk = "I'm facing some issues. Can you try after some time or try asking your question again?"
                # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
                user_call_record = get_user_call_record(str(req_id))
                event_type = user_call_record["eventType"]
                tts_style = user_call_record["ttsStyle"]
                voice_code = user_call_record["voiceCode"]
                transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(voice_code,
                                                                                            chunk,
                                                                                            req_id,
                                                                                            event_type,
                                                                                            tts_style, provider, gender,
                                                                                            is_translate)
                currentMessageId = user_call_record["currentMessageId"]
                messageId = generate_dynamic_message_id(currentMessageId, "Avatar")
                sending_chunk = current_chunk + " "
                message_response = MessageResponse(callId=req_id, chunk=sending_chunk,
                                                   isEndChunk=True, transcript=transcript,
                                                   messageId=messageId,
                                                   eventType=event_type)
                logger.info(f"call_id {req_id} - Sending message response - {message_response.__repr__()}")
                await send_chat_chunk_callback_socket(sid=user_call_record["socketId"],
                                                      data=message_response.dict())

    except Exception as e:
        logger.error(f"Exception occurred in claude_stream_handler - {e}", exc_info=True)
