from models.database_models import Base, SubAgentConfiguration, AssistantConfiguration
from fastapi import HTTPException,Response
from datetime import datetime
from sqlalchemy.exc import NoResultFound
import os
from urllib.parse import urlencode
from sqlalchemy.exc import SQLAlchemyError
from config.database_config import SessionLocal
from fastapi.responses import JSONResponse, FileResponse
from logger.__init__ import get_logger
from sqlalchemy import desc,and_
from utils.agent_utils import generate_download_file_url, generate_download_uml_url
from typing import List, Tuple
import re
logger = get_logger(__name__)

def get_sub_agents_by_assistant_id(assistant_id: str):
    db = SessionLocal()
    try:
        logger.info(f"Fetching sub-agents for assistantId: {assistant_id}")
        sub_agents = db.query(SubAgentConfiguration).filter(SubAgentConfiguration.assistantId == assistant_id).order_by(desc(SubAgentConfiguration.updatedOn)).all()
        return sub_agents
    except Exception as e:
        logger.error(f"An error occurred while fetching sub-agents for assistantId: {assistant_id} - {e}", exc_info=True)
        return []
    finally:
        db.close()


def format_tool_list(tool_list: str) -> str:
    # Split the input by commas, remove extra spaces, and ensure valid integers
    tools = [tool.strip() for tool in tool_list.split(',') if tool.strip().isdigit()]
    
    # Join them back into a comma-separated string
    formatted_list = ", ".join(tools)
    logger.debug(f"Formatted tool list: {formatted_list}")
    
    return formatted_list


def update_agent_tool_list(tenantId: str, assistantId: str, agentId: str, toolList: str, userId: str):
    db = SessionLocal()
    try:
        logger.info(f"Updating agent tools for tenantId: {tenantId}, assistantId: {assistantId}, agentId: {agentId}")
        agent_prompt = db.query(SubAgentConfiguration).filter_by(id=agentId).one_or_none()

        if not agent_prompt:
            raise NoResultFound(f"No AgentPrompts found for tenantId: {tenantId} and assistantId: {assistantId}")

        # Format and update the toolList
        formatted_tool_list = format_tool_list(toolList)
        if not formatted_tool_list:
            raise ValueError("Tool list is empty or invalid after formatting.")

        # Update the agent tool list and audit fields
        agent_prompt.toolList = formatted_tool_list
        agent_prompt.updateBy = userId
        agent_prompt.updateOn = datetime.utcnow()

        db.commit()
        logger.info(f"Tool list for AgentPrompt with id {agent_prompt.id} successfully updated.")
        
        return agent_prompt
    except NoResultFound as e:
        db.rollback()
        logger.error(f"NoResultFound: {e}", exc_info=True)
        return []
    except ValueError as e:
        db.rollback()
        logger.error(f"Error parsing toolList: {e}", exc_info=True)
        return []
    except Exception as e:
        db.rollback()
        logger.error(f"An error occurred while updating agent tool list for tenantId: {tenantId}, agentId: {agentId} - {e}", exc_info=True)
        return []
    finally:
        db.close()



def toggle_status(tenantId,assistantId, agentId):
    db = SessionLocal()
    try:
        # Query for the entry by ID
        entry = db.query(SubAgentConfiguration).filter_by(id=agentId).first()

        if entry:
            logger.info(f"Updating agent tools for tenantId: {tenantId}, assistantId: {assistantId}, agentId: {agentId}")
            original_status = entry.status
            entry.status = not entry.status

            # Commit the change to the database
            db.commit()

            logger.info(f"Status for entry ID {agentId} toggled from {original_status} to {entry.status}")
            return entry  # Return the updated entry
        else:
            logger.warning(f"No entry found with ID {agentId}")
            return None

    except SQLAlchemyError as e:
        # Rollback in case of any error during the transaction
        db.rollback()
        logger.error(f"An error occurred while toggling status for entry ID {agentId}: {e}", exc_info=True)
        return None  # Return None in case of an error
    finally:
        db.close()


def update_doc(file_path,agentId):
    # Update the document link in the database
    db = SessionLocal()
    try:
        # Fetch the SubAgentConfiguration entry for the given assistant_id
        sub_agent = db.query(SubAgentConfiguration).filter(SubAgentConfiguration.id == agentId).first()
        if not sub_agent:
            raise HTTPException(status_code=404, detail="SubAgentConfiguration not found")
        
        # Update the documentLink field
        sub_agent.documentLink = file_path
        db.commit()
        return JSONResponse(content={"message": "File uploaded successfully", "documentLink": file_path})
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()
        

def download_doc(agentId):
    db = SessionLocal()
    try:
        # Fetch the SubAgentConfiguration entry for the given assistant_id
        sub_agent = db.query(SubAgentConfiguration).filter(SubAgentConfiguration.id == agentId).first()
        if not sub_agent or not sub_agent.documentLink:
            raise HTTPException(status_code=404, detail="File not found for the provided assistant_id")
        
        # Define the file path from the documentLink
        file_path = sub_agent.documentLink
        
        # Check if the file exists
        if not os.path.exists(file_path):
            raise HTTPException(status_code=404, detail="File does not exist on the server")
        
        # Read the file and send it as a response
        with open(file_path, "rb") as f:
            content = f.read()
        
        # Return the file as a response with the correct MIME type
        return Response(content=content, media_type='application/octet-stream', headers={"Content-Disposition": f"attachment; filename={os.path.basename(file_path)}"})
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


def extract_bullet_points(prompt):
    """
    Extracts bullet points from the given prompt using regex and formats them as a text summary.
    
    Args:
        prompt (str): The input text containing bullet points.
    
    Returns:
        str: A formatted string containing the bullet points.
    """
    # Regex pattern to match bullet points, assuming they start with numbers or dashes followed by a period or space
    bullet_points_pattern = r"(?:\d+\.|-) (.*?)(?=\n|$)"
    
    # Find all matches for bullet points in the prompt
    bullet_points = re.findall(bullet_points_pattern, prompt)
    
    # Join the bullet points into a single text block separated by newlines
    summary = "\n".join(f"- {point}" for point in bullet_points)
    
    return summary


def write_to_db(documentLink, agentId, name, description, prompt, toolList, userId, umlPath, assistantId):
    db = SessionLocal()
    logger.info(f"Function write_to_db called with args: documentLink={documentLink}, agentId={agentId}, name={name}, "
                f"description={description}, prompt length={len(prompt) if prompt else 0}, toolList={toolList}, "
                f"userId={userId}, umlPath={umlPath}")

    try:
        if agentId is None:
            logger.info("Creating a new SubAgentConfiguration entry")

            # Input validation
            if not documentLink:
                logger.warning("documentLink is missing")
                return "documentLink Missing"
            if not name:
                logger.warning("name is missing")
                return "name_missing"
            if not prompt:
                logger.warning("prompt is missing")
                return "prompt missing"
            if not toolList:
                logger.warning("tools list is missing")
                return "tools missing"
            if not description:
                logger.warning("agent description is missing")
                return "missing agent description"

            # Extract bullet points for the summary
            summary = extract_bullet_points(prompt)
            logger.info(f"Extracted summary: {summary}")

            # Create new entry
            new_sub_agent = SubAgentConfiguration(
                assistantId=assistantId,  # Replace with logic if needed
                name=name,
                description=description,
                prompt=prompt,
                toolList=toolList,
                summary=summary,
                documentLink=generate_download_file_url(documentLink),
                createdBy=userId,
                updatedBy=userId,
                status=True,
                state='Processed',
                flowUML=generate_download_uml_url(umlPath)
            )

            db.add(new_sub_agent)
            db.commit()
            db.refresh(new_sub_agent)
            logger.info(f"New SubAgentConfiguration created with ID: {new_sub_agent.id}")
            return new_sub_agent

        else:
            logger.info(f"Updating SubAgentConfiguration with ID: {agentId}")

            # Fetch existing entry
            sub_agent = db.query(SubAgentConfiguration).filter(SubAgentConfiguration.id == agentId).first()
            if not sub_agent:
                logger.error(f"SubAgentConfiguration with ID {agentId} not found", exc_info=True)
                raise HTTPException(status_code=404, detail="SubAgentConfiguration not found")

            # Input validation
            if not documentLink:
                logger.warning("documentLink is missing")
                return "documentLink Missing"
            if not name:
                logger.warning("name is missing")
                return "name_missing"
            if not prompt:
                logger.warning("prompt is missing")
                return "prompt missing"
            if not toolList:
                logger.warning("tools list is missing")
                return "tools missing"
            if not description:
                logger.warning("agent description is missing")
                return "missing agent description"

            summary = extract_bullet_points(prompt)
            logger.info(f"Extracted summary: {summary}")

            # Update fields
            sub_agent.description = description
            sub_agent.prompt = prompt
            sub_agent.summary = summary
            sub_agent.documentLink = generate_download_file_url(documentLink)
            sub_agent.updatedBy = userId
            sub_agent.updatedOn = datetime.utcnow()
            sub_agent.status = True
            sub_agent.state = 'Processing'
            sub_agent.flowUML = generate_download_uml_url(umlPath)

            db.commit()
            db.refresh(sub_agent)
            logger.info(f"SubAgentConfiguration with ID {agentId} updated successfully")
            return sub_agent

    except SQLAlchemyError as e:
        db.rollback()
        logger.error(f"Database error occurred in write_to_db: {str(e)}", exc_info=True)
        return None
    except Exception as e:
        logger.error(f"Unexpected error in write_to_db: {str(e)}", exc_info=True)
        return None
    finally:
        db.close()
        logger.info("Database session closed in write_to_db")

        
        
def get_agent_UML(agentId: int):
    db = SessionLocal()
    logger.info(f"Attempting to fetch UML image for agentId: {agentId}")
    
    try:
        # Fetch the SubAgentConfiguration record for the given assistantId
        sub_agent = db.query(SubAgentConfiguration).filter(SubAgentConfiguration.id == agentId).first()
        
        if not sub_agent:
            logger.warning(f"No record found for agentId: {agentId}")
            raise HTTPException(status_code=404, detail="Agent not found for the provided assistantId")
        
        if not sub_agent.flowUML:
            logger.warning(f"No UML image path found in flowUML for agentId: {agentId}")
            raise HTTPException(status_code=404, detail="Image not found for the provided assistantId")
        
        # Construct the full path to the image
        image_path = sub_agent.flowUML
        logger.info(f"Found image path for agentId {agentId}: {image_path}")
        
        # Check if the image file exists on the server
        if not os.path.exists(image_path):
            logger.error(f"Image file does not exist at path: {image_path} for agentId: {agentId}", exc_info=True)
            raise HTTPException(status_code=404, detail="Image file does not exist on the server")
        
        # Log successful retrieval
        logger.info(f"Successfully retrieved UML image for agentId: {agentId}")
        
        # Return the image file as a response
        return FileResponse(image_path, media_type="image/png")
    
    except HTTPException as http_err:
        logger.error(f"HTTP error for agentId {agentId}: {http_err.detail}", exc_info=True)
        raise http_err  # Re-raise HTTPException so FastAPI can handle it correctly
    except Exception as e:
        logger.exception(f"An unexpected error occurred while retrieving UML image for agentId {agentId}: {str(e)}")
        return None
    finally:
        db.close()
        logger.info(f"Database session closed for agentId: {agentId}")
###########################################################################################################################################

def get_prompts_and_tool_lists_by_assistant_id(assistant_id: int) -> List[Tuple[str, str]]:
    db = SessionLocal()
    try:
        logger.info(f"Fetching prompts and tool lists for assistantId: {assistant_id}")
        results = (
                    db.query(SubAgentConfiguration.prompt, SubAgentConfiguration.toolList)
                    .filter(and_(
                        SubAgentConfiguration.assistantId == 1001,
                        SubAgentConfiguration.status == True
                    ))
                    .order_by(desc(SubAgentConfiguration.updatedOn))
                    .all()
                )
        return results
    except Exception as e:
        logger.error(f"An error occurred while fetching prompts and tool lists for assistantId: {assistant_id} - {e}", exc_info=True)
        return []
    finally:
        db.close()
