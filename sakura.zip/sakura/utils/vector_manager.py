from qdrant_client import QdrantClient
from qdrant_client.http.models import Distance, VectorParams, PointStruct
import json
import uuid
from typing import Dict, List, Optional, Tuple
from sentence_transformers import SentenceTransformer
import logging
from datetime import datetime
import os
from keyword_manager import KeywordManager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class VectorManager:
    """Manages Qdrant operations for PA pattern matching"""
    def __init__(self):
        """Initialize vector manager with Qdrant and sentence transformer"""
        # Load config from environment
        import os
        from dotenv import load_dotenv
        load_dotenv()
        qdrant_host = os.getenv("QDRANT_HOST", "localhost")
        qdrant_port = int(os.getenv("QDRANT_PORT", "6333"))
        collection_name = os.getenv("QDRANT_COLLECTION", "pa_patterns")
        model_name = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-mpnet-base-v2")
        vector_size = int(os.getenv("VECTOR_SIZE", "768"))
        self.collection_name = collection_name
        # Initialize dynamic keyword manager
        logger.info("VectorManager: Initializing dynamic keyword manager...")
        self.keyword_manager = KeywordManager()
        # Initialize Qdrant client
        logger.info(f"VectorManager: Connecting to Qdrant at {qdrant_host}:{qdrant_port}")
        self.client = QdrantClient(host=qdrant_host, port=qdrant_port)
        # Ensure collection exists
        if collection_name not in [c.name for c in self.client.get_collections().collections]:
            logger.info(f"VectorManager: Creating Qdrant collection '{collection_name}'")
            self.client.recreate_collection(
                collection_name=collection_name,
                vectors_config=VectorParams(size=vector_size, distance=Distance.COSINE)
            )
        # Load embedding model
        logger.info(f"VectorManager: Loading embedding model '{model_name}'...")
        self.encoder = SentenceTransformer(model_name)
        logger.info("VectorManager: Embedding model loaded successfully")
        logger.info(f"VectorManager initialized with Qdrant collection '{collection_name}'")

    def normalize_query(self, query: str) -> str:
        """Normalize query by replacing entities with placeholders using latest self-learned dictionaries"""
        import re
        normalized = query.lower().strip()
        # Use latest person names from KeywordManager
        person_names = self.keyword_manager.get_keywords("person_names")
        for name in person_names:
            normalized = re.sub(rf'\b{name}\b', '[PERSON]', normalized, flags=re.IGNORECASE)
        # Company, time, and other references can be extended similarly if needed
        return normalized

    def detect_context(self, query: str) -> Dict[str, str]:
        """Detect context factors from query using dynamic keyword system"""
        return self.keyword_manager.detect_context(query)
    
    def classify_intent(self, query: str) -> str:
        """Classify intent using dynamic keyword system"""
        return self.keyword_manager.classify_intent(query)
    
    def get_keyword_manager(self) -> KeywordManager:
        """Get keyword manager instance for learning updates"""
        return self.keyword_manager
    
    def get_keyword_learning_report(self) -> Dict:
        """Get learning statistics from keyword manager"""
        return self.keyword_manager.get_learning_report()

    def calculate_context_compatibility(self, query_context: Dict, stored_context: Dict) -> float:
        """Calculate context compatibility score (0-1)"""
        
        # Urgency compatibility matrix
        urgency_matrix = {
            ('high', 'high'): 1.0,
            ('high', 'medium'): 0.7,
            ('high', 'low'): 0.2,
            ('medium', 'high'): 0.8,
            ('medium', 'medium'): 1.0,
            ('medium', 'low'): 0.6,
            ('low', 'high'): 0.3,
            ('low', 'medium'): 0.7,
            ('low', 'low'): 1.0,
        }
        
        # Formality compatibility matrix
        formality_matrix = {
            ('formal', 'formal'): 1.0,
            ('formal', 'professional'): 0.8,
            ('formal', 'casual'): 0.3,
            ('professional', 'formal'): 0.9,
            ('professional', 'professional'): 1.0,
            ('professional', 'casual'): 0.6,
            ('casual', 'formal'): 0.2,
            ('casual', 'professional'): 0.7,
            ('casual', 'casual'): 1.0,
        }
        
        # Calculate scores
        urgency_score = urgency_matrix.get(
            (query_context['urgency_level'], stored_context['urgency_level']), 0.5
        )
        
        formality_score = formality_matrix.get(
            (query_context['formality_level'], stored_context['formality_level']), 0.5
        )
        
        # Sentiment score
        sentiment_score = 1.0 if query_context['sentiment'] == stored_context['sentiment'] else 0.6
        
        # Weighted average
        compatibility_score = (urgency_score * 0.4) + (formality_score * 0.4) + (sentiment_score * 0.2)
        
        return compatibility_score

    def calculate_confidence_score(self, semantic_score: float, context_score: float, 
                                 usage_count: int = 0, success_rate: float = 1.0) -> float:
        """Calculate overall confidence score using weighted factors"""
        
        # Historical success factor (0.5 to 1.0 based on usage)
        historical_factor = min(1.0, 0.5 + (usage_count * 0.1))
        historical_score = success_rate * historical_factor
        
        # Query complexity factor (simplified for now)
        complexity_score = 0.9  # Could be enhanced based on query analysis
        
        # Weighted combination
        confidence = (
            semantic_score * 0.60 +
            context_score * 0.25 +
            historical_score * 0.10 +
            complexity_score * 0.05
        )
        
        return min(1.0, confidence)

    def search_patterns(self, query: str, top_k: int = 5) -> List[Dict]:
        """Search for matching patterns and return candidates with scores"""
        
        normalized_query = self.normalize_query(query)
        query_context = self.detect_context(query)
        
        logger.info(f"Searching patterns for: '{query}' (normalized: '{normalized_query}')")
        
        # Perform vector search
        results = self.collection.query(
            query_texts=[normalized_query],
            n_results=min(top_k * 2, self.collection.count()),  # Get more for filtering
        )
        
        candidates = []
        
        if results['documents'] and results['documents'][0]:
            for i, (doc, metadata, distance) in enumerate(zip(
                results['documents'][0],
                results['metadatas'][0],
                results['distances'][0]
            )):
                # Convert distance to similarity
                semantic_score = 1 - distance
                
                # Calculate context compatibility
                stored_context = {
                    'urgency_level': metadata.get('urgency_level', 'medium'),
                    'formality_level': metadata.get('formality_level', 'professional'),
                    'sentiment': metadata.get('sentiment', 'neutral')
                }
                
                context_score = self.calculate_context_compatibility(query_context, stored_context)
                
                # Calculate overall confidence
                confidence = self.calculate_confidence_score(
                    semantic_score, 
                    context_score,
                    metadata.get('usage_count', 0),
                    metadata.get('success_rate', 1.0)
                )
                
                candidate = {
                    'id': results['ids'][0][i],
                    'original_query': metadata.get('original_query', ''),
                    'normalized_pattern': doc,
                    'llm_response': metadata.get('llm_response', ''),
                    'tts_file_path': metadata.get('tts_file_path', ''),
                    'intent': metadata.get('intent', ''),
                    'urgency_level': metadata.get('urgency_level', ''),
                    'formality_level': metadata.get('formality_level', ''),
                    'sentiment': metadata.get('sentiment', ''),
                    'confidence_score': confidence,
                    'semantic_score': semantic_score,
                    'context_score': context_score,
                    'usage_count': metadata.get('usage_count', 0),
                    'success_rate': metadata.get('success_rate', 1.0),
                    'created_at': metadata.get('created_at', ''),
                    'match_reasons': self._generate_match_reasons(semantic_score, context_score, confidence)
                }
                
                candidates.append(candidate)
        
        # Sort by confidence score
        candidates.sort(key=lambda x: x['confidence_score'], reverse=True)
        
        return candidates[:top_k]

    def _generate_match_reasons(self, semantic_score: float, context_score: float, confidence: float) -> List[str]:
        """Generate human-readable match reasons"""
        reasons = []
        
        if semantic_score > 0.9:
            reasons.append("Excellent semantic similarity")
        elif semantic_score > 0.7:
            reasons.append("Good semantic similarity")
        else:
            reasons.append("Moderate semantic similarity")
        
        if context_score > 0.8:
            reasons.append("Strong context match")
        elif context_score > 0.6:
            reasons.append("Good context compatibility")
        else:
            reasons.append("Weak context match")
        
        if confidence > 0.9:
            reasons.append("High overall confidence")
        elif confidence > 0.7:
            reasons.append("Medium confidence")
        else:
            reasons.append("Low confidence")
        
        return reasons

    def add_entry(self, entry_data: Dict) -> str:
        """
        Add new entry to vector database using the full metadata structure.
        Flattens nested fields for ChromaDB compatibility.
        """
        entry_id = entry_data.get('id', str(uuid.uuid4()))
        # Flatten metadata for ChromaDB (no nested dicts)
        metadata = {}
        # Flatten query_metadata
        qm = entry_data.get('query_metadata', {})
        for k, v in qm.items():
            if isinstance(v, dict) or isinstance(v, list):
                metadata[f'query_metadata_{k}'] = json.dumps(v)
            else:
                metadata[f'query_metadata_{k}'] = v
        # Flatten response_metadata
        rm = entry_data.get('response_metadata', {})
        for k, v in rm.items():
            metadata[f'response_metadata_{k}'] = v
        # Flatten context_analysis
        ca = entry_data.get('context_analysis', {})
        for k, v in ca.items():
            if isinstance(v, dict):
                for subk, subv in v.items():
                    metadata[f'context_analysis_{k}_{subk}'] = subv
            else:
                metadata[f'context_analysis_{k}'] = v
        # Flatten semantic_analysis
        sa = entry_data.get('semantic_analysis', {})
        for k, v in sa.items():
            if isinstance(v, list):
                metadata[f'semantic_analysis_{k}'] = json.dumps(v)
            else:
                metadata[f'semantic_analysis_{k}'] = v
        # Flatten quality_metrics
        qm2 = entry_data.get('quality_metrics', {})
        for k, v in qm2.items():
            metadata[f'quality_metrics_{k}'] = v
        # Flatten learning_data
        ld = entry_data.get('learning_data', {})
        for k, v in ld.items():
            if isinstance(v, dict):
                for subk, subv in v.items():
                    metadata[f'learning_data_{k}_{subk}'] = json.dumps(subv) if isinstance(subv, list) else subv
            else:
                metadata[f'learning_data_{k}'] = v
        # Flatten system_metadata
        sm = entry_data.get('system_metadata', {})
        for k, v in sm.items():
            metadata[f'system_metadata_{k}'] = v
        # Use normalized pattern as document
        document = qm.get('normalized_pattern', self.normalize_query(qm.get('original_query', '')))
        # Add to collection
        self.collection.add(
            documents=[document],
            metadatas=[metadata],
            ids=[entry_id]
        )
        logger.info(f"Added new entry: {entry_id}")
        return entry_id

    def load_data_from_json(self, json_file: str) -> int:
        """Load training data from JSON file"""
        
        try:
            with open(json_file, 'r') as f:
                data = json.load(f)
            
            count = 0
            for entry in data:
                self.add_entry(entry)
                count += 1
            
            logger.info(f"Loaded {count} entries from {json_file}")
            return count
            
        except FileNotFoundError:
            logger.error(f"File not found: {json_file}")
            return 0
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            return 0

    def get_database_stats(self) -> Dict:
        """Get comprehensive database statistics"""
        
        total_count = self.collection.count()
        
        if total_count == 0:
            return {
                'total_entries': 0,
                'intent_distribution': {},
                'urgency_distribution': {},
                'formality_distribution': {},
                'sentiment_distribution': {}
            }
        
        # Get all metadata for analysis
        all_data = self.collection.get()
        metadatas = all_data['metadatas']
        
        # Count distributions
        intent_counts = {}
        urgency_counts = {}
        formality_counts = {}
        sentiment_counts = {}
        
        for metadata in metadatas:
            intent = metadata.get('intent', 'unknown')
            urgency = metadata.get('urgency_level', 'unknown')
            formality = metadata.get('formality_level', 'unknown')
            sentiment = metadata.get('sentiment', 'unknown')
            
            intent_counts[intent] = intent_counts.get(intent, 0) + 1
            urgency_counts[urgency] = urgency_counts.get(urgency, 0) + 1
            formality_counts[formality] = formality_counts.get(formality, 0) + 1
            sentiment_counts[sentiment] = sentiment_counts.get(sentiment, 0) + 1
        
        return {
            'total_entries': total_count,
            'intent_distribution': intent_counts,
            'urgency_distribution': urgency_counts,
            'formality_distribution': formality_counts,
            'sentiment_distribution': sentiment_counts
        }

    def clear_database(self):
        """Clear all entries from database"""
        
        try:
            self.client.delete_collection("pa_patterns")
            self.collection = self.client.create_collection(
                name="pa_patterns",
                metadata={"hnsw:space": "cosine"}
            )
            logger.info("Database cleared successfully")
        except Exception as e:
            logger.error(f"Error clearing database: {e}")
