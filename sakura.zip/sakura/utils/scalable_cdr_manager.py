"""
Scalable CDR Batch Manager for Heavy Load Scenarios
Provides sharded batching with load balancing and overflow protection
"""
import json
import time
import threading
import hashlib
from typing import Dict, Optional, List
from dataclasses import dataclass, field
from models.redis_models import UserCallCDR
from utils.redis_db_manager import redis_manager
from utils.redis_hash_optimizer import RedisHashOptimizer
from logger import get_logger
import os
import queue
from concurrent.futures import ThreadPoolExecutor
import weakref

logger = get_logger(__name__)

@dataclass
class CDRBatch:
    """Represents a batched CDR update"""
    call_id: str
    cdr_record: UserCallCDR
    last_update: float = field(default_factory=time.time)
    pending_updates: int = 0
    first_update: float = field(default_factory=time.time)
    shard_id: int = 0

class CircuitBreaker:
    """Circuit breaker to protect Redis from overload"""
    
    def __init__(self, failure_threshold: int = 5, timeout: float = 30.0):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.failure_count = 0
        self.last_failure_time = 0
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
        self.lock = threading.RLock()  # FIXED: Use RLock for potential recursive calls
    
    def call(self, func, *args, **kwargs):
        """Execute function with circuit breaker protection"""
        with self.lock:
            if self.state == "OPEN":
                if time.time() - self.last_failure_time > self.timeout:
                    self.state = "HALF_OPEN"
                    logger.info("Circuit breaker moving to HALF_OPEN state")
                else:
                    raise Exception("Circuit breaker is OPEN - Redis operations blocked")
        
        try:
            result = func(*args, **kwargs)
            with self.lock:
                if self.state == "HALF_OPEN":
                    self.state = "CLOSED"
                    self.failure_count = 0
                    logger.info("Circuit breaker reset to CLOSED state")
            return result
            
        except Exception as e:
            with self.lock:
                self.failure_count += 1
                self.last_failure_time = time.time()
                
                if self.failure_count >= self.failure_threshold:
                    self.state = "OPEN"
                    logger.error(f"Circuit breaker OPENED after {self.failure_count} failures")
            raise

class ScalableCDRManager:
    """Manages CDR updates with sharding and load balancing for heavy load scenarios"""
    
    def __init__(self, 
                 num_shards: int = None,
                 batch_interval: float = 1.0, 
                 max_pending: int = 10,
                 max_batches_per_shard: int = 1000,
                 flush_workers: int = None):
        
        # Read from environment variables with reasonable defaults
        self.num_shards = num_shards or int(os.getenv('CDR_NUM_SHARDS', min(max(os.cpu_count() or 2, 1), 4)))
        self.flush_workers = flush_workers or int(os.getenv('CDR_FLUSH_WORKERS', min(self.num_shards, 4)))
        
        self.batch_interval = batch_interval
        self.max_pending = max_pending
        self.max_batches_per_shard = max_batches_per_shard
        
        # Sharded storage - each shard has its own lock to reduce contention
        self.shards: List[CDRShard] = []
        
        # OPTIMIZATION: Multiple Redis clients to eliminate single-client bottleneck
        self.redis_clients = []
        self.circuit_breakers = []
        self._init_redis_clients()
        
    def _init_redis_clients(self):
        """Initialize multiple Redis clients for parallel operations"""
        for shard_id in range(self.num_shards):
            try:
                # Create separate Redis client for each shard to eliminate serialization
                # PERFORMANCE FIX: Use CDR database for heavy JSON operations
                client = redis_manager.get_cdr_client()
                circuit_breaker = CircuitBreaker()
                
                self.redis_clients.append(client)
                self.circuit_breakers.append(circuit_breaker)
                
                # PERFORMANCE FIX: Initialize hash optimizer for each shard
                hash_optimizer = RedisHashOptimizer(client)
                self.hash_optimizers = getattr(self, 'hash_optimizers', [])
                self.hash_optimizers.append(hash_optimizer)
                
                logger.info(f"Initialized Redis client and hash optimizer for CDR shard {shard_id}")
            except Exception as e:
                logger.error(f"Failed to initialize Redis client for shard {shard_id}: {e}")
                # Fallback to shared client if individual fails
                # PERFORMANCE FIX: Use CDR database for fallback as well
                fallback_client = redis_manager.get_cdr_client()
                self.redis_clients.append(fallback_client)
                self.circuit_breakers.append(CircuitBreaker())
                
                # Initialize hash optimizer for fallback client too
                fallback_hash_optimizer = RedisHashOptimizer(fallback_client)
                self.hash_optimizers = getattr(self, 'hash_optimizers', [])
                self.hash_optimizers.append(fallback_hash_optimizer)
        
        # Lazy initialization - flush executor created on demand
        self.flush_executor = None
        self._executor_lock = threading.Lock()
        
        # Statistics
        self.stats = {
            'total_updates': 0,
            'total_flushes': 0,
            'failed_flushes': 0,
            'dropped_updates': 0,
            'avg_batch_size': 0.0,
            'circuit_breaker_trips': 0
        }
        self.stats_lock = threading.RLock()
        
        self._shutdown = False
        self._init_shards()
        self._start_monitoring()
        
        logger.info(f"ScalableCDRManager initialized with {self.num_shards} shards, "
                   f"{self.flush_workers} flush workers (lazy creation)")
    
    def _init_shards(self):
        """Initialize CDR shards"""
        for i in range(self.num_shards):
            shard = CDRShard(
                shard_id=i,
                batch_interval=self.batch_interval,
                max_pending=self.max_pending,
                max_batches=self.max_batches_per_shard,
                flush_callback=self._flush_batch
            )
            self.shards.append(shard)
    
    def _ensure_flush_executor(self):
        """Lazily create flush executor if needed"""
        if self.flush_executor is None:
            with self._executor_lock:
                if self.flush_executor is None:
                    logger.info(f"Lazily creating CDR flush executor with {self.flush_workers} workers")
                    self.flush_executor = ThreadPoolExecutor(
                        max_workers=self.flush_workers,
                        thread_name_prefix="CDRFlush"
                    )
                    logger.info("CDR flush executor created")
        return self.flush_executor
    
    def _hash_to_shard(self, call_id) -> int:
        """Distribute calls across shards using consistent hashing"""
        # PERFORMANCE FIX: Handle both string and integer call_ids
        call_id_str = str(call_id)
        return int(hashlib.md5(call_id_str.encode()).hexdigest(), 16) % self.num_shards
    
    def update_cdr(self, call_id: str, cdr_record: UserCallCDR, force_flush: bool = False):
        """Queue a CDR update for batching"""
        if self._shutdown:
            return
        
        shard_id = self._hash_to_shard(call_id)
        shard = self.shards[shard_id]
        
        with self.stats_lock:
            self.stats['total_updates'] += 1
        
        try:
            shard.update_cdr(call_id, cdr_record, force_flush)
        except Exception as e:
            with self.stats_lock:
                self.stats['dropped_updates'] += 1
            logger.error(f"Failed to update CDR for {call_id}: {e}")
    
    def _flush_batch(self, batch: CDRBatch):
        """Flush a single batch to Redis (called by shards) - OPTIMIZED with per-shard clients"""
        # Use shard-specific Redis client to eliminate serialization bottleneck
        shard_id = batch.shard_id
        redis_client = self.redis_clients[shard_id]
        circuit_breaker = self.circuit_breakers[shard_id]
        
        try:
            def redis_operation():
                call_cdr_key = f"{batch.call_id}_cdr"
                # PERFORMANCE FIX: Use Redis hash instead of JSON string
                hash_optimizer = self.hash_optimizers[shard_id]
                success = hash_optimizer.set_cdr_hash(batch.call_id, batch.cdr_record.__dict__)
                
                if not success:
                    # Fallback to JSON if hash operation fails
                    redis_client.set(call_cdr_key, json.dumps(batch.cdr_record.__dict__))
                
                # Set expiration only if not already set
                max_call_allowed_time = int(os.getenv('MAX_CALL_ALLOWED_TIME', 3600))
                # Set expiration based on which method was used
                if success:
                    # Hash method already handles expiration, but double-check
                    hash_key = f"{batch.call_id}_cdr_hash"
                    if redis_client.ttl(hash_key) == -1:
                        redis_client.expire(hash_key, max_call_allowed_time)
                else:
                    # JSON fallback method needs expiration
                    if redis_client.ttl(call_cdr_key) == -1:
                        redis_client.expire(call_cdr_key, max_call_allowed_time)
            
            # Use shard-specific circuit breaker protection
            circuit_breaker.call(redis_operation)
            
            with self.stats_lock:
                self.stats['total_flushes'] += 1
                # Update running average batch size
                total_flushes = self.stats['total_flushes']
                self.stats['avg_batch_size'] = (
                    (self.stats['avg_batch_size'] * (total_flushes - 1) + batch.pending_updates) 
                    / total_flushes
                )
            
            logger.debug(f"Flushed CDR batch for {batch.call_id}: "
                        f"{batch.pending_updates} updates (shard {batch.shard_id})")
            
        except Exception as e:
            with self.stats_lock:
                self.stats['failed_flushes'] += 1
                if "Circuit breaker" in str(e):
                    self.stats['circuit_breaker_trips'] += 1
            
            logger.error(f"Error flushing CDR batch for {batch.call_id}: {e}")
    
    def _start_monitoring(self):
        """Start background monitoring and cleanup"""
        def monitor_loop():
            while not self._shutdown:
                try:
                    time.sleep(30)  # Monitor every 30 seconds
                    self._log_stats()
                    self._cleanup_completed_batches()
                except Exception as e:
                    logger.error(f"Error in CDR monitor: {e}")
        
        monitor_thread = threading.Thread(target=monitor_loop, daemon=True, name="CDRMonitor")
        monitor_thread.start()
    
    def _log_stats(self):
        """Log comprehensive statistics"""
        with self.stats_lock:
            global_stats = self.stats.copy()
        
        shard_stats = [shard.get_stats() for shard in self.shards]
        total_active_batches = sum(s['active_batches'] for s in shard_stats)
        total_pending_updates = sum(s['pending_updates'] for s in shard_stats)
        
        logger.info(f"CDR Manager Stats - Updates: {global_stats['total_updates']}, "
                   f"Flushes: {global_stats['total_flushes']}, "
                   f"Failed: {global_stats['failed_flushes']}, "
                   f"Dropped: {global_stats['dropped_updates']}, "
                   f"Active Batches: {total_active_batches}, "
                   f"Pending: {total_pending_updates}, "
                   f"Avg Batch Size: {global_stats['avg_batch_size']:.1f}, "
                   f"CB Trips: {global_stats['circuit_breaker_trips']}")
    
    def _cleanup_completed_batches(self):
        """Clean up any stale batches across all shards"""
        for shard in self.shards:
            shard.cleanup_stale_batches()
    
    def force_flush_all(self):
        """Force flush all pending batches"""
        for shard in self.shards:
            shard.force_flush_all()
        logger.info("All CDR batches force flushed")
    
    def get_stats(self) -> dict:
        """Get comprehensive statistics"""
        with self.stats_lock:
            global_stats = self.stats.copy()
        
        shard_stats = [shard.get_stats() for shard in self.shards]
        
        return {
            'global': global_stats,
            'shards': shard_stats,
            'num_shards': self.num_shards,
            'flush_workers': self.flush_workers,
            'circuit_breaker_state': self.circuit_breaker.state
        }
    
    def shutdown(self):
        """Shutdown the CDR manager"""
        self._shutdown = True
        
        # Flush all pending batches
        self.force_flush_all()
        
        # Shutdown thread pool if it was created
        if self.flush_executor is not None:
            self.flush_executor.shutdown(wait=True)
        
        logger.info("ScalableCDRManager shutdown completed")

class CDRShard:
    """Individual shard managing a subset of CDR batches"""
    
    def __init__(self, shard_id: int, batch_interval: float, max_pending: int, 
                 max_batches: int, flush_callback):
        self.shard_id = shard_id
        self.batch_interval = batch_interval
        self.max_pending = max_pending
        self.max_batches = max_batches
        self.flush_callback = flush_callback
        
        self.batches: Dict[str, CDRBatch] = {}
        self.lock = threading.RLock()
        self._start_flush_timer()
    
    def _start_flush_timer(self):
        """Start periodic flush timer for this shard"""
        def flush_loop():
            while True:
                try:
                    time.sleep(self.batch_interval / 2)
                    self.flush_expired_batches()
                except Exception as e:
                    logger.error(f"Error in shard {self.shard_id} flush loop: {e}")
        
        timer_thread = threading.Thread(
            target=flush_loop, 
            daemon=True, 
            name=f"CDRShard-{self.shard_id}"
        )
        timer_thread.start()
    
    def update_cdr(self, call_id: str, cdr_record: UserCallCDR, force_flush: bool = False):
        """Update CDR for this shard - OPTIMIZED for minimal lock time"""
        current_time = time.time()
        batch_to_flush = None
        
        # OPTIMIZATION: Minimize critical section time
        with self.lock:
            # Fast capacity check
            if len(self.batches) >= self.max_batches and call_id not in self.batches:
                logger.warning(f"Shard {self.shard_id} at capacity, dropping update for {call_id}")
                raise Exception(f"Shard {self.shard_id} at capacity")
            
            # Fast update or create
            if call_id in self.batches:
                batch = self.batches[call_id]
                batch.cdr_record = cdr_record
                batch.last_update = current_time
                batch.pending_updates += 1
            else:
                # Create new batch
                batch = CDRBatch(
                    call_id=call_id,
                    cdr_record=cdr_record,
                    last_update=current_time,
                    pending_updates=1,
                    first_update=current_time,
                    shard_id=self.shard_id
                )
                self.batches[call_id] = batch
            
            # Fast flush decision (minimize computation in critical section)
            should_flush = (
                force_flush or 
                batch.pending_updates >= self.max_pending or
                (current_time - batch.first_update) >= (self.batch_interval * 3)
            )
            
            # Prepare for flush if needed (still in lock to maintain consistency)
            if should_flush:
                batch_to_flush = batch
                # Remove from batches to prevent memory buildup
                if call_id in self.batches:
                    del self.batches[call_id]
        
        # OPTIMIZATION: Flush outside the lock to reduce contention
        if batch_to_flush:
            try:
                self.flush_callback(batch_to_flush)
            except Exception as e:
                logger.error(f"Failed to flush batch for {call_id} in shard {self.shard_id}: {e}")
    
    def _flush_batch_internal(self, call_id: str, batch: CDRBatch):
        """Internal flush method (assumes lock is held)"""
        # Remove from batches before flushing to prevent memory buildup
        if call_id in self.batches:
            del self.batches[call_id]
        
        # Submit to flush callback (async)
        try:
            self.flush_callback(batch)
        except Exception as e:
            logger.error(f"Error submitting batch for flush: {e}")
    
    def flush_expired_batches(self):
        """Flush batches that have exceeded time interval"""
        current_time = time.time()
        to_flush = []
        
        with self.lock:
            for call_id, batch in list(self.batches.items()):
                time_since_last = current_time - batch.last_update
                time_since_first = current_time - batch.first_update
                
                should_flush = (
                    time_since_last >= self.batch_interval or
                    time_since_first >= (self.batch_interval * 4)  # Emergency flush
                )
                
                if should_flush:
                    to_flush.append((call_id, batch))
        
        for call_id, batch in to_flush:
            with self.lock:
                if call_id in self.batches:
                    self._flush_batch_internal(call_id, batch)
    
    def cleanup_stale_batches(self):
        """Clean up very old batches that might be stuck"""
        current_time = time.time()
        stale_threshold = 300  # 5 minutes
        
        with self.lock:
            stale_calls = [
                call_id for call_id, batch in self.batches.items()
                if current_time - batch.first_update > stale_threshold
            ]
            
            for call_id in stale_calls:
                logger.warning(f"Cleaning up stale batch for {call_id} in shard {self.shard_id}")
                if call_id in self.batches:
                    batch = self.batches[call_id]
                    self._flush_batch_internal(call_id, batch)
    
    def force_flush_all(self):
        """Force flush all batches in this shard"""
        with self.lock:
            for call_id, batch in list(self.batches.items()):
                self._flush_batch_internal(call_id, batch)
    
    def get_stats(self) -> dict:
        """Get shard statistics"""
        with self.lock:
            return {
                'shard_id': self.shard_id,
                'active_batches': len(self.batches),
                'pending_updates': sum(b.pending_updates for b in self.batches.values()),
                'max_batches': self.max_batches
            }

# Global CDR manager instance (scalable by default)
_cdr_manager = ScalableCDRManager()

def update_cdr_record_with_expiration(call_id: str, cdr_record: UserCallCDR, force_immediate: bool = False):
    """CDR update function with sharding and load balancing (scalable implementation)"""
    _cdr_manager.update_cdr(call_id, cdr_record, force_flush=force_immediate)

def update_cdr_record_scalable(call_id: str, cdr_record: UserCallCDR, force_immediate: bool = False):
    """CDR update function (alias for compatibility)"""
    _cdr_manager.update_cdr(call_id, cdr_record, force_flush=force_immediate)

def get_cdr_batch_stats() -> dict:
    """Get CDR manager statistics (scalable implementation)"""
    return _cdr_manager.get_stats()

def get_scalable_cdr_stats() -> dict:
    """Get CDR manager statistics (alias for compatibility)"""
    return _cdr_manager.get_stats()

def force_flush_all_cdr():
    """Force flush all pending CDR updates (scalable implementation)"""
    _cdr_manager.force_flush_all()

def force_flush_all_scalable_cdr():
    """Force flush all pending CDR updates (alias for compatibility)"""
    _cdr_manager.force_flush_all()

def force_flush_cdr(call_id: str):
    """Force flush CDR for a specific call"""
    _cdr_manager.force_flush_call(call_id)

# Register cleanup
import atexit
atexit.register(_cdr_manager.shutdown)
