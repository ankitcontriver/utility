voice_mappings = {
    "af-ZA-AdriNeural": {
        "provider": "azure",
        "speech_code": "af-ZA",
    },
    "af-ZA-WillemNeural": {
        "provider": "azure",
        "speech_code": "af-ZA",
    },
    "am-ET-MekdesNeural": {
        "provider": "azure",
        "speech_code": "am-ET",
    },
    "am-ET-AmehaNeural": {
        "provider": "azure",
        "speech_code": "am-ET",
    },
    "ar-AE-FatimaNeural": {
        "provider": "azure",
        "speech_code": "ar-AE",
    },
    "ar-AE-HamdanNeural": {
        "provider": "azure",
        "speech_code": "ar-AE",
    },
    "ar-BH-LailaNeural": {
        "provider": "azure",
        "speech_code": "ar-BH",
    },
    "ar-BH-AliNeural": {
        "provider": "azure",
        "speech_code": "ar-BH",
    },
    "ar-DZ-AminaNeural": {
        "provider": "azure",
        "speech_code": "ar-DZ",
    },
    "ar-DZ-IsmaelNeural": {
        "provider": "azure",
        "speech_code": "ar-DZ",
    },
    "ar-EG-SalmaNeural": {
        "provider": "azure",
        "speech_code": "ar-EG",
    },
    "ar-EG-ShakirNeural": {
        "provider": "azure",
        "speech_code": "ar-EG",
    },
    "ar-IQ-RanaNeural": {
        "provider": "azure",
        "speech_code": "ar-IQ",
    },
    "ar-IQ-BasselNeural": {
        "provider": "azure",
        "speech_code": "ar-IQ",
    },
    "ar-JO-SanaNeural": {
        "provider": "azure",
        "speech_code": "ar-JO",
    },
    "ar-JO-TaimNeural": {
        "provider": "azure",
        "speech_code": "ar-JO",
    },
    "ar-KW-NouraNeural": {
        "provider": "azure",
        "speech_code": "ar-KW",
    },
    "ar-KW-FahedNeural": {
        "provider": "azure",
        "speech_code": "ar-KW",
    },
    "ar-LB-LaylaNeural": {
        "provider": "azure",
        "speech_code": "ar-LB",
    },
    "ar-LB-RamiNeural": {
        "provider": "azure",
        "speech_code": "ar-LB",
    },
    "ar-LY-ImanNeural": {
        "provider": "azure",
        "speech_code": "ar-LY",
    },
    "ar-LY-OmarNeural": {
        "provider": "azure",
        "speech_code": "ar-LY",
    },
    "ar-MA-MounaNeural": {
        "provider": "azure",
        "speech_code": "ar-MA",
    },
    "ar-MA-JamalNeural": {
        "provider": "azure",
        "speech_code": "ar-MA",
    },
    "ar-OM-AyshaNeural": {
        "provider": "azure",
        "speech_code": "ar-OM",
    },
    "ar-OM-AbdullahNeural": {
        "provider": "azure",
        "speech_code": "ar-OM",
    },
    "ar-QA-AmalNeural": {
        "provider": "azure",
        "speech_code": "ar-QA",
    },
    "ar-QA-MoazNeural": {
        "provider": "azure",
        "speech_code": "ar-QA",
    },
    "ar-SA-ZariyahNeural": {
        "provider": "azure",
        "speech_code": "ar-SA",
    },
    "ar-SA-HamedNeural": {
        "provider": "azure",
        "speech_code": "ar-SA",
    },
    "ar-SY-AmanyNeural": {
        "provider": "azure",
        "speech_code": "ar-SY",
    },
    "ar-SY-LaithNeural": {
        "provider": "azure",
        "speech_code": "ar-SY",
    },
    "ar-TN-ReemNeural": {
        "provider": "azure",
        "speech_code": "ar-TN",
    },
    "ar-TN-HediNeural": {
        "provider": "azure",
        "speech_code": "ar-TN",
    },
    "ar-YE-MaryamNeural": {
        "provider": "azure",
        "speech_code": "ar-YE",
    },
    "ar-YE-SalehNeural": {
        "provider": "azure",
        "speech_code": "ar-YE",
    },
    "az-AZ-BanuNeural": {
        "provider": "azure",
        "speech_code": "az-AZ",
    },
    "az-AZ-BabekNeural": {
        "provider": "azure",
        "speech_code": "az-AZ",
    },
    "bg-BG-KalinaNeural": {
        "provider": "azure",
        "speech_code": "bg-BG",
    },
    "bg-BG-BorislavNeural": {
        "provider": "azure",
        "speech_code": "bg-BG",
    },
    "bn-BD-NabanitaNeural": {
        "provider": "azure",
        "speech_code": "bn-BD",
    },
    "bn-BD-PradeepNeural": {
        "provider": "azure",
        "speech_code": "bn-BD",
    },
    "bn-IN-TanishaaNeural": {
        "provider": "azure",
        "speech_code": "bn-IN",
    },
    "bn-IN-BashkarNeural": {
        "provider": "azure",
        "speech_code": "bn-IN",
    },
    "bs-BA-VesnaNeural": {
        "provider": "azure",
        "speech_code": "bs-BA",
    },
    "bs-BA-GoranNeural": {
        "provider": "azure",
        "speech_code": "bs-BA",
    },
    "ca-ES-JoanaNeural": {
        "provider": "azure",
        "speech_code": "ca-ES",
    },
    "ca-ES-EnricNeural": {
        "provider": "azure",
        "speech_code": "ca-ES",
    },
    "ca-ES-AlbaNeural": {
        "provider": "azure",
        "speech_code": "ca-ES",
    },
    "cs-CZ-VlastaNeural": {
        "provider": "azure",
        "speech_code": "cs-CZ",
    },
    "cs-CZ-AntoninNeural": {
        "provider": "azure",
        "speech_code": "cs-CZ",
    },
    "cy-GB-NiaNeural": {
        "provider": "azure",
        "speech_code": "cy-GB",
    },
    "cy-GB-AledNeural": {
        "provider": "azure",
        "speech_code": "cy-GB",
    },
    "da-DK-ChristelNeural": {
        "provider": "azure",
        "speech_code": "da-DK",
    },
    "da-DK-JeppeNeural": {
        "provider": "azure",
        "speech_code": "da-DK",
    },
    "de-AT-IngridNeural": {
        "provider": "azure",
        "speech_code": "de-AT",
    },
    "de-AT-JonasNeural": {
        "provider": "azure",
        "speech_code": "de-AT",
    },
    "de-CH-LeniNeural": {
        "provider": "azure",
        "speech_code": "de-CH",
    },
    "de-CH-JanNeural": {
        "provider": "azure",
        "speech_code": "de-CH",
    },
    "de-DE-KatjaNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-ConradNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-AmalaNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-BerndNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-ChristophNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-ElkeNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-GiselaNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-KasperNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-KillianNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-KlarissaNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-KlausNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-LouisaNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-MajaNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-RalfNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-TanjaNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-FlorianMultilingualNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "de-DE-SeraphinaMultilingualNeural": {
        "provider": "azure",
        "speech_code": "de-DE",
    },
    "el-GR-AthinaNeural": {
        "provider": "azure",
        "speech_code": "el-GR",
    },
    "el-GR-NestorasNeural": {
        "provider": "azure",
        "speech_code": "el-GR",
    },
    "en-AU-NatashaNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-WilliamNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-AnnetteNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-CarlyNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-DarrenNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-DuncanNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-ElsieNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-FreyaNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-JoanneNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-KenNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-KimNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-NeilNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-TimNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-AU-TinaNeural": {
        "provider": "azure",
        "speech_code": "en-AU",
    },
    "en-CA-ClaraNeural": {
        "provider": "azure",
        "speech_code": "en-CA",
    },
    "en-CA-LiamNeural": {
        "provider": "azure",
        "speech_code": "en-CA",
    },
    "en-GB-SoniaNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-RyanNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-LibbyNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-AbbiNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-AlfieNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-BellaNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-ElliotNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-EthanNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-HollieNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-MaisieNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-NoahNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-OliverNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-OliviaNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-GB-ThomasNeural": {
        "provider": "azure",
        "speech_code": "en-GB",
    },
    "en-HK-YanNeural": {
        "provider": "azure",
        "speech_code": "en-HK",
    },
    "en-HK-SamNeural": {
        "provider": "azure",
        "speech_code": "en-HK",
    },
    "en-IE-EmilyNeural": {
        "provider": "azure",
        "speech_code": "en-IE",
    },
    "en-IE-ConnorNeural": {
        "provider": "azure",
        "speech_code": "en-IE",
    },
    "en-IN-NeerjaNeural": {
        "provider": "azure",
        "speech_code": "en-IN",
    },
    "en-IN-PrabhatNeural": {
        "provider": "azure",
        "speech_code": "en-IN",
    },
    "en-KE-AsiliaNeural": {
        "provider": "azure",
        "speech_code": "en-KE",
    },
    "en-KE-ChilembaNeural": {
        "provider": "azure",
        "speech_code": "en-KE",
    },
    "en-NG-EzinneNeural": {
        "provider": "azure",
        "speech_code": "en-NG",
    },
    "en-NG-AbeoNeural": {
        "provider": "azure",
        "speech_code": "en-NG",
    },
    "en-NZ-MollyNeural": {
        "provider": "azure",
        "speech_code": "en-NZ",
    },
    "en-NZ-MitchellNeural": {
        "provider": "azure",
        "speech_code": "en-NZ",
    },
    "en-PH-RosaNeural": {
        "provider": "azure",
        "speech_code": "en-PH",
    },
    "en-PH-JamesNeural": {
        "provider": "azure",
        "speech_code": "en-PH",
    },
    "en-SG-LunaNeural": {
        "provider": "azure",
        "speech_code": "en-SG",
    },
    "en-SG-WayneNeural": {
        "provider": "azure",
        "speech_code": "en-SG",
    },
    "en-TZ-ImaniNeural": {
        "provider": "azure",
        "speech_code": "en-TZ",
    },
    "en-TZ-ElimuNeural": {
        "provider": "azure",
        "speech_code": "en-TZ",
    },
    "en-US-AvaNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-AndrewNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-EmmaNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-BrianNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-JennyNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-GuyNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-AriaNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-DavisNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-JaneNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-JasonNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-SaraNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-TonyNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-NancyNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-AmberNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-AnaNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-AshleyNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-BrandonNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-ChristopherNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-CoraNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-ElizabethNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-EricNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-JacobNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-JennyMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-MichelleNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-MonicaNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-RogerNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-RyanMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-SteffanNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-AIGenerate1Neural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-AIGenerate2Neural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-AndrewMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-AvaMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-BlueNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-BrianMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-EmmaMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-AlloyMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-EchoMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-FableMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-OnyxMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-NovaMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-ShimmerMultilingualNeural": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-AlloyMultilingualNeuralHD": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-EchoMultilingualNeuralHD": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-FableMultilingualNeuralHD": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-OnyxMultilingualNeuralHD": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-NovaMultilingualNeuralHD": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-US-ShimmerMultilingualNeuralHD": {
        "provider": "azure",
        "speech_code": "en-US",
    },
    "en-ZA-LeahNeural": {
        "provider": "azure",
        "speech_code": "en-ZA",
    },
    "en-ZA-LukeNeural": {
        "provider": "azure",
        "speech_code": "en-ZA",
    },
    "es-AR-ElenaNeural": {
        "provider": "azure",
        "speech_code": "es-AR",
    },
    "es-AR-TomasNeural": {
        "provider": "azure",
        "speech_code": "es-AR",
    },
    "es-BO-SofiaNeural": {
        "provider": "azure",
        "speech_code": "es-BO",
    },
    "es-BO-MarceloNeural": {
        "provider": "azure",
        "speech_code": "es-BO",
    },
    "es-CL-CatalinaNeural": {
        "provider": "azure",
        "speech_code": "es-CL",
    },
    "es-CL-LorenzoNeural": {
        "provider": "azure",
        "speech_code": "es-CL",
    },
    "es-CO-SalomeNeural": {
        "provider": "azure",
        "speech_code": "es-CO",
    },
    "es-CO-GonzaloNeural": {
        "provider": "azure",
        "speech_code": "es-CO",
    },
    "es-CR-MariaNeural": {
        "provider": "azure",
        "speech_code": "es-CR",
    },
    "es-CR-JuanNeural": {
        "provider": "azure",
        "speech_code": "es-CR",
    },
    "es-CU-BelkysNeural": {
        "provider": "azure",
        "speech_code": "es-CU",
    },
    "es-CU-ManuelNeural": {
        "provider": "azure",
        "speech_code": "es-CU",
    },
    "es-DO-RamonaNeural": {
        "provider": "azure",
        "speech_code": "es-DO",
    },
    "es-DO-EmilioNeural": {
        "provider": "azure",
        "speech_code": "es-DO",
    },
    "es-EC-AndreaNeural": {
        "provider": "azure",
        "speech_code": "es-EC",
    },
    "es-EC-LuisNeural": {
        "provider": "azure",
        "speech_code": "es-EC",
    },
    "es-ES-ElviraNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-AlvaroNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-AbrilNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-ArnauNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-DarioNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-EliasNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-EstrellaNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-IreneNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-LaiaNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-LiaNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-NilNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-SaulNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-TeoNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-TrianaNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-VeraNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-ES-XimenaNeural": {
        "provider": "azure",
        "speech_code": "es-ES",
    },
    "es-GQ-TeresaNeural": {
        "provider": "azure",
        "speech_code": "es-GQ",
    },
    "es-GQ-JavierNeural": {
        "provider": "azure",
        "speech_code": "es-GQ",
    },
    "es-GT-MartaNeural": {
        "provider": "azure",
        "speech_code": "es-GT",
    },
    "es-GT-AndresNeural": {
        "provider": "azure",
        "speech_code": "es-GT",
    },
    "es-HN-KarlaNeural": {
        "provider": "azure",
        "speech_code": "es-HN",
    },
    "es-HN-CarlosNeural": {
        "provider": "azure",
        "speech_code": "es-HN",
    },
    "es-MX-DaliaNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-JorgeNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-BeatrizNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-CandelaNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-CarlotaNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-CecilioNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-GerardoNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-LarissaNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-LibertoNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-LucianoNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-MarinaNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-NuriaNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-PelayoNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-RenataNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-MX-YagoNeural": {
        "provider": "azure",
        "speech_code": "es-MX",
    },
    "es-NI-YolandaNeural": {
        "provider": "azure",
        "speech_code": "es-NI",
    },
    "es-NI-FedericoNeural": {
        "provider": "azure",
        "speech_code": "es-NI",
    },
    "es-PA-MargaritaNeural": {
        "provider": "azure",
        "speech_code": "es-PA",
    },
    "es-PA-RobertoNeural": {
        "provider": "azure",
        "speech_code": "es-PA",
    },
    "es-PE-CamilaNeural": {
        "provider": "azure",
        "speech_code": "es-PE",
    },
    "es-PE-AlexNeural": {
        "provider": "azure",
        "speech_code": "es-PE",
    },
    "es-PR-KarinaNeural": {
        "provider": "azure",
        "speech_code": "es-PR",
    },
    "es-PR-VictorNeural": {
        "provider": "azure",
        "speech_code": "es-PR",
    },
    "es-PY-TaniaNeural": {
        "provider": "azure",
        "speech_code": "es-PY",
    },
    "es-PY-MarioNeural": {
        "provider": "azure",
        "speech_code": "es-PY",
    },
    "es-SV-LorenaNeural": {
        "provider": "azure",
        "speech_code": "es-SV",
    },
    "es-SV-RodrigoNeural": {
        "provider": "azure",
        "speech_code": "es-SV",
    },
    "es-US-PalomaNeural": {
        "provider": "azure",
        "speech_code": "es-US",
    },
    "es-US-AlonsoNeural": {
        "provider": "azure",
        "speech_code": "es-US",
    },
    "es-UY-ValentinaNeural": {
        "provider": "azure",
        "speech_code": "es-UY",
    },
    "es-UY-MateoNeural": {
        "provider": "azure",
        "speech_code": "es-UY",
    },
    "es-VE-PaolaNeural": {
        "provider": "azure",
        "speech_code": "es-VE",
    },
    "es-VE-SebastianNeural": {
        "provider": "azure",
        "speech_code": "es-VE",
    },
    "et-EE-AnuNeural": {
        "provider": "azure",
        "speech_code": "et-EE",
    },
    "et-EE-KertNeural": {
        "provider": "azure",
        "speech_code": "et-EE",
    },
    "eu-ES-AinhoaNeural": {
        "provider": "azure",
        "speech_code": "eu-ES",
    },
    "eu-ES-AnderNeural": {
        "provider": "azure",
        "speech_code": "eu-ES",
    },
    "fa-IR-DilaraNeural": {
        "provider": "azure",
        "speech_code": "fa-IR",
    },
    "fa-IR-FaridNeural": {
        "provider": "azure",
        "speech_code": "fa-IR",
    },
    "fi-FI-SelmaNeural": {
        "provider": "azure",
        "speech_code": "fi-FI",
    },
    "fi-FI-HarriNeural": {
        "provider": "azure",
        "speech_code": "fi-FI",
    },
    "fi-FI-NooraNeural": {
        "provider": "azure",
        "speech_code": "fi-FI",
    },
    "fil-PH-BlessicaNeural": {
        "provider": "azure",
        "speech_code": "fil-PH",
    },
    "fil-PH-AngeloNeural": {
        "provider": "azure",
        "speech_code": "fil-PH",
    },
    "fr-BE-CharlineNeural": {
        "provider": "azure",
        "speech_code": "fr-BE",
    },
    "fr-BE-GerardNeural": {
        "provider": "azure",
        "speech_code": "fr-BE",
    },
    "fr-CA-SylvieNeural": {
        "provider": "azure",
        "speech_code": "fr-CA",
    },
    "fr-CA-JeanNeural": {
        "provider": "azure",
        "speech_code": "fr-CA",
    },
    "fr-CA-AntoineNeural": {
        "provider": "azure",
        "speech_code": "fr-CA",
    },
    "fr-CA-ThierryNeural": {
        "provider": "azure",
        "speech_code": "fr-CA",
    },
    "fr-CH-ArianeNeural": {
        "provider": "azure",
        "speech_code": "fr-CH",
    },
    "fr-CH-FabriceNeural": {
        "provider": "azure",
        "speech_code": "fr-CH",
    },
    "fr-FR-DeniseNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-HenriNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-AlainNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-BrigitteNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-CelesteNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-ClaudeNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-CoralieNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-EloiseNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-JacquelineNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-JeromeNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-JosephineNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-MauriceNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-YvesNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-YvetteNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-RemyMultilingualNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "fr-FR-VivienneMultilingualNeural": {
        "provider": "azure",
        "speech_code": "fr-FR",
    },
    "ga-IE-OrlaNeural": {
        "provider": "azure",
        "speech_code": "ga-IE",
    },
    "ga-IE-ColmNeural": {
        "provider": "azure",
        "speech_code": "ga-IE",
    },
    "gl-ES-SabelaNeural": {
        "provider": "azure",
        "speech_code": "gl-ES",
    },
    "gl-ES-RoiNeural": {
        "provider": "azure",
        "speech_code": "gl-ES",
    },
    "gu-IN-DhwaniNeural": {
        "provider": "azure",
        "speech_code": "gu-IN",
    },
    "gu-IN-NiranjanNeural": {
        "provider": "azure",
        "speech_code": "gu-IN",
    },
    "he-IL-HilaNeural": {
        "provider": "azure",
        "speech_code": "he-IL",
    },
    "he-IL-AvriNeural": {
        "provider": "azure",
        "speech_code": "he-IL",
    },
    "hi-IN-SwaraNeural": {
        "provider": "azure",
        "speech_code": "hi-IN",
    },
    "hi-IN-MadhurNeural": {
        "provider": "azure",
        "speech_code": "hi-IN",
    },
    "hr-HR-GabrijelaNeural": {
        "provider": "azure",
        "speech_code": "hr-HR",
    },
    "hr-HR-SreckoNeural": {
        "provider": "azure",
        "speech_code": "hr-HR",
    },
    "hu-HU-NoemiNeural": {
        "provider": "azure",
        "speech_code": "hu-HU",
    },
    "hu-HU-TamasNeural": {
        "provider": "azure",
        "speech_code": "hu-HU",
    },
    "hy-AM-AnahitNeural": {
        "provider": "azure",
        "speech_code": "hy-AM",
    },
    "hy-AM-HaykNeural": {
        "provider": "azure",
        "speech_code": "hy-AM",
    },
    "id-ID-GadisNeural": {
        "provider": "azure",
        "speech_code": "id-ID",
    },
    "id-ID-ArdiNeural": {
        "provider": "azure",
        "speech_code": "id-ID",
    },
    "is-IS-GudrunNeural": {
        "provider": "azure",
        "speech_code": "is-IS",
    },
    "is-IS-GunnarNeural": {
        "provider": "azure",
        "speech_code": "is-IS",
    },
    "it-IT-ElsaNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-IsabellaNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-DiegoNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-BenignoNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-CalimeroNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-CataldoNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-FabiolaNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-FiammaNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-GianniNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-ImeldaNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-IrmaNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-LisandroNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-PalmiraNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-PierinaNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-RinaldoNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "it-IT-GiuseppeNeural": {
        "provider": "azure",
        "speech_code": "it-IT",
    },
    "ja-JP-NanamiNeural": {
        "provider": "azure",
        "speech_code": "ja-JP",
    },
    "ja-JP-KeitaNeural": {
        "provider": "azure",
        "speech_code": "ja-JP",
    },
    "ja-JP-AoiNeural": {
        "provider": "azure",
        "speech_code": "ja-JP",
    },
    "ja-JP-DaichiNeural": {
        "provider": "azure",
        "speech_code": "ja-JP",
    },
    "ja-JP-MayuNeural": {
        "provider": "azure",
        "speech_code": "ja-JP",
    },
    "ja-JP-NaokiNeural": {
        "provider": "azure",
        "speech_code": "ja-JP",
    },
    "ja-JP-ShioriNeural": {
        "provider": "azure",
        "speech_code": "ja-JP",
    },
    "ja-JP-MasaruMultilingualNeural1,": {
        "provider": "azure",
        "speech_code": "ja-JP",
    },
    "jv-ID-SitiNeural": {
        "provider": "azure",
        "speech_code": "jv-ID",
    },
    "jv-ID-DimasNeural": {
        "provider": "azure",
        "speech_code": "jv-ID",
    },
    "ka-GE-EkaNeural": {
        "provider": "azure",
        "speech_code": "ka-GE",
    },
    "ka-GE-GiorgiNeural": {
        "provider": "azure",
        "speech_code": "ka-GE",
    },
    "kk-KZ-AigulNeural": {
        "provider": "azure",
        "speech_code": "kk-KZ",
    },
    "kk-KZ-DauletNeural": {
        "provider": "azure",
        "speech_code": "kk-KZ",
    },
    "km-KH-SreymomNeural": {
        "provider": "azure",
        "speech_code": "km-KH",
    },
    "km-KH-PisethNeural": {
        "provider": "azure",
        "speech_code": "km-KH",
    },
    "kn-IN-SapnaNeural": {
        "provider": "azure",
        "speech_code": "kn-IN",
    },
    "kn-IN-GaganNeural": {
        "provider": "azure",
        "speech_code": "kn-IN",
    },
    "ko-KR-SunHiNeural": {
        "provider": "azure",
        "speech_code": "ko-KR",
    },
    "ko-KR-InJoonNeural": {
        "provider": "azure",
        "speech_code": "ko-KR",
    },
    "ko-KR-BongJinNeural": {
        "provider": "azure",
        "speech_code": "ko-KR",
    },
    "ko-KR-GookMinNeural": {
        "provider": "azure",
        "speech_code": "ko-KR",
    },
    "ko-KR-JiMinNeural": {
        "provider": "azure",
        "speech_code": "ko-KR",
    },
    "ko-KR-SeoHyeonNeural": {
        "provider": "azure",
        "speech_code": "ko-KR",
    },
    "ko-KR-SoonBokNeural": {
        "provider": "azure",
        "speech_code": "ko-KR",
    },
    "ko-KR-YuJinNeural": {
        "provider": "azure",
        "speech_code": "ko-KR",
    },
    "ko-KR-HyunsuNeural": {
        "provider": "azure",
        "speech_code": "ko-KR",
    },
    "lo-LA-KeomanyNeural": {
        "provider": "azure",
        "speech_code": "lo-LA",
    },
    "lo-LA-ChanthavongNeural": {
        "provider": "azure",
        "speech_code": "lo-LA",
    },
    "lt-LT-OnaNeural": {
        "provider": "azure",
        "speech_code": "lt-LT",
    },
    "lt-LT-LeonasNeural": {
        "provider": "azure",
        "speech_code": "lt-LT",
    },
    "lv-LV-EveritaNeural": {
        "provider": "azure",
        "speech_code": "lv-LV",
    },
    "lv-LV-NilsNeural": {
        "provider": "azure",
        "speech_code": "lv-LV",
    },
    "mk-MK-MarijaNeural": {
        "provider": "azure",
        "speech_code": "mk-MK",
    },
    "mk-MK-AleksandarNeural": {
        "provider": "azure",
        "speech_code": "mk-MK",
    },
    "ml-IN-SobhanaNeural": {
        "provider": "azure",
        "speech_code": "ml-IN",
    },
    "ml-IN-MidhunNeural": {
        "provider": "azure",
        "speech_code": "ml-IN",
    },
    "mn-MN-YesuiNeural": {
        "provider": "azure",
        "speech_code": "mn-MN",
    },
    "mn-MN-BataaNeural": {
        "provider": "azure",
        "speech_code": "mn-MN",
    },
    "mr-IN-AarohiNeural": {
        "provider": "azure",
        "speech_code": "mr-IN",
    },
    "mr-IN-ManoharNeural": {
        "provider": "azure",
        "speech_code": "mr-IN",
    },
    "ms-MY-YasminNeural": {
        "provider": "azure",
        "speech_code": "ms-MY",
    },
    "ms-MY-OsmanNeural": {
        "provider": "azure",
        "speech_code": "ms-MY",
    },
    "mt-MT-GraceNeural": {
        "provider": "azure",
        "speech_code": "mt-MT",
    },
    "mt-MT-JosephNeural": {
        "provider": "azure",
        "speech_code": "mt-MT",
    },
    "my-MM-NilarNeural": {
        "provider": "azure",
        "speech_code": "my-MM",
    },
    "my-MM-ThihaNeural": {
        "provider": "azure",
        "speech_code": "my-MM",
    },
    "nb-NO-PernilleNeural": {
        "provider": "azure",
        "speech_code": "nb-NO",
    },
    "nb-NO-FinnNeural": {
        "provider": "azure",
        "speech_code": "nb-NO",
    },
    "nb-NO-IselinNeural": {
        "provider": "azure",
        "speech_code": "nb-NO",
    },
    "ne-NP-HemkalaNeural": {
        "provider": "azure",
        "speech_code": "ne-NP",
    },
    "ne-NP-SagarNeural": {
        "provider": "azure",
        "speech_code": "ne-NP",
    },
    "nl-BE-DenaNeural": {
        "provider": "azure",
        "speech_code": "nl-BE",
    },
    "nl-BE-ArnaudNeural": {
        "provider": "azure",
        "speech_code": "nl-BE",
    },
    "nl-NL-FennaNeural": {
        "provider": "azure",
        "speech_code": "nl-NL",
    },
    "nl-NL-MaartenNeural": {
        "provider": "azure",
        "speech_code": "nl-NL",
    },
    "nl-NL-ColetteNeural": {
        "provider": "azure",
        "speech_code": "nl-NL",
    },
    "pl-PL-AgnieszkaNeural": {
        "provider": "azure",
        "speech_code": "pl-PL",
    },
    "pl-PL-MarekNeural": {
        "provider": "azure",
        "speech_code": "pl-PL",
    },
    "pl-PL-ZofiaNeural": {
        "provider": "azure",
        "speech_code": "pl-PL",
    },
    "ps-AF-LatifaNeural": {
        "provider": "azure",
        "speech_code": "ps-AF",
    },
    "ps-AF-GulNawazNeural": {
        "provider": "azure",
        "speech_code": "ps-AF",
    },
    "pt-BR-FranciscaNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-AntonioNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-BrendaNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-DonatoNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-ElzaNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-FabioNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-GiovannaNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-HumbertoNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-JulioNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-LeilaNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-LeticiaNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-ManuelaNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-NicolauNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-ValerioNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-YaraNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-BR-ThalitaNeural": {
        "provider": "azure",
        "speech_code": "pt-BR",
    },
    "pt-PT-RaquelNeural": {
        "provider": "azure",
        "speech_code": "pt-PT",
    },
    "pt-PT-DuarteNeural": {
        "provider": "azure",
        "speech_code": "pt-PT",
    },
    "pt-PT-FernandaNeural": {
        "provider": "azure",
        "speech_code": "pt-PT",
    },
    "ro-RO-AlinaNeural": {
        "provider": "azure",
        "speech_code": "ro-RO",
    },
    "ro-RO-EmilNeural": {
        "provider": "azure",
        "speech_code": "ro-RO",
    },
    "ru-RU-SvetlanaNeural": {
        "provider": "azure",
        "speech_code": "ru-RU",
    },
    "ru-RU-DmitryNeural": {
        "provider": "azure",
        "speech_code": "ru-RU",
    },
    "ru-RU-DariyaNeural": {
        "provider": "azure",
        "speech_code": "ru-RU",
    },
    "si-LK-ThiliniNeural": {
        "provider": "azure",
        "speech_code": "si-LK",
    },
    "si-LK-SameeraNeural": {
        "provider": "azure",
        "speech_code": "si-LK",
    },
    "sk-SK-ViktoriaNeural": {
        "provider": "azure",
        "speech_code": "sk-SK",
    },
    "sk-SK-LukasNeural": {
        "provider": "azure",
        "speech_code": "sk-SK",
    },
    "sl-SI-PetraNeural": {
        "provider": "azure",
        "speech_code": "sl-SI",
    },
    "sl-SI-RokNeural": {
        "provider": "azure",
        "speech_code": "sl-SI",
    },
    "so-SO-UbaxNeural": {
        "provider": "azure",
        "speech_code": "so-SO",
    },
    "so-SO-MuuseNeural": {
        "provider": "azure",
        "speech_code": "so-SO",
    },
    "sq-AL-AnilaNeural": {
        "provider": "azure",
        "speech_code": "sq-AL",
    },
    "sq-AL-IlirNeural": {
        "provider": "azure",
        "speech_code": "sq-AL",
    },
    "sr-Latn-RS-NicholasNeural": {
        "provider": "azure",
        "speech_code": "sr-LATN-RS",
    },
    "sr-Latn-RS-SophieNeural": {
        "provider": "azure",
        "speech_code": "sr-LATN-RS",
    },
    "sr-RS-SophieNeural": {
        "provider": "azure",
        "speech_code": "sr-RS",
    },
    "sr-RS-NicholasNeural": {
        "provider": "azure",
        "speech_code": "sr-RS",
    },
    "su-ID-TutiNeural": {
        "provider": "azure",
        "speech_code": "su-ID",
    },
    "su-ID-JajangNeural": {
        "provider": "azure",
        "speech_code": "su-ID",
    },
    "sv-SE-SofieNeural": {
        "provider": "azure",
        "speech_code": "sv-SE",
    },
    "sv-SE-MattiasNeural": {
        "provider": "azure",
        "speech_code": "sv-SE",
    },
    "sv-SE-HilleviNeural": {
        "provider": "azure",
        "speech_code": "sv-SE",
    },
    "sw-KE-ZuriNeural": {
        "provider": "azure",
        "speech_code": "sw-KE",
    },
    "sw-KE-RafikiNeural": {
        "provider": "azure",
        "speech_code": "sw-KE",
    },
    "sw-TZ-RehemaNeural": {
        "provider": "azure",
        "speech_code": "sw-TZ",
    },
    "sw-TZ-DaudiNeural": {
        "provider": "azure",
        "speech_code": "sw-TZ",
    },
    "ta-IN-PallaviNeural": {
        "provider": "azure",
        "speech_code": "ta-IN",
    },
    "ta-IN-ValluvarNeural": {
        "provider": "azure",
        "speech_code": "ta-IN",
    },
    "ta-LK-SaranyaNeural": {
        "provider": "azure",
        "speech_code": "ta-LK",
    },
    "ta-LK-KumarNeural": {
        "provider": "azure",
        "speech_code": "ta-LK",
    },
    "ta-MY-KaniNeural": {
        "provider": "azure",
        "speech_code": "ta-MY",
    },
    "ta-MY-SuryaNeural": {
        "provider": "azure",
        "speech_code": "ta-MY",
    },
    "ta-SG-VenbaNeural": {
        "provider": "azure",
        "speech_code": "ta-SG",
    },
    "ta-SG-AnbuNeural": {
        "provider": "azure",
        "speech_code": "ta-SG",
    },
    "te-IN-ShrutiNeural": {
        "provider": "azure",
        "speech_code": "te-IN",
    },
    "te-IN-MohanNeural": {
        "provider": "azure",
        "speech_code": "te-IN",
    },
    "th-TH-PremwadeeNeural": {
        "provider": "azure",
        "speech_code": "th-TH",
    },
    "th-TH-NiwatNeural": {
        "provider": "azure",
        "speech_code": "th-TH",
    },
    "th-TH-AcharaNeural": {
        "provider": "azure",
        "speech_code": "th-TH",
    },
    "tr-TR-EmelNeural": {
        "provider": "azure",
        "speech_code": "tr-TR",
    },
    "tr-TR-AhmetNeural": {
        "provider": "azure",
        "speech_code": "tr-TR",
    },
    "uk-UA-PolinaNeural": {
        "provider": "azure",
        "speech_code": "uk-UA",
    },
    "uk-UA-OstapNeural": {
        "provider": "azure",
        "speech_code": "uk-UA",
    },
    "ur-IN-GulNeural": {
        "provider": "azure",
        "speech_code": "ur-IN",
    },
    "ur-IN-SalmanNeural": {
        "provider": "azure",
        "speech_code": "ur-IN",
    },
    "ur-PK-UzmaNeural": {
        "provider": "azure",
        "speech_code": "ur-PK",
    },
    "ur-PK-AsadNeural": {
        "provider": "azure",
        "speech_code": "ur-PK",
    },
    "uz-UZ-MadinaNeural": {
        "provider": "azure",
        "speech_code": "uz-UZ",
    },
    "uz-UZ-SardorNeural": {
        "provider": "azure",
        "speech_code": "uz-UZ",
    },
    "vi-VN-HoaiMyNeural": {
        "provider": "azure",
        "speech_code": "vi-VN",
    },
    "vi-VN-NamMinhNeural": {
        "provider": "azure",
        "speech_code": "vi-VN",
    },
    "wuu-CN-XiaotongNeural": {
        "provider": "azure",
        "speech_code": "wuu-CN",
    },
    "wuu-CN-YunzheNeural": {
        "provider": "azure",
        "speech_code": "wuu-CN",
    },
    "yue-CN-XiaoMinNeural": {
        "provider": "azure",
        "speech_code": "yue-CN",
    },
    "yue-CN-YunSongNeural": {
        "provider": "azure",
        "speech_code": "yue-CN",
    },
    "zh-CN-XiaoxiaoNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-YunxiNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-YunjianNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaoyiNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-YunyangNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaochenNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaohanNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaomengNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaomoNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaoqiuNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaoruiNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaoshuangNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaoyanNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaoyouNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaozhenNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-YunfengNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-YunhaoNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-YunxiaNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-YunyeNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-YunzeNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaochenMultilingualNeural1,": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaorouNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaoxiaoDialectsNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaoxiaoMultilingualNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-XiaoyuMultilingualNeural1,": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-YunjieNeural": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-YunyiMultilingualNeural1,": {
        "provider": "azure",
        "speech_code": "zh-CN",
    },
    "zh-CN-guangxi-YunqiNeural1,": {
        "provider": "azure",
        "speech_code": "zh-CN-GUANGXI",
    },
    "zh-CN-henan-YundengNeural": {
        "provider": "azure",
        "speech_code": "zh-CN-henan",
    },
    "zh-CN-liaoning-XiaobeiNeural1,": {
        "provider": "azure",
        "speech_code": "zh-CN-liaoning",
    },
    "zh-CN-liaoning-YunbiaoNeural1,": {
        "provider": "azure",
        "speech_code": "zh-CN-liaoning",
    },
    "zh-CN-shaanxi-XiaoniNeural1,": {
        "provider": "azure",
        "speech_code": "zh-CN-shaanxi",
    },
    "zh-CN-shandong-YunxiangNeural": {
        "provider": "azure",
        "speech_code": "zh-CN-shandong",
    },
    "zh-CN-sichuan-YunxiNeural1,": {
        "provider": "azure",
        "speech_code": "zh-CN-sichuan",
    },
    "zh-HK-HiuMaanNeural": {
        "provider": "azure",
        "speech_code": "zh-HK",
    },
    "zh-HK-WanLungNeural": {
        "provider": "azure",
        "speech_code": "zh-HK",
    },
    "zh-HK-HiuGaaiNeural": {
        "provider": "azure",
        "speech_code": "zh-HK",
    },
    "zh-TW-HsiaoChenNeural": {
        "provider": "azure",
        "speech_code": "zh-TW",
    },
    "zh-TW-YunJheNeural": {
        "provider": "azure",
        "speech_code": "zh-TW",
    },
    "zh-TW-HsiaoYuNeural": {
        "provider": "azure",
        "speech_code": "zh-TW",
    },
    "zu-ZA-ThandoNeural": {
        "provider": "azure",
        "speech_code": "zu-ZA",
    },
    "zu-ZA-ThembaNeural": {
        "provider": "azure",
        "speech_code": "zu-ZA",
    },
    "ar-XA-Wavenet-A": {
        "provider": "google",
        "speech_code": "ar-XA",
        "gender": "female",
    },
    "ar-XA-Wavenet-B": {
        "provider": "google",
        "speech_code": "ar-XA",
        "gender": "male",
    },
    "ar-XA-Wavenet-C": {
        "provider": "google",
        "speech_code": "ar-XA",
        "gender": "male",
    },
    "ar-XA-Wavenet-D": {
        "provider": "google",
        "speech_code": "ar-XA",
        "gender": "female",
    },
    "bn-IN-Wavenet-A": {
        "provider": "google",
        "speech_code": "bn-IN",
        "gender": "female",
    },
    "bn-IN-Wavenet-B": {
        "provider": "google",
        "speech_code": "bn-IN",
        "gender": "male",
    },
    "bn-IN-Wavenet-C": {
        "provider": "google",
        "speech_code": "bn-IN",
        "gender": "female",
    },
    "bn-IN-Wavenet-D": {
        "provider": "google",
        "speech_code": "bn-IN",
        "gender": "male",
    },
    "cs-CZ-Wavenet-A": {
        "provider": "google",
        "speech_code": "cs-CZ",
        "gender": "female",
    },
    "da-DK-Neural2-D": {
        "provider": "google",
        "speech_code": "da-DK",
        "gender": "female",
    },
    "da-DK-Wavenet-A": {
        "provider": "google",
        "speech_code": "da-DK",
        "gender": "female",
    },
    "da-DK-Wavenet-C": {
        "provider": "google",
        "speech_code": "da-DK",
        "gender": "male",
    },
    "da-DK-Wavenet-D": {
        "provider": "google",
        "speech_code": "da-DK",
        "gender": "female",
    },
    "da-DK-Wavenet-E": {
        "provider": "google",
        "speech_code": "da-DK",
        "gender": "female",
    },
    "nl-BE-Wavenet-A": {
        "provider": "google",
        "speech_code": "nl-BE",
        "gender": "female",
    },
    "nl-BE-Wavenet-B": {
        "provider": "google",
        "speech_code": "nl-BE",
        "gender": "male",
    },
    "nl-NL-Wavenet-A": {
        "provider": "google",
        "speech_code": "nl-NL",
        "gender": "female",
    },
    "nl-NL-Wavenet-B": {
        "provider": "google",
        "speech_code": "nl-NL",
        "gender": "male",
    },
    "nl-NL-Wavenet-C": {
        "provider": "google",
        "speech_code": "nl-NL",
        "gender": "male",
    },
    "nl-NL-Wavenet-D": {
        "provider": "google",
        "speech_code": "nl-NL",
        "gender": "female",
    },
    "nl-NL-Wavenet-E": {
        "provider": "google",
        "speech_code": "nl-NL",
        "gender": "female",
    },
    "en-AU-Neural2-A": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "female",
    },
    "en-AU-Neural2-B": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "male",
    },
    "en-AU-Neural2-C": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "female",
    },
    "en-AU-Neural2-D": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "male",
    },
    "en-AU-News-E": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "female",
    },
    "en-AU-News-F": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "female",
    },
    "en-AU-News-G": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "male",
    },
    "en-AU-Polyglot-1": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "male",
    },
    "en-AU-Wavenet-A": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "female",
    },
    "en-AU-Wavenet-B": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "male",
    },
    "en-AU-Wavenet-C": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "female",
    },
    "en-AU-Wavenet-D": {
        "provider": "google",
        "speech_code": "en-AU",
        "gender": "male",
    },
    "en-IN-Neural2-A": {
        "provider": "google",
        "speech_code": "en-IN",
        "gender": "female",
    },
    "en-IN-Neural2-B": {
        "provider": "google",
        "speech_code": "en-IN",
        "gender": "male",
    },
    "en-IN-Neural2-C": {
        "provider": "google",
        "speech_code": "en-IN",
        "gender": "male",
    },
    "en-IN-Neural2-D": {
        "provider": "google",
        "speech_code": "en-IN",
        "gender": "female",
    },
    "en-IN-Wavenet-A": {
        "provider": "google",
        "speech_code": "en-IN",
        "gender": "female",
    },
    "en-IN-Wavenet-B": {
        "provider": "google",
        "speech_code": "en-IN",
        "gender": "male",
    },
    "en-IN-Wavenet-C": {
        "provider": "google",
        "speech_code": "en-IN",
        "gender": "male",
    },
    "en-IN-Wavenet-D": {
        "provider": "google",
        "speech_code": "en-IN",
        "gender": "female",
    },
    "en-GB-Neural2-A": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "female",
    },
    "en-GB-Neural2-B": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "male",
    },
    "en-GB-Neural2-C": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "female",
    },
    "en-GB-Neural2-D": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "male",
    },
    "en-GB-Neural2-F": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "female",
    },
    "en-GB-News-G": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "female",
    },
    "en-GB-News-H": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "female",
    },
    "en-GB-News-I": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "female",
    },
    "en-GB-News-J": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "male",
    },
    "en-GB-News-K": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "male",
    },
    "en-GB-News-L": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "male",
    },
    "en-GB-News-M": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "male",
    },
    "en-GB-Wavenet-A": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "female",
    },
    "en-GB-Wavenet-B": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "male",
    },
    "en-GB-Wavenet-C": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "female",
    },
    "en-GB-Wavenet-D": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "male",
    },
    "en-GB-Wavenet-F": {
        "provider": "google",
        "speech_code": "en-GB",
        "gender": "female",
    },
    "en-US-Casual-K": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-Journey-D": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-Journey-F": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Journey-O": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Neural2-A": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-Neural2-C": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Neural2-D": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-Neural2-E": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Neural2-F": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Neural2-G": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Neural2-H": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Neural2-I": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-Neural2-J": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-News-K": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-News-L": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-News-N": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-Polyglot-1": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-Wavenet-A": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-Wavenet-B": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-Wavenet-C": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Wavenet-D": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-Wavenet-E": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Wavenet-F": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Wavenet-G": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Wavenet-H": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "female",
    },
    "en-US-Wavenet-I": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "en-US-Wavenet-J": {
        "provider": "google",
        "speech_code": "en-US",
        "gender": "male",
    },
    "fil-PH-Wavenet-A": {
        "provider": "google",
        "speech_code": "fil-PH",
        "gender": "female",
    },
    "fil-PH-Wavenet-B": {
        "provider": "google",
        "speech_code": "fil-PH",
        "gender": "female",
    },
    "fil-PH-Wavenet-C": {
        "provider": "google",
        "speech_code": "fil-PH",
        "gender": "male",
    },
    "fil-PH-Wavenet-D": {
        "provider": "google",
        "speech_code": "fil-PH",
        "gender": "male",
    },
    "fil-ph-Neural2-A": {
        "provider": "google",
        "speech_code": "fil-PH",
        "gender": "female",
    },
    "fil-ph-Neural2-D": {
        "provider": "google",
        "speech_code": "fil-PH",
        "gender": "male",
    },
    "fi-FI-Wavenet-A": {
        "provider": "google",
        "speech_code": "fi-FI",
        "gender": "female",
    },
    "fr-CA-Neural2-A": {
        "provider": "google",
        "speech_code": "fr-CA",
        "gender": "female",
    },
    "fr-CA-Neural2-B": {
        "provider": "google",
        "speech_code": "fr-CA",
        "gender": "male",
    },
    "fr-CA-Neural2-C": {
        "provider": "google",
        "speech_code": "fr-CA",
        "gender": "female",
    },
    "fr-CA-Neural2-D": {
        "provider": "google",
        "speech_code": "fr-CA",
        "gender": "male",
    },
    "fr-CA-Wavenet-A": {
        "provider": "google",
        "speech_code": "fr-CA",
        "gender": "female",
    },
    "fr-CA-Wavenet-B": {
        "provider": "google",
        "speech_code": "fr-CA",
        "gender": "male",
    },
    "fr-CA-Wavenet-C": {
        "provider": "google",
        "speech_code": "fr-CA",
        "gender": "female",
    },
    "fr-CA-Wavenet-D": {
        "provider": "google",
        "speech_code": "fr-CA",
        "gender": "male",
    },
    "fr-FR-Neural2-A": {
        "provider": "google",
        "speech_code": "fr-FR",
        "gender": "female",
    },
    "fr-FR-Neural2-B": {
        "provider": "google",
        "speech_code": "fr-FR",
        "gender": "male",
    },
    "fr-FR-Neural2-C": {
        "provider": "google",
        "speech_code": "fr-FR",
        "gender": "female",
    },
    "fr-FR-Neural2-D": {
        "provider": "google",
        "speech_code": "fr-FR",
        "gender": "male",
    },
    "fr-FR-Neural2-E": {
        "provider": "google",
        "speech_code": "fr-FR",
        "gender": "female",
    },
    "fr-FR-Polyglot-1": {
        "provider": "google",
        "speech_code": "fr-FR",
        "gender": "male",
    },
    "fr-FR-Wavenet-A": {
        "provider": "google",
        "speech_code": "fr-FR",
        "gender": "female",
    },
    "fr-FR-Wavenet-B": {
        "provider": "google",
        "speech_code": "fr-FR",
        "gender": "male",
    },
    "fr-FR-Wavenet-C": {
        "provider": "google",
        "speech_code": "fr-FR",
        "gender": "female",
    },
    "fr-FR-Wavenet-D": {
        "provider": "google",
        "speech_code": "fr-FR",
        "gender": "male",
    },
    "fr-FR-Wavenet-E": {
        "provider": "google",
        "speech_code": "fr-FR",
        "gender": "female",
    },
    "de-DE-Neural2-A": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "female",
    },
    "de-DE-Neural2-B": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "male",
    },
    "de-DE-Neural2-C": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "female",
    },
    "de-DE-Neural2-D": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "male",
    },
    "de-DE-Neural2-F": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "female",
    },
    "de-DE-Polyglot-1": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "male",
    },
    "de-DE-Wavenet-A": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "female",
    },
    "de-DE-Wavenet-B": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "male",
    },
    "de-DE-Wavenet-C": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "female",
    },
    "de-DE-Wavenet-D": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "male",
    },
    "de-DE-Wavenet-E": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "male",
    },
    "de-DE-Wavenet-F": {
        "provider": "google",
        "speech_code": "de-DE",
        "gender": "female",
    },
    "el-GR-Wavenet-A": {
        "provider": "google",
        "speech_code": "el-GR",
        "gender": "female",
    },
    "gu-IN-Wavenet-A": {
        "provider": "google",
        "speech_code": "gu-IN",
        "gender": "female",
    },
    "gu-IN-Wavenet-B": {
        "provider": "google",
        "speech_code": "gu-IN",
        "gender": "male",
    },
    "gu-IN-Wavenet-C": {
        "provider": "google",
        "speech_code": "gu-IN",
        "gender": "female",
    },
    "gu-IN-Wavenet-D": {
        "provider": "google",
        "speech_code": "gu-IN",
        "gender": "male",
    },
    "he-IL-Wavenet-A": {
        "provider": "google",
        "speech_code": "he-IL",
        "gender": "female",
    },
    "he-IL-Wavenet-B": {
        "provider": "google",
        "speech_code": "he-IL",
        "gender": "male",
    },
    "he-IL-Wavenet-C": {
        "provider": "google",
        "speech_code": "he-IL",
        "gender": "female",
    },
    "he-IL-Wavenet-D": {
        "provider": "google",
        "speech_code": "he-IL",
        "gender": "male",
    },
    "hi-IN-Neural2-A": {
        "provider": "google",
        "speech_code": "hi-IN",
        "gender": "female",
    },
    "hi-IN-Neural2-B": {
        "provider": "google",
        "speech_code": "hi-IN",
        "gender": "male",
    },
    "hi-IN-Neural2-C": {
        "provider": "google",
        "speech_code": "hi-IN",
        "gender": "male",
    },
    "hi-IN-Neural2-D": {
        "provider": "google",
        "speech_code": "hi-IN",
        "gender": "female",
    },
    "hi-IN-Wavenet-A": {
        "provider": "google",
        "speech_code": "hi-IN",
        "gender": "female",
    },
    "hi-IN-Wavenet-B": {
        "provider": "google",
        "speech_code": "hi-IN",
        "gender": "male",
    },
    "hi-IN-Wavenet-C": {
        "provider": "google",
        "speech_code": "hi-IN",
        "gender": "male",
    },
    "hi-IN-Wavenet-D": {
        "provider": "google",
        "speech_code": "hi-IN",
        "gender": "female",
    },
    "hu-HU-Wavenet-A": {
        "provider": "google",
        "speech_code": "hu-HU",
        "gender": "female",
    },
    "id-ID-Wavenet-A": {
        "provider": "google",
        "speech_code": "id-ID",
        "gender": "female",
    },
    "id-ID-Wavenet-B": {
        "provider": "google",
        "speech_code": "id-ID",
        "gender": "male",
    },
    "id-ID-Wavenet-C": {
        "provider": "google",
        "speech_code": "id-ID",
        "gender": "male",
    },
    "id-ID-Wavenet-D": {
        "provider": "google",
        "speech_code": "id-ID",
        "gender": "female",
    },
    "it-IT-Neural2-A": {
        "provider": "google",
        "speech_code": "it-IT",
        "gender": "female",
    },
    "it-IT-Neural2-C": {
        "provider": "google",
        "speech_code": "it-IT",
        "gender": "male",
    },
    "it-IT-Wavenet-A": {
        "provider": "google",
        "speech_code": "it-IT",
        "gender": "female",
    },
    "it-IT-Wavenet-B": {
        "provider": "google",
        "speech_code": "it-IT",
        "gender": "female",
    },
    "it-IT-Wavenet-C": {
        "provider": "google",
        "speech_code": "it-IT",
        "gender": "male",
    },
    "it-IT-Wavenet-D": {
        "provider": "google",
        "speech_code": "it-IT",
        "gender": "male",
    },
    "ja-JP-Neural2-B": {
        "provider": "google",
        "speech_code": "ja-JP",
        "gender": "female",
    },
    "ja-JP-Neural2-C": {
        "provider": "google",
        "speech_code": "ja-JP",
        "gender": "male",
    },
    "ja-JP-Neural2-D": {
        "provider": "google",
        "speech_code": "ja-JP",
        "gender": "male",
    },
    "ja-JP-Wavenet-A": {
        "provider": "google",
        "speech_code": "ja-JP",
        "gender": "female",
    },
    "ja-JP-Wavenet-B": {
        "provider": "google",
        "speech_code": "ja-JP",
        "gender": "female",
    },
    "ja-JP-Wavenet-C": {
        "provider": "google",
        "speech_code": "ja-JP",
        "gender": "male",
    },
    "ja-JP-Wavenet-D": {
        "provider": "google",
        "speech_code": "ja-JP",
        "gender": "male",
    },
    "kn-IN-Wavenet-A": {
        "provider": "google",
        "speech_code": "kn-IN",
        "gender": "female",
    },
    "kn-IN-Wavenet-B": {
        "provider": "google",
        "speech_code": "kn-IN",
        "gender": "male",
    },
    "kn-IN-Wavenet-C": {
        "provider": "google",
        "speech_code": "kn-IN",
        "gender": "female",
    },
    "kn-IN-Wavenet-D": {
        "provider": "google",
        "speech_code": "kn-IN",
        "gender": "male",
    },
    "ko-KR-Neural2-A": {
        "provider": "google",
        "speech_code": "ko-KR",
        "gender": "female",
    },
    "ko-KR-Neural2-B": {
        "provider": "google",
        "speech_code": "ko-KR",
        "gender": "female",
    },
    "ko-KR-Neural2-C": {
        "provider": "google",
        "speech_code": "ko-KR",
        "gender": "male",
    },
    "ko-KR-Wavenet-A": {
        "provider": "google",
        "speech_code": "ko-KR",
        "gender": "female",
    },
    "ko-KR-Wavenet-B": {
        "provider": "google",
        "speech_code": "ko-KR",
        "gender": "female",
    },
    "ko-KR-Wavenet-C": {
        "provider": "google",
        "speech_code": "ko-KR",
        "gender": "male",
    },
    "ko-KR-Wavenet-D": {
        "provider": "google",
        "speech_code": "ko-KR",
        "gender": "male",
    },
    "ms-MY-Wavenet-A": {
        "provider": "google",
        "speech_code": "ms-MY",
        "gender": "female",
    },
    "ms-MY-Wavenet-B": {
        "provider": "google",
        "speech_code": "ms-MY",
        "gender": "male",
    },
    "ms-MY-Wavenet-C": {
        "provider": "google",
        "speech_code": "ms-MY",
        "gender": "female",
    },
    "ms-MY-Wavenet-D": {
        "provider": "google",
        "speech_code": "ms-MY",
        "gender": "male",
    },
    "ml-IN-Wavenet-A": {
        "provider": "google",
        "speech_code": "ml-IN",
        "gender": "female",
    },
    "ml-IN-Wavenet-B": {
        "provider": "google",
        "speech_code": "ml-IN",
        "gender": "male",
    },
    "ml-IN-Wavenet-C": {
        "provider": "google",
        "speech_code": "ml-IN",
        "gender": "female",
    },
    "ml-IN-Wavenet-D": {
        "provider": "google",
        "speech_code": "ml-IN",
        "gender": "male",
    },
    "cmn-CN-Wavenet-A": {
        "provider": "google",
        "speech_code": "cmn-CN",
        "gender": "female",
    },
    "cmn-CN-Wavenet-B": {
        "provider": "google",
        "speech_code": "cmn-CN",
        "gender": "male",
    },
    "cmn-CN-Wavenet-C": {
        "provider": "google",
        "speech_code": "cmn-CN",
        "gender": "male",
    },
    "cmn-CN-Wavenet-D": {
        "provider": "google",
        "speech_code": "cmn-CN",
        "gender": "female",
    },
    "cmn-TW-Wavenet-A": {
        "provider": "google",
        "speech_code": "cmn-TW",
        "gender": "female",
    },
    "cmn-TW-Wavenet-B": {
        "provider": "google",
        "speech_code": "cmn-TW",
        "gender": "male",
    },
    "cmn-TW-Wavenet-C": {
        "provider": "google",
        "speech_code": "cmn-TW",
        "gender": "male",
    },
    "mr-IN-Wavenet-A": {
        "provider": "google",
        "speech_code": "mr-IN",
        "gender": "female",
    },
    "mr-IN-Wavenet-B": {
        "provider": "google",
        "speech_code": "mr-IN",
        "gender": "male",
    },
    "mr-IN-Wavenet-C": {
        "provider": "google",
        "speech_code": "mr-IN",
        "gender": "female",
    },
    "nb-NO-Wavenet-A": {
        "provider": "google",
        "speech_code": "nb-NO",
        "gender": "female",
    },
    "nb-NO-Wavenet-B": {
        "provider": "google",
        "speech_code": "nb-NO",
        "gender": "male",
    },
    "nb-NO-Wavenet-C": {
        "provider": "google",
        "speech_code": "nb-NO",
        "gender": "female",
    },
    "nb-NO-Wavenet-D": {
        "provider": "google",
        "speech_code": "nb-NO",
        "gender": "male",
    },
    "nb-NO-Wavenet-E": {
        "provider": "google",
        "speech_code": "nb-NO",
        "gender": "female",
    },
    "pl-PL-Wavenet-A": {
        "provider": "google",
        "speech_code": "pl-PL",
        "gender": "female",
    },
    "pl-PL-Wavenet-B": {
        "provider": "google",
        "speech_code": "pl-PL",
        "gender": "male",
    },
    "pl-PL-Wavenet-C": {
        "provider": "google",
        "speech_code": "pl-PL",
        "gender": "male",
    },
    "pl-PL-Wavenet-D": {
        "provider": "google",
        "speech_code": "pl-PL",
        "gender": "female",
    },
    "pl-PL-Wavenet-E": {
        "provider": "google",
        "speech_code": "pl-PL",
        "gender": "female",
    },
    "pt-BR-Neural2-A": {
        "provider": "google",
        "speech_code": "pt-BR",
        "gender": "female",
    },
    "pt-BR-Neural2-B": {
        "provider": "google",
        "speech_code": "pt-BR",
        "gender": "male",
    },
    "pt-BR-Neural2-C": {
        "provider": "google",
        "speech_code": "pt-BR",
        "gender": "female",
    },
    "pt-BR-Wavenet-A": {
        "provider": "google",
        "speech_code": "pt-BR",
        "gender": "female",
    },
    "pt-BR-Wavenet-B": {
        "provider": "google",
        "speech_code": "pt-BR",
        "gender": "male",
    },
    "pt-BR-Wavenet-C": {
        "provider": "google",
        "speech_code": "pt-BR",
        "gender": "female",
    },
    "pt-PT-Wavenet-A": {
        "provider": "google",
        "speech_code": "pt-PT",
        "gender": "female",
    },
    "pt-PT-Wavenet-B": {
        "provider": "google",
        "speech_code": "pt-PT",
        "gender": "male",
    },
    "pt-PT-Wavenet-C": {
        "provider": "google",
        "speech_code": "pt-PT",
        "gender": "male",
    },
    "pt-PT-Wavenet-D": {
        "provider": "google",
        "speech_code": "pt-PT",
        "gender": "female",
    },
    "pa-IN-Wavenet-A": {
        "provider": "google",
        "speech_code": "pa-IN",
        "gender": "female",
    },
    "pa-IN-Wavenet-B": {
        "provider": "google",
        "speech_code": "pa-IN",
        "gender": "male",
    },
    "pa-IN-Wavenet-C": {
        "provider": "google",
        "speech_code": "pa-IN",
        "gender": "female",
    },
    "pa-IN-Wavenet-D": {
        "provider": "google",
        "speech_code": "pa-IN",
        "gender": "male",
    },
    "ro-RO-Wavenet-A": {
        "provider": "google",
        "speech_code": "ro-RO",
        "gender": "female",
    },
    "ru-RU-Wavenet-A": {
        "provider": "google",
        "speech_code": "ru-RU",
        "gender": "female",
    },
    "ru-RU-Wavenet-B": {
        "provider": "google",
        "speech_code": "ru-RU",
        "gender": "male",
    },
    "ru-RU-Wavenet-C": {
        "provider": "google",
        "speech_code": "ru-RU",
        "gender": "female",
    },
    "ru-RU-Wavenet-D": {
        "provider": "google",
        "speech_code": "ru-RU",
        "gender": "male",
    },
    "ru-RU-Wavenet-E": {
        "provider": "google",
        "speech_code": "ru-RU",
        "gender": "female",
    },
    "sk-SK-Wavenet-A": {
        "provider": "google",
        "speech_code": "sk-SK",
        "gender": "female",
    },
    "es-ES-Neural2-A": {
        "provider": "google",
        "speech_code": "es-ES",
        "gender": "female",
    },
    "es-ES-Neural2-B": {
        "provider": "google",
        "speech_code": "es-ES",
        "gender": "male",
    },
    "es-ES-Neural2-C": {
        "provider": "google",
        "speech_code": "es-ES",
        "gender": "female",
    },
    "es-ES-Neural2-D": {
        "provider": "google",
        "speech_code": "es-ES",
        "gender": "female",
    },
    "es-ES-Neural2-E": {
        "provider": "google",
        "speech_code": "es-ES",
        "gender": "female",
    },
    "es-ES-Neural2-F": {
        "provider": "google",
        "speech_code": "es-ES",
        "gender": "male",
    },
    "es-ES-Polyglot-1": {
        "provider": "google",
        "speech_code": "es-ES",
        "gender": "male",
    },
    "es-ES-Wavenet-B": {
        "provider": "google",
        "speech_code": "es-ES",
        "gender": "male",
    },
    "es-ES-Wavenet-C": {
        "provider": "google",
        "speech_code": "es-ES",
        "gender": "female",
    },
    "es-ES-Wavenet-D": {
        "provider": "google",
        "speech_code": "es-ES",
        "gender": "female",
    },
    "es-US-Neural2-A": {
        "provider": "google",
        "speech_code": "es-US",
        "gender": "female",
    },
    "es-US-Neural2-B": {
        "provider": "google",
        "speech_code": "es-US",
        "gender": "male",
    },
    "es-US-Neural2-C": {
        "provider": "google",
        "speech_code": "es-US",
        "gender": "male",
    },
    "es-US-News-D": {
        "provider": "google",
        "speech_code": "es-US",
        "gender": "male",
    },
    "es-US-News-E": {
        "provider": "google",
        "speech_code": "es-US",
        "gender": "male",
    },
    "es-US-News-F": {
        "provider": "google",
        "speech_code": "es-US",
        "gender": "female",
    },
    "es-US-News-G": {
        "provider": "google",
        "speech_code": "es-US",
        "gender": "female",
    },
    "es-US-Polyglot-1": {
        "provider": "google",
        "speech_code": "es-US",
        "gender": "male",
    },
    "es-US-Wavenet-A": {
        "provider": "google",
        "speech_code": "es-US",
        "gender": "female",
    },
    "es-US-Wavenet-B": {
        "provider": "google",
        "speech_code": "es-US",
        "gender": "male",
    },
    "es-US-Wavenet-C": {
        "provider": "google",
        "speech_code": "es-US",
        "gender": "male",
    },
    "sv-SE-Wavenet-A": {
        "provider": "google",
        "speech_code": "sv-SE",
        "gender": "female",
    },
    "sv-SE-Wavenet-B": {
        "provider": "google",
        "speech_code": "sv-SE",
        "gender": "female",
    },
    "sv-SE-Wavenet-C": {
        "provider": "google",
        "speech_code": "sv-SE",
        "gender": "male",
    },
    "sv-SE-Wavenet-D": {
        "provider": "google",
        "speech_code": "sv-SE",
        "gender": "female",
    },
    "sv-SE-Wavenet-E": {
        "provider": "google",
        "speech_code": "sv-SE",
        "gender": "male",
    },
    "ta-IN-Wavenet-A": {
        "provider": "google",
        "speech_code": "ta-IN",
        "gender": "female",
    },
    "ta-IN-Wavenet-B": {
        "provider": "google",
        "speech_code": "ta-IN",
        "gender": "male",
    },
    "ta-IN-Wavenet-C": {
        "provider": "google",
        "speech_code": "ta-IN",
        "gender": "female",
    },
    "ta-IN-Wavenet-D": {
        "provider": "google",
        "speech_code": "ta-IN",
        "gender": "male",
    },
    "th-TH-Neural2-C": {
        "provider": "google",
        "speech_code": "th-TH",
        "gender": "female",
    },
    "tr-TR-Wavenet-A": {
        "provider": "google",
        "speech_code": "tr-TR",
        "gender": "female",
    },
    "tr-TR-Wavenet-B": {
        "provider": "google",
        "speech_code": "tr-TR",
        "gender": "male",
    },
    "tr-TR-Wavenet-C": {
        "provider": "google",
        "speech_code": "tr-TR",
        "gender": "female",
    },
    "tr-TR-Wavenet-D": {
        "provider": "google",
        "speech_code": "tr-TR",
        "gender": "female",
    },
    "tr-TR-Wavenet-E": {
        "provider": "google",
        "speech_code": "tr-TR",
        "gender": "male",
    },
    "uk-UA-Wavenet-A": {
        "provider": "google",
        "speech_code": "uk-UA",
        "gender": "female",
    },
    "vi-VN-Neural2-A": {
        "provider": "google",
        "speech_code": "vi-VN",
        "gender": "female",
    },
    "vi-VN-Neural2-D": {
        "provider": "google",
        "speech_code": "vi-VN",
        "gender": "male",
    },
    "vi-VN-Wavenet-A": {
        "provider": "google",
        "speech_code": "vi-VN",
        "gender": "female",
    },
    "vi-VN-Wavenet-B": {
        "provider": "google",
        "speech_code": "vi-VN",
        "gender": "male",
    },
    "vi-VN-Wavenet-C": {
        "provider": "google",
        "speech_code": "vi-VN",
        "gender": "female",
    },
    "vi-VN-Wavenet-D": {
        "provider": "google",
        "speech_code": "vi-VN",
        "gender": "male",
    },
    "OKanSStS6li6xyU1WdXa": {
        "provider": "eleven-labs",
        "speech_code": "en-IN"
    },
    "mRdG9GYEjJmIzqbYTidv": {
        "provider": "eleven-labs",
        "speech_code": "en-IN"
    }
}
