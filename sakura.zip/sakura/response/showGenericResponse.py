class GenericResponse:
    def __init__(self, statusCode, status, message):
        self.statusCode = statusCode
        self.status = status
        self.message = message

    def __repr__(self):
        return f"GenericResponse(statusCode={self.statusCode}, status={self.status}, message={self.message})"