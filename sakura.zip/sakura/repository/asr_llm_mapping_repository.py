from typing import List, Optional
from sqlalchemy.orm import Session
from models.database_models import ASRLLMMapping
from logger import get_logger

logger = get_logger(__name__)

def get_all_active_asr_llm_mappings(db: Session) -> List[ASRLLMMapping]:
    """Get all ASR/LLM mappings from database"""
    try:
        return db.query(ASRLLMMapping).all()
    except Exception as e:
        logger.error(f"Error fetching ASR/LLM mappings: {e}")
        return []

def get_asr_llm_mapping_by_op_co(db: Session, op_co: str) -> Optional[ASRLLMMapping]:
    """Get ASR/LLM mapping by operator_country key"""
    try:
        return db.query(ASRLLMMapping).filter(ASRLLMMapping.op_co == op_co).first()
    except Exception as e:
        logger.error(f"Error fetching ASR/LLM mapping for {op_co}: {e}")
        return None

def create_asr_llm_mapping(db: Session, mapping_data: dict) -> Optional[ASRLLMMapping]:
    """Create new ASR/LLM mapping"""
    try:
        mapping = ASRLLMMapping(**mapping_data)
        db.add(mapping)
        db.commit()
        db.refresh(mapping)
        logger.info(f"Created ASR/LLM mapping for {mapping.op_co}")
        return mapping
    except Exception as e:
        logger.error(f"Error creating ASR/LLM mapping: {e}")
        db.rollback()
        return None

def update_asr_llm_mapping(db: Session, op_co: str, update_data: dict) -> Optional[ASRLLMMapping]:
    """Update existing ASR/LLM mapping"""
    try:
        mapping = get_asr_llm_mapping_by_op_co(db, op_co)
        if mapping:
            for key, value in update_data.items():
                setattr(mapping, key, value)
            db.commit()
            db.refresh(mapping)
            logger.info(f"Updated ASR/LLM mapping for {op_co}")
            return mapping
        return None
    except Exception as e:
        logger.error(f"Error updating ASR/LLM mapping for {op_co}: {e}")
        db.rollback()
        return None

def delete_asr_llm_mapping(db: Session, op_co: str) -> bool:
    """Delete ASR/LLM mapping"""
    try:
        mapping = get_asr_llm_mapping_by_op_co(db, op_co)
        if mapping:
            db.delete(mapping)
            db.commit()
            logger.info(f"Deleted ASR/LLM mapping for {op_co}")
            return True
        return False
    except Exception as e:
        logger.error(f"Error deleting ASR/LLM mapping for {op_co}: {e}")
        db.rollback()
        return False
