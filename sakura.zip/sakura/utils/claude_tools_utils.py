claude_assistants = {
    "2": {
        "tools": [
            {
                "name": "web_search",
                "description": "Perform a web search to retrieve information about recent events. This function is optimized for finding the latest news and updates related to the specified query.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The search query string focused on recent events or news topics.",
                        }
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "get_time",
                "description": "Retrieve the current time for a specified time zone.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "time_zone": {
                            "type": "string",
                            "description": "The location to get the current time for. This should be a recognizable time zone identifier."
                        }
                    },
                    "required": ["time_zone"]
                },
            },
            {
                "name": "get_weather",
                "description": "Retrieve the current weather for a specified location.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "The location to get the current weather for. This should be a recognizable city or region name."
                        }
                    },
                    "required": ["location"]
                },
            }
        ]
    },
    "18": {
        "tools": [
            {
                "name": "check_balance",
                "description": "A tool to check the balance of the user's account.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "mobile_number": {
                            "type": "string",
                            "description": "Mobile number of the user to check the balance for."
                        },
                    },
                    "required": ["mobile_number"]
                }
            }
        ]
    },
    "19": {
        "tools": [
            {
                "name": "check_balance",
                "description": "A tool to check the balance of the user's account.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "mobile_number": {
                            "type": "string",
                            "description": "Mobile number of the user to check the balance for."
                        },
                    },
                    "required": ["mobile_number"]
                }
            },
            {
                "name": "get_nearest_service_center",
                "description": "Use this tool to find the nearest Dialog service center or outlet based on the location provided by the user.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "Location which user has provided to find the nearest Dialog service center or outlet."
                        },
                    },
                    "required": ["location"]
                }
            }
        ]
    },
    "22": {
        "tools": [
            {
                "name": "web_search",
                "description": "Perform a web search to retrieve information about recent events. This function is optimized for finding the latest news and updates related to the specified query.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The search query string focused on recent events or news topics.",
                        }
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "get_time",
                "description": "Retrieve the current time for a specified time zone.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "time_zone": {
                            "type": "string",
                            "description": "The location to get the current time for. This should be a recognizable time zone identifier."
                        }
                    },
                    "required": ["time_zone"]
                },
            },
            {
                "name": "get_weather",
                "description": "Retrieve the current weather for a specified location.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "The location to get the current weather for. This should be a recognizable city or region name."
                        }
                    },
                    "required": ["location"]
                },
            }
        ]
    }
}
