import asyncio
import json
import time
import threading
import os

import requests

from config.config import create_socketio_app
from utils.redis_db_manager import redis_manager
from utils.memory_cache_manager import get_user_call_record, set_user_call_record
from logger import get_logger

logger = get_logger(__name__)


sio = create_socketio_app()

# Store reference to main event loop for thread-safe SocketIO operations
_main_event_loop = None

# SocketIO operations are routed through main event loop for thread safety

def set_main_event_loop(loop):
    """Store reference to main event loop for thread-safe SocketIO operations"""
    global _main_event_loop
    _main_event_loop = loop
    logger.info("Main event loop reference stored for thread-safe SocketIO operations")

def get_main_event_loop():
    """Get the main event loop, with fallback detection"""
    global _main_event_loop
    
    if _main_event_loop and not _main_event_loop.is_closed():
        return _main_event_loop
    
    # Fallback: try to detect the main loop
    try:
        if threading.current_thread() == threading.main_thread():
            _main_event_loop = asyncio.get_running_loop()
            return _main_event_loop
    except RuntimeError:
        pass
    
    # Last resort: return None (will cause fallback behavior)
    return None


def add_to_user_messages(req_id, data, event):
    logger.info(f" request received for add_to_user_messages ------> req_id ---> {req_id} data ----> {data} event -----> {event}")
    try:
        # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
        user_obj = get_user_call_record(str(req_id))
        if user_obj is None:
            return
    except Exception as e:
        logger.error(f"exception occured while getting user object in the event {event} error --> {e}",exc_info=True)
    user_obj["messages_array"].append(data)
    try:
        # PERFORMANCE FIX: Update user call record in memory instead of Redis
        set_user_call_record(str(req_id), user_obj)
    except Exception as e:
        logger.error(f"exception occured while settings user object in the event {event} error --> {e}",exc_info=True)


def send_chat_chunk_callback(req_id: str, chunk: str, isEndChunk: bool):
    logger.info(f"send chat chunk callback called chunk -------> {chunk} isEndChunk ----> {isEndChunk}")
    url = "http://localhost:8080/api/callbacks/chat-chunk-callback"
    payload = {
        "reqId": req_id,
        "chunk": chunk,
        "isEndChunk": isEndChunk
    }
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()  # Raises an HTTPError for bad responses
        logger.info(f"Request to {url} succeeded: {response.status_code}")
        return response.json()  # Return the JSON response content
    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred: {http_err} - Status: {response.status_code}")
    except requests.exceptions.ConnectionError:
        logger.error("Connection error occurred. Please check your connection or URL.")
    except requests.exceptions.Timeout:
        logger.error("Timeout occurred. The request timed out.")
    except requests.exceptions.RequestException as err:
        logger.error(f"An error occurred: {err}",exc_info=True)
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}",exc_info=True)

    return None


async def send_chat_chunk_callback_socket(sid, data, event='call_message'):
    try:
        milliseconds = int(round(time.time() * 1000))
        logger.info(f"send chat response for sid ------> {sid} --------> in time {milliseconds}")
        
        # Check if socket is still connected before sending
        try:
            # Import here to avoid circular imports
            from sockets.sockets import connected_clients
            
            if sid not in connected_clients:
                logger.warning(f"Socket {sid} not in connected_clients, skipping message send")
                logger.info(f"Currently connected sockets: {list(connected_clients)}")
                return False
            
            logger.debug(f"Socket {sid} found in connected_clients ({len(connected_clients)} total)")
                
        except ImportError:
            logger.warning("Could not import connected_clients, sending anyway")
        
        # CRITICAL FIX: Ensure SocketIO operations run on main event loop
        current_thread_name = threading.current_thread().name
        
        if "AsyncLoop" in current_thread_name:
            # Route SocketIO operation to main event loop for thread safety
            logger.debug(f"Routing SocketIO operation from {current_thread_name} to main event loop")
            main_loop = get_main_event_loop()
            
            if main_loop and main_loop.is_running():
                try:
                    # Schedule SocketIO emit on main event loop
                    logger.debug(f"Scheduling event '{event}' on main loop for socket {sid}")
                    future = asyncio.run_coroutine_threadsafe(
                        sio.emit(event, data, to=sid), 
                        main_loop
                    )
                    
                    # Wait for completion (with timeout)
                    future.result(timeout=10.0)
                    logger.info(f"Message sent via main event loop to socket {sid} via event '{event}'")
                    return True
                    
                except Exception as e:
                    logger.error(f"Failed to route SocketIO to main loop for {sid}: {e}", exc_info=True)
                    return False
            else:
                logger.error(f"Main event loop not available for socket {sid}")
                return False
        else:
            # We're already on the main thread - send directly
            logger.debug(f"Sending event '{event}' directly to socket {sid} (on {current_thread_name})")
            await sio.emit(event, data, to=sid)
            logger.info(f"Message sent successfully to socket {sid} via event '{event}'")
            return True
        
    except Exception as e:
        logger.error(f"Error in send_chat_chunk_callback_socket() for {sid}: {e}",exc_info=True)
        return False


def send_socket_event_sync(sid, response, loop=None):
    try:
        logger.info(f"Send sync event loop {loop}")
        if loop is None:
            loop = asyncio.get_event_loop()  # Use the main event loop
        if loop.is_running():
            asyncio.run_coroutine_threadsafe(send_chat_chunk_callback_socket(sid, response), loop)
        else:
            loop.run_until_complete(send_chat_chunk_callback_socket(sid, response))
            loop.close()
    except Exception as e:
        logger.error(f"Error in send_socket_event_sync() : {e}",exc_info=True)
