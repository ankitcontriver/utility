from sqlalchemy import Column, Integer, String, Text
from sqlalchemy.ext.declarative import declarative_base

# Create a separate declarative base for global database
GlobalBase = declarative_base()


class SecurityProperties(GlobalBase):
    __tablename__ = 'security_properties'
    id = Column(Integer, primary_key=True, autoincrement=True)
    operator = Column(String(25), nullable=False)
    country = Column(String(25), nullable=False)
    prop_key = Column(String(100), nullable=False)
    value = Column(Text, nullable=False)

    def __repr__(self):
        return f"SecurityProperties(id={self.id}, operator={self.operator}, country={self.country}, prop_key={self.prop_key}, value={self.value})" 