from fastapi import APIRouter

from service.scrape_service import scrape_url_service

router = APIRouter()


@router.get("/scrape_url", tags=["Scrape Controller"])
async def scrape_url(url: str):
    return await scrape_url_service(url)
