from response.GenericResponse import GenericResponse


class GetCountryLanguage():
    def __init__(self, id, language_id, language_name):
        self.id = id
        self.language_id = language_id
        self.language_name = language_name

    def __repr__(self):
        return f"id: {self.id}, language_id: {self.language_id}, language_name: {self.language_name}"


class GetCountryLanguageResponse(GenericResponse):
    def __init__(self, status, status_code, message, data: list[GetCountryLanguage]):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, status_code: {self.status_code}, message: {self.message}, data: {self.data}"
