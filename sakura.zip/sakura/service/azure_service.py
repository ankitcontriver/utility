import audioop
import base64
import logging
import os
import time

import azure.cognitiveservices.speech as speechsdk


def pcm16_to_mulaw(pcm16_data):
    """
    Convert 16-bit PCM data to 8-bit mu-law data.

    Parameters:
    pcm16_data (bytes): Raw bytes in 16-bit PCM format.

    Returns:
    bytes: Raw bytes in 8-bit mu-law format.
    """
    # Convert 16-bit PCM data to 8-bit mu-law data
    mulaw_data = audioop.lin2ulaw(pcm16_data, 2)  # 2 bytes for 16-bit samples
    return mulaw_data


def speech_synthesis_to_result(socket_id, input_text: str, speed: str = "+20.00"):
    tts_start_time: float = time.time() * 1000
    speech_config = speechsdk.SpeechConfig(subscription=os.getenv('AZURE_SPEECH_KEY'),
                                           region=os.getenv('AZURE_SPEECH_REGION'))
    speech_config.set_speech_synthesis_output_format(speechsdk.SpeechSynthesisOutputFormat.Riff8Khz16BitMonoPcm)
    voice_name = 'en-US-AvaMultilingualNeural'
    speech_config.speech_synthesis_voice_name = voice_name
    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=None)

    ssml = f"""
    <speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xmlns:mstts="https://www.w3.org/2001/mstts" xml:lang='en-US'>
        <voice name='{voice_name}'>
             <prosody rate="{speed}%">
                 <mstts:express-as style='cheerful' styledegree="1">
                    {input_text}
                 </mstts:express-as>
            </prosody>
        </voice>
    </speak>
    """

    result = speech_synthesizer.speak_ssml(ssml=ssml)
    tts_end_time: float = time.time() * 1000
    stt_result: str | None = None

    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        audio_data = result.audio_data
        logging.debug("[%s] Speech synthesized for text '%s' received %d bytes of audio data", socket_id, input_text,
                      len(audio_data))
        audio_data = pcm16_to_mulaw(audio_data)
        audio_base64 = base64.b64encode(audio_data[58:]).decode('utf-8')
        stt_result = audio_base64
    elif result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        logging.warning("[%s] Speech synthesis cancelled: %s", socket_id, cancellation_details.reason)
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            logging.error("[%s] Error details: %s", socket_id, cancellation_details.error_details)

    logging.info("[%s] TTS time taken for '%s': %d ms", socket_id, input_text, tts_end_time - tts_start_time)
    return stt_result
