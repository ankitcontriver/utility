from logger.__init__ import get_logger
from repository.agent_repository import update_agent_tool_list, get_sub_agents_by_assistant_id, toggle_status, \
    write_to_db
from repository.tools_repository import get_tools_by_ids
from response.ShowAgentResponse import showAgentItem, showAgentResponse, updateAgentTempResponse, updateAgentResponse, \
    tmpUpdateStatus, UpdateStatusResponse, uploadDocResponse
from response.ShowToolResponse import shortToolInfo
from service.file_upload_service import upload_doc_service as sh_doc_service
from utils.agent_utils import extract_content,generate_response
import json

logger = get_logger(__name__)


def get_agents_by_assId_service(tenantId: str, assistantId: int):
    try:
        logger.info(f"Fetching agents for tenantId: {tenantId}, assistantId: {assistantId}")
        
        agents = get_sub_agents_by_assistant_id(assistantId)
        data = []

        if agents:
            logger.debug(f"Found {len(agents)} agents for assistantId: {assistantId}")
            for agent in agents:
                
                # Ensure `agent.toolList` is a list of IDs
                tool_list = agent.toolList
                if isinstance(tool_list, str):
                    # Convert comma-separated string to list of strings
                    tool_list = tool_list.split(',')
                elif isinstance(tool_list, (list, tuple)):
                    # Verify all items are strings or integers, else log and skip
                    tool_list = [str(tool) for tool in tool_list]
                else:
                    logger.error(f"Unexpected type for `agent.toolList`: {type(tool_list)}. Expected str, list, or tuple.")
                    tool_list = []  # Default to an empty list in case of unexpected type

                lst = []
                
                # Fetch tools based on corrected `tool_list`
                for tool in get_tools_by_ids(tool_list):
                    try:
                        tool_desc = tool.gptTool["function"]["description"] if tool.gptTool else "No description"
                    except (json.JSONDecodeError, TypeError, KeyError):
                        logger.error(f"Invalid tool description format for tool ID {tool.id}")
                        tool_desc = "Invalid description format"
                    
                    lst.append(shortToolInfo(tool.id, tool.name, tool_desc, tool.status))
                data.append(showAgentItem(
                    id=agent.id,
                    name=agent.name,
                    toolList=lst,
                    description=agent.description,
                    documentLink=agent.documentLink,
                    createdBy=agent.createdBy,
                    createdOn=agent.createdOn,
                    updatedBy=agent.updatedBy,
                    updatedOn=agent.updatedOn,
                    status=agent.status,
                    state=agent.state,
                    flowUml=agent.flowUML
                ))

            response = showAgentResponse(statusCode=200, status="Success", message="Agents found", data=data)
        else:
            logger.info(f"No agents found for assistantId: {assistantId}")
            response = showAgentResponse(statusCode=501, status="Success", message="No agents found", data=[])

    except Exception as e:
        logger.error(f"Exception occurred while fetching agents for assistantId: {assistantId} - {e}")
        response = showAgentResponse(statusCode=502, status="Failure", message="Error fetching agents", data=[])

    finally:
        logger.info(f"Database connection closed for tenantId: {tenantId}, assistantId: {assistantId}")
        return response


def update_agent_tools_service(tenantID: str, assistantId: str, agentId: str, toolList: list, userId: str):
    try:
        logger.info(
            f"Updating tools for agentId: {agentId}, tenantID: {tenantID}, assistantId: {assistantId}, userId: {userId}")
        agent = update_agent_tool_list(tenantID, assistantId, agentId, toolList, userId)

        if isinstance(agent, str):
            logger.error(f"Error updating agent tools: {agent}")
            return updateAgentResponse(statusCode="error", status=602, message=agent, data=[])

        lst = []
        for tool in get_tools_by_ids(agent.toolList):
            lst.append(
                shortToolInfo(tool.id, tool.name, tool.gptTool["function"]["description"], tool.status))

        data = updateAgentTempResponse(
            id=agent.id,
            agentName=agent.name,
            data=lst
        )
        response = updateAgentResponse(statusCode="success", status=200, message="Successfully updated tools",
                                       data=data)
        logger.info(f"Successfully updated tools for agentId: {agentId}")

    except Exception as e:
        logger.error(f"Exception occurred while updating tools for agentId: {agentId} - {e}")
        response = updateAgentResponse(statusCode="error", status=601, message=f"Error: {str(e)}", data=[])

    finally:
        logger.info(f"Database connection closed for tenantID: {tenantID}, assistantId: {assistantId}")

    return response


def update_agent_status_service(tenantId, assistantId, agentId):
    response = None  # Initialize response to None

    try:
        # Try toggling the agent's status
        agent = toggle_status(tenantId, assistantId, agentId)
        sh_response = sh_doc_service(assistant_id=assistantId)
        if agent is not None:
            # Prepare data if agent is found and status toggled
            data = tmpUpdateStatus(
                id=agent.id,
                name=agent.name,
                status=agent.status
            )

            # Successful response
            if (sh_response.status == "success"):
                response = UpdateStatusResponse(
                    statusCode=200,
                    status="Success",
                    message="Agent Status Updated Successfully",
                    data=data
                )
                logger.info(f"Agent status updated successfully for agentId: {agentId}")
            else:
                response = UpdateStatusResponse(
                    statusCode=1000,
                    status="Success",
                    message="No agent found",
                    data=data
                )
                logger.warning(f"Failed to update extra columns and assistant_configuration for agentId: {agentId}, assistantId: {assistantId}, tenantId: {tenantId}")

        else:
            # If no agent is found
            data = None
            response = UpdateStatusResponse(
                statusCode=1000,
                status="Success",
                message="No agent found",
                data=data
            )
            logger.warning(f"No agent found for agentId: {agentId}, assistantId: {assistantId}, tenantId: {tenantId}")

    except Exception as e:
        # Log the exception and prepare failure response
        logger.error(
            f"Exception occurred while updating agent status for agentId: {agentId}, assistantId: {assistantId}, tenantId: {tenantId}. Error: {e}")
        data = None
        response = UpdateStatusResponse(
            statusCode=1001,
            status="Failure",
            message="Internal Server Error",
            data=data
        )

    finally:
        # Ensure the session is closed
        return response


def upload_doc_service(tenantId, assistantId, agentId, file_path,filename, userId):
    try:
        file_content = extract_content(file_path)
        tool_name, tool_input,umlPath = generate_response(file_content, file_path)
        if tool_name == "write_to_db":
                    agent = write_to_db(filename, agentId, tool_input["agent_token"], tool_input['agent_description'],
                            tool_input["prompt"], tool_input["tool_indexes"], userId, umlPath, assistantId=assistantId)     
        else:
                    agent=None

        sh_response = sh_doc_service(assistant_id=assistantId)
        
        if agent:
            lst = []
            for tool in get_tools_by_ids(agent.toolList):
                lst.append(shortToolInfo(tool.id, tool.name, tool.gptTool["function"]["description"],
                                         tool.status))
            data = showAgentItem(
                id=agent.id,
                name=agent.name,
                toolList=lst,
                description=agent.description,
                documentLink= agent.documentLink,
                createdBy=agent.createdBy,
                createdOn=agent.createdOn,
                updatedBy=agent.updatedBy,
                updatedOn=agent.updatedOn,
                status=agent.status,
                state=agent.state,
                flowUml= agent.flowUML
            )
            if (sh_response.status == "success"):
                response = uploadDocResponse(
                    statusCode=200,
                    status="Success",
                    message="Agent Updated Successfully",
                    data=data
                )
            else:
                response = uploadDocResponse(
                    statusCode=1001,
                    status="Failure",
                    message="Error in updating prompt",
                    data=data
                )

        else:
            response = uploadDocResponse(
                statusCode=1001,
                status="Failure",
                message="No agent found with such parameters",
                data = []
            )

    except Exception as e:
        logger.error(
            f"Exception occurred while updating agent: {agentId}, assistantId: {assistantId}, tenantId: {tenantId}. Error: {e}")
        data = None
        response = UpdateStatusResponse(
            statusCode=1002,
            status="Failure",
            message="Internal Server Error",
            data=data
        )
    finally:
        # Ensure the session is closed
        return response


def create_agent_service(tenantId, assistantId, file_path, filename, userId):
    data = None  # Initialize data as None at the beginning
    try:
        file_content = extract_content(file_path)
        agent = None
        agentId=None
        tool_name, tool_input,umlPath = generate_response(file_content, file_path)
        if tool_name == "write_to_db":
                    agent = write_to_db(filename, agentId, tool_input["agent_token"], tool_input['agent_description'],
                            tool_input["prompt"], tool_input["tool_indexes"], userId, umlPath,assistantId= assistantId)     
        sh_response = sh_doc_service(assistant_id=assistantId)
        
        if agent:
            lst = []
            for tool in get_tools_by_ids(agent.toolList):
                # Convert any set within tool.gptTool["function"]["description"] to list if it exists
                description = tool.gptTool["function"]["description"]
                if isinstance(description, set):
                    description = list(description)  # Convert set to list
                    
                lst.append(shortToolInfo(
                    tool.id, 
                    tool.name, 
                    description,
                    tool.status
                ))
            
            data = showAgentItem(
                id=agent.id,
                name=agent.name,
                toolList=lst,
                description=agent.description,
                documentLink=agent.documentLink,
                createdBy=agent.createdBy,
                createdOn=agent.createdOn,
                updatedBy=agent.updatedBy,
                updatedOn=agent.updatedOn,
                status=agent.status,
                state=agent.state,
                flowUml=agent.flowUML
            )

            if sh_response.status == "success":
                response = uploadDocResponse(
                    statusCode=200,
                    status="Success",
                    message="Agent Updated Successfully",
                    data=data
                )
            else:
                response = uploadDocResponse(
                    statusCode=1001,
                    status="Failure",
                    message="Error creating prompt",
                    data=data
                )
        else:
            response = uploadDocResponse(
                statusCode=1001,
                status="Failure",
                message="No agent found with such parameters",
                data=data  # data is None here, but it's defined
            )

    except Exception as e:
        logger.error(
            f"Exception occurred while creating agent: assistantId: {assistantId}, tenantId: {tenantId}. Error: {e}")
        response = UpdateStatusResponse(
            statusCode=1002,
            status="Failure",
            message="Internal Server Error",
            data=data  # data remains None in case of an error
        )
    finally:
        return response  # Ensure response is returned in all cases

