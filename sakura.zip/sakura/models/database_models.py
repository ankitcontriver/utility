import uuid
from datetime import datetime, timezone

from sqlalchemy import \
    Column, \
    Integer, \
    String, \
    DateTime, \
    Boolean, \
    Text, \
    JSON, \
    UniqueConstraint, Enum, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from enums.scrape_status_enum import ScrapeStatus

Base = declarative_base()


class Country(Base):
    __tablename__ = 'country'
    id = Column(Integer, primary_key=True)
    country_iso_code = Column(String(10))
    country_name = Column(String(255))
    country_calling_code = Column(String(10))
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, default=True)

    def __repr__(self):
        return f"Country(country_iso_code={self.country_iso_code}, country_name={self.country_name}, country_calling_code={self.country_calling_code}, status={self.status})"


class Language(Base):
    __tablename__ = 'languages'
    id = Column(Integer, primary_key=True)
    lang_id = Column(String(10))
    lang_name = Column(String(255))
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, default=True)

    def __repr__(self):
        return f"Language(lang_id={self.lang_id}, lang_name={self.lang_name}, status={self.status})"


class TTSModel(Base):
    __tablename__ = 'tts_model'
    id = Column(Integer, primary_key=True)
    tts_model_name = Column(String(255))
    tts_model_provider = Column(String(255))
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, default=True)

    def __repr__(self):
        return f"TTSModel(tts_model_name={self.tts_model_name}, tts_model_provider={self.tts_model_provider}, status={self.status})"


class ASRModel(Base):
    __tablename__ = 'asr_model'
    id = Column(Integer, primary_key=True)
    asr_model_name = Column(String(255))
    asr_model_provider = Column(String(255))
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, default=True)

    def __repr__(self):
        return f"ASRModel(asr_model_name={self.asr_model_name}, asr_model_provider={self.asr_model_provider}, status={self.status})"


class LLMModel(Base):
    __tablename__ = 'llm_model'
    id = Column(Integer, primary_key=True)
    llm_model_display_name = Column(String(255))
    llm_model_provider = Column(String(255))
    llm_model_name = Column(String(255))
    tool_call_support = Column(Boolean, default=False)
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, default=True)

    def __repr__(self):
        return f"LLMModel(llm_model_display_name={self.llm_model_display_name}, llm_model_provider={self.llm_model_provider}, llm_model_name={self.llm_model_name}, tool_call_support={self.tool_call_support})"


class CountryLanguageMapping(Base):
    __tablename__ = 'country_language_mapping'
    id = Column(Integer, primary_key=True)
    country_id = Column(String(10))
    country_name = Column(String(255))
    language_id = Column(String(10))
    language_name = Column(String(255))
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, default=True)

    def __repr__(self):
        return f"CountryLanguageMapping(country_id={self.country_id}, country_name={self.country_name}, language_id={self.language_id}, language_name={self.language_name})"


class ASRLanguageMapping(Base):
    __tablename__ = 'asr_language_mapping'
    id = Column(Integer, primary_key=True)
    asr_name = Column(String(255))
    language_id = Column(String(10))
    language_name = Column(String(255))
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, default=True)

    def __repr__(self):
        return f"ASRLanguageMapping(asr_name={self.asr_name}, language_id={self.language_id}, language_name={self.language_name})"


class ASRCountryMapping(Base):
    __tablename__ = 'asr_country_mapping'
    id = Column(Integer, primary_key=True)
    asr_name = Column(String(255))
    language_id = Column(String(10))
    language_name = Column(String(255))
    country_specific_language_id = Column(String(10))
    country_specific_language_name = Column(String(255))
    country_id = Column(String(10))
    country_name = Column(String(255))
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, default=True)

    def __repr__(self):
        return f"ASRCountryMapping(asr_name={self.asr_name}, language_id={self.language_id}, language_name={self.language_name}, country_specific_language_id={self.country_specific_language_id}, country_specific_language_name={self.country_specific_language_name}, country_id={self.country_id}, country_name={self.country_name})"


class TTSLanguageMapping(Base):
    __tablename__ = 'tts_language_mapping'
    id = Column(Integer, primary_key=True)
    tts_model_provider = Column(String(50))
    tts_model_name = Column(String(255))
    language_id = Column(String(10))
    language_code = Column(String(255))
    language_name = Column(String(255))
    language_display_name = Column(String(255))
    voice_name = Column(String(255))
    voice_type = Column(String(15))
    country_id = Column(String(10))
    country_name = Column(String(255))
    gender = Column(String(255))
    sample_voice_text = Column(String(255))
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, default=True)

    def __repr__(self):
        return f"TTSLanguageMapping(tts_model_provider={self.tts_model_provider}, tts_model_name={self.tts_model_name}, language_id={self.language_id}, language_code={self.language_code}, language_name={self.language_name}, language_display_name={self.language_display_name}, voice_name={self.voice_name}, country_id={self.country_id}, country_name={self.country_name}, gender={self.gender}, sample_voice_text={self.sample_voice_text}, status={self.status})"


class LLMMapping(Base):
    __tablename__ = 'llm_mapping'
    id = Column(Integer, primary_key=True)
    assistant_ids = Column(String(255))
    llm_model_provider = Column(String(255))
    llm_model_display_name = Column(String(64))
    llm_model_name = Column(String(255))
    tool_call_support = Column(Boolean, default=False)
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, default=True)

    def __repr__(self):
        return f"LLMLanguageMapping(assistant_ids={self.assistant_ids}, llm_model_provider={self.llm_model_provider}, llm_model_name={self.llm_model_name}, llm_model_display_name={self.llm_model_display_name}, status={self.status})"


class AssistantConfiguration(Base):
    __tablename__ = 'assistant_configuration'
    assistant_id = Column(Integer, primary_key=True)
    role = Column(String(255))
    name = Column(String(255))
    age = Column(Integer)
    company = Column(String(255))
    description = Column(String(255))
    male_picture_url = Column(String(255))
    female_picture_url = Column(String(255))
    prompt = Column(Text)
    call_summary_prompt= Column(Text,nullable=True)
    opening_message = Column(Text,nullable=True)
    model_id_list = Column(String(255))
    tts_style = Column(String(255))
    user_specific = Column(Boolean, default=True)
    header = Column(String(255), nullable=True)
    questions = Column(Text, nullable=True)
    tool_call_support = Column(Boolean, default=False)
    tools_supported = Column(Text)
    claude_tools = Column(Text)
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, default=True)
    country = Column(String(25), nullable=False)
    operator = Column(String(25), nullable=False)
    country_code = Column(String(25))
    ivr_stt_array = Column(Text, nullable=True)
    path_finder_json = Column(Text, nullable=True)
    calendar_prompt = Column(Text, nullable=True)
    lang_selection_via_asr = Column(Boolean, default=False)
    tier2_prompt = Column(Text, nullable=True)
    tier2_tools = Column(Text, nullable=True)

    def __repr__(self):
        return f"AssistantConfiguration(assistant_id={self.assistant_id}, tool_call_support={self.tool_call_support}, country={self.country}, operator={self.operator}, countryCode={self.country_code})"


class VoiceConfiguration(Base):
    __tablename__ = 'voice_configuration'
    id = Column(Integer, primary_key=True)
    display_name = Column(String(255))
    voice_name = Column(String(255))
    provider = Column(String(255))
    gender = Column(String(255))
    style = Column(String(255))
    speed = Column(String(255))
    style_degree = Column(String(255))
    language_code = Column(String(255))

    def __repr__(self):
        return f"VoiceConfiguration(display_name={self.display_name}, voice_name={self.voice_name}, provider={self.provider}, gender={self.gender}, style={self.style}, speed={self.speed}, style_degree={self.style_degree}, language_code={self.language_code})"


class UserAssistantMapping(Base):
    __tablename__ = 'user_assistant_mapping'
    id = Column(Integer, primary_key=True)
    email = Column(String(255))
    assistant_id_list = Column(Text)
    show_default = Column(Boolean)


class ScrapedData(Base):
    __tablename__ = 'scraped_data'
    id = Column(Integer, primary_key=True, index=True)
    url = Column(String(255), unique=True, index=True)
    status = Column(Enum(ScrapeStatus), nullable=False, default=ScrapeStatus.PROCESSING)
    # organisation = Column(String(255))
    base_url = Column(String(69), nullable=True)
    summary = Column(Text, nullable=True)
    created_on = Column(DateTime, default=datetime.utcnow)
    updated_on = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class OrganizationNames(Base):
    __tablename__ = 'organization_names'

    id = Column(Integer, primary_key=True, index=True)
    organization_name = Column(String(255), nullable=False)
    sector = Column(String(255), nullable=False)
    emails = Column(Text, nullable=False)
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<organizationName(id={self.id}, organization_name={self.organization_name}, sector={self.sector}, emails={self.emails}, createdOn={self.createdOn}, updatedOn={self.updatedOn})>"


class UserDetails(Base):
    __tablename__ = 'user_details'
    id = Column(Integer, primary_key=True, index=True)
    email_id = Column(String(255), unique=True, index=True)
    org_id = Column(Integer, nullable=False)
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return (
            f"UserDetails(id={self.id}, email='{self.email_id}', org_ID={self.org_ID}, createdOn={self.createdOn},updatedOn={self.updatedOn})")


class ExtraColumns(Base):
    __tablename__ = 'extra_columns'

    id = Column(Integer, primary_key=True, autoincrement=True)
    agent_id = Column(Integer, nullable=False)
    organization_name = Column(String(255))
    org_id = Column(Integer, nullable=False)
    agent_type = Column(String(255), nullable=False)
    enterprise_data = Column(Text, nullable=True)
    local_specs = Column(Text, nullable=True)
    website = Column(String(255), nullable=False)
    website_summary = Column(Text, nullable=True)
    parameters = Column(JSON, nullable=True)
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"ExtraColumns(id={self.id}, agent_id={self.agent_id}, org_id={self.org_id}, agent_type={self.agent_type}, enterprise_data={self.enterprise_data}, local_specs={self.local_specs}, website={self.website}, website_url={self.website_summary}, parameters={self.parameters}, createdOn={self.createdOn}, updatedOn={self.updatedOn})"


class Sector(Base):
    __tablename__ = 'sectors'

    id = Column(Integer, primary_key=True, index=True)
    sector_name = Column(String(255), unique=True, nullable=False)
    capabilities = Column(Text, nullable=True)

    def __repr__(self):
        return f"<Sector(id={self.id}, sector_name={self.sector_name}, capabilities={self.capabilities})>"


class DefaultPrompts(Base):
    __tablename__ = 'default_prompts'

    id = Column(Integer, primary_key=True, autoincrement=True)
    agent_id = Column(Integer, nullable=False)
    model_id = Column(Integer, nullable=False)
    role = Column(Text, nullable=True)
    behaviour = Column(Text, nullable=True)
    capabilities = Column(Text, nullable=True)
    knowledge = Column(Text, nullable=True)
    do_donts = Column(Text, nullable=True)
    parameters = Column(JSON, nullable=True)
    createdOn = Column(DateTime, default=datetime.utcnow)
    updatedOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return (f"<DefaultPrompts(id={self.id}, agent_id={self.agent_id}, "
                f"model_id={self.model_id}, role={self.role}, behaviour={self.behaviour}, "
                f"capabilities={self.capabilities}, knowledge={self.knowledge}, "
                f"do_donts={self.do_donts}, parameters={self.parameters}, "
                f"createdOn={self.createdOn}, updatedOn={self.updatedOn})>")


class WhitelistedDomains(Base):
    __tablename__ = 'whitelisted_domains'
    id = Column(Integer, primary_key=True, autoincrement=True)
    domain = Column(String(255), nullable=False)
    name = Column(String(255), nullable=True)
    created_on = Column(DateTime, default=datetime.utcnow)
    updated_on = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(Boolean, nullable=False, default=True)


class User(Base):
    __tablename__ = 'user_base'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    email = Column(String(255), nullable=False, unique=True)
    password = Column(String(255), nullable=True)
    contact_number = Column(String(255), nullable=True)
    latest_ip = Column(String(255), nullable=True)
    last_login = Column(DateTime, nullable=True, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = Column(Boolean, nullable=False, default=False)
    is_enable = Column(Boolean, nullable=False, default=True)
    language = Column(String(255), nullable=True)
    voice = Column(String(255), nullable=True)
    flow = Column(String(255), nullable=True)
    is_bng = Column(Boolean, nullable=False, default=False)
    encoded_key = Column(String(255), nullable=True, unique=True)

    def __repr__(self):
        return f"id={self.id}, name={self.name}, email={self.email}, contact_number={self.contact_number}, password={self.password}, language={self.language}, voice={self.voice}, flow={self.flow}, is_bng={self.is_bng}, is_enable={self.is_enable}, is_active={self.is_active}"


class CallLog(Base):
    __tablename__ = 'call_logs'
    id = Column(Integer, primary_key=True, autoincrement=True)
    date = Column(DateTime, default=datetime.utcnow)
    email = Column(String(255), nullable=False)
    call_duration = Column(Integer, nullable=True)
    call_logs = Column(Text, nullable=True)
    ip = Column(String(255), nullable=True)
    browser_data = Column(Text, nullable=True)
    config = Column(Text, nullable=True)


class UrlLoginDetails(Base):
    __tablename__ = 'url_login_details'
    id = Column(Integer, primary_key=True, autoincrement=True)
    url = Column(String(255), nullable=False)
    count = Column(Integer, nullable=False)
    login_track = Column(String(255), nullable=False)
    email = Column(String(255), nullable=False)


class Configuration(Base):
    __tablename__ = 'configuration'
    id = Column(Integer, primary_key=True, autoincrement=True)
    config_key = Column(String(255), nullable=False)
    value = Column(Text, nullable=False)


class ContactForms(Base):
    __tablename__ = 'contact_form'
    id = Column(Integer, primary_key=True, autoincrement=True)
    email = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    name = Column(String(255), nullable=False)
    phone_number = Column(String(255), nullable=False)
    query_type = Column(Text, nullable=False)
    user_id = Column(Integer, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


"""THIS TABLE IS REALATED RAG OPERATION """


class ToolDescription(Base):
    __tablename__ = 'tool_descriptions'

    id = Column(Integer, primary_key=True, autoincrement=True)
    assistant_id = Column(String(50), nullable=False, unique=True)  # Unique constraint for assistant_id
    tool_description = Column(Text, nullable=False)
    created_on = Column(DateTime, default=datetime.now(timezone.utc), nullable=False)
    updated_on = Column(DateTime, default=datetime.now(timezone.utc), onupdate=datetime.now(timezone.utc))
    created_by = Column(String(50), nullable=False)
    updated_by = Column(String(50), nullable=True)

    __table_args__ = (UniqueConstraint('assistant_id', name='uq_assistant_id'),)

    def __repr__(self):
        return f"<ToolDescription( assistant_id='{self.assistant_id}', description='{self.tool_description}', created_by='{self.created_by}', updated_by='{self.updated_by}')>"


class Files(Base):
    __tablename__ = 'files'

    tag_id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    file_name = Column(String(255), nullable=False)
    file_type = Column(String(50))
    file_size = Column(Integer)
    clean_file_path = Column(String(255), default="")
    original_file_path = Column(String(255), default="")
    current_version = Column(Integer, default=1)
    doc_tags = Column(String(512))
    created_on = Column(DateTime, default=datetime.now(timezone.utc))
    updated_on = Column(DateTime, default=datetime.now(timezone.utc), onupdate=datetime.now(timezone.utc))
    created_by = Column(String(50), nullable=False)
    updated_by = Column(String(50), nullable=True)
    status = Column(Boolean, default=False)
    process_state = Column(Enum(ScrapeStatus), default=ScrapeStatus.PROCESSING)  # Enum with default "PROCESSING"
    task_id = Column(String(36), nullable=True)
    # Relationship to document versions
    document_versions = relationship('DocumentVersion', back_populates='file')

    def __repr__(self):
        return (
            f"<File(tag_id='{self.tag_id}', file_name='{self.file_name}', file_type='{self.file_type}', file_size={self.file_size}, "
            f"clean_file_path='{self.clean_file_path}', original_file_path='{self.original_file_path}', current_version={self.current_version}, "
            f"status={self.status}, process_state='{self.process_state}',task_id='{self.task_id}', created_by='{self.created_by}', updated_by='{self.updated_by}')>")


class AgentFileMapping(Base):
    __tablename__ = 'agent_file_mapping'

    id = Column(Integer, primary_key=True, autoincrement=True)
    assistant_id = Column(String(50), nullable=False)  # Changed nullable to False
    tag_id = Column(String(36), ForeignKey('files.tag_id'), nullable=False)
    created_on = Column(DateTime, default=datetime.now(timezone.utc))
    updated_on = Column(DateTime, default=datetime.now(timezone.utc), onupdate=datetime.now(timezone.utc))
    created_by = Column(String(50), nullable=False)
    updated_by = Column(String(50), nullable=True)
    __table_args__ = (
        UniqueConstraint('assistant_id', 'tag_id', name='_assistant_id_file_uc'),  # Adjusted unique constraint
    )

    file = relationship('Files')

    def __repr__(self):
        return (f"<AgentFileMapping(id={self.id}, assistant_id='{self.assistant_id}', "
                f"tag_id='{self.tag_id}', created_on={self.created_on}, updated_on={self.updated_on}, "
                f"created_by='{self.created_by}', updated_by='{self.updated_by}')>")


class DocumentVersion(Base):
    __tablename__ = 'document_versions'

    id = Column(Integer, primary_key=True, autoincrement=True)
    tag_id = Column(String(36), ForeignKey('files.tag_id'))
    file_name = Column(String(255))
    file_type = Column(String(50))
    file_size = Column(Integer)
    version = Column(Integer, nullable=False)
    original_file_path = Column(String(255))
    clean_file_path = Column(String(255))
    doc_tags = Column(String(512))
    created_on = Column(DateTime, default=datetime.now(timezone.utc), nullable=False)
    created_by = Column(String(50), nullable=False)

    file = relationship('Files', back_populates='document_versions')

    def __repr__(self):
        return (
            f"<DocumentVersion(id={self.id}, version={self.version}, tag_id='{self.tag_id}', file_name='{self.file_name}', "
            f"file_type='{self.file_type}', doc_tags='{self.doc_tags}', created_on={self.created_on}, created_by='{self.created_by}')>")


class TaskStatus(Base):
    __tablename__ = 'task_status'

    id = Column(Integer, primary_key=True, autoincrement=True)
    task_id = Column(String(100), nullable=False)
    state = Column(String(50), nullable=False)
    detail = Column(String(500), nullable=True)
    created_on = Column(DateTime, default=datetime.now(timezone.utc), nullable=False)
    updated_on = Column(DateTime, default=datetime.now(timezone.utc), onupdate=datetime.now(timezone.utc),
                        nullable=False)

    def __repr__(self):
        return f"<TaskStatus(id={self.id}, task_id='{self.task_id}', state='{self.state}', detail='{self.detail}')>"


class Tool(Base):
    __tablename__ = 'tools'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    tenantId = Column(String(255), nullable = True)
    gptTool = Column(JSON, nullable=False)  # Changed from Text to JSON
    claudeTool = Column(JSON, nullable=True)  # Changed from Text to JSON
    createdBy = Column(String(255), nullable=True)
    createdOn = Column(DateTime, default=datetime.utcnow, nullable=True)
    updateBy = Column(String(255), nullable=True)
    updateOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=True)
    status = Column(Boolean, default=True, nullable=False)
    state = Column(String(255), nullable=True)

    def __repr__(self):
        return (f"Tool(id={self.id}, name={self.name}, tenantId={self.tenantId} gptTool={self.gptTool}, claudeTool={self.claudeTool}, "
                f"createdBy={self.createdBy}, createdOn={self.createdOn}, updateBy={self.updateBy}, "
                f"updateOn={self.updateOn}, status={self.status}, state ={self.state})")


##### view only tables(tools, assistants and workflow(agents)):
class Assistant_Configuration(Base):
    __tablename__ = 'assistants'

    id = Column(Integer, primary_key=True, autoincrement=True)
    tenantId = Column(String(255), nullable=True)
    assistantName = Column(String(255), nullable=True)
    assistantRole = Column(String(255), nullable=True)
    assistantDescription = Column(String(255), nullable=True)
    assistantAge = Column(Integer, nullable=True)
    assistantGender = Column(String(255), nullable=True)
    assistantLanguage = Column(String(255), nullable=True)
    assistantVoice = Column(String(255), nullable=True)
    assistantInterface = Column(String(255), nullable=True)
    assistantOrganization = Column(String(255), nullable=True)
    assistantStatus = Column(Boolean, nullable=True)
    assistantPrompt = Column(Text, nullable=True)  # LONGTEXT in MySQL
    createdOn = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    createdBy = Column(String(255), nullable=True)
    updatedOn = Column(DateTime(timezone=True), onupdate=func.now(), nullable=True)
    updatedBy = Column(String(255), nullable=True)
    assistantRole = Column(String(255),
                           nullable=True)  # No direct equivalent to BrainEnum.AssistantRole, assuming it's String(255)
    assistantImageUrl = Column(String(255), nullable=True)
    assistantImageView = Column(String(255), nullable=True)
    assistantOpeningMessage = Column(String(255), nullable=True)
    assistantModerationPrompt = Column(String(255), nullable=True)
    assistantSubAgentList = Column(String(255), nullable=True)
    assistantCategory = Column(String(255), nullable = True)
    
    def __repr__(self):
        return (f"<Assistant_Configuration(id={self.id}, tenantId={self.tenantId}, "
                f"assistantName={self.assistantName}, assistantRole = {self.assistantRole},assistantDescription={self.assistantDescription}, "
                f"assistantAge={self.assistantAge}, assistantGender={self.assistantGender}, "
                f"assistantLanguage={self.assistantLanguage},assistantVoice={self.assistantVoice},assistantInterface={self.assistantInterface}, assistantOrganization={self.assistantOrganization}, "
                f"assistantStatus={self.assistantStatus}, assistantPrompt={self.assistantPrompt}, "
                f"createdOn={self.createdOn}, createdBy={self.createdBy}, updatedOn={self.updatedOn}, "
                f"updatedBy={self.updatedBy}, assistantRole={self.assistantRole}, "
                f"assistantImageUrl={self.assistantImageUrl}, assistantImageView = {self.assistantImageView}, assistantOpeningMessage={self.assistantOpeningMessage}, "
                f"assistantModerationPrompt={self.assistantModerationPrompt}, assistantSubAgentList={self.assistantSubAgentList}, assistantCategory={self.assistantCategory})>")


class Tools(Base):
    __tablename__ = 'tool_view'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    tenantId = Column(String(255), nullable=False)
    createdBy = Column(String(255), nullable=False)
    createdOn = Column(DateTime, default=datetime.utcnow, nullable=False)
    updateBy = Column(String(255), nullable=True)
    updateOn = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=True)
    status = Column(Boolean, default=True, nullable=False)
    state = Column(String(255), nullable=True)

    def __repr__(self):
        return (f"Tools(id={self.id}, name={self.name}, description={self.description}, tenantId={self.tenantId}, "
                f"createdBy={self.createdBy}, createdOn={self.createdOn}, updateBy={self.updateBy}, "
                f"updateOn={self.updateOn}, status={self.status},state={self.state})")


class SubAgentConfiguration(Base):
    __tablename__ = 'sub_agent_configuration'

    id = Column(Integer, primary_key=True, autoincrement=True)
    assistantId = Column(Integer, nullable=False)
    name = Column(String(255), nullable=True)
    description = Column(Text, nullable=True)
    prompt = Column(Text, nullable=True)  # LONGTEXT equivalent in SQLAlchemy
    toolList = Column(String(255), nullable=True)
    status = Column(Boolean, nullable=True)
    summary = Column(Text, nullable=True)
    documentLink = Column(String(255), nullable=True)
    documentDownload = Column(String(255), nullable=True)
    createdOn = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    createdBy = Column(String(255), nullable=False)
    updatedOn = Column(DateTime(timezone=True), onupdate=func.now(), nullable=True)
    updatedBy = Column(String(255), nullable=True)
    state = Column(String(255), nullable=True)
    flowUML = Column(Text, nullable=True)
    umlDownload = Column(String(255), nullable=True)

    def __repr__(self):
        return (f"<SubAgentConfiguration(id={self.id}, assistantId={self.assistantId}, "
                f"name={self.name}, description={self.description}, prompt={self.prompt}, "
                f"toolList={self.toolList}, status={self.status}, summary={self.summary}, documentLink={self.documentLink}, documentDownload= {self.documentDownload}, createdOn={self.createdOn}, "
                f"createdBy={self.createdBy}, updatedOn={self.updatedOn}, updatedBy={self.updatedBy},state = {self.state},flowUML={self.flowUML}, umlDownload= {self.umlDownload} )>")


####end####

class CDRTable(Base):
    __tablename__ = 'cdr_table'

    id = Column(Integer, primary_key=True, autoincrement=True)
    callId = Column(String(255), nullable=False)
    cdr = Column(JSON, nullable=False)  # Stores the entire CDR JSON
    callMessage = Column(JSON, nullable=False)  # Stores the call messages JSON
    createdOn = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updatedOn = Column(DateTime(timezone=True), onupdate=func.now(), nullable=True)

    def __repr__(self):
        return f"CDRTable(id={self.id}, callId={self.callId}, cdr={self.cdr}, callMessage={self.callMessage})"


class ASRLLMMapping(Base):
    __tablename__ = 'asr_llm_mapping'

    id = Column(Integer, primary_key=True, autoincrement=True)
    op_co = Column(String(25), nullable=False, unique=True)
    stt_provider = Column(String(25), nullable=True)
    stt_region = Column(String(30), nullable=True)
    stt_key = Column(String(100), nullable=True)
    llm_provider = Column(String(25), nullable=True)
    llm_api = Column(String(250), nullable=True)
    llm_key = Column(String(100), nullable=True)
    llm_model = Column(String(100), nullable=True)
    tts_provider = Column(String(25), nullable=True)
    tts_api = Column(String(250), nullable=True)
    tts_key = Column(String(100), nullable=True)
    perplexity_api = Column(String(250), nullable=True)
    perplexity_key = Column(String(100), nullable=True)
    perplexity_model = Column(String(100), nullable=True)

    def __repr__(self):
        return f"ASRLLMMapping(id={self.id}, op_co={self.op_co}, llm_provider={self.llm_provider}, tts_provider={self.tts_provider})"
