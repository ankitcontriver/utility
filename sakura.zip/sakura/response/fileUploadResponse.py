from response.GenericResponse import GenericResponse

class UploadDocResponse(GenericResponse):
    def __init__(self, status, status_code, message, data=None):
        """
        Initializes an UploadDocResponse object with a nested data dictionary containing detailed fields.
        
        Parameters:
        - status (str): The success or error status of the response.
        - status_code (int): The HTTP status code.
        - message (str): A message detailing the response.
        - data (dict): A dictionary with assistant-related details, default is None if not provided.
        """
        super().__init__(status=status, status_code=status_code, message=message)
        self.data = data if data is not None else {}

    def __repr__(self):
        return (f"status={self.status}, status_code={self.status_code}, message={self.message}, "
                f"data={self.data}")