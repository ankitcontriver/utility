import json

from enums.call_enums import Event
from models.database_models import CDRTable


class UserCallRecord:
    def __init__(self, callId, assistantId, gender, languageCode, voiceName, ttsModel, userMessage=None,
                 llmMessage=None,
                 processing=False, socketId=None, interrupt=False, speaking=True, listening=False, langCode="en-IN",
                 voiceCode="en-IN-NeerjaNeural", currentMessageId="0_Avatar", eventType=Event.CALL.value, ttsStyle=
                 "chat", llmModel="gpt-4o-mini", isTranslate=False, prompt_category=None, provider="azure",
                 consecutive_no_reply_count=0, tools=None, claude_tools=None, isSendEmail=None, aParty=None,
                 bParty=None, serviceType=None, questionPerCall=None, isCallOngoing=None, gpt_response_stream=False, 
                 current_node_id = -1, user_path=None, pending_vector_id=None, vector_metadata_cache=None):
        if llmMessage is None:
            llmMessage = []
        if userMessage is None:
            userMessage = []
        self.callId = callId
        self.assistantId = assistantId
        self.gender = gender
        self.languageCode = languageCode
        self.voiceName = voiceName
        self.ttsModel = ttsModel
        self.userMessage = userMessage
        self.llmMessage = llmMessage
        self.processing = processing
        self.socketId = socketId
        self.interrupt = interrupt
        self.speaking = speaking
        self.listening = listening
        self.langCode = langCode
        self.voiceCode = voiceCode
        self.currentMessageId = currentMessageId
        self.eventType = eventType
        self.ttsStyle = ttsStyle
        self.llmModel = llmModel
        self.isTranslate = isTranslate
        self.prompt_category = prompt_category
        self.provider = provider
        self.consecutive_no_reply_count = consecutive_no_reply_count
        self.tools = tools
        self.claude_tools = claude_tools
        self.isSendEmail = isSendEmail
        self.aParty = aParty
        self.bParty = bParty
        self.serviceType = serviceType
        self.questionPerCall = questionPerCall
        self.isCallOngoing= isCallOngoing
        self.gpt_response_stream = gpt_response_stream
        self.current_node_id = current_node_id
        self.user_path = user_path
        self.pending_vector_id = pending_vector_id
        self.vector_metadata_cache = vector_metadata_cache if vector_metadata_cache is not None else []


    def __str__(self):
        return (f"UserCallRecord(callId={self.callId}, assistantId={self.assistantId}, gender={self.gender}, "
                f"languageCode={self.languageCode}, voiceName={self.voiceName}, ttsModel={self.ttsModel}, "
                f"userMessage={self.userMessage}, llmMessage={self.llmMessage}, processing={self.processing}, "
                f"socketId={self.socketId}, interrupt={self.interrupt}, speaking={self.speaking}, listening={self.listening}, langCode={self.langCode}, voiceCode={self.voiceCode}, currentMessageId={self.currentMessageId}, eventType={self.eventType}, ttsStyle={self.ttsStyle}, llmModel={self.llmModel}, isTranslate={self.isTranslate}, prompt_category={self.prompt_category}, provider={self.provider}, consecutive_no_reply_count={self.consecutive_no_reply_count}, tools={self.tools},claude_tools={self.claude_tools}, isSendEmail={self.isSendEmail}, aParty={self.aParty}, bParty={self.bParty}, serviceType={self.serviceType}, questionPerCall={self.questionPerCall}, isCallOngoing={self.isCallOngoing})")


class UserCallCDR:
    def __init__(self, call_id, assistant_id, assistant_name, call_start_time, call_end_time, call_duration,
                 call_status, call_type, user_id, question_count, answer_count, tools_used, rag_tool_use,
                 satisfaction_score, sentiment, emotions, intent, call_messages, avg_overall_response_time, 
                 avg_normal_response_time, avg_time_first_chunk_generation, total_time_first_chunk_generation,
                 total_output_token, total_input_token, avg_output_token, avg_input_token,total_web_response_time,
                 avg_web_response_time, total_perplexity_queries, total_function_call_failure,
                 gpt_failure_counts, total_overall_response_time, total_normal_response_time,language, country="", operator="", country_code=""):
        self.language = language
        self.gpt_failure_counts = gpt_failure_counts
        self.total_overall_response_time = total_overall_response_time
        self.total_normal_response_time = total_normal_response_time
        self.call_id = call_id
        self.assistant_id = assistant_id
        self.assistant_name = assistant_name
        self.call_start_time = call_start_time
        self.call_end_time = call_end_time
        self.call_duration = call_duration
        self.call_status = call_status
        self.call_type = call_type
        self.user_id = user_id
        self.question_count = question_count
        self.answer_count = answer_count
        self.tools_used = tools_used
        self.rag_tool_use = rag_tool_use
        self.satisfaction_score = satisfaction_score
        self.sentiment = sentiment
        self.emotions = emotions
        self.intent = intent
        self.call_messages = call_messages
        self.avg_overall_response_time = avg_overall_response_time
        self.avg_normal_response_time = avg_normal_response_time
        self.avg_time_first_chunk_generation = avg_time_first_chunk_generation
        self.total_time_first_chunk_generation = total_time_first_chunk_generation
        self.total_input_token = total_input_token
        self.total_output_token = total_output_token
        self.avg_input_token = avg_input_token
        self.avg_output_token = avg_output_token
        self.total_web_response_time = total_web_response_time
        self.avg_web_response_time = avg_web_response_time
        self.total_perplexity_queries = total_perplexity_queries
        self.total_function_call_failure = total_function_call_failure
        self.country = country
        self.operator = operator
        self.country_code = country_code


def save_to_db(self, session):
        # Serialize the main CDR and call_messages to JSON format
        cdr_json = json.dumps(self.__dict__, default=str)
        call_message_json = json.dumps(self.call_messages, default=str)

        # Create a CDRTable instance with serialized data
        cdr_entry = CDRTable(
            callId=self.call_id,
            cdr=json.loads(cdr_json),
            callMessage=json.loads(call_message_json)
        )

        # Add and commit to the database
        session.add(cdr_entry)
        session.commit()
