from response.GenericResponse import GenericResponse
from models.database_models import User


class UidLoginResponse(GenericResponse):
    def __init__(self, status, status_code, message, data:User):
        super().__init__(status_code=status_code,status=status,message=message)
        self.data = data

    def __repr__(self):
        return f"status_code={self.status_code}, status={self.status},message={self.message}, data={self.data}"