from sqlalchemy import or_
from sqlalchemy.orm import Session
from sqlalchemy.sql import func
from models.database_models import LLMMapping


def get_llm_models(db: Session, language_id: str, avatar_id: str):
    return db.query(LLMMapping).filter(LLMMapping.status, or_(func.find_in_set(avatar_id, LLMMapping.assistant_ids) > 0,
                                                              LLMMapping.assistant_ids == "ALL"))
# todo Complete Repository for LLM API
