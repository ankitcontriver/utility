from repository.tools_repository import get_tools,toggle_tool_status, update_tool_description 
from response.showGenericResponse import GenericResponse
from response.ShowToolResponse import ToolListResponse,ToolResponseItem, shortToolInfo, UpdateToolResponse
import json
from config.database_config import SessionLocal
from logger.__init__ import get_logger
logger = get_logger(__name__)




def get_tools_by_assId_service(tenantId: str):
    try:
        logger.info(f"Fetching tools for tenantId: {tenantId}")
        tools = get_tools( tenantId)
        
        if tools and len(tools) > 0:
            tenant_tools = [
                ToolResponseItem(
                    id=tenant_tool.id, 
                    name=tenant_tool.name, 
                    description=tenant_tool.gptTool["function"]["description"],
                    createdBy=tenant_tool.createdBy, 
                    createdOn=tenant_tool.createdOn, 
                    updateBy=tenant_tool.updateBy, 
                    updateOn=tenant_tool.updateOn, 
                    status=tenant_tool.status,
                    state= tenant_tool.state,
                    defination=tenant_tool.gptTool
                )
                for tenant_tool in tools
            ]
            response = ToolListResponse(
                statusCode=200,
                status="Success", 
                message="Tools found for Tenant", 
                data=tenant_tools
            )
            logger.info(f"Tools fetched successfully for tenantId: {tenantId}")
        else:
            logger.info(f"No tools found for tenantId: {tenantId}")
            response = ToolListResponse(
                statusCode=201,
                status="Success", 
                message="No tools found for this Tenant", 
                data=[]
            )
    except Exception as e:
        logger.error(f"Exception occurred while fetching tools for tenantId: {tenantId} - {e}")
        response = ToolListResponse(
            statusCode=202, 
            status="Failed", 
            message="Failed to fetch tools for the tenant", 
            data=[]
        )
    finally:
        logger.info(f"Database connection closed for tenantId: {tenantId}")
        return response


def update_tool_status_service(tenantId: str, Id: int, userId: str):
    try:
        logger.info(f"Updating tool status for toolId: {Id}, tenantId: {tenantId}, userId: {userId}")
        tool = toggle_tool_status(Id, tenantId, userId)
        
        if tool is not None:
            tool_data = shortToolInfo(
                id=tool.id,
                name=tool.name,
                description=tool.gptTool["function"]["description"],
                status=tool.status
            )
            response = UpdateToolResponse(
                statusCode=200, 
                status="success", 
                message="Tool status updated successfully", 
                data=tool_data
            )
            logger.info(f"Tool status updated successfully for toolId: {Id}")
        else:
            logger.info(f"No tool found with toolId: {Id}")
            response = GenericResponse(
                statusCode=301, 
                status="success", 
                message="No tool found with such properties"
            )
    except Exception as e:
        logger.error(f"Exception occurred while updating tool status for toolId: {Id} - {e}")
        response = GenericResponse(
            statusCode=302, 
            status="Failed", 
            message="Error updating the tool status"
        )
    finally:
        logger.info(f"Database connection closed for tenantId: {tenantId}")
        return response


def update_tool_description_service(tenantId: str, Id: int, description: str, userId: str):
    try:
        logger.info(f"Updating tool description for toolId: {Id}, tenantId: {tenantId}, userId: {userId}")
        tool = update_tool_description(tenantId, Id, description, userId)
        
        if tool is not None:
            tool_data = shortToolInfo(
                id=tool.id,
                name=tool.name,
                description=tool.gptTool["function"]["description"],
                status=tool.status
            )
            response = UpdateToolResponse(
                statusCode=400, 
                status="success", 
                message="Tool description updated successfully", 
                data=tool_data
            )
            logger.info(f"Tool description updated successfully for toolId: {Id}")
        else:
            logger.info(f"No tool found with toolId: {Id}")
            response = GenericResponse(
                statusCode=401, 
                status="success", 
                message="No tool found with such properties"
            )
    except Exception as e:
        logger.error(f"Exception occurred while updating tool description for toolId: {Id} - {e}")
        response = GenericResponse(
            statusCode=402, 
            status="Failed", 
            message="Error updating the tool description"
        )
    finally:
        logger.info(f"Database connection closed for tenantId: {tenantId}")
        return response