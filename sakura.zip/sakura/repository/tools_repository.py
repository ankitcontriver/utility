import json
from datetime import datetime

from dotenv import load_dotenv
from fastapi import HTTPException
from sqlalchemy import desc

from config.database_config import SessionLocal
from logger.__init__ import get_logger
from models.database_models import Tool

# Load the database URL from .env
load_dotenv()
logger = get_logger(__name__)


def get_tools(tenantId: int):
    db = SessionLocal()
    try:
        logger.info(f"Fetching tools for tenantId: {tenantId}")
        tools = db.query(Tool).filter(Tool.tenantId == tenantId).order_by(desc(Tool.updateOn)).all()

        if not tools:
            logger.warning(f"No tools found for tenantId: {tenantId}")
            raise HTTPException(status_code=404, detail="No tools found for this tenant.")

        logger.info(f"Found {len(tools)} tools for tenantId: {tenantId}")
        return tools
    except HTTPException as e:
        logger.error(f"HTTPException: {e.detail}", exc_info=True)
        return []
    except Exception as e:
        logger.error(f"An error occurred while fetching tools for tenantId: {tenantId} - {e}", exc_info=True)
        return []
    finally:
        db.close()


def toggle_tool_status(id: int, tenantId: int, updateBy: str):
    db = SessionLocal()
    try:
        # Query the tool by id and tenantId
        tool = db.query(Tool).filter_by(id=id, tenantId=tenantId).first()

        if tool:
            # Toggle the status
            tool.status = not tool.status

            # Update the updateBy and updateOn fields
            tool.updateBy = updateBy
            tool.updateOn = datetime.utcnow()

            # Commit the changes to the database
            db.commit()
            logger.info(f"Tool status updated successfully. New status: {tool.status}")
            tool = db.query(Tool).filter_by(id=id).first()
            return tool
        else:
            logger.warning(f"No tool found with id={id} and tenantId={tenantId}.")
            return []

    except Exception as e:
        db.rollback()  # Rollback the session in case of an error
        logger.error(f"Error occurred while updating tool status: {e}", exc_info=True)
        return []
    finally:
        db.close()


def update_tool_description(tenantId: int, id: int, description: str, userId: str):
    db = SessionLocal()
    try:
        tool = db.query(Tool).filter_by(id=id, tenantId=tenantId).first()
        if tool:
            try:
                # Attempt to load the current description as JSON
                current_description = tool.gptTool
            except json.JSONDecodeError as json_error:
                # Handle cases where the current description is not valid JSON
                logger.error(f"Invalid JSON in the current description: {json_error}", exc_info=True)
                current_description = {}

            # Update the function description within the JSON structure
            current_description["function"]["description"] = description

            # Save the updated description back as a JSON string
            tool.gptTool = json.dumps(current_description)

            # Update the user who made the change and the timestamp
            tool.updateBy = userId
            tool.updateOn = datetime.utcnow()

            # Commit the changes to the database
            db.commit()
            logger.info(f"Description updated for tool with id: {id} and tenantId: {tenantId}")
            return tool
        else:
            logger.warning("No tool found with the provided parameters.")
            return []
    except Exception as e:
        # Rollback in case of any errors
        db.rollback()
        logger.error(f"Error occurred while updating tool description: {e}", exc_info=True)
        return []
    finally:
        db.close()


def get_tools_by_ids(ids):
    db = SessionLocal()
    try:
        # Check if `ids` is a list; if not, assume it's a comma-separated string
        if isinstance(ids, str):
            # Convert the input string to a list of integers
            ids_list = [int(id.strip()) for id in ids.split(',')]
        elif isinstance(ids, list):
            # Assume it's already a list of strings or integers
            ids_list = [int(id) for id in ids]
        else:
            logger.error(f"Unexpected type for `ids`: {type(ids)}. Expected str or list.", exc_info=True)
            return []

        logger.info(f"Fetching tools for ids: {ids_list}")

        # Query the database to retrieve tools with matching ids
        tools = db.query(Tool).filter(Tool.id.in_(ids_list)).all()

        if not tools:
            logger.warning(f"No tools found for ids: {ids_list}")
            raise HTTPException(status_code=404, detail="No tools found for the provided IDs.")

        logger.info(f"Retrieved {len(tools)} tools for ids: {ids_list}.")
        return tools

    except ValueError as e:
        logger.error(f"Error parsing ids: {ids} - {e}", exc_info=True)
        return []
    except HTTPException as e:
        logger.error(f"HTTPException: {e.detail}", exc_info=True)
        return []
    except Exception as e:
        logger.error(f"An error occurred while retrieving tools for ids: {ids} - {e}", exc_info=True)
        return []
    finally:
        db.close()


def get_all_tools():
    try:
        session = SessionLocal()
        tools = session.query(Tool).all()
        result = []

        for tool in tools:
            tool_id = tool.id
            tool_name = tool.name  # updated attribute to match the schema
            tool_description = tool.gptTool # parse the JSON string

            # Safely extract values from the parsed description
            function_description = tool_description.get('function', {}).get('description', 'No description available')
            required_params = tool_description.get('function', {}).get('parameters', {}).get('required', [])

            result.append({
                "id": tool_id,
                "name": tool_name,
                "description": function_description,
                "required": required_params
            })

        return result

    except Exception as e:
        logger.error(f"Error occurred in get_all_tools function: {e}", exc_info=True)
        return []
