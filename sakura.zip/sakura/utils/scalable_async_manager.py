"""
Scalable AsyncIO Manager for Heavy Load Scenarios
Provides multiple event loops with load balancing for high-concurrency Redis operations
"""
import asyncio
import threading
import hashlib
from typing import Optional, List
from concurrent.futures import ThreadPoolExecutor
from logger import get_logger
import weakref
import os
import time

logger = get_logger(__name__)

class ScalableAsyncManager:
    """Manages multiple event loops with load balancing for heavy load scenarios"""
    
    def __init__(self, num_loops: int = None, max_workers_per_loop: int = None):
        # Read from environment variables with enhanced defaults for high performance
        cpu_count = os.cpu_count() or 4
        default_loops = max(24, min(cpu_count * 6, 48))  # 24-48 loops for Redis burst handling
        default_workers = 6  # Fewer workers per loop, more loops for better Redis concurrency
        
        self.num_loops = num_loops or int(os.getenv('ASYNC_NUM_LOOPS', default_loops))
        self.max_workers_per_loop = max_workers_per_loop or int(os.getenv('ASYNC_MAX_WORKERS_PER_LOOP', default_workers))
        
        # Configurable async operation timeout (in seconds)
        self.default_timeout = float(os.getenv('ASYNC_OPERATION_TIMEOUT', '10.0'))
        
        self.loop_managers: List[SingleLoopManager] = []
        self.shutdown_event = threading.Event()
        # PERFORMANCE FIX: Lock-free stats using threading.local() to eliminate contention
        self._local_stats = threading.local()
        self._global_stats = {
            'total_operations': 0,
            'failed_operations': 0,
            'avg_response_time': 0.0,
            'active_operations': 0,
            'load_balanced_routes': 0,
            'hash_affinity_routes': 0
        }
        self._stats_aggregation_lock = threading.Lock()  # Only used for periodic aggregation
        
        total_workers = self.num_loops * self.max_workers_per_loop
        logger.info(f"Initializing ScalableAsyncManager:")
        logger.info(f"   • Event loops: {self.num_loops}")
        logger.info(f"   • Workers per loop: {self.max_workers_per_loop}")  
        logger.info(f"   • Total async workers: {total_workers}")
        logger.info(f"   • Target capacity: ~{total_workers * 2} concurrent calls")
        
        if total_workers < 50:
            logger.warning(f"Low worker count ({total_workers}) - may cause bottlenecks under high load")
        elif total_workers > 200:
            logger.info(f"High worker count ({total_workers}) - optimized for extreme loads")
        else:
            logger.info(f"Optimal worker count ({total_workers}) for high-concurrency scenarios")
        
    def start(self):
        """Initialize manager and pre-create all AsyncLoop threads for immediate availability"""
        # PERFORMANCE FIX: Pre-create all loops to prevent Redis message processing delays
        self.loop_managers = [None] * self.num_loops
        
        logger.info(f"Creating {self.num_loops} AsyncLoop threads...")
        
        # Pre-create and start all loops
        created_count = 0
        for i in range(self.num_loops):
            try:
                manager = SingleLoopManager(
                    loop_id=i,
                    max_workers=self.max_workers_per_loop
                )
                manager.start()
                self.loop_managers[i] = manager
                created_count += 1
            except Exception as e:
                logger.error(f"Failed to create AsyncLoop-{i}: {e}", exc_info=True)
                # Continue creating other loops even if one fails
        
        logger.info(f"Successfully created {created_count}/{self.num_loops} AsyncLoop threads")
        
        # Start stats monitoring
        self._start_stats_monitor()
        
        active_loops = sum(1 for manager in self.loop_managers if manager and manager.is_running())
        logger.info(f"ScalableAsyncManager initialized with {active_loops}/{self.num_loops} active loops (pre-created)")
        
        if active_loops < self.num_loops:
            logger.warning(f"Only {active_loops}/{self.num_loops} loops started successfully")
    
    def _hash_to_loop(self, key) -> int:
        """Distribute operations across loops using consistent hashing (fallback only)"""
        # PERFORMANCE FIX: Handle both string and integer keys
        key_str = str(key)
        return int(hashlib.md5(key_str.encode()).hexdigest(), 16) % self.num_loops
    
    def get_least_busy_loop(self) -> int:
        """Get the least busy loop (create if needed) based on load monitoring"""
        if not self.loop_managers:
            return 0
        
        # Get real-time stats from all loops
        loop_loads = []
        for i, manager in enumerate(self.loop_managers):
            if manager is None:
                # Uninitialized loop - lowest possible load (0.0)
                loop_loads.append((i, 0.0))
                continue
                
            if not manager.is_running():
                # Skip non-running loops
                continue
            
            stats = manager.get_stats()
            # Calculate load score: queue_size + (operations_count / 1000) for tie-breaking
            load_score = stats['queue_size'] + (stats['operations_count'] / 1000.0)
            loop_loads.append((i, load_score))
        
        if not loop_loads:
            # All loops are down, fallback to first loop
            logger.warning("No available loops, creating first loop")
            return 0
        
        # Return index of loop with minimum load
        return min(loop_loads, key=lambda x: x[1])[0]
    
    def _ensure_loop_manager(self, loop_index: int) -> 'SingleLoopManager':
        """Get pre-created loop manager (fallback lazy creation for robustness)"""
        manager = self.loop_managers[loop_index]
        
        if manager is None:
            # Fallback lazy creation (should rarely happen with pre-creation)
            logger.warning(f"Fallback: Creating AsyncLoop-{loop_index} (should be pre-created)")
            manager = SingleLoopManager(
                loop_id=loop_index,
                max_workers=self.max_workers_per_loop
            )
            manager.start()
            self.loop_managers[loop_index] = manager
            logger.info(f"AsyncLoop-{loop_index} created via fallback")
        elif not manager.is_running():
            # Restart failed loop
            logger.warning(f"Restarting failed AsyncLoop-{loop_index}")
            try:
                manager.start()
            except Exception as e:
                logger.error(f"Failed to restart AsyncLoop-{loop_index}: {e}", exc_info=True)
                # Create new manager as last resort
                manager = SingleLoopManager(
                    loop_id=loop_index,
                    max_workers=self.max_workers_per_loop
                )
                manager.start()
                self.loop_managers[loop_index] = manager
        
        return manager
    
    def _get_optimal_loop_fast(self, key: str = None) -> int:
        """Ultra-fast loop selection with proper key-based load balancing"""
        if key:
            # Hash-based distribution using the provided key (e.g., call_id)
            # This ensures different keys go to different loops for proper load balancing
            import hashlib
            # PERFORMANCE FIX: Handle both string and integer keys
            key_str = str(key)
            hash_value = int(hashlib.md5(key_str.encode()).hexdigest(), 16)
            return hash_value % self.num_loops
        else:
            # Fall back to thread-based routing when no key provided
            import threading
            thread_id = threading.current_thread().ident or 0
            return (thread_id % self.num_loops)
    
    def run_coroutine_safe(self, coro, key: str = None, timeout: float = None):
        """Run coroutine with circuit breaker to prevent queue saturation and fast failure"""
        if timeout is None:
            timeout = self.default_timeout
        start_time = time.time()
        
        try:
            # CIRCUIT BREAKER: Prevent queue saturation under extreme load
            # Quick approximation check using local stats - no lock needed
            local_stats = self._get_local_stats()
            if local_stats['active_operations'] > self.max_workers_per_loop:  # Per-thread limit
                logger.warning(f"Thread queue near capacity ({local_stats['active_operations']} operations), rejecting new task")
                raise RuntimeError("AsyncLoop queue saturated - rejecting task to prevent deadlock")
            
            # Ultra-fast loop selection
            loop_index = self._get_optimal_loop_fast(key)
            
            # Lock-free stats tracking
            self._increment_stat('active_operations', 1)
            self._increment_stat('total_operations', 1)
            
            # PERFORMANCE FIX: Circuit breaker pattern
            failure_rate = self._get_recent_failure_rate()
            if failure_rate > 0.5:  # If >50% of recent operations failed
                self._increment_stat('circuit_breaker_trips', 1)
                self._increment_stat('active_operations', -1)
                logger.warning(f"Circuit breaker triggered - failure rate {failure_rate:.2f}, rejecting operation")
                raise RuntimeError("Circuit breaker open - too many recent failures")
            
            # Ensure the manager exists (lazy creation)
            manager = self._ensure_loop_manager(loop_index)
            
            result = manager.run_coroutine_safe(coro, timeout)
            
            # Lock-free stats cleanup
            self._increment_stat('active_operations', -1)
            self._increment_stat('successful_operations', 1)
            
            return result
            
        except Exception as e:
            # Lock-free error stats
            self._increment_stat('active_operations', -1)
            self._increment_stat('failed_operations', 1)
            if "queue saturated" not in str(e):
                logger.error(f"Error in scalable async operation: {e}", exc_info=True)
            raise
    
    def _start_stats_monitor(self):
        """Start background stats monitoring"""
        def monitor_loop():
            while not self.shutdown_event.is_set():
                try:
                    time.sleep(60)  # Log stats every minute
                    
                    # Get aggregated stats (no locking on main path)
                    stats = self.get_stats()['global']
                    
                    # Only get stats from created loop managers
                    loop_stats = [m.get_stats() for m in self.loop_managers if m is not None]
                    total_queue_size = sum(s['queue_size'] for s in loop_stats)
                    
                    # Calculate routing percentages
                    total_routes = stats['load_balanced_routes'] + stats['hash_affinity_routes']
                    load_balanced_pct = (stats['load_balanced_routes'] / max(total_routes, 1)) * 100
                    hash_affinity_pct = (stats['hash_affinity_routes'] / max(total_routes, 1)) * 100
                    
                    logger.info(f"AsyncManager Stats - Total Ops: {stats['total_operations']}, "
                              f"Active: {stats['active_operations']}, Failed: {stats['failed_operations']}, "
                              f"Avg Response: {stats['avg_response_time']:.3f}s, Queue Size: {total_queue_size}, "
                              f"Load Balanced: {load_balanced_pct:.1f}%, Hash Affinity: {hash_affinity_pct:.1f}%")
                              
                except Exception as e:
                    logger.error(f"Error in stats monitor: {e}")
        
        monitor_thread = threading.Thread(target=monitor_loop, daemon=True, name="AsyncStatsMonitor")
        monitor_thread.start()
        
    def _get_local_stats(self):
        """Get thread-local stats, initialize if needed"""
        if not hasattr(self._local_stats, 'counters'):
            self._local_stats.counters = {
                'total_operations': 0,
                'failed_operations': 0,
                'active_operations': 0,
                'successful_operations': 0,  # Added missing stat
                'circuit_breaker_trips': 0,  # Added missing stat
                'load_balanced_routes': 0,
                'hash_affinity_routes': 0
            }
        return self._local_stats.counters
    
    def _increment_stat(self, stat_name: str, delta: int = 1):
        """Thread-local stat increment - no locking needed"""
        local_stats = self._get_local_stats()
        local_stats[stat_name] += delta
    
    def _get_recent_failure_rate(self) -> float:
        """Calculate recent failure rate for circuit breaker"""
        try:
            local_stats = self._get_local_stats()
            recent_successful = local_stats.get('successful_operations', 0) 
            recent_failed = local_stats.get('failed_operations', 0)
            recent_total = recent_successful + recent_failed
            
            if recent_total == 0:
                return 0.0
            
            # Only consider if we have meaningful sample size
            if recent_total < 10:
                return 0.0
                
            failure_rate = recent_failed / recent_total
            
            # Reset counters periodically to focus on recent performance
            if recent_total > 1000:
                local_stats['successful_operations'] = int(recent_successful * 0.1)
                local_stats['failed_operations'] = int(recent_failed * 0.1)
                
            return failure_rate
            
        except Exception:
            return 0.0  # Safe default
    
    def _aggregate_stats(self):
        """Aggregate thread-local stats into global stats (called periodically)"""
        # This method is called only from the stats monitor thread, so minimal contention
        pass  # Local stats are read during get_stats() call
    
    def get_stats(self) -> dict:
        """Get comprehensive statistics by aggregating thread-local stats"""
        # Aggregate current thread's local stats
        local_stats = self._get_local_stats()
        
        # Create aggregated global stats (this is an approximation since we can't
        # access other threads' local stats without complex tracking)
        global_stats = {
            'total_operations': local_stats.get('total_operations', 0),
            'failed_operations': local_stats.get('failed_operations', 0),
            'avg_response_time': 0.0,
            'active_operations': local_stats.get('active_operations', 0),
            'load_balanced_routes': local_stats.get('load_balanced_routes', 0),
            'hash_affinity_routes': local_stats.get('hash_affinity_routes', 0)
        }
        
        # Only get stats from created loop managers
        loop_stats = [m.get_stats() for m in self.loop_managers if m is not None]
        
        return {
            'global': global_stats,
            'loops': loop_stats,
            'total_loops': len([m for m in self.loop_managers if m is not None]),
            'created_loops': len(loop_stats),
            'max_loops': len(self.loop_managers),
            'total_queue_size': sum(s['queue_size'] for s in loop_stats)
        }
    
    def shutdown(self):
        """Shutdown all event loop managers"""
        self.shutdown_event.set()
        
        # Shutdown all created loop managers (skip None entries)
        for manager in self.loop_managers:
            if manager is not None:
                try:
                    manager.shutdown()
                except Exception as e:
                    logger.error(f"Error shutting down loop manager: {e}")
        
        logger.info("ScalableAsyncManager shutdown completed")

class SingleLoopManager:
    """Manages a single event loop with monitoring"""
    
    def __init__(self, loop_id: int, max_workers: int = None):
        max_workers = max_workers or int(os.getenv('ASYNC_MAX_WORKERS_PER_LOOP', 10))
        self.loop_id = loop_id
        self.max_workers = max_workers
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._loop_thread: Optional[threading.Thread] = None
        self._shutdown_event = threading.Event()
        self._loop_ready = threading.Event()
        self._lock = threading.Lock()
        
        # OPTIMIZED: Simplified stats to reduce lock contention
        self.operations_count = 0
        self._stats_lock = threading.Lock()
        
    def start(self):
        """Start the event loop"""
        with self._lock:
            if self._loop_thread is not None and self._loop_thread.is_alive():
                return
            
            self._shutdown_event.clear()
            self._loop_ready.clear()
            
            self._loop_thread = threading.Thread(
                target=self._run_loop,
                daemon=True,
                name=f"AsyncLoop-{self.loop_id}"
            )
            self._loop_thread.start()
            
            if not self._loop_ready.wait(timeout=10.0):
                raise RuntimeError(f"Loop {self.loop_id} failed to start within 10 seconds")
    
    def _run_loop(self):
        """Run the event loop"""
        try:
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            
            # Configure loop for heavy load
            if hasattr(self._loop, 'set_debug'):
                self._loop.set_debug(False)  # Disable debug mode for performance
            
            self._loop_ready.set()
            logger.debug(f"AsyncLoop-{self.loop_id} started successfully")
            
            self._loop.run_until_complete(self._wait_for_shutdown())
            
        except Exception as e:
            logger.error(f"Error in AsyncLoop-{self.loop_id}: {e}", exc_info=True)
        finally:
            if self._loop and not self._loop.is_closed():
                self._loop.close()
            logger.info(f"AsyncLoop-{self.loop_id} stopped")
    
    async def _wait_for_shutdown(self):
        """Wait for shutdown signal"""
        while not self._shutdown_event.is_set():
            await asyncio.sleep(0.1)
    
    def run_coroutine_safe(self, coro, timeout: float = None):
        """Run coroutine safely on this loop with circuit breaker and fast failure"""
        if not self.is_running():
            raise RuntimeError(f"Loop {self.loop_id} is not running")
        
        if timeout is None:
            timeout = float(os.getenv('ASYNC_OPERATION_TIMEOUT', '10.0'))
        
        # PERFORMANCE FIX: Configurable timeout from ASYNC_OPERATION_TIMEOUT env var (default 10s)
        # Redis operations should complete in <5s, configurable timeout allows for LLM complexity tuning
        try:
            future = asyncio.run_coroutine_threadsafe(coro, self._loop)
            result = future.result(timeout=timeout)
            
            # Single lock acquisition for all stats updates
            with self._stats_lock:
                self.operations_count += 1
            
            return result
            
        except asyncio.TimeoutError:
            # CRITICAL FIX: Fast failure instead of 30s hang
            logger.warning(f"Coroutine timed out on loop {self.loop_id} after {timeout}s - failing fast to prevent cascade")
            future.cancel()
            raise
        except Exception as e:
            logger.error(f"Error running coroutine on loop {self.loop_id}: {e}")
            raise
    
    def is_running(self) -> bool:
        """Check if loop is running"""
        return (
            self._loop is not None 
            and not self._loop.is_closed() 
            and self._loop_thread is not None 
            and self._loop_thread.is_alive()
        )
    
    def get_stats(self) -> dict:
        """Get loop statistics with minimal locking"""
        with self._stats_lock:
            return {
                'loop_id': self.loop_id,
                'operations_count': self.operations_count,
                'queue_size': 0,  # Simplified to reduce lock contention
                'max_queue_size': 0,  # Simplified to reduce lock contention
                'is_running': self.is_running()
            }
    
    def shutdown(self):
        """Shutdown the loop"""
        with self._lock:
            self._shutdown_event.set()
            
            if self._loop_thread and self._loop_thread.is_alive():
                self._loop_thread.join(timeout=10.0)

# Global async manager instance (scalable by default)
_async_manager = ScalableAsyncManager()

def get_async_manager() -> ScalableAsyncManager:
    """Get the global async manager instance (scalable implementation)"""
    return _async_manager

def get_scalable_async_manager() -> ScalableAsyncManager:
    """Get the global async manager instance (alias for compatibility)"""
    return _async_manager

def run_coroutine_safe(coro, key: str = None, timeout: float = None):
    """Run coroutine safely with load balancing (scalable implementation) - configurable timeout"""
    return _async_manager.run_coroutine_safe(coro, key=key, timeout=timeout)

def run_coroutine_scalable(coro, key: str = None, timeout: float = None):
    """Run coroutine with load balancing (alias for compatibility) - configurable timeout"""
    return _async_manager.run_coroutine_safe(coro, key=key, timeout=timeout)

# Register cleanup
import atexit
atexit.register(_async_manager.shutdown)
