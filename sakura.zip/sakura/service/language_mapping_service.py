from config.voice_config import voices
from logger import get_logger
import traceback

logger = get_logger(__name__)


def get_voice_service(lang_code: str):
    logger.info(f"get_voice_service called for {lang_code}")
    try:
        lang_voice_mapping = voices.get(lang_code)
        if lang_voice_mapping is not None:
            return lang_voice_mapping['voice-codes']
        else:
            return voices['English']['voice-codes']

    except Exception as e:
        logger.error(f"Exception in get_voice_service: {e}",exc_info=True)
