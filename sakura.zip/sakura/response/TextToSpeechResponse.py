from response.GenericResponse import GenericResponse


class TextToSpeechResponse(GenericResponse):
    def __init__(self, status, status_code, message, data):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return f"TextToSpeechResponse(status={self.status}, status_code={self.status_code}, message={self.message}, data={self.data})"
