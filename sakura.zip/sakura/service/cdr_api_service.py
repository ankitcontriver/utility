"""
CDR API Push Service
Handles pushing CDR data to external Elastic API
"""
import os
import json
import base64
import ssl
import urllib3
import requests
from typing import Optional, Dict, Any
from cache.assistant_configuration_cache import get_assistant_details_by_role
from enums.call_enums import ServiceType
from logger import get_logger
from models.redis_models import UserCallCDR
from utils.function_call_util_functions import get_cdr_data
from utils.memory_cache_manager import get_user_call_record
from concurrent.futures import ThreadPoolExecutor
import threading

logger = get_logger(__name__)

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class CDRAPIPusher:
    """Handles CDR data pushing to external API"""
    
    def __init__(self):
        self.api_url = os.getenv('API_URL')
        self.content_type_header = os.getenv('CONTENT_TYPE_HEADER', 'application/json')
        self.gui_topic_header = os.getenv('GUI_TOPIC_HEADER', 'cdr-push')
        self.push_cdr_enabled = os.getenv('PUSH_CDR', 'false').lower() == 'true'
        
        # Thread pool for async API calls
        self.executor = ThreadPoolExecutor(max_workers=5, thread_name_prefix="CDR-API")
        
        # Disable SSL verification
        self._disable_ssl_verification()
        
        logger.info(f"CDRAPIPusher initialized - Push enabled: {self.push_cdr_enabled}")
    
    def _disable_ssl_verification(self):
        """Disable SSL verification for API calls"""
        try:
            # Create unverified SSL context
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            # Apply to requests session
            requests.packages.urllib3.disable_warnings()
            
            logger.debug("SSL verification disabled for CDR API calls")
        except Exception as e:
            logger.error(f"Failed to disable SSL verification: {e}")
    
    def _encode_cdr_message(self, cdr_data: Dict[str, Any]) -> str:
        """
        Serialize CDR data to JSON and Base64 encode
        
        Args:
            cdr_data: CDR data dictionary
            
        Returns:
            Base64 encoded JSON string
        """
        try:
            # Convert to JSON string
            json_message = json.dumps(cdr_data, default=str, ensure_ascii=False)
            
            # Base64 encode
            encoded_message = base64.b64encode(json_message.encode('utf-8')).decode('utf-8')
            
            logger.debug(f"CDR message encoded - Original size: {len(json_message)}, Encoded size: {len(encoded_message)}")
            return encoded_message
            
        except Exception as e:
            logger.error(f"Failed to encode CDR message: {e}")
            raise
    
    def _push_cdr_to_api(self, call_id: str, encoded_message: str) -> bool:
        """
        Push CDR data to external API
        
        Args:
            call_id: Call ID for logging
            encoded_message: Base64 encoded CDR data
            
        Returns:
            bool: Success status
        """
        try:
            headers = {
                'guiTopic': self.gui_topic_header,
                'Content-Type': self.content_type_header
            }
            
            logger.info(f"Pushing CDR to API for call_id: {call_id}")
            
            response = requests.post(
                self.api_url,
                data=encoded_message,
                headers=headers,
                timeout=30,
                verify=False  # Disable SSL verification
            )
            
            if response.status_code == 200:
                logger.info(f"Successfully pushed CDR to API for call_id: {call_id}, Response: {response.text}")
                return True
            else:
                logger.error(f"API call failed for call_id: {call_id}, Status: {response.status_code}, Response: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Exception while pushing CDR to API for call_id: {call_id}: {e}")
            return False
    
    def push_cdr_async(self, call_id: str, cdr_data: Optional[Dict[str, Any]] = None) -> None:
        """
        Push CDR data to API asynchronously in background thread
        
        Args:
            call_id: Call ID
            cdr_data: CDR data (if None, will retrieve from Redis)
        """
        if not self.push_cdr_enabled:
            logger.debug(f"CDR push disabled, skipping for call_id: {call_id}")
            return
        
        if not self.api_url:
            logger.error("API_URL not configured, cannot push CDR")
            return
        
        def _background_push():
            """Background task that runs in separate thread"""
            try:
                logger.info(f"Starting background CDR push for call_id: {call_id}")
                
                # Get CDR data if not provided
                if cdr_data is None:
                    cdr_data = get_cdr_data(call_id)
                    if not cdr_data:
                        logger.warning(f"No CDR data found for call_id: {call_id}")
                        return
                
                # Encode message
                encoded_message = self._encode_cdr_message(cdr_data)
                
                # Push to API
                success = self._push_cdr_to_api(call_id, encoded_message)
                
                if success:
                    logger.info(f"CDR successfully pushed to API for call_id: {call_id}")
                else:
                    logger.error(f"Failed to push CDR to API for call_id: {call_id}")
                    
            except Exception as e:
                logger.error(f"Error in background CDR push for call_id: {call_id}: {e}")
            finally:
                logger.debug(f"Background CDR push completed for call_id: {call_id}")
        
        # Submit to thread pool - this is truly async and non-blocking
        try:
            future = self.executor.submit(_background_push)
            logger.debug(f"CDR push task submitted to background thread for call_id: {call_id}")
            
            # Optional: Add callback for completion tracking (non-blocking)
            def _completion_callback(fut):
                try:
                    fut.result()  # This will raise any exception that occurred
                except Exception as e:
                    logger.error(f"Background CDR push failed for call_id: {call_id}: {e}")
            
            future.add_done_callback(_completion_callback)
            
        except Exception as e:
            logger.error(f"Failed to submit CDR push task for call_id: {call_id}: {e}")
    
    def create_cdr_from_params(self, country: str, operator: str, call_status: str) -> Dict[str, Any]:
        """
        Create CDR with default values from API parameters
        
        Args:
            country: Country code
            operator: Operator name
            call_status: Call status
            
        Returns:
            CDR data dictionary
        """
        try:
            # Generate a unique call ID
            import time
            
            # Get country code from assistant configuration
            country_code = country  # Default fallback
            try:
                assistant_config = get_assistant_details_by_role(ServiceType.PA.value, country, operator)
                if assistant_config and assistant_config.get('country_code'):
                    country_code = assistant_config.get('country_code')
            except Exception as e:
                logger.warning(f"Could not get country_code from assistant config: {e}, using fallback: {country}")
            
            # Create CDR with default values
            cdr_data = {
                'call_id': None,
                'assistant_id': 0,
                'assistant_name': 'Personal_Assistant',
                'call_start_time': int(time.time()),
                'call_end_time': int(time.time()),
                'call_duration': 0,
                'call_status': call_status,
                'call_type': None,
                'user_id': None,
                'question_count': 0,
                'answer_count': 0,
                'tools_used': [],
                'rag_tool_use': 0,
                'satisfaction_score': 0.0,
                'sentiment': 'neutral',
                'emotions': [],
                'intent': 'api_call',
                'call_messages': [],
                'avg_overall_response_time': 0.0,
                'avg_normal_response_time': 0.0,
                'avg_time_first_chunk_generation': 0.0,
                'total_time_first_chunk_generation': 0.0,
                'total_output_token': 0,
                'total_input_token': 0,
                'avg_output_token': 0.0,
                'avg_input_token': 0.0,
                'total_web_response_time': 0.0,
                'avg_web_response_time': 0.0,
                'total_perplexity_queries': 0,
                'total_function_call_failure': 0,
                'gpt_failure_counts': 0,
                'total_overall_response_time': 0.0,
                'total_normal_response_time': 0.0,
                'language': None,
                'country': country,
                'operator': operator,
                'country_code': country_code
            }
            
            logger.info(f"Created CDR from API params - country: {country}, operator: {operator}, status: {call_status}")
            return cdr_data
            
        except Exception as e:
            logger.error(f"Failed to create CDR from params: {e}")
            raise
    
    def shutdown(self):
        """Shutdown the CDR API pusher"""
        try:
            self.executor.shutdown(wait=True)
            logger.info("CDRAPIPusher shutdown completed")
        except Exception as e:
            logger.error(f"Error during CDRAPIPusher shutdown: {e}")

# Global instance
_cdr_api_pusher = None

def get_cdr_api_pusher() -> CDRAPIPusher:
    """Get global CDR API pusher instance"""
    global _cdr_api_pusher
    if _cdr_api_pusher is None:
        _cdr_api_pusher = CDRAPIPusher()
    return _cdr_api_pusher
