from sqlalchemy import text
from typing import Optional
from config.database_config import SessionLocal
from logger.__init__ import get_logger

logger = get_logger(__name__)


def get_client_config_id(short_code: str, tenant_id: Optional[str] = None) -> int:
    """
    Get client configuration ID based on short_code and optionally tenant_id.
    
    Args:
        short_code (str): Short code of the client
        tenant_id (Optional[str]): Tenant ID, optional. If not provided, only filter by short_code
        
    Returns:
        int: ID of the matching client configuration or None if not found
    """
    try:
        with SessionLocal() as session:
            # Build query based on whether tenant_id is provided
            if tenant_id:
                query = text("""
                    SELECT id 
                    FROM client_config 
                    WHERE short_code = :short_code 
                    AND tenant_id = :tenant_id
                """)
                params = {
                    "short_code": short_code,
                    "tenant_id": tenant_id
                }
            else:
                query = text("""
                    SELECT id 
                    FROM client_config 
                    WHERE short_code = :short_code
                """)
                params = {
                    "short_code": short_code
                }
            
            result = session.execute(query, params).first()
            return result[0] if result else None
            
    except Exception as e:
        logger.error(f"Error fetching client config ID: {str(e)}")
        return None

def get_assistant_id_by_client_config(client_config_id: int) -> int:
    """
    Get assistant ID based on client configuration ID.
    
    Args:
        client_config_id (int): ID from client_config table
        
    Returns:
        int: Assistant ID mapped to the client config or None if not found
    """
    try:
        with SessionLocal() as session:
            # Using text() for direct SQL query
            query = text("""
                SELECT assistant_id 
                FROM conversation_metadata 
                WHERE client_config_id = :client_config_id
            """)
            
            result = session.execute(
                query, 
                {
                    "client_config_id": client_config_id
                }
            ).first()
            
            return result[0] if result else None
            
    except Exception as e:
        logger.error(f"Error fetching assistant ID: {str(e)}")
        return None 