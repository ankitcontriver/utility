from config.database_config import SessionLocal
from logger import get_logger
from repository.asr_repository import get_asr_model as get_asr_model_repository, \
    get_asr_language as get_asr_language_repository
from response.GetASRLanguageResponse import GetASRLanguageResponse, GetASRLanguage
from response.GetASRModelResponse import GetASRModel, GetASRModelResponse

logger = get_logger(__name__)


def get_asr_model(language_id: str):
    logger.info(f"get_asr_model request language_id : {language_id}")
    db = SessionLocal()
    try:
        asr_models = get_asr_model_repository(db, language_id)
        logger.info(f"asr_models : {asr_models}")
        if asr_models is None or len(asr_models) == 0:
            response = GetASRModelResponse(status="Failed", status_code=400, message="ASR Model List not found",
                                           data=[])
        else:
            seen_models = set()
            unique_models = []

            for model in asr_models:
                if model.asr_name not in seen_models:
                    seen_models.add(model.asr_name)
                    unique_models.append(GetASRModel(
                        language_id=model.language_id,
                        asr_model=model.asr_name
                    ))

            response = GetASRModelResponse(
                status="Success",
                status_code=200,
                message="ASR Model List retrieved successfully",
                data=unique_models
            )

    except Exception as e:
        logger.error(f"Error in get_asr_model service : {e}")
        response = GetASRModelResponse(status="Failed", status_code=500, message="Internal Server Error", data=[])
    finally:
        db.close()
    logger.info(f"get_asr_model response : {response}")
    return response


def get_asr_language(country: str, language_id: str, asr_model: str):
    logger.info(f"get_asr_language request country : {country}, language_id : {language_id}, asr_model : {asr_model}")
    db = SessionLocal()
    try:
        asr_languages = get_asr_language_repository(db, language_id, country, asr_model)
        logger.info(f"asr_languages : {asr_languages}")
        if not asr_languages:
            response = GetASRLanguageResponse(
                status="Failed",
                status_code=400,
                message="ASR Language List not found",
                data=[]
            )
        else:

            # Initialize variables
            matched_languages = []
            other_languages = []

            # Separate languages into matched and unmatched lists
            for language in asr_languages:
                if language.country_name == country:
                    matched_languages.append(language)
                else:
                    other_languages.append(language)

            # Combine matched languages followed by unmatched languages
            sorted_languages = matched_languages + other_languages

            # Prepare the response data
            languages = [
                GetASRLanguage(
                    id=lang.id,
                    country_specific_language_id=lang.country_specific_language_id,
                    country_specific_language_name=lang.country_specific_language_name
                ) for lang in sorted_languages
            ]

            response = GetASRLanguageResponse(
                status="Success",
                status_code=200,
                message="ASR Language List retrieved successfully",
                data=languages
            )
    except Exception as e:
        logger.error(f"Error in get_asr_language service : {e}")
        response = GetASRLanguageResponse(status="Failed", status_code=500, message="Internal Server Error", data=[])
    finally:
        db.close()
    logger.info(f"get_asr_language response : {response}")
    return response
