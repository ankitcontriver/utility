"""
Redis Hash Optimizer for CDR Operations
Replaces large JSON string operations with efficient Redis hash operations
"""

import json
import time
from typing import Dict, Any, Optional
from logger import get_logger

logger = get_logger(__name__)

class RedisHashOptimizer:
    """
    Optimizes CDR operations using Redis hashes instead of large JSON strings
    
    Benefits:
    - Memory efficient: Redis hashes use less memory than JSON strings
    - Atomic updates: Can update individual fields without full object serialization
    - Better performance: Faster reads/writes for large objects
    """
    
    def __init__(self, redis_client):
        self.redis_client = redis_client
        
    def set_cdr_hash(self, call_id: str, cdr_data: Dict[str, Any], expiry_seconds: int = None) -> bool:
        """
        Store CDR data as Redis hash instead of JSON string
        
        Args:
            call_id: Call ID for the CDR
            cdr_data: CDR data dictionary 
            expiry_seconds: Expiration time in seconds
            
        Returns:
            bool: Success status
        """
        try:
            hash_key = f"{call_id}_cdr_hash"
            
            # Convert nested objects to JSON strings only for complex fields
            flattened_data = self._flatten_cdr_data(cdr_data)
            
            # Use Redis pipeline for atomic hash operations
            pipe = self.redis_client.pipeline()
            
            # Clear existing hash and set new data
            pipe.delete(hash_key)
            pipe.hset(hash_key, mapping=flattened_data)
            
            if expiry_seconds:
                pipe.expire(hash_key, expiry_seconds)
                
            pipe.execute()
            
            logger.debug(f"CDR hash stored for call_id: {call_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to store CDR hash for {call_id}: {e}")
            return False
    
    def get_cdr_hash(self, call_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve CDR data from Redis hash
        
        Args:
            call_id: Call ID for the CDR
            
        Returns:
            Dict with CDR data or None if not found
        """
        try:
            hash_key = f"{call_id}_cdr_hash"
            hash_data = self.redis_client.hgetall(hash_key)
            
            if not hash_data:
                return None
                
            # Reconstruct the original CDR structure
            return self._reconstruct_cdr_data(hash_data)
            
        except Exception as e:
            logger.error(f"Failed to retrieve CDR hash for {call_id}: {e}")
            return None
    
    def update_cdr_field(self, call_id: str, field: str, value: Any) -> bool:
        """
        Update a single CDR field atomically (much faster than full object update)
        
        Args:
            call_id: Call ID for the CDR
            field: Field name to update
            value: New value for the field
            
        Returns:
            bool: Success status
        """
        try:
            hash_key = f"{call_id}_cdr_hash"
            
            # Convert complex values to JSON
            if isinstance(value, (dict, list)):
                value = json.dumps(value)
            elif value is None:
                value = ""
            else:
                value = str(value)
                
            result = self.redis_client.hset(hash_key, field, value)
            logger.debug(f"Updated CDR field {field} for call_id: {call_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to update CDR field {field} for {call_id}: {e}")
            return False
    
    def increment_cdr_counter(self, call_id: str, field: str, increment: int = 1) -> Optional[int]:
        """
        Atomically increment a CDR counter field
        
        Args:
            call_id: Call ID for the CDR
            field: Counter field name
            increment: Amount to increment by
            
        Returns:
            New counter value or None if failed
        """
        try:
            hash_key = f"{call_id}_cdr_hash"
            new_value = self.redis_client.hincrby(hash_key, field, increment)
            logger.debug(f"Incremented CDR counter {field} for call_id: {call_id} to {new_value}")
            return new_value
            
        except Exception as e:
            logger.error(f"Failed to increment CDR counter {field} for {call_id}: {e}")
            return None
    
    def _flatten_cdr_data(self, cdr_data: Dict[str, Any]) -> Dict[str, str]:
        """Convert CDR data to flat string dictionary for Redis hash"""
        flattened = {}
        
        for key, value in cdr_data.items():
            if isinstance(value, (dict, list)):
                # Store complex objects as JSON
                flattened[key] = json.dumps(value)
            elif value is None:
                flattened[key] = ""
            else:
                flattened[key] = str(value)
                
        return flattened
    
    def _reconstruct_cdr_data(self, hash_data: Dict) -> Dict[str, Any]:
        """Reconstruct original CDR data structure from Redis hash"""
        reconstructed = {}
        
        for key, value in hash_data.items():
            # Handle byte strings from Redis
            if isinstance(key, bytes):
                key = key.decode('utf-8')
            if isinstance(value, bytes):
                value = value.decode('utf-8')
                
            # Try to parse JSON for complex fields
            if key in ['call_messages', 'llmMessage'] or value.startswith('[') or value.startswith('{'):
                try:
                    reconstructed[key] = json.loads(value) if value else []
                except json.JSONDecodeError:
                    reconstructed[key] = value
            elif key in ['question_count', 'answer_count', 'tools_used', 'rag_tool_use', 
                        'gpt_failure_counts', 'total_input_token', 'total_output_token', 'total_perplexity_queries',
                        'total_function_call_failure']:
                # Convert integer fields
                reconstructed[key] = int(value) if value else 0
            elif key in ['total_overall_response_time', 'total_normal_response_time',
                        'avg_overall_response_time', 'avg_normal_response_time',
                        'total_time_first_chunk_generation', 'avg_time_first_chunk_generation',
                        'total_web_response_time', 'avg_web_response_time', 'avg_input_token', 'avg_output_token']:
                # Convert float fields  
                reconstructed[key] = float(value) if value else 0.0
            else:
                reconstructed[key] = value
                
        return reconstructed
