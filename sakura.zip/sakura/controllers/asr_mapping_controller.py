from fastapi import APIRouter

from service.asr_mapping_service import get_asr_language as get_asr_language_service
from service.asr_mapping_service import get_asr_model as get_asr_model_service
from logger import get_logger

router = APIRouter()


@router.get("/get_asr_model", tags=["ASR Mapping"])
def get_asr_model(language_id: str):
    logger.info(f"get_asr_model controller called for language_id: {language_id}")
    return get_asr_model_service(language_id)


@router.get("/get_asr_language", tags=["ASR Mapping"])
def get_asr_language(country: str, language_id: str, asr_model: str):
    logger.info(f"get_asr_language controller called for country: {country}, language_id: {language_id}, asr_model: {asr_model}")
    return get_asr_language_service(country, language_id, asr_model)
