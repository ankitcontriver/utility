"""
Redis Batch Operations Manager
Batches multiple Redis operations for improved performance and reduced network overhead
"""

import time
import threading
from typing import List, Dict, Any, Callable, Optional
from dataclasses import dataclass
from queue import Queue, Empty
from logger import get_logger

logger = get_logger(__name__)

@dataclass
class BatchOperation:
    """Represents a single Redis operation to be batched"""
    operation_type: str  # 'set', 'expire', 'hset', 'del', etc.
    key: str
    value: Any = None
    expiry: Optional[int] = None
    callback: Optional[Callable] = None
    timestamp: float = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()

class RedisBatchManager:
    """
    Manages batched Redis operations for improved performance
    
    Features:
    - Automatic batching of operations with configurable size/time limits
    - Pipeline execution for atomic batch operations
    - Background processing to avoid blocking main operations
    - Automatic fallback for failed batches
    """
    
    def __init__(self, redis_client, batch_size: int = 50, flush_interval: float = 0.1):
        """
        Initialize Redis batch manager
        
        Args:
            redis_client: Redis client instance
            batch_size: Maximum operations per batch
            flush_interval: Maximum time to wait before flushing batch (seconds)
        """
        self.redis_client = redis_client
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        
        self.operation_queue = Queue()
        self.current_batch = []
        self.last_flush_time = time.time()
        
        self.is_running = True
        self.batch_thread = threading.Thread(target=self._batch_processor, daemon=True)
        self.batch_thread.start()
        
        self.stats = {
            'total_operations': 0,
            'batches_processed': 0,
            'failed_operations': 0,
            'avg_batch_size': 0
        }
        
        logger.info(f"RedisBatchManager started - batch_size={batch_size}, flush_interval={flush_interval}s")
    
    def add_operation(self, operation_type: str, key: str, value: Any = None, 
                     expiry: Optional[int] = None, callback: Optional[Callable] = None):
        """
        Add an operation to the batch queue
        
        Args:
            operation_type: Type of Redis operation ('set', 'expire', 'hset', 'del')
            key: Redis key
            value: Value for the operation
            expiry: Expiration time in seconds
            callback: Optional callback function for operation result
        """
        try:
            operation = BatchOperation(
                operation_type=operation_type,
                key=key,
                value=value,
                expiry=expiry,
                callback=callback
            )
            
            self.operation_queue.put(operation, timeout=1)
            self.stats['total_operations'] += 1
            
        except Exception as e:
            logger.error(f"Failed to queue batch operation {operation_type} for key {key}: {e}")
            # Fallback: execute immediately
            self._execute_single_operation(operation_type, key, value, expiry)
    
    def set_with_expiry(self, key: str, value: Any, expiry: int):
        """Convenience method for set with expiry"""
        logger.debug(f"Batching set_with_expiry: {key} -> {value} (expires in {expiry}ms)")
        self.add_operation('set_with_expiry', key, value, expiry)
    
    def hash_set(self, key: str, field: str, value: Any):
        """Convenience method for hash set"""
        self.add_operation('hset', key, {'field': field, 'value': value})
    
    def delete_key(self, key: str):
        """Convenience method for delete"""
        self.add_operation('del', key)
    
    def increment_counter(self, key: str, field: str = None, increment: int = 1):
        """Convenience method for increment operations"""
        if field:
            self.add_operation('hincrby', key, {'field': field, 'increment': increment})
        else:
            self.add_operation('incr', key, increment)
    
    def force_flush(self):
        """Force immediate processing of current batch"""
        logger.debug("Force flush triggered")
        self.operation_queue.put('FLUSH_NOW')
    
    def get_stats(self) -> Dict[str, Any]:
        """Get batch processing statistics"""
        if self.stats['batches_processed'] > 0:
            self.stats['avg_batch_size'] = (
                self.stats['total_operations'] / self.stats['batches_processed']
            )
        return self.stats.copy()
    
    def shutdown(self):
        """Gracefully shutdown the batch manager"""
        self.is_running = False
        self.force_flush()
        self.batch_thread.join(timeout=5)
        logger.info("RedisBatchManager shutdown complete")
    
    def _batch_processor(self):
        """Background thread that processes batched operations"""
        while self.is_running:
            try:
                # Check if we should flush based on time or size
                current_time = time.time()
                should_flush = (
                    len(self.current_batch) >= self.batch_size or
                    (self.current_batch and 
                     current_time - self.last_flush_time >= self.flush_interval)
                )
                
                if should_flush:
                    self._flush_current_batch()
                    continue
                
                # Get next operation with timeout
                try:
                    operation = self.operation_queue.get(timeout=0.05)
                    
                    if operation == 'FLUSH_NOW':
                        logger.debug("Processing FLUSH_NOW command")
                        self._flush_current_batch()
                        continue
                    
                    self.current_batch.append(operation)
                    
                except Empty:
                    continue
                    
            except Exception as e:
                logger.error(f"Error in batch processor: {e}")
                time.sleep(0.1)
    
    def _flush_current_batch(self):
        """Execute all operations in current batch using Redis pipeline"""
        if not self.current_batch:
            return
        
        try:
            pipe = self.redis_client.pipeline()
            callbacks = []
            
            for operation in self.current_batch:
                self._add_operation_to_pipeline(pipe, operation)
                if operation.callback:
                    callbacks.append(operation.callback)
            
            # Execute all operations atomically
            results = pipe.execute()
            
            # Execute callbacks if any
            for callback in callbacks:
                try:
                    callback(True)
                except Exception as e:
                    logger.error(f"Batch operation callback failed: {e}")
            
            self.stats['batches_processed'] += 1
            batch_size = len(self.current_batch)
            
            logger.debug(f"Batch processed: {batch_size} operations")
            
        except Exception as e:
            logger.error(f"Batch execution failed: {e}")
            # Fallback: execute operations individually
            self._fallback_individual_execution()
            
        finally:
            self.current_batch = []
            self.last_flush_time = time.time()
    
    def _add_operation_to_pipeline(self, pipe, operation: BatchOperation):
        """Add a single operation to the Redis pipeline"""
        try:
            if operation.operation_type == 'set_with_expiry':
                # Use px for milliseconds instead of ex for seconds
                pipe.set(operation.key, operation.value, px=operation.expiry)
            elif operation.operation_type == 'set':
                pipe.set(operation.key, operation.value)
            elif operation.operation_type == 'expire':
                pipe.expire(operation.key, operation.expiry)
            elif operation.operation_type == 'pexpire':
                pipe.pexpire(operation.key, operation.expiry)
            elif operation.operation_type == 'hset':
                field = operation.value.get('field')
                value = operation.value.get('value')
                pipe.hset(operation.key, field, value)
            elif operation.operation_type == 'hincrby':
                field = operation.value.get('field')
                increment = operation.value.get('increment', 1)
                pipe.hincrby(operation.key, field, increment)
            elif operation.operation_type == 'del':
                pipe.delete(operation.key)
            elif operation.operation_type == 'incr':
                pipe.incr(operation.key, operation.value)
            else:
                logger.warning(f"Unknown operation type: {operation.operation_type}")
                
        except Exception as e:
            logger.error(f"Failed to add operation {operation.operation_type} to pipeline: {e}")
    
    def _fallback_individual_execution(self):
        """Execute operations individually if batch fails"""
        for operation in self.current_batch:
            try:
                self._execute_single_operation(
                    operation.operation_type,
                    operation.key,
                    operation.value,
                    operation.expiry
                )
                if operation.callback:
                    operation.callback(True)
            except Exception as e:
                logger.error(f"Individual fallback execution failed: {e}")
                self.stats['failed_operations'] += 1
                if operation.callback:
                    operation.callback(False)
    
    def _execute_single_operation(self, operation_type: str, key: str, 
                                 value: Any = None, expiry: Optional[int] = None):
        """Execute a single Redis operation directly"""
        if operation_type == 'set_with_expiry':
            # Use px for milliseconds instead of ex for seconds
            self.redis_client.set(key, value, px=expiry)
        elif operation_type == 'set':
            self.redis_client.set(key, value)
        elif operation_type == 'expire':
            self.redis_client.expire(key, expiry)
        elif operation_type == 'pexpire':
            self.redis_client.pexpire(key, expiry)
        elif operation_type == 'del':
            self.redis_client.delete(key)
        # Add other operations as needed
