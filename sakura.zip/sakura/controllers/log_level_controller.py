from fastapi import APIRouter, HTTPException, Query
import logging
from logger import get_logger, SECURE_LEVEL

router = APIRouter()
logger = get_logger(__name__)

@router.get("/changeLogLevel", tags=["Logging"])
def set_log_level(level: str = Query(..., description="Log level to set (DEBUG, INFO, SECURE, WARNING, ERROR)")):
    level = level.upper()
    valid_levels = ["DEBUG", "INFO", "SECURE", "WARNING", "ERROR"]
    if level not in valid_levels:
        logger.warning(f"Attempt to set invalid log level: {level}")
        raise HTTPException(status_code=400, detail="Invalid log level")
    
    old_level = logging.getLevelName(logging.getLogger().level)
    
    # Handle custom SECURE level
    if level == "SECURE":
        logging.getLogger().setLevel(SECURE_LEVEL)
    else:
        logging.getLogger().setLevel(getattr(logging, level))
    
    return {"message": f"Log level set to {level}", "old_level": old_level}