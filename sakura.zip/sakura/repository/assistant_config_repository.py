from sqlalchemy import or_, and_, asc
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from logger import get_logger



from models.database_models import AssistantConfiguration

logger = get_logger(__name__)

def update_assistant_config(db: Session, assistant_id: int, ivr_stt_array: str, path_finder_json: str):
    db.query(AssistantConfiguration).filter(
        AssistantConfiguration.assistant_id == assistant_id
    ).update(
        {
            "ivr_stt_array": ivr_stt_array,
            "path_finder_json": path_finder_json
        },
    synchronize_session=False
    )
    db.commit()



def get_assistant_config_from_db(db: Session, id_list: list, show_default: bool):
    return db.query(AssistantConfiguration).filter(
        or_(and_(AssistantConfiguration.assistant_id.in_(id_list), AssistantConfiguration.status == True),
            and_(show_default, AssistantConfiguration.user_specific == False, AssistantConfiguration.status))).order_by(asc(AssistantConfiguration.createdOn)).all()

def get_all_active_assistants(db: Session):
    """
    Fetch all active assistants.
    Raises exception on database error so retry mechanism can work.
    """
    try:
        result = db.query(AssistantConfiguration) \
            .filter(AssistantConfiguration.status == True) \
            .order_by(asc(AssistantConfiguration.createdOn)) \
            .all()
        return result
    except Exception as e:
        error_type = type(e).__name__
        logger.error(f"Database error while fetching active assistants: {error_type}: {e}")
        
        # Re-raise the exception so the retry mechanism can work
        raise

def get_assistant_details_by_id_from_db(session: Session, assistant_id: int):
    result = session.query(
        AssistantConfiguration.prompt,
        AssistantConfiguration.call_summary_prompt,
        AssistantConfiguration.opening_message,
        AssistantConfiguration.tts_style,
        AssistantConfiguration.company,
        AssistantConfiguration.age,
        AssistantConfiguration.name,
        AssistantConfiguration.tools_supported,
        AssistantConfiguration.claude_tools,
        AssistantConfiguration.country,
        AssistantConfiguration.operator,
        AssistantConfiguration.country_code,
        AssistantConfiguration.calendar_prompt,
        AssistantConfiguration.tier2_prompt
    ).filter_by(assistant_id=assistant_id).first()

    if result:
        return {
            "prompt": result.prompt,
            "call_summary_prompt": result.call_summary_prompt,
            "calendar_prompt":result.calendar_prompt,
            "opening_message": result.opening_message,
            "tts_style": result.tts_style,
            "company": result.company,
            "age": result.age,
            "name": result.name,
            "tools_supported": result.tools_supported,
            "claude_tools": result.claude_tools,
            "country": result.country,
            "operator": result.operator,
            "country_code":result.country_code,
            "tier2_prompt": result.tier2_prompt
        }
    return None
