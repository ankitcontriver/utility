import audioop
import base64
import io
import json
import os
import re
import logging
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests
from utils.alarm_utils import send_alarm, run_alarm_in_thread
from service.pa_tts_manager import get_tts_manager
from config.database_config import SessionLocal
from controllers.audio_controller import generate_audio_azure, generate_audio_google, generate_audio_eleven_labs, \
    generate_audio_whisper
from logger import get_logger
from repository.tts_repository import get_tts_language_mapping_by_voice_name

logger = get_logger(__name__)


def get_current_time_with_milliseconds():
    now = datetime.now()
    # Format the datetime to include milliseconds
    return now.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def transcribe_audio_whisper(base64_data):
    # Decode the base64 string
    audio_bytes = base64.b64decode(base64_data)

    # Create a byte stream from decoded bytes
    audio_stream = io.BytesIO(audio_bytes)

    url = 'http://3.6.186.47:49801/inference'

    files = {
        'file': ('audio.ogg', audio_stream),  # Assuming the audio format is OGG; adjust the file name accordingly
    }

    # Additional form data
    data = {
        'temperature': '0.0',
        'temperature_inc': '0.2',
        'response_format': 'json'
    }

    try:
        # Make the POST request
        response = requests.post(url, files=files, data=data)

        # After posting, close the stream
        audio_stream.close()
        response.raise_for_status()

        # Process the response
        json_response = response.json()
        transcription_text = json_response.get("text", "Transcription not available.")
        logger.info(f"json_response transcribe audio whisper -----> {json_response} ")

        unwanted_patterns = ['[BLANK_AUDIO]', '[INAUDIBLE]', '[silence]', '[tapping]', '[POPPING]']
        if any(pattern in transcription_text for pattern in unwanted_patterns):
            logger.info( "unwanted patterns found in STT response")

        return transcription_text
    except requests.exceptions.RequestException as e:
        logger.error( f"An error occurred in transcribe_audio_whisper, {e}", exc_info=True)
        return None


def read_tts(asst_id):
    filename = f"tts_outputs_{asst_id}.txt"

    try:
        with open(filename, 'r') as file:
            contents = file.read()
        return contents
    except FileNotFoundError:
        return f"File {filename} not found."


def get_opening_message(lang_code, voice_code, opening_message, tts_style, gender, provider):
    try:
        logger.info(f" get_opening_message")
        if all([voice_code, lang_code, provider, gender]):
            voice_code = voice_code
            speech = lang_code
            provider = provider
            gender = gender
        else:
            speech = "en-US"
            provider = "azure"
            voice_code = "en-US-JennyMultilingualNeural"
            gender = None

        if lang_code is None:
            lang_code = "en-US"

        # lang = lang_code.split('-')[0]
        start_msg = opening_message

       
        if provider == "google":
            audio_msg = generate_audio_google(start_msg, speech, voice_code, gender)
        elif provider == "eleven-labs":
            audio_msg = generate_audio_eleven_labs(start_msg, voice_code)
        elif provider == "whisper" or provider == "openai":
            audio_msg = generate_audio_whisper(message=start_msg, voice_name=voice_code)
        else:
            audio_msg = generate_audio_azure(start_msg, lang_code, voice_code, tts_style)

        return start_msg, audio_msg, provider, gender
    except Exception as e:
        logger.error(f"Exception in get_opening_message: {e}", exc_info=True)


def append_asst_msg(messages, function_id, function_name, function_args):
    messages.append(
        {
            "role": "assistant",
            "content": None,
            "tool_calls": [
                {
                    "id": function_id,
                    "function": {
                        "name": function_name,
                        "arguments": function_args
                    },
                    "type": "function"
                }
            ]
        }
    )


def append_tool_call_message(messages, function_id, function_name, function_returns):
    messages.append(
        {
            "tool_call_id": function_id,
            "role": "tool",
            "name": function_name,
            "content": function_returns,
        }
    )


def function_args_check(function_name, function_arguments, call_id):
    logger.info(f"{call_id} function call with function_name ----> {function_name},function_arguments ----> {function_arguments}")

    def parse_concatenated_json(json_str):
        # This function tries to split and parse concatenated JSON objects
        json_objects = []
        while json_str:
            json_str = json_str.strip()
            try:
                obj, index = json.JSONDecoder().raw_decode(json_str)
                json_objects.append(obj)
                json_str = json_str[index:].strip()
            except json.JSONDecodeError:
                logger.error(f"{call_id} Error in parsing json",exc_info=True)
                raise ValueError("Invalid JSON string")
                break
        return json_objects

    if function_name:
        # Split and parse concatenated JSON objects
        arguments_list = parse_concatenated_json(function_arguments)
        logger.debug(f"{call_id} -- arguments_list ----> {arguments_list}")
        # Merge the parsed dictionaries
        merged_arguments = {}
        for arg in arguments_list:
            merged_arguments.update(arg)

        logger.debug(f"{call_id} -- merged arguments -----> {merged_arguments}")

        # Specific handling for 'get_time'
        if function_name == "get_time" and len(merged_arguments) == 2:
            # Pick only the argument with the key 'time_zone'
            logger.info(f"{call_id} -- get_time function with 2 arguments")
            filtered_arguments = {"time_zone": merged_arguments.get("time_zone")}
        # Specific handling for 'web_search'
        elif function_name == "web_search" and len(merged_arguments) == 2:
            logger.info(f"{call_id} -- web_search function with 2 arguments")
            # Pick only the argument with the key 'query'
            filtered_arguments = {"query": merged_arguments.get("query")}
        elif function_name == "get_weather" and len(merged_arguments) == 2:
            # Pick only the argument with the key 'query'
            filtered_arguments = {"location": merged_arguments.get("location")}
        elif function_name == "disconnect_service" and len(merged_arguments) == 2:
            # Pick only the argument with the key 'parameter'
            filtered_arguments = {"parameter": merged_arguments.get("parameter")}
        elif function_name == "use_cached":
            # Handle use_cached function with vector_id and reason
            filtered_arguments = merged_arguments
        elif function_name == "fresh_generation":
            # Handle fresh_generation function with response
            filtered_arguments = merged_arguments
        elif function_name == "handle_telemarketing_call" and len(merged_arguments) == 2:
            # Pick only the argument with the key 'parameter'
            filtered_arguments = {"parameter": merged_arguments.get("parameter")}
        else:
            # Use the original merged arguments
            logger.info(f"only 1 argument received with funtion name {function_name}")
            filtered_arguments = merged_arguments
        return filtered_arguments


def adjust_messages_length(call_id, messages, message_length_threshold=50):
    logger.info(f"{call_id} -- adjusting messages length")

    popped_objects = []

    if len(messages) > message_length_threshold:
        logger.debug(f"{call_id} -- messages length is more than {message_length_threshold},messages before popping ----> {messages}")
        
        # Preserve system message (index 0) and keep recent conversation context
        # Instead of removing from index 1, remove older messages while preserving recent context
        messages_to_keep = 20  # Keep last 20 messages for context
        
        if len(messages) > messages_to_keep:
            # Keep system message and recent messages
            system_message = messages[0] if messages and messages[0].get('role') == 'system' else None
            recent_messages = messages[-messages_to_keep:]
            
            # Reconstruct messages list
            if system_message:
                messages = [system_message] + recent_messages
            else:
                messages = recent_messages
                
            logger.debug(f"{call_id} -- kept system message and last {messages_to_keep} messages, new length: {len(messages)}")

        logger.debug(f"{call_id} -- logging messages after adjustment ----> {messages},messages length after adjustment ----> {len(messages)}")

    return messages


def remove_messages_in_range(messages, start_offset, end_offset):
    """
    Removes elements from a list in a specified range.

    :param messages: List of messages
    :param start_offset: The start offset from the end of the list (inclusive)
    :param end_offset: The end offset from the end of the list (inclusive)
    """
    # Calculate the start and end indices
    start_index = -end_offset - 1
    end_index = -start_offset

    # Remove the specified range of elements
    del messages[start_index:end_index]


def convert_wav_to_base64(file_path):
    with open(file_path, 'rb') as wav_file:
        wav_data = wav_file.read()
        # mulaw_data = pcm16_to_mulaw(wav_data[58:])
        base64_encoded = base64.b64encode(wav_data).decode('utf-8')
    return base64_encoded


def pcm16_to_mulaw(pcm16_data):
    """
    Convert 16-bit PCM data to 8-bit mu-law data.

    Parameters:
    pcm16_data (bytes): Raw bytes in 16-bit PCM format.

    Returns:
    bytes: Raw bytes in 8-bit mu-law format.
    """
    # Convert 16-bit PCM data to 8-bit mu-law data
    mulaw_data = audioop.lin2ulaw(pcm16_data, 2)  # 2 bytes for 16-bit samples
    return mulaw_data


def handle_additional_info_call_start(system_prompt, additional_info, call_id):
    try:
        logger.info(f"{call_id} handle_additional_info_call_start called")
        if additional_info is None or additional_info == "None":
            logger.info(f"{call_id} additional_info is not present")
            system_prompt = system_prompt
        else:
            logger.info(f"{call_id} additional_info is present")
            system_prompt = system_prompt + "\n Use this additional Information to answer User query and treat it as HIGH PRIORITY. \n Additional Info -  " + additional_info

        return system_prompt
    except Exception as e:
        logger.error(f"{call_id} Exception in handle_additional_info_call_start: {e}",exc_info=True)
        return system_prompt


def save_audio_to_file(base64_audio: str, save_path: str):
    try:
        # Ensure the directory exists
        os.makedirs(os.path.dirname(save_path), exist_ok=True)

        # Decode the base64 audio data
        audio_data = base64.b64decode(base64_audio)

        # Write the audio data to the specified file
        with open(save_path, 'wb') as audio_file:
            audio_file.write(audio_data)

        logger.info(f"Audio file saved successfully at {save_path}")
    except Exception as e:
        logger.error(f"Error saving audio to file: {e}", exc_info=True)


def get_voice_mapping_from_voice_code(voice_code):
    try:
        db = SessionLocal()
        voice_mapping = get_tts_language_mapping_by_voice_name(db, voice_code)
        logger.info(f"voice_mapping in get_voice_mapping_from_voice_code ----> {voice_mapping}")

        if voice_mapping is not None:
            voice_code = voice_code
            speech = voice_mapping.language_code
            provider = voice_mapping.tts_model_provider.lower()
            gender = voice_mapping.gender
            language = voice_mapping.language_name
        else:
            speech = "en-US"
            provider = "azure"
            voice_code = "en-US-JennyMultilingualNeural"
            gender = None
            language = "English"
    except Exception as e:
        logger.error(f"Exception in get_voice_mapping_from_voice_code: {e}",exc_info=True)
        speech = "en-US"
        provider = "azure"
        voice_code = "en-US-JennyMultilingualNeural"
        gender = None
        language = "English"

    return speech, provider, voice_code, gender, language


def extract_json_from_script(soup):
    """
    Generic function to extract JSON-like data from script tags.
    """
    scripts = soup.find_all('script')
    for script in scripts:
        # Try to match JSON-like structures
        json_match = re.search(r'({.*})', script.string or '', re.DOTALL)
        if json_match:
            try:
                json_data = json.loads(json_match.group(1))
                return json_data  # Return the first valid JSON found
            except json.JSONDecodeError:
                continue  # If it fails, try the next script

    return None


def is_valid_url(url):
    logger.info(f"Input in is_valid_url:{url}k0k")
    if not url.startswith(('http://', 'https://')):
        corrected_url = 'http://' + url  # Assume http if no scheme is provided
    else:
        corrected_url = url

    parsed_url = urlparse(corrected_url)
    is_valid = all([parsed_url.scheme, parsed_url.netloc])

    return is_valid, corrected_url


def text_to_speech_azure(text: str, file_name: str, tts_style=None, voice_name='en-NG-EzinneNeural'):
    # print(f"text ----> {text} , file_name ----> {file_name}")
    # Construct the URL based on the provided region

    if not voice_name:
        voice_name = 'en-US-AvaMultilingualNeural'

    text = text.replace("&", "and")

    if not tts_style:
        tts_style = ''

    lang = voice_name.split("-")[0] + "-" + voice_name.split("-")[1]

    url = os.getenv('AZURE_TTS_URL')
    sub_key = os.getenv('AZURE_SUB_KEY')

    # Headers required by the API
    headers = {
        'Ocp-Apim-Subscription-Key': sub_key,
        'Content-Type': 'application/ssml+xml',
        'X-Microsoft-OutputFormat': 'audio-16khz-128kbitrate-mono-mp3',
        'User-Agent': 'curl'
    }

    data = f"""
    <speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xmlns:mstts="https://www.w3.org/2001/mstts" xml:lang='{lang}'>
        <voice name='{voice_name}'>
             <prosody rate="+0.00%">
                 <mstts:express-as style='{tts_style}' styledegree="1">
                    {text}
                 </mstts:express-as>
            </prosody>
        </voice>
    </speak>

    """

    encoded_data = data.encode('utf-8')

    logger.debug(f"logging encoded data ----> \n\n{encoded_data}\n\n")
    # Send the POST request
    try:
        response = requests.post(url, headers=headers, data=encoded_data)
    except Exception as e:
        logger.error(f"response from azure ----> {e}", exc_info=True)
        run_alarm_in_thread(send_alarm(alarm_type='Azure_TTS', remarks=str(e), status='raise'))
    # Check if the request was successful
    if response.status_code == 200:
        logger.info(f"response code 200\n")
        run_alarm_in_thread(send_alarm(alarm_type='Azure_TTS', remarks='Azure TTS working fine', status='clear'))
        # Save the response content as an audio file
        with open(file_name, 'wb') as audio_file:
            audio_file.write(response.content)
        return file_name
    else:
        error_message = response.text  # This will capture the error message from the response body
        logger.error(f"Azure error: response code={response.status_code}, message={error_message}\n",exc_info=True)
        run_alarm_in_thread(send_alarm(alarm_type='Azure_TTS', remarks=error_message, status='raise'))
        raise Exception(f"\nFailed to generate speech. Status code: {response.status_code}, Error: {error_message}\n")


def match_b64(raw: str, encoded: str):
    return base64.b64encode(raw.encode('utf-8')).decode() == encoded


def get_current_time_iso():
    """
    Get the current UTC time and format it as an ISO 8601 string (e.g., "2024-11-07T10:00:00Z").

    Returns:
        str: The current time in ISO 8601 format.
    """
    # Get the current UTC time
    current_time = datetime.now(timezone.utc)

    # Format the time in ISO 8601 format with "Z" to denote UTC
    iso_format_time = current_time.strftime("%Y-%m-%dT%H:%M:%SZ")

    return iso_format_time


def iso_time_difference_in_seconds(start_time, end_time):
    """
    Calculate the difference between two ISO 8601 formatted times and return it in seconds.

    Parameters:
        start_time (str): Start time in ISO 8601 format (e.g., "2024-11-07T10:00:00Z").
        end_time (str): End time in ISO 8601 format (e.g., "2024-11-07T12:30:00Z").

    Returns:
        int: The time difference in seconds.
    """
    # Parse the start and end times to datetime objects
    start_dt = datetime.strptime(start_time, "%Y-%m-%dT%H:%M:%SZ")
    end_dt = datetime.strptime(end_time, "%Y-%m-%dT%H:%M:%SZ")

    # Calculate the difference and return it in seconds
    delta = end_dt - start_dt
    return int(delta.total_seconds())

def check_if_should_mask_data(operator: str, country: str, a_party: str, b_party: str) -> bool:
    """
    Check if we should mask data for this call
    Returns True if security is enabled AND numbers are NOT whitelisted
    """
    try:
        # Lazy import to avoid circular dependency
        from cache.security_properties_cache import is_security_enabled, is_number_whitelisted

        # Check if security is enabled for this operator/country
        if is_security_enabled(country, operator):
            # Security is enabled, check if numbers are whitelisted
            a_party_whitelisted = is_number_whitelisted(a_party, country, operator)
            b_party_whitelisted = is_number_whitelisted(b_party, country, operator)

            # If either number is whitelisted, don't mask
            if a_party_whitelisted or b_party_whitelisted:
                return False  # Don't mask
            else:
                return True   # Mask (security enabled but numbers not whitelisted)
        else:
            # Security not enabled, so no masking needed
            return False  # Don't mask

    except Exception as e:
        logger.error(f"Error checking mask status: {str(e)}")
        return False

def adjust_log_level(enable_secure_logging: bool):
    """
    Adjust log level based on security flag.
    - If enable_secure_logging is True and current level is info: change to secure
    - If enable_secure_logging is False and current level is secure: change to info
    - Otherwise: keep current level

    Args:
        enable_secure_logging (bool): True if secure logging should be enabled
        logger_instance: Logger instance to use
    """
    try:
        current_level = logging.getLevelName(logging.getLogger().level)

        if enable_secure_logging:
            # If secure logging is required and current level is info, change to secure
            if current_level == "INFO":
                logging.getLogger().setLevel(25)
        else:
            # If secure logging is not required and current level is secure, change to info
            if current_level == "SECURE":
                logging.getLogger().setLevel(logging.INFO)

    except Exception as e:
        logger.error(f"Error adjusting log level for masking: {str(e)}", exc_info=True)
