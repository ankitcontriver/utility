from response.GenericResponse import GenericResponse


class GetTTSModel:
    def __init__(self, id, tts_model_name):
        self.id = id
        self.tts_model_name = tts_model_name

    def __repr__(self):
        return f"id: {self.id}, tts_model_name: {self.tts_model_name}"


class GetTTSModelResponse(GenericResponse):
    def __init__(self, status, status_code, message, data: list[GetTTSModel]):
        super().__init__(status_code=status_code, status=status, message=message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, status_code: {self.status_code}, message: {self.message}, data: {self.data}"
