from response.GenericResponse import GenericResponse


class SendLoginCredResponse(GenericResponse):
    def __init__(self, status, status_code, message, data: str):
        super().__init__(status_code=status_code,status=status,message=message)
        self.data = data

    def __repr__(self):
        return f"status={self.status}, status_code={self.status_code}, message={self.message}, data={self.data}"
