from fastapi import APIRouter, HTTPException

from logger import get_logger
from models.request_models import OrganizationNameRequest, UserMappingRequest, SectorRequest, \
    UpdateOrganizationDetailRequest
from service.group_names_service import get_organization_detail as get_organization_detail_service, \
    update_organization_detail as update_organization_detail_service, get_unique_agents as get_unique_agents_service
from service.group_names_service import get_organization_names as get_organization_names_service, \
    add_organization_name as add_organization_name_service, delete_organization as delete_organization_serivce, \
    get_organization_emails as get_organization_emails_service, \
    update_organization_email as update_organization_email_service
from service.group_names_service import get_sectors as get_sectors_service, upsert_sector as upsert_sector_service
from service.group_names_service import get_user_mapping as get_user_mapping_service, \
    update_user_mapping as update_user_mapping_service

logger = get_logger(__name__)

router = APIRouter()


@router.get("/get_organization_names", tags=["Organization Names"])
def get_organization_names(email: str):
    try:
        logger.info(f"get_organization_names controller called")
        response = get_organization_names_service(email)
        return response
    except Exception as e:
        logger.error(f"Error in get_organization_names controller, {e}, exc_info=True")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.post("/add_organization_name", tags=["Organization Names"])
def add_organization_name(organization_name_request: OrganizationNameRequest):
    try:
        logger.info(
            f"add_organization_name controller called for organization_name: {organization_name_request.organization_name}, sector: {organization_name_request.sector} ")
        response = add_organization_name_service(organization_name_request)
        return response
    except Exception as e:
        logger.error(f"Error in add_organization_name controller, {e}, exc_info=True")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.delete("/delete_organization_email", tags=["Organization Names"])
def delete_organization_email(organization_name: str, sector: str, email: str):
    try:
        logger.info(
            f'delete_organization_email controller called for email:{email}, organization: {organization_name}, sector: {sector}')
        response = delete_organization_serivce(organization_name, sector, email)
        return response
    except Exception as e:
        logger.error(f"Error in delete_organization_email controller, {e}, exc_info=True")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/get_organization_emails", tags=["Organization Names"])
def get_organization_emails(org_id: int):
    try:
        response = get_organization_emails_service(org_id)
        return response
    except Exception as e:
        logger.error(f"Error in get_organization_emails controller, {e}, exc_info=True")
        raise HTTPException(status_code=500, detail=f"Internal Server Error {e}")


@router.put("/update_organization_email")
def update_organization_email(org_id: int, emails: list[str]):
    try:
        response = update_organization_email_service(org_id, emails)
        return response
    except Exception as e:
        logger.error(f"Error in update_organization_email controller, {e}, exc_info=True")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/get_user_mapping", tags=["Organization Names"])
def get_user_mapping(email: str):
    try:
        logger.info(f"get_user_mapping controller called for email: {email}")
        response = get_user_mapping_service(email)
        return response
    except Exception as e:
        logger.error(f"Error in get_user_mapping controller, {e}, exc_info=True")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.post("/update_user_mapping", tags=["Organization Names"])
def update_user_mapping(user_mapping_request: UserMappingRequest):
    try:
        logger.info(
            f"update_user_mapping controller called for email: {user_mapping_request.email}  org_ID: {user_mapping_request.org_id}")
        response = update_user_mapping_service(user_mapping_request.email, user_mapping_request.org_id)
        return response
    except Exception as e:
        logger.error(f"Error in update_user_mapping controller, {e}, exc_info=True")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/get_organization_detail", tags=["Organization Names"])
def get_organization_detail(agent_id: str, org_id: int):
    try:
        logger.info(
            f"get_organization_detail controller called for agent_id: {agent_id}, org_id: {org_id}")
        response = get_organization_detail_service(agent_id, org_id)
        return response
    except Exception as e:
        logger.error(f"Error in get_organization_detail controller, {e}, exc_info=True")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.post("/update_organization_detail", tags=["Organization Names"])
def update_organization_detail(update_request: UpdateOrganizationDetailRequest):
    try:
        logger.info(
            f"update_organization_detail controller called for agent_id: {update_request.agent_id}, org_id: {update_request.org_id}, agent_type: {update_request.agent_type}, enterprise_data: {update_request.enterprise_data}, local_specs: {update_request.local_specs}, website:{update_request.website}, website_summary: {update_request.website_summary}, parameters: {update_request.parameters}")
        response = update_organization_detail_service(
            update_request.agent_id,
            update_request.org_id,
            update_request.agent_type,
            update_request.enterprise_data,
            update_request.local_specs,
            update_request.parameters,
            update_request.website,
            update_request.website_summary
        )
        if response.status == "Success":
            return response
        else:
            raise HTTPException(status_code=response.status_code, detail=response.message)
    except Exception as e:
        logger.error(f"Error in get_unique_agents controller, {e}, exc_info=True"   )
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/get_unique_agents", tags=["Organization Names"])
def get_unique_agents():
    try:
        logger.info(f"get_unique_agents controller called")
        response = get_unique_agents_service()
        return response
    except Exception as e:
        logger.error(f"Error in get_sectors controller, {e}, exc_info=True")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/get_sectors", tags=["Organization Names"])
def get_sectors():
    try:
        logger.info(f"get_sectors controller called")
        response = get_sectors_service()
        return response
    except Exception as e:
        logger.error(f"Error in upsert_sector controller, {e}, exc_info=True")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.post("/upsert_sector", tags=["Organization Names"])
def upsert_sector(sector_request: SectorRequest):
    try:
        logger.info(
            f"upsert_sector controller called for sector_name: {sector_request.sector_name}, capabilities: {sector_request.capabilities}")
        response = upsert_sector_service(sector_request)
        if response.status == "Success":
            return response
        else:
            raise HTTPException(status_code=response.status_code, detail=response.message)
    except Exception as e:
        logger.error(f"Error in upsert_sector controller, {e}, exc_info=True")
        raise HTTPException(status_code=500, detail="Internal Server Error")
