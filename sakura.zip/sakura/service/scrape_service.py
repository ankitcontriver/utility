import asyncio
import os
import threading
import time
import traceback
from datetime import datetime
from threading import Thread
from urllib.parse import urljoin, urlparse

import requests
import urllib3
from bs4 import BeautifulSoup
from dotenv import load_dotenv
from openai import OpenAI
from playwright.async_api import async_playwright

from config.database_config import SessionLocal
from enums.scrape_status_enum import ScrapeStatus
from logger import get_logger
from models.database_models import ScrapedData
from repository.scrape_repository import get_scraped_data, add_scraped_data, update_data
from response.ScrapeResponse import ScrapeResponse, ScrapedDataObject, GenericResponse
from utils.utils import extract_json_from_script, is_valid_url

load_dotenv()

logger = get_logger(__name__)

api_key = os.getenv("OPENAI_API_KEY")

suzume_url = os.getenv("SUZUME_URL")

bright_data_auth_user = os.getenv("BRIGHT_DATA_AUTH_USER")
bright_data_auth_pass = os.getenv("BRIGHT_DATA_AUTH_PASS")
bright_data_auth_url = os.getenv("BRIGHT_DATA_AUTH_URL")

client = OpenAI()

base_url = ''

all_summaries = []

summarize_times = []

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
}

# Set to keep track of visited URLs to avoid duplicates
visited_urls = set()

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

AUTH = f'{bright_data_auth_user}:{bright_data_auth_pass}'
SBR_WS_CDP = f'wss://{AUTH}@brd.superproxy.io:9222'


async def background_processing(url):
    try:
        scraper = WebScraper(max_depth=2, max_pages=10)
        await scraper.scrape_and_summarize(url)
    except Exception as e:
        logger.error(f"Error in background processing: {e}",exc_info=True)


async def scrape_url_service(url: str):
    try:
        db = SessionLocal()
        url = normalize_url(url)
        scraped_data_object = get_scraped_data(db, url)

        if scraped_data_object is None:
            new_scrape_entry = ScrapedData(url=url, base_url=normalize_url(url))
            add_scraped_data(db, new_scrape_entry)
            # thread = Thread(target=background_processing, args=[url])
            # thread.start()
            # await asyncio.create_task(background_processing(url))

            thread = Thread(target=lambda: asyncio.run(background_processing(url)))
            thread.start()

            response_data = ScrapedDataObject(state=ScrapeStatus.PROCESSING, summary="", url=url)

            response = ScrapeResponse(status_code=202, status="Successful", message="Request Acknowledged",
                                      data=response_data)
            return response
        elif scraped_data_object.status == ScrapeStatus.PROCESSING or scraped_data_object.status == ScrapeStatus.SECURITY_PROCESSING:
            response_data = ScrapedDataObject(state=ScrapeStatus.PROCESSING, summary="", url=url)
            response = ScrapeResponse(status_code=201, status="Successful", message="In Processing State",
                                      data=response_data)
            return response

        elif scraped_data_object.status == ScrapeStatus.PROCESSED:
            response_data = ScrapedDataObject(state=ScrapeStatus.PROCESSED, summary=scraped_data_object.summary,
                                              url=url)
            response = ScrapeResponse(status_code=200, status="Successful", message="Data Fetched Successfully",
                                      data=response_data)
            return response

        elif scraped_data_object.status == ScrapeStatus.FAILED:
            response_data = ScrapedDataObject(state=ScrapeStatus.FAILED, summary=scraped_data_object.summary, url=url)
            response = ScrapeResponse(status_code=200, status="Successful", message=scraped_data_object.summary,
                                      data=response_data)
            return response
    except Exception as e:
        logger.error(f"Error in scrape_url_service: {e}")
        return GenericResponse(status_code=500, status="Internal Server Error",
                               message=f"Error in scrape_url_service: {e}")


def summarize_content(content):
    logger.info("Summarizing content...")
    try:
        summarize_start_time = time.time()
        system_prompt = """
        I have gathered a substantial amount of textual data from a website, which includes information from various sections of the page. I need a detailed and well-organized summary that captures the core essence of this data.
        Please follow these instructions for the summary:
        Main Themes and Topics: Identify and outline the main themes or topics covered in the text. Summarize each theme with a few sentences, capturing the overall message or purpose.
        Section Breakdown: If the data is divided into distinct sections or categories, provide a brief summary for each section. Clearly indicate the section titles and summarize the content under each.
        Key Details: Highlight any key details, facts, or figures that are important for understanding the context or significance of the information. These could include statistics, rules, procedures, or other specific details mentioned in the text.
        User Instructions or Actions: If the text includes instructions, steps, or guidelines for the reader to follow, summarize these clearly. Ensure that the sequence of actions or steps is maintained for clarity.
        Additional Insights: Include any other relevant insights or observations that can help in comprehending the broader context or implications of the data. This could involve any underlying messages, trends, or noteworthy points that are implied or explicitly mentioned.
        Organize the Information: Structure the summary in a logical and coherent manner, using bullet points or headings where necessary to separate different sections or themes. Ensure the summary flows well and provides a clear narrative or overview.
        Conciseness: While being thorough, aim to keep the summary concise and to the point. Avoid overly long explanations unless absolutely necessary to convey the meaning.

        AND THE RESPONSE SHOULD NOT BE LIKE:
                #### User Instructions or Actions

                        - **Enrollment in Team Bonus**:
                                1. Register on the website or mobile app.
                                2. Use the USSD code *555#.

        RATHER IT SHOULD BE LIKE:
                User Instructions or Actions

                        - Enrollment in Team Bonus:
                                1. Register on the website or mobile app.
                                2. Use the USSD code *555#.       

        IF THERE IS A ANY DATA THAT IS REVOLVING AROUND NUMERICAL VALUES, THE EXPLANATION FOR IT SHOULD BE SUBSTANTIAL. NO NUMERICAL DATA SHOULD BE DISCARDED. 

        DO NOT TRY TO BOLD ANY TEXT IN THE RESPONSE YOU ARE SENDING
        """

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Here is the scraped data: {content}"}
            ]
        )

        summarize_end_time = time.time()
        summarize_time = summarize_end_time - summarize_start_time

        return response.choices[0].message.content, summarize_time
    except Exception as e:
        logger.error(f"Error in summarize_text() : {e}")
        return "Error in summarize_text", 0


def normalize_url(url):
    try:
        parsed_url = urlparse(url)
        path = parsed_url.path.rstrip('/')
        normalized_url = urljoin(url, path)
        return normalized_url
    except Exception as e:
        logger.error(f"Error in normalize_url() : {e}")


def extract_organization(url):
    return url.replace("https://www", "").split("/")[0]


async def scrape_page(url):
    is_valid, valid_url = is_valid_url(url)
    if not is_valid:
        logger.error(f"Invalid URL: {url}")
        return None, None, False
    normalized_url = normalize_url(valid_url)
    start_time = datetime.now()
    logger.info(f"[{start_time}] Starting to scrape URL: {valid_url}")
    is_js_enabled = False
    try:
        # response = requests.get(normalized_url, verify=False, headers=headers)
        # response.raise_for_status()  # This will raise an HTTPError for bad responses
        # print(f"Response = {response.status_code}")
        # logger.info(f"Response = {response.status_code}")
        async with async_playwright() as p:
            browser = await p.chromium.connect_over_cdp(SBR_WS_CDP)
            # context = browser.new_context(ignore_https_errors=True)
            # context = browser.new_context(
            #     ignore_https_errors=True # Disabling JavaScript might prevent some detections
            # )
            # page = context.new_page()
            # stealth_sync(page)
            page = await browser.new_page()
            try:
                # Increase timeout to 60 seconds
                # page.goto(normalized_url)
                await page.goto(normalized_url, timeout=2 * 60 * 1000)
                # page.wait_for_load_state('networkidle')
                content = await page.content()
                logger.info(f"[{datetime.now()}] Page loaded successfully")
            except TimeoutError:
                logger.error("Page loading timed out", exc_info=True)
                content = "Error: Page loading timed out"
            finally:
                await browser.close()
        soup = BeautifulSoup(content, 'html.parser')
        logger.info(f"[{datetime.now()}] Page content parsed successfully")
        logger.info(f"Soup - {soup}")
        # with open(f'{valid_url}.html', 'w', encoding='utf-8') as file:
        #     file.write(str(soup))
        check = soup.find("noscript")
        # if check and check.text == "You need to enable JavaScript to run this app.":
        #     is_js_enabled = True
        #     logger.info(f"[{datetime.now()}] No data to scrape on {normalized_url}")
        #     print(f"[{datetime.now()}] No data to scrape on {normalized_url}")
        #     return "", soup, is_js_enabled

        # Extract meaningful content (simplified for demonstration)
        meaningful_content = soup.get_text()
        logger.debug(f"Meaningful Content = {meaningful_content}")

        if meaningful_content is None or meaningful_content == "":
            logger.info(f"[{datetime.now()}] No data to scrape on {normalized_url}")
            meaningful_content = extract_json_from_script(soup)
            # print(f"Meaningful Content = {meaningful_content}")
        logger.info(f"[{datetime.now()}] Successfully scraped content from {url}")

        # Summarize the page content
        page_summary, summarize_time = summarize_content(meaningful_content)
        logger.info(f"[{datetime.now()}] Content summarized in {summarize_time:.2f} seconds")

        return page_summary, soup, is_js_enabled  # Return the summary and the soup object

    except Exception as e:
        logger.error(f"[{datetime.now()}] Error in scrape_page for  {url}: {e}")
        return None, None, is_js_enabled  # Ensure it returns None in case of error

    finally:
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        logger.info(f"[{datetime.now()}] Finished scraping content from {url} in {duration:.2f} seconds")


class WebScraper:
    def __init__(self, max_depth=2, max_pages=10):
        self.max_depth = max_depth
        self.max_pages = max_pages
        self.visited_urls = set()
        self.page_summaries = []
        self.lock = threading.Lock()

    async def scrape_and_summarize(self, url, current_depth=0):
        try:
            if current_depth > self.max_depth or len(self.visited_urls) >= self.max_pages:
                return

            self.visited_urls.add(normalize_url(url))

            page_summary, soup, is_js_enabled = await scrape_page(url)

            if page_summary is None:
                return

            if is_js_enabled:
                call_js_enabled_scraping(url)
                return

            if page_summary and soup:  # Proceed only if both are not None
                with self.lock:
                    self.page_summaries.append(f"{page_summary}\n[Source: {url}]\n\n")

                if current_depth < self.max_depth:
                    links_to_scrape = set()
                    new_link_count = 0
                    for link in soup.find_all('a', href=True):
                        absolute_link = urljoin(url, link['href'])
                        normalized_link = normalize_url(absolute_link)
                        if normalized_link not in self.visited_urls:
                            links_to_scrape.add(normalized_link)
                            new_link_count += 1

                    logger.info(f"[{datetime.now()}] {new_link_count} new links found on {url}")

                    if links_to_scrape:
                        await asyncio.gather(
                            *[self.scrape_and_summarize(link, current_depth + 1) for link in links_to_scrape]
                        )

            if current_depth == 0:
                final_summary = " ".join(self.page_summaries)
                with self.lock:
                    db = SessionLocal()
                    db_url = get_scraped_data(db, url)
                    if db_url is not None:
                        if final_summary and final_summary.strip():
                            update_data(db, db_url, final_summary)
                        else:
                            update_data(db, db_url, f"Unable to Scrape {url}", ScrapeStatus.FAILED)
                    else:
                        logger.error(f"Could not retrieve data for {url}.")
                        update_data(db, None, f"Error retrieving data for {url}", ScrapeStatus.FAILED)
        except Exception as e:
            logger.error(f"Error in scrape_and_summarize() : {e}",exc_info=True)
            db = SessionLocal()
            db_url = get_scraped_data(db, url)
            if db_url is not None:
                update_data(db, db_url, f"Error while Scraping {url} : {e}", ScrapeStatus.FAILED)
            else:
                logger.error(f"Could not retrieve data for {url}.")
                update_data(db, None, f"Error while Scraping {url} : {e}", ScrapeStatus.FAILED)


def call_js_enabled_scraping(url):
    # Base URL of the API
    suzume = f'{suzume_url}scrape_url'

    # Parameters for the GET request
    params = {'url': url}

    # Headers for the GET request
    suzume_headers = {'accept': 'application/json'}

    try:
        # Make the GET request
        response = requests.get(suzume, params=params, headers=suzume_headers)

        # Check if the request was successful
        response.raise_for_status()

        # Print the response status code
        logger.info(f"Status Code: {response.status_code}")

        # Print the JSON response
        result = response.json()
        # print(f"Response: {result}")

        return result
    except requests.exceptions.HTTPError as http_err:
        logger.error(f"HTTP error occurred: {http_err}")
    except requests.exceptions.RequestException as err:
        logger.error(f"Error occurred: {err}")
