from logger import get_logger

logger = get_logger(__name__)


def check_statement_complete(statement: str) -> bool:
    # analyse_start_time = int(round(time.time() * 1000))
    # result = analyze_conversation_chunk(appended_chunk=statement)
    # decision = result.content
    # analyse_end_time = int(round(time.time() * 1000))
    # print(f"Decision: {decision} for Statement - {statement}")
    # print(f"Time taken to analyse statement - {analyse_end_time-analyse_start_time}")
    #
    # return decision.lower() != "no"
    return True


def append_current_statement_to_user_messages(user_message, statement):
    try:
        logger.info(f"user_message - {user_message}")
        logger.info(f"statement - {statement}")
        old_message = " ".join(user_message)

        transcript = (old_message.strip() + " " + statement.strip()).strip()
        logger.info(f"transcript ----> {transcript}")
        return transcript
    except Exception as e:
        logger.error(f"Error while appending current statement to user message in message_service.py: {e}")


def handle_statement_incomplete(statement, callId):
    logger.info(f"Statement is incomplete {statement}")


def check_is_statement_interrupting(statement):
    logger.info(f"statement to check - {statement}")
    try:
        if 'stop' in statement or 'hold on' in statement or 'wait' in statement:
            return True

        return False
    except Exception as e:
        logger.error(f"Error while checking if statement is interrupting or not in message_service: {e}")
