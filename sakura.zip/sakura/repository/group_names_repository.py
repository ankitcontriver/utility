from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

from models.database_models import OrganizationNames, UserDetails, ExtraColumns, Sector


def delete_organization(db: Session, organization_name: str, sector: str, email: str):
    # Retrieve the organization by name and sector
    organization = db.query(OrganizationNames).filter(
        OrganizationNames.organization_name == organization_name,
        OrganizationNames.sector == sector
    ).first()

    if organization:
        # Split the emails into a list and remove the specified email
        email_list = organization.emails.split(',')
        if email in email_list:
            email_list.remove(email)
            # Update the emails field in the database
            organization.emails = ','.join(email_list)
            db.commit()
            db.refresh(organization)
            return True
    return False


def get_organization_names(db: Session, email_id: str):
    return db.query(OrganizationNames).filter(
        (OrganizationNames.emails.like(f"%{email_id}%")) | (OrganizationNames.organization_name == "default") | (OrganizationNames.id == 1)
    ).all()


def add_organization_name(db: Session, organization_name: str, sector: str, email: str):
    existing_organization_with_email = db.query(OrganizationNames).filter(
        OrganizationNames.emails.like(f"%{email}%"),
        OrganizationNames.sector == sector,
        OrganizationNames.organization_name == organization_name
    ).first()

    if existing_organization_with_email:
        # Return None if email already exists
        return None
    # Create a new organization with the given email
    new_organization = OrganizationNames(
        organization_name=organization_name,
        sector=sector,
        emails=email,
        createdOn=datetime.utcnow(),
        updatedOn=datetime.utcnow()
    )
    db.add(new_organization)
    db.commit()
    db.refresh(new_organization)
    return new_organization


def get_organization_emails(db: Session, org_id: int):
    return db.query(OrganizationNames).filter(
        OrganizationNames.id == org_id
    ).first()


def update_organization_email(db: Session, org_id: int, emails: list[str]):
    # Retrieve the organization by org_id
    organization = db.query(OrganizationNames).filter(
        OrganizationNames.id == org_id
    ).first()

    if organization:
        # Update the emails field with the new list of emails
        organization.emails = ','.join(emails)
        db.commit()
        db.refresh(organization)
        return organization
    return None


def get_user_mapping(db: Session, email: str):
    return (
        db.query(UserDetails, OrganizationNames)
        .join(OrganizationNames, UserDetails.org_id == OrganizationNames.id)
        .filter(UserDetails.email_id == email)
        .first()
    )


def update_user_mapping(db: Session, email: str, org_id: int):
    # Check if the org_id is -1 and get the "default" organization in the "telecommunication" sector
    if org_id == -1:
        default_organization = db.query(OrganizationNames).filter(
            OrganizationNames.organization_name == "default",
            OrganizationNames.sector == "Telecommunication"
        ).first()
        if not default_organization:
            return None
        org_id = default_organization.id
        user = db.query(UserDetails).filter(UserDetails.email_id == email).first()
        if not user:
            user = UserDetails(email_id=email, org_id=org_id)
            db.add(user)
        else:
            user.org_id = org_id
        
        db.commit()
        db.refresh(user)

        user_data = {
            "id": user.id,
            "email": user.email_id,
            "organization_name": default_organization.organization_name,
            "org_id": org_id,
            "sector": default_organization.sector
        }
        return user_data

    # Check if the organization exists and the email is authorized
    organization = db.query(OrganizationNames).filter(OrganizationNames.id == org_id).first()
    if not organization:
        return None

    # Check if the user exists
    user = db.query(UserDetails).filter(UserDetails.email_id == email).first()
    if not user:
        user = UserDetails(email_id=email, org_id=org_id)
        db.add(user)
    else:
        user.org_id = org_id
    
    db.commit()
    db.refresh(user)

    user_data = {
        "id": user.id,
        "email": user.email_id,
        "organization_name": organization.organization_name,
        "org_id": org_id,
        "sector": organization.sector
    }
    return user_data


def get_organization_detail(db: Session, agent_id: int, org_id):
    query = db.query(ExtraColumns).outerjoin(OrganizationNames, ExtraColumns.org_id == OrganizationNames.id)
    
    if org_id is not None:
        # Query using org_id
        organization_detail = query.filter(ExtraColumns.agent_id == agent_id, ExtraColumns.org_id == org_id).first()
    else:
        # Query using agent_id and default organization_name
        organization_detail = query.filter(ExtraColumns.agent_id == agent_id, ExtraColumns.organization_name == "default").first()

    if organization_detail:
        result = {
            "id": organization_detail.id,
            "agent_id": organization_detail.agent_id,
            "org_id": organization_detail.org_id,
            "organization_name": organization_detail.organization_name,  # Add this to the result
            "agent_type": organization_detail.agent_type,
            "enterprise_data": organization_detail.enterprise_data,
            "local_specs": organization_detail.local_specs,
            "website": organization_detail.website,
            "website_summary": organization_detail.website_summary,
            "parameters": organization_detail.parameters
        }
    else:
        result = None

    return result


def upsert_organization_detail(db: Session, agent_id: int, org_id: int, agent_type: str, enterprise_data: str,
                               local_specs: str, parameters: dict, website: str, website_summary: str):
    
    organization_detail = db.query(ExtraColumns).filter(ExtraColumns.agent_id == agent_id, ExtraColumns.org_id == org_id).first()

    organization_name_record = db.query(OrganizationNames).filter(OrganizationNames.id == org_id).first()
    organization_name = organization_name_record.organization_name if organization_name_record else None

    if organization_detail:
        organization_detail.agent_type = agent_type
        organization_detail.enterprise_data = enterprise_data
        organization_detail.local_specs = local_specs
        organization_detail.parameters = parameters
        organization_detail.organization_name = organization_name  
        if website:
            organization_detail.website = website
        if website_summary:
            organization_detail.website_summary = website_summary
    else:
        organization_detail = ExtraColumns(
            agent_id=agent_id,
            org_id=org_id,
            organization_name=organization_name,  
            agent_type=agent_type,
            enterprise_data=enterprise_data,
            local_specs=local_specs,
            parameters=parameters,
            website=website,
            website_summary=website_summary
        )
        db.add(organization_detail)
        
    db.commit()
    db.refresh(organization_detail)
    return organization_detail



def get_unique_agents(db: Session):
    return db.query(ExtraColumns.agent_id, ExtraColumns.agent_type).distinct().all()


def get_sectors(db: Session):
    return db.query(Sector).all()


def upsert_sector(db: Session, sector_name: str, capabilities: Optional[str]):
    sector = db.query(Sector).filter(Sector.sector_name == sector_name).first()
    if sector:
        sector.capabilities = capabilities
    else:
        sector = Sector(sector_name=sector_name, capabilities=capabilities)
        db.add(sector)
    db.commit()
    db.refresh(sector)
    return sector
