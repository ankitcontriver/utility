from config.database_config import SessionLocal
from logger import get_logger
from repository.llm_repository import get_llm_models
from response.GetLLMModelResponse import GetLLMModel, GetLLMModelResponse

logger = get_logger(__name__)


def get_llm_model(language: str, avatar_id: str):
    logger.info(f"get_llm_model service called for language: {language}, avatar_id: {avatar_id}")
    db = SessionLocal()
    try:
        llm_models = get_llm_models(db, language, avatar_id)
        logger.info(f"llm_models : {llm_models}")

        models = [GetLLMModel(llm_model_display_name=llm.llm_model_display_name, llm_model_name=llm.llm_model_name,
                              llm_model_provider=llm.llm_model_provider, tool_call_support=llm.tool_call_support) for
                  llm in llm_models]
        response = GetLLMModelResponse(status="Successful", status_code=200,
                                       message="llm models retrieved successfully", data=models)

        if llm_models is None:
            response = GetLLMModelResponse(status="Failed", status_code=400, message="LLM models not found", data=[])

    except Exception as e:
        logger.error(f"Error in get_llm_model() service  for language: {language}, avatar_id: {avatar_id} due to an error: {e}")
        response = GetLLMModelResponse(status="Exception", status_code=500, message="Internal Server Error", data=[])
    finally:
        db.close()
    return response
