from sqlalchemy.orm import Session
from models.database_models import User
from datetime import datetime
from models.request_models import SignUpRequest


def get_user(db: Session, user_id: int):
    return db.query(User).filter(User.id == user_id).first()


def get_user_by_email(db: Session, email: str):
    return db.query(User).filter(User.email == email).first()


def login_user(db: Session, user: User, ip: str):
    user.is_active = True
    user.latest_ip = ip
    user.last_login = datetime.now()
    db.commit()
    return user


def add_user(db: Session, request: SignUpRequest):
    new_user = User(name=request.name, email=request.email, contact_number=request.contact_number)
    db.add(new_user)
    db.commit()
    return get_user_by_email(db, request.email)


def delete_user(db: Session, user: User):
    db.delete(user)
    db.commit()


def logout_user(db: Session, user: User):
    user.is_active = False
    db.commit()


def upsert_user(db: Session, user: User):
    db.add(user)
    db.commit()


def save_user(db: Session, user: User):
    db.add(user)
    db.commit()


def get_all_users(db: Session):
    return db.query(User).all()


def get_user_by_id(db: Session, key: str):
    return db.query(User).filter(User.encoded_key == key).first()
