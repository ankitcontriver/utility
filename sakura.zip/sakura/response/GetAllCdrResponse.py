from typing import List

from response.GenericResponse import GenericResponse


class CdrDetails:
    def __init__(self, call_id, assistant_id, assistant_name, call_start_time, call_end_time, call_duration,
                 call_status, call_type, user_id, question_count, answer_count, tools_used, rag_tool_use,
                 satisfaction_score, sentiment, emotions, intent):
        self.call_id = call_id
        self.assistant_id = assistant_id
        self.assistant_name = assistant_name
        self.call_start_time = call_start_time
        self.call_end_time = call_end_time
        self.call_duration = call_duration
        self.call_status = call_status
        self.call_type = call_type
        self.user_id = user_id
        self.question_count = question_count
        self.answer_count = answer_count
        self.tools_used = tools_used
        self.rag_tool_use = rag_tool_use
        self.satisfaction_score = satisfaction_score
        self.sentiment = sentiment
        self.emotions = emotions
        self.intent = intent

    def __repr__(self):
        return f"CdrDetails(call_id={self.call_id}, assistant_id={self.assistant_id}, assistant_name={self.assistant_name}, " \
               f"call_start_time={self.call_start_time}, call_end_time={self.call_end_time}, call_duration={self.call_duration}, " \
               f"call_status={self.call_status}, call_type={self.call_type}, user_id={self.user_id}, " \
               f"question_count={self.question_count}, answer_count={self.answer_count}, tools_used={self.tools_used}, " \
               f"rag_tool_use={self.rag_tool_use}, satisfaction_score={self.satisfaction_score}, sentiment={self.sentiment}, " \
               f"emotions={self.emotions}, intent={self.intent})"


class GetAllCdrResponse(GenericResponse):
    def __init__(self, status_code, status, message, data: List[CdrDetails]):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return f"status_code: {self.status_code}, status: {self.status}, message: {self.message}, data: {self.data}"
