from sqlalchemy.orm import Session
from models.database_models import UserAssistantMapping


def get_assistant_mapping_repository(db: Session, email: str):
    return db.query(UserAssistantMapping).with_entities(UserAssistantMapping.assistant_id_list, UserAssistantMapping.show_default).filter(UserAssistantMapping.email == email).all()
