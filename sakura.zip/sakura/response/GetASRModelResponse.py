from response.GenericResponse import GenericResponse


class GetASRModel:
    def __init__(self, language_id, asr_model):
        self.language_id = language_id
        self.asr_model = asr_model

    def __repr__(self):
        return f' language_id: {self.language_id}, asr_model: {self.asr_model}'


class GetASRModelResponse(GenericResponse):
    def __init__(self, status_code, status, message, data: list[GetASRModel]):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return f'status_code: {self.status_code}, status: {self.status}, message: {self.message}, data: {self.data}'
