from typing import List, Dict, Any, Optional
from logger import get_logger
from config.ivr_path_config import get_non_skippable_types
from config.ivr_path_config import get_node_type_map

logger = get_logger(__name__)

class IVRPathAnalysisService:
    # Get non-skippable node types from configuration
    NON_SKIPPABLE_NODES = {node_type: "Configured non-skippable node" 
                          for node_type in get_non_skippable_types()}

    @staticmethod
    def build_parent_map(flat_array: List[Dict[str, Any]]) -> Dict[str, Optional[str]]:
        parent_map = {}
        for node in flat_array:
            if node['parent'] is not None:
                parent_map[node['id']] = node['parent']
        return parent_map

    @staticmethod
    def build_children_map(flat_array: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        children_map = {}
        for node in flat_array:
            children_map[node['id']] = node.get('children', [])
        return children_map

    @staticmethod
    def find_all_paths(flat_array: List[Dict[str, Any]], target_id: str) -> str:
        """
        Find a single path from any root node to the target node.
        Returns a string path (e.g., 1->2->'3'->4) with non-skippable nodes in single quotes.
        Uses the isSkippable field from the flat array.
        """
        node_map = {node['id']: node for node in flat_array}
        # Backtrack from target_id to root
        path = []
        current = target_id
        while current in node_map:
            path.append(current)
            parent = node_map[current]['parent']
            if parent is None:
                break
            current = parent
        path = path[::-1]  # root to target
        # Mark non-skippable nodes using isSkippable
        marked_path = [f"'{node_id}'" if not node_map[node_id].get('isSkippable', True) else str(node_id) for node_id in path]
        return '->'.join(marked_path)

    @staticmethod
    def highlight_path_with_tags(path: List[str], non_skippable_nodes: List[str], node_map: Dict[str, Any]) -> str:
        """
        Highlight a path with <red>, <green>, <yellow> tags for UI (not ANSI codes).
        """
        colored_parts = []
        for node_id in path:
            node_info = node_map.get(node_id, {})
            node_type = node_info.get('type', 'Unknown')
            node_value = node_info.get('value', '')
            node_display = f"{node_id}"
            if node_value:
                node_display += f"({node_value})"
            if node_id in non_skippable_nodes:
                colored_parts.append(f"<red><b>{node_display}</b></red>")
            elif node_type == 'Start':
                colored_parts.append(f"<green>{node_display}</green>")
            elif node_type == 'Exit':
                colored_parts.append(f"<yellow>{node_display}</yellow>")
            else:
                colored_parts.append(node_display)
        return " -> ".join(colored_parts)

    @staticmethod
    def analyze_path_for_non_skippable(path: List[str], non_skippable_nodes: List[str]) -> Dict[str, Any]:
        non_skippable_in_path = [node_id for node_id in path if node_id in non_skippable_nodes]
        return {
            'path': path,
            'has_non_skippable': len(non_skippable_in_path) > 0,
            'non_skippable_nodes': non_skippable_in_path,
            'non_skippable_count': len(non_skippable_in_path),
            'total_nodes': len(path)
        }

    @staticmethod
    def get_non_skippable_nodes(flat_array: List[Dict[str, Any]], non_skippable_types: List[str]) -> List[str]:
        """
        Return a list of node IDs whose type matches any in non_skippable_types (case-insensitive).
        """
        return [node['id'] for node in flat_array if node.get('type', '').lower() in [t.lower() for t in non_skippable_types]]

    @staticmethod
    def get_next_dc_node_id(nodes: List[Dict[str, Any]], node_id: str) -> str:
        """
        Find the node_id of a node with type "DigitCollection" in the children of the given node_id.
        If no such node is found, return the given node_id.
        
        Args:
            nodes: List of node dictionaries
            node_id: The ID of the node to search children for
            
        Returns:
            The node_id of the DigitCollection node if found, otherwise the original node_id
        """
        
        # Find the node with the given node_id
        target_node = None
        for node in nodes:
            if str(node['id']) == str(node_id):
                target_node = node
                break
        
        if not target_node:
            logger.warning(f"Target node {node_id} not found in nodes")
            return node_id
        
        # Get children of the target node
        children = target_node.get('children', [])
        
        # Search for DigitCollection node in children
        for child_id in children:
            for node in nodes:
                if str(node['id']) == str(child_id):
                    if node.get('type') == 'DigitCollection':
                        logger.info(f"Found DigitCollection node: {child_id} for parent: {node_id}")
                        return child_id
        
        logger.warning(f"No DigitCollection node found in children of {node_id}, returning original node_id")
        # If no DigitCollection node found, return original node_id
        return node_id

    @staticmethod
    def get_node_before_next_non_skippable(path_str: str, current_node_id: str) -> str:
        """
        Given a path string (e.g., 1->2->3->'4'->5->'6'->7) and a current_node_id,
        returns the node_id just before the next non-skippable node after the current_node_id.
        If current_node_id is not in the path, returns the node_id just before the first non-skippable node.
        If no such node exists, returns current_node_id.
        """
        import re
        # Split path into list, keeping non-skippable nodes with quotes
        path_nodes = re.findall(r"'[^']+'|\d+", path_str)
        # Remove quotes for comparison, but keep original for output
        path_nodes_clean = [n.strip("'") for n in path_nodes]
        # Find indices of non-skippable nodes (those with quotes)
        non_skippable_indices = [i for i, n in enumerate(path_nodes) if n.startswith("'") and n.endswith("'")]
        if not non_skippable_indices:
            return str(current_node_id)  # No non-skippable nodes in path
        # Find start index
        try:
            start_idx = path_nodes_clean.index(str(current_node_id))
        except ValueError:
            start_idx = -1  # Not found
        # Find the first non-skippable node after start_idx
        for idx in non_skippable_indices:
            if idx > start_idx:
                if idx == 0:
                    return str(current_node_id)  # No node before the first node
                return path_nodes_clean[idx-1]
        return str(current_node_id)  # No non-skippable node after current_node_id 

    @staticmethod
    def get_node_before_next_non_skippable_with_history(current_path_str: str, last_path_str: str, current_node_id: str, node_map: dict = None):
        """
        Given current and last user path strings (e.g., 1->2->3->'4'->5->'6'->7), and a current_node_id,
        - If last_path_str is None or empty, returns the node_id just before the first non-skippable node in current_path, and the path from current_node_id to that node.
        - If there is no coinciding path between the two, returns the node_id just before the first non-skippable node in current_path, and the path from current_node_id to that node.
        - If there is a coinciding path, starts after the common part and returns the node_id just before the first non-skippable node after that, and the path from current_node_id to that node.
        - If no such node exists, returns the last node id of the path and the path from current_node_id to the last node.
        - If last_path and current_path are identical, returns the last node id and the full path.
        - Uses land_before field from the flat array to determine how many nodes before the non-skippable node to land.
        """
        import re
        logger.info(f"getting node_id with current_path {current_path_str}, last_path, {last_path_str}, and current_node_id, {current_node_id}")
        def parse_path(path_str):
            if not isinstance(path_str, str) or not path_str:
                return [], []
            # Split by the '->' delimiter for robustness
            nodes = path_str.split('->')
            # Create the clean version by stripping quotes
            clean = [n.strip("'") for n in nodes]
            return nodes, clean

        curr_nodes, curr_clean = parse_path(current_path_str)
        last_nodes, last_clean = parse_path(last_path_str)
        logger.info(f"curr_clean repr: {[repr(x) for x in curr_clean]}, current_node_id repr: {repr(current_node_id)}, str(current_node_id) repr: {repr(str(current_node_id))}")

        if node_map is None:
            logger.warning("node_map not provided to get_node_before_next_non_skippable_with_history; using default land_before=1")
            node_map = {nid: {'land_before': 1} for nid in curr_clean}

        # If last_path_str is None or empty, skip comparison
        if not last_clean:
            try:
                start_idx = curr_clean.index(str(current_node_id)) + 1
            except ValueError:
                try:
                    start_idx = curr_clean.index(f"'{current_node_id}'") + 1
                except ValueError:
                    start_idx = 0
            logger.info(f"start_idx: {start_idx}")
            non_skippable_indices = [i for i, n in enumerate(curr_nodes) if n.startswith("'") and n.endswith("'")]
            for idx in non_skippable_indices:
                if idx >= start_idx:
                    non_skippable_id = curr_clean[idx]
                    land_before = node_map.get(non_skippable_id, {}).get('land_before', 1)
                    land_idx = max(0, idx - land_before)
                    result_node = curr_clean[land_idx]
                    logger.info(f"Returning result_node: {result_node}")
                    path = curr_clean[curr_clean.index(str(current_node_id)):land_idx+1] if str(current_node_id) in curr_clean else curr_clean[:land_idx+1]
                    path = [str(current_node_id)] + path[1:] if path and path[0] != str(current_node_id) else path
                    return result_node, path
            # If no non-skippable node found after current_node_id, return last node and path from current_node_id to last node
            if str(current_node_id) in curr_clean:
                idx_start = curr_clean.index(str(current_node_id))
                path = curr_clean[idx_start:]
                logger.info(f"Returning last node: {curr_clean[-1]}")
                return curr_clean[-1], path
            else:
                logger.info(f"Returning last node: {curr_clean[-1]}")
                return curr_clean[-1], curr_clean

        # Find longest common prefix
        min_len = min(len(curr_clean), len(last_clean))
        common_idx = 0
        for i in range(min_len):
            if curr_clean[i] == last_clean[i]:
                common_idx += 1
            else:
                break

        # If paths are identical, return last node and full path
        if curr_clean == last_clean:
            logger.info(f"Returning last node: {curr_clean[-1]}")
            return curr_clean[-1], curr_clean

        # Find the last common node by searching backwards
        last_common_node_idx = -1
        last_clean_unquoted = [n.strip("'") for n in last_clean]
        for i in range(len(last_clean_unquoted) - 1, -1, -1):
            node_to_find = last_clean_unquoted[i]
            if node_to_find in curr_clean:
                last_common_node_idx = curr_clean.index(node_to_find)
                break
        
        start_idx = last_common_node_idx + 1 if last_common_node_idx != -1 else 0
        logger.info(f"start_idx after last common node: {start_idx}")
        if start_idx >= len(curr_clean):
            logger.info(f"Returning last node: {curr_clean[-1]}")
            return curr_clean[-1], curr_clean

        non_skippable_indices = [i for i, n in enumerate(curr_nodes) if n.startswith("'") and n.endswith("'")]
        for idx in non_skippable_indices:
            if idx >= start_idx:
                non_skippable_id = curr_clean[idx]
                land_before = node_map.get(non_skippable_id, {}).get('land_before', 1)
                land_idx = max(0, idx - land_before)
                result_node = curr_clean[land_idx]
                logger.info(f"Returning result_node: {result_node}")
                path = curr_clean[curr_clean.index(str(current_node_id)):land_idx+1] if str(current_node_id) in curr_clean else curr_clean[:land_idx+1]
                path = [str(current_node_id)] + path[1:] if path and path[0] != str(current_node_id) else path
                return result_node, path
        # If no non-skippable node found after actual_start_idx, return last node and path from current_node_id to last node
        if str(current_node_id) in curr_clean:
            idx_start = curr_clean.index(str(current_node_id))
            path = curr_clean[idx_start:]
            logger.info(f"Returning last node: {curr_clean[-1]}")
            return curr_clean[-1], path
        else:
            logger.info(f"Returning last node: {curr_clean[-1]}")
            return curr_clean[-1], curr_clean 