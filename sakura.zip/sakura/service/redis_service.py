import asyncio
import json
import threading
import time
import traceback
import os

from dotenv import load_dotenv
import redis
from logger import get_logger
from config.config import get_redis_client, get_redis_pipeline
from utils.redis_db_manager import redis_manager
from utils.memory_cache_manager import get_memory_cache, get_user_call_record, set_user_call_record
from controllers.llm_wrapper_controller import stream_handler
from models.redis_models import UserCallRecord, UserCallCDR
from service.chat_analyser_service import analyse_transcript_filler_category
from service.claude_service import claude_stream_handler
from service.gemini_service import gemini_stream_handler
from service.llama_service import stream_handler as llama_stream_handler
from service.message_service import append_current_statement_to_user_messages
from service.structured_output_openai_service import call_vini
from sockets.sockets import sio_server
from utils.function_call_util_functions import update_cdr_record_with_expiration

from utils.llm_util import set_buildup_prompt
from utils.prompt_template import no_reply_prompt
from utils.utils import adjust_messages_length


from utils.thread_pool import get_named_thread_pool
from concurrent.futures import ThreadPoolExecutor


load_dotenv()
logger = get_logger(__name__)

# PERFORMANCE FIX: Use separated Redis databases
# Main database for user records and timing-critical operations
redis_client = redis_manager.get_main_client()
# CDR database for heavy JSON operations (isolated from timing-critical ops)
cdr_redis_client = redis_manager.get_cdr_client()
# Expiry database for key expiration event monitoring
expiry_redis_client = redis_manager.get_expiry_client()
redis_client_log = None
# Remove redis_executor for event subscription
# redis_executor = get_named_thread_pool(pool_name='redis_listeners', max_workers=5)

thread_pool_max_workers = int(os.getenv('THREAD_POOL_MAX_WORKERS'))
call_executor = get_named_thread_pool(pool_name='call_execution', max_workers=thread_pool_max_workers)
alarm_executor = get_named_thread_pool(pool_name='alarm_execution', max_workers=5)
vini_assistant_ids = os.getenv('VINI_ASSISTANT_ID', '').split(',')
vini_assistant_ids = [id.strip() for id in vini_assistant_ids]

# Configurable async operation timeout (in seconds)
ASYNC_OPERATION_TIMEOUT = float(os.getenv('ASYNC_OPERATION_TIMEOUT', '10.0'))
logger.info(f"Redis Service initialized with ASYNC_OPERATION_TIMEOUT = {ASYNC_OPERATION_TIMEOUT}s")

# PERFORMANCE FIX: Memory cache expiry callback system
memory_cache = None

def initialize_memory_expiry_callbacks():
    """Initialize memory cache expiry callbacks to replace Redis pubsub"""
    global memory_cache
    try:
        memory_cache = get_memory_cache()

        # Register callback for utterance and wait key expiry
        memory_cache.register_expiry_callback("utterance", handle_memory_expiry)
        memory_cache.register_expiry_callback("wait", handle_memory_expiry)

        logger.info("Memory cache expiry callbacks registered")
        return True
    except Exception as e:
        logger.error(f"REDIS_SERVICE: Failed to initialize memory cache callbacks: {e}")
        return False

def handle_memory_expiry(call_id: str, key_type: str, cache_key: str):
    """
    Handle memory cache key expiry - replaces Redis pubsub handle_expiration
    This function is called when utterance/wait keys expire in memory cache
    """
    try:
        logger.info(f"Memory key {cache_key} expired for call_id {call_id} at {int(round(time.time() * 1000))}")

        # Use async manager to handle the expiry in proper async context
        from utils.scalable_async_manager import get_async_manager
        async_manager = get_async_manager()

        # Route expiry to proper handler based on key type
        if key_type in ["utterance", "wait"]:
            # Run the expiry handler asynchronously with increased timeout for LLM stream processing
            try:
                # PERFORMANCE FIX: Use configurable timeout instead of 30s to prevent cascade failures
                # Memory cache expiry operations should complete quickly, configurable timeout allows tuning
                logger.debug(f"Starting memory expiry processing for {cache_key} with timeout {ASYNC_OPERATION_TIMEOUT}s")
                async_manager.run_coroutine_safe(
                    handle_memory_key_expiration(call_id, key_type, cache_key),
                    key=str(call_id),
                    timeout=ASYNC_OPERATION_TIMEOUT  # Configurable timeout from ASYNC_OPERATION_TIMEOUT env var
                )
            except Exception as async_error:
                error_type = type(async_error).__name__
                if "TimeoutError" in error_type:
                    logger.error(f"TIMEOUT: Memory expiry processing for {cache_key} timed out after {ASYNC_OPERATION_TIMEOUT}s - {async_error}")
                elif "RuntimeError" in error_type and "circuit breaker" in str(async_error).lower():
                    logger.error(f"CIRCUIT_BREAKER: Memory expiry processing for {cache_key} blocked by circuit breaker - {async_error}")
                else:
                    logger.error(f"Async manager failed for {cache_key}: {error_type} - {async_error}")
        else:
            logger.warning(f"Unknown key type for memory expiry: {key_type}")

    except Exception as e:
        logger.error(f"Error in handle_memory_expiry for {cache_key}: {e}", exc_info=True)

async def handle_memory_key_expiration(call_id: str, key_type: str, cache_key: str):
    """
    Async handler for memory cache key expiration - replaces handle_expiration function
    This processes the actual LLM call when utterance/wait keys expire
    """
    start_time = time.time()
    try:
        logger.info(f"handle_memory_key_expiration called for call_id - {call_id} with key_type - {key_type}")

        # PERFORMANCE FIX: Retrieve user call record from memory instead of Redis
        user_call_record_data = get_user_call_record(str(call_id))

        if user_call_record_data is not None:
            try:
                user_call_record = UserCallRecord(**user_call_record_data)
            except Exception as e:
                logger.error(f"Exception while creating UserCallRecord from memory: {e} for data {user_call_record_data}",exc_info=True)
                return

            # Check user state before processing to avoid duplicate processing
            if user_call_record.processing:
                logger.info(f"Call {call_id} already in processing state, skipping to prevent duplicates")
                return

            transcript = append_current_statement_to_user_messages(user_call_record.userMessage, "")
            user_message = []
            user_call_record.userMessage = user_message
            llm_message = user_call_record.llmMessage
            llm_message = adjust_messages_length(call_id, llm_message)
            user_call_record.processing = True
            user_call_record.listening = False
            user_call_record.speaking = True
            user_call_record.interrupt = False

            # check llm model from user_call_record
            llm_model = user_call_record.llmModel
            assistantId = user_call_record.assistantId

            if key_type == "no_reply" and user_call_record.consecutive_no_reply_count > 2:
                await sio_server.disconnect(user_call_record.socketId)
                return

            if key_type == "no_reply":
                user_call_record.llmMessage.append({"role": "system", "content": no_reply_prompt})
                user_call_record.consecutive_no_reply_count += 1
                # PERFORMANCE FIX: Use memory instead of Redis for user record storage
                set_user_call_record(str(call_id), vars(user_call_record))

            if assistantId in vini_assistant_ids:
                logger.info(f"Assistant ID is {assistantId}, using call vini")
                if key_type != "no_reply":
                    llm_message.append({"role": "user", "content": transcript})
                    user_call_record.llmMessage = llm_message
                    # PERFORMANCE FIX: Use memory instead of Redis for user record storage
                    set_user_call_record(str(call_id), vars(user_call_record))
                    await call_vini(call_id)
                    return
            else:
                logger.info(f"Assistant ID is {assistantId}, using standard LLM processing")
                if key_type != "no_reply":
                    logger.debug(f"APPENDING user message to llmMessage array: '{transcript}'")
                    llm_message.append({"role": "user", "content": transcript})
                    user_call_record.llmMessage = llm_message
                    logger.debug(f"llmMessage array after append: {[m.get('role', 'no_role') for m in llm_message]}")
                    # PERFORMANCE FIX: Use memory instead of Redis for user record storage
                    set_user_call_record(str(call_id), vars(user_call_record))
                else:
                    logger.error(f"CRITICAL BUG: User message NOT appended! key_type='{key_type}' treated as 'no_reply'")

                if llm_model == "gpt-3.5-turbo" or llm_model == "gpt-4o-mini" or llm_model == "gpt-4o" or llm_model=="gpt-4.1-mini":
                    await stream_handler(model_name="gpt-3.5-turbo", req_id=call_id)
                elif llm_model == "llama3-8b-8192":
                    await llama_stream_handler(model_name="llama3-8b-8192", req_id=call_id)
                elif llm_model == "gemini-1.5-flash-latest":
                    await gemini_stream_handler(model_name="gemini", req_id=call_id)
                elif llm_model == "claude-3-5-sonnet-20240620":
                    await claude_stream_handler(model_name="claude-3-sonnet-20240229", req_id=call_id)

            # call_executor.submit(handle_buildup_prompt, transcript, call_id)
        else:
            execution_time = (time.time() - start_time) * 1000  # Convert to milliseconds
            logger.info(f"No user call record found in memory for call_id: {call_id} - completed in {execution_time:.2f}ms")
            return  # Early return when no user call record is found
    except Exception as e:
        execution_time = (time.time() - start_time) * 1000  # Convert to milliseconds
        logger.error(f"Exception in handle_memory_key_expiration - {e} - failed after {execution_time:.2f}ms",exc_info=True)
    finally:
        execution_time = (time.time() - start_time) * 1000  # Convert to milliseconds
        logger.debug(f"handle_memory_key_expiration for {call_id} completed in {execution_time:.2f}ms")


def push_to_queue(call_id, data):
    try:
        request_json = json.dumps({"call_id": call_id, "data": data})
        logger.info(f"Pushing data to queue: {request_json}")
        redis_client.lpush(call_id, request_json)
    except Exception as e:
        logger.error(f'Error while pushing to queue in redis_service: {e}',exc_info=True)


def pop_from_queue(queue_name):
    try:
        response_json = redis_client.brpop(queue_name, timeout=0)[1]
        logger.info(f"Popping data from queue: {response_json}")
        response = json.loads(response_json)
        logger.info(f"Response: {response}")
    except Exception as e:
        logger.error(f'Error while popping from queue in redis_service: {e}',exc_info=True)


def is_queue_empty(queue_name):
    return redis_client.llen(queue_name) == 0


def check_key_exists(key):
    return redis_client.exists(key)


def get_redis_client_log():
    global redis_client_log
    if redis_client_log is None:
        redis_client_log = redis.StrictRedis(host='localhost', port=6379, db=2, decode_responses=True)
        logger.info("Initialized Redis client log on db=2")
    return redis_client_log


def listen_for_messages(channel, callback):
    """Listens for messages on a Redis channel and calls the callback function."""
    pubsub = redis_client.pubsub()
    pubsub.subscribe(channel)
    logger.info(f"Subscribed to Redis channel: {channel}")
    for message in pubsub.listen():
        if message['type'] == 'pmessage':
            try:
                data = json.loads(message['data'])
                # PERFORMANCE FIX: Direct callback execution - eliminates thread pool explosion
                callback(data)
            except (json.JSONDecodeError, TypeError) as e:
                logger.error(f"Could not parse message data: {message['data']}, error: {e}",exc_info=True)


def subscribe_to_redis():
    try:
        # Use expiry client specifically for listening to expiry events on DB=1
        expiry_client = redis_manager.get_expiry_client()
        pubsub = expiry_client.pubsub()
        # Subscribe to both socket events and key expiration events
        pubsub.psubscribe('socket_*', '__keyevent@1__:expired')
        logger.info("Subscribed to socket_* channels and key expiration events on db=1")
        for message in pubsub.listen():
            if message['type'] == 'pmessage':
                logger.info(f"Received Redis message: {message}")
                # PERFORMANCE FIX: Direct routing to AsyncLoops - eliminates thread pool explosion
                sync_wrapper(message)
    except Exception as e:
        logger.error(f"Exception in subscribe_to_redis - {e}",exc_info=True)


def start_listener_thread():
    try:
        listener_thread = threading.Thread(target=subscribe_to_redis, daemon=True)
        listener_thread.start()
    except Exception as e:
        logger.error(f"Exception in start_listener_thread - {e}",exc_info=True)


_redis_listener_started = False

def start_event_loop_in_thread():
    global _redis_listener_started
    if _redis_listener_started:
        return
    _redis_listener_started = True
    try:
        def thread_function():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            loop.run_until_complete(subscribe_to_redis())
            loop.run_forever()

        listener_thread = threading.Thread(target=thread_function, daemon=True)
        listener_thread.start()
    except Exception as e:
        logger.error(f"Exception in start_event_loop_in_thread - {e}",exc_info=True)

def sync_wrapper(message):
    """PERFORMANCE OPTIMIZED: Direct AsyncLoop routing without thread pool intermediary"""
    try:
        from utils.scalable_async_manager import run_coroutine_safe
        
        # Extract the key from the message based on the pattern
        # Since we're using decode_responses=True, we get strings instead of bytes
        if message['pattern'] == '__keyevent@1__:expired':
            redis_key = message['data']
        else:
            # Handle socket events
            redis_key = message['data']
            
        logger.info(f"Processing Redis message for key: {redis_key}")
        
        # Use call_id as routing key to distribute across all 8 AsyncLoops
        # This ensures proper load balancing instead of everything going to loop 0
        call_id = redis_key.split(':')[0] if ':' in redis_key else redis_key

        # PERFORMANCE FIX: Direct routing to AsyncLoop - eliminates 10s thread pool delays
        run_coroutine_safe(
            handle_expiration({'data': redis_key}),
            key=call_id,
            timeout=30.0
        )
        
    except Exception as e:
        logger.error(f"Exception in sync_wrapper - {e}", exc_info=True)


async def handle_expiration(message):
    try:
        redis_key = message['data']
        logger.info(f"Key {redis_key} expired in Redis at {int(round(time.time() * 1000))}")
        
        # Handle CDR key expiration (format: call_id_cdr)
        if "_cdr" in redis_key:
            call_id = redis_key.replace("_cdr", "")
            logger.info(f"CDR key {redis_key} expired for call_id {call_id}")
            
            # Try to retrieve existing CDR data before it fully expires
            try:
                # CRITICAL FIX: CDR is stored as hash, not JSON string
                # Import hash optimizer here to avoid circular imports
                from utils.redis_hash_optimizer import RedisHashOptimizer

                hash_optimizer = RedisHashOptimizer(cdr_redis_client)
                cdr_data = hash_optimizer.get_cdr_hash(call_id)

                if cdr_data:
                    # CDR still exists, extend its life
                    user_call_cdr_record = UserCallCDR(**cdr_data)
                    logger.info(f"Extending CDR life for call_id {call_id}")
                    update_cdr_record_with_expiration(call_id, user_call_cdr_record)
                else:
                    logger.info(f"CDR key {redis_key} already fully expired for call_id {call_id}")
            except Exception as e:
                logger.error(f"Error handling CDR expiration for {redis_key}: {e}")
            return
        
        # Handle regular call key expiration (format: call_id:key_type)
        pattern = redis_key.split(":")
        call_id = pattern[0]
        key_type = pattern[1] if len(pattern) > 1 else None
        
        logger.info(f"handle_expiration called for call_id - {call_id} with key_type - {key_type}")
        
        # PERFORMANCE OPTIMIZATION: Removed processing lock - use atomic state checks instead
        # The user_call_record.processing state check below is sufficient for preventing duplicates
        
        try:
            # Use the single redis_client instance
            logger.debug(f"get key {call_id} from Redis")
            serialized_user_call_record = redis_client.get(call_id)
            
            if serialized_user_call_record is not None:
                try:
                    data = json.loads(serialized_user_call_record)
                    user_call_record = UserCallRecord(**data)
                except Exception as e:
                    logger.error(f"Exception while creating UserCallRecord: {e} for data {serialized_user_call_record}",exc_info=True)
                    return
                    
                # Check user state before processing to avoid duplicate processing
                if user_call_record.processing:
                    logger.info(f"Call {call_id} already in processing state, skipping to prevent duplicates")
                    return
                    
                transcript = append_current_statement_to_user_messages(user_call_record.userMessage, "")
                user_message = []
                user_call_record.userMessage = user_message
                llm_message = user_call_record.llmMessage
                llm_message = adjust_messages_length(call_id, llm_message)
                user_call_record.processing = True
                user_call_record.listening = False
                user_call_record.speaking = True
                user_call_record.interrupt = False
                
                # check llm model from user_call_record   
                llm_model = user_call_record.llmModel
                assistantId = user_call_record.assistantId

                if key_type == "no_reply" and user_call_record.consecutive_no_reply_count > 2:
                    await sio_server.disconnect(user_call_record.socketId)
                    return

                if key_type == "no_reply":
                    user_call_record.llmMessage.append({"role": "system", "content": no_reply_prompt})
                    user_call_record.consecutive_no_reply_count += 1
                    # PERFORMANCE OPTIMIZATION: Use batched operations
                    batch_redis_operations(call_id, user_call_record)

                if assistantId in vini_assistant_ids:
                    logger.info(f"Assistant ID is {assistantId}, using call vini")
                    if key_type != "no_reply":
                        llm_message.append({"role": "user", "content": transcript})
                        user_call_record.llmMessage = llm_message
                        # PERFORMANCE OPTIMIZATION: Use batched operations
                        batch_redis_operations(call_id, user_call_record)
                        await call_vini(call_id)
                        return
                else:
                    logger.info(f"Assistant ID is {assistantId}, using standard LLM processing")
                    logger.debug(f"CRITICAL DEBUG: key_type='{key_type}', transcript='{transcript}'")
                    logger.debug(f"CRITICAL DEBUG: key_type != 'no_reply' = {key_type != 'no_reply'}")
                    if key_type != "no_reply":
                        logger.debug(f"APPENDING user message to llmMessage array: '{transcript}'")
                        llm_message.append({"role": "user", "content": transcript})
                        user_call_record.llmMessage = llm_message
                        logger.debug(f"llmMessage array after append: {[m['role'] for m in llm_message]}")
                        # PERFORMANCE OPTIMIZATION: Use batched operations
                        batch_redis_operations(call_id, user_call_record)
                    else:
                        logger.error(f"CRITICAL BUG: User message NOT appended! key_type='{key_type}' treated as 'no_reply'")

                    if llm_model == "gpt-3.5-turbo" or llm_model == "gpt-4o-mini" or llm_model == "gpt-4o" or llm_model=="gpt-4.1-mini":
                        await stream_handler(model_name="gpt-3.5-turbo", req_id=call_id)
                    elif llm_model == "llama3-8b-8192":
                        await llama_stream_handler(model_name="llama3-8b-8192", req_id=call_id)
                    elif llm_model == "gemini-1.5-flash-latest":
                        await gemini_stream_handler(model_name="gemini", req_id=call_id)
                    elif llm_model == "claude-3-5-sonnet-20240620":
                        await claude_stream_handler(model_name="claude-3-sonnet-20240229", req_id=call_id)

                # call_executor.submit(handle_buildup_prompt, transcript, call_id)
            else:
                logger.info(f"No serialized data found for call_id: {call_id}")
        except Exception as processing_error:
            logger.error(f"Error in call processing for {call_id}: {processing_error}", exc_info=True)
    except Exception as e:
        logger.error(f"Exception in handle_expiration - {e}",exc_info=True)
def update_key_in_redis_with_expiration_timer(key, data):
    """PERFORMANCE OPTIMIZED: Batch TTL and SET operations"""
    try:
        # Use pipeline to batch operations - reduces round trips
        pipe = get_redis_pipeline()
        pipe.ttl(key)
        pipe.set(key, data)
        results = pipe.execute()

        current_ttl = results[0]
        if current_ttl > 0:
            redis_client.expire(key, current_ttl)
    except Exception as e:
        logger.error(f"Error in batched Redis update: {e}", exc_info=True)
        # Fallback to individual operations
        current_ttl = redis_client.ttl(key)
        redis_client.set(key, data)
        if current_ttl > 0:
            redis_client.expire(key, current_ttl)

def batch_redis_operations(call_id: str, user_call_record: UserCallRecord):
    """PERFORMANCE OPTIMIZATION: Store user record in memory (Redis operations removed)"""
    try:
        # PERFORMANCE FIX: Store user record in memory instead of Redis
        logger.debug(f"SAVING USER RECORD TO MEMORY: call_id={call_id}, llmMessage={[m['role'] for m in user_call_record.llmMessage]}")
        set_user_call_record(str(call_id), vars(user_call_record))
        logger.debug(f"User record stored in memory for call {call_id}")

    except Exception as e:
        logger.error(f"Error in batch Redis operations for {call_id}: {e}", exc_info=True)
        # Fallback to individual operations
        serialized_data = json.dumps(vars(user_call_record))
        redis_client.set(call_id, serialized_data)


def handle_buildup_prompt(query: str, call_id: str):
    start_time = time.time()
    result = analyse_transcript_filler_category(query, assistant_id=None)
    end_time = time.time()
    logger.info(f"Time taken to get buildup prompt - {end_time - start_time} for query - {query}")
    set_buildup_prompt(call_id=call_id, prompt_category=result)
