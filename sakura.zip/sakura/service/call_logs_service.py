from datetime import datetime

from config.database_config import SessionLocal
from logger import get_logger
from models.request_models import CallLogsRequest
from repository.call_logs_repository import get_call_logs_asc, get_call_logs_desc, save
from response.GenericResponse import GenericResponse
from response.GetCallLogsResponse import GetCallLogsResponse

logger = get_logger(__name__)


def get_call_logs_service(email: str, order: str):
    try:
        db = SessionLocal()
        logger.info(f"Getting call_logs for {email}")
        data = None
        if order == "asc":
            data = get_call_logs_asc(db, email)
        elif order == "desc":
            data = get_call_logs_desc(db, email)
        return GetCallLogsResponse(status_code=200, status="SUCCESS", message="Data fetched successfully", data=data)
    except Exception as e:
        logger.error(f"Error getting call_logs for {email}")
        return GenericResponse(status_code=500, status="Error while fetching Call Logs",
                               message=f"Error while fetching Call Logs: {e}")


def save_call_logs_service(request: CallLogsRequest):
    db = SessionLocal()
    try:
        logger.info(f"Save Call Logs Service hit for {request.id}")
        request.date = datetime.now()
        save(db, request)
        return GenericResponse(status_code=200, status="SUCCESS", message="Call Logs Saved Successfully")
    except Exception as e:
        logger.error(f"Error saving Call Logs Service hit for {request.id}")
        return GenericResponse(status_code=500, status="Error while saving Call Logs",
                               message=f"Error while saving Call Logs: {e}")
