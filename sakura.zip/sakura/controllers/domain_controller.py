from typing import Optional
from fastapi import APIRouter
from logger import get_logger
from service.domain_service import check_domain_service, add_domain_service, remove_domain_service, get_audio_zip_service, get_singular_audio_service

from models.request_models import AudioRequest, SingleAudioRequest

logger = get_logger(__name__)
router = APIRouter()


@router.get("/get_domain", tags=["Domain Whitelist"])
def check_domain(domain: str):
    logger.info(f"Checking Domain Whitelist for {domain}")
    return check_domain_service(domain)


@router.post("/add_domain", tags=["Domain Whitelist"])
def add_domain(domain: str, name: Optional[str]):
    logger.info(f"add_domain controller hit for {domain}")
    return add_domain_service(domain, name)


@router.put("/remove_domain", tags=["Domain Whitelist"])
def remove_domain(domain: str):
    logger.info(f"remove_domain controller hit for {domain}")
    return remove_domain_service(domain)


@router.post("/get_audio_zip", tags=["Audio Generation"])
def get_audio_zip(request: AudioRequest):
    logger.info(f"get_audio_zip controller hit for {request}")
    return get_audio_zip_service(request)


@router.post("/get_singular_audio", tags=["Audio Generation"])
def get_singular_audio(request: SingleAudioRequest):
    logger.info(f"get_singular_audio controller hit for {request}")
    return get_singular_audio_service(request)