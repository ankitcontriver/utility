import os

from dotenv import load_dotenv
from openai import OpenAI, AzureOpenAI

from logger import get_logger
from models.request_models import IntentAnalyserRequest
from utils.llm_util import call_openai_based_on_model_and_systemmessage
from utils.prompt_template import speaking_state_intent_analyser, \
    listening_state_intent_analyser
from utils.prompt_template import transcription_intent_analyser_prompt
import asyncio
from utils.alarm_utils import send_alarm, run_alarm_in_thread

load_dotenv()
logger = get_logger(__name__)
api_key = os.getenv("OPENAI_API_KEY")

client = OpenAI(api_key=api_key)

# Removed hardcoded Azure client - now using database-cached configurations
# All LLM operations now use multi-client configuration system


def chat_intent_analyser(intent_analyser_req: IntentAnalyserRequest):
    try:
        logger.info(f"chat_intent_analyser request - {intent_analyser_req}")

        if intent_analyser_req.is_bot_speaking:
            system_message = speaking_state_intent_analyser
        else:
            system_message = listening_state_intent_analyser

        user_message = [{"role": "system", "content": system_message}, {"role": "user", "content":
            intent_analyser_req.transcript}]

        logger.info(f"User Message - {user_message}")
        response = call_openai_based_on_model_and_systemmessage("gpt-4o-mini", user_message, assistant_id=None)
        run_alarm_in_thread(send_alarm(alarm_type='Azure_OpenAI', remarks='Azure API working fine', status='clear'))
        return {"status": "success", "statuscode": 200, "data": response}
    except Exception as e:
        logger.error(f"Error in chat_analyser_service -> {e}")
        run_alarm_in_thread(send_alarm(alarm_type='Azure_OpenAI', remarks=str(e), status='raise'))


def analyse_transcript_filler_category(query, assistant_id=None):
    logger.info(f"analyse_transcript_filler_category called with query - {query}")
    try:
        system_prompt = """Please give a category for the given statement from the given categories. If the category doesn't exist, return "other". The response should be in one word. The categories are current_affairs, food_restaurants, general_knowledge, health_queries, recipes_cooking, sports, time_queries, travel_tourism, weather, technology, entertainment, finance, fashion, education, fitness, shopping, home_improvement, automotive, parenting, career_job_search, diy_crafts, relationships, pets, gardening, hobbies.
        """

        user_message = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query}
        ]

        # Use the multi-client configuration system
        response = call_openai_based_on_model_and_systemmessage("gpt-3.5-turbo", user_message, assistant_id=assistant_id)
        
        logger.info(f"analyse_transcript_filler_category completion response - {response}")
        return response.strip()
    except Exception as e:
        logger.warning(f"Error in analyse_transcript_filler_category - {e}")
        return "other"


def analyse_user_transcript(query):
    logger.info(f"analyse_user_transcript called with query - {query}")
    try:
        system_prompt = transcription_intent_analyser_prompt

        # Create the completion request
        completion = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": query,
                },
            ],
        )

        # Extract and return the model's response
        return completion.choices[0].message.content
    except Exception as e:
        logger.error(f"Error in analyse_user_transcript - {e}, exc_info=True")
