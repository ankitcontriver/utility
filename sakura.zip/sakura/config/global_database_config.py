import asyncio
import os
import time
from contextlib import contextmanager

from dotenv import load_dotenv
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import OperationalError, DisconnectionError, DatabaseError, TimeoutError
from models.global_database_models import SecurityProperties
from utils.alarm_utils import send_alarm
from logger import get_logger

logger = get_logger(__name__)

load_dotenv()

# Global database URL for whitelisted settings table only
GLOBAL_DATABASE_URL = os.getenv("GLOBAL_DATABASE_URL")
country = os.getenv('DEFAULT_COUNTRY')
operator = os.getenv('DEFAULT_OPERATOR')

def test_global_database_connection(engine):
    """Test global database connection with retry mechanism"""
    max_retries = 3
    delay = 1
    
    for attempt in range(max_retries):
        try:
            logger.info(f"Testing global database connection, attempt {attempt + 1}/{max_retries}")
            with engine.connect() as connection:
                connection.execute(text("SELECT 1"))
                logger.info("Global database connection test successful")
                return True
        except Exception as e:
            logger.warning(f"Global database connection test failed, attempt {attempt + 1}/{max_retries}: {e}")
            if attempt < max_retries - 1:
                logger.info(f"Retrying in {delay * (2 ** attempt)}s...")
                time.sleep(delay * (2 ** attempt))
            else:
                logger.error(f"All global database connection tests failed after {max_retries} attempts")
                return False

try:
    global_engine = create_engine(
        GLOBAL_DATABASE_URL,
        echo=True,
        pool_size=5,  # Very small pool since we only have one table
        max_overflow=10,
        pool_timeout=30,
        pool_recycle=1800
    )
    
    # Test connection before proceeding
    if test_global_database_connection(global_engine):
        logger.info("Global database engine created and connection verified")
        asyncio.run(send_alarm(
            operator=operator,
            country=country,
            alarm_type='DB_Connection', 
            remarks="Global DB Connected", 
            status='clear'
        ))
    else:
        logger.error("Failed to establish global database connection after retries")
        # Send alarm for connection failure after all retries
        asyncio.run(send_alarm(
            operator=operator,
            country=country,
            alarm_type='DB_Connection', 
            remarks="Failed to establish Global DB connection after retries", 
            status='raise'
        ))
        raise Exception("Global database connection failed after retries")
        
except Exception as e:
    logger.error(f"Error creating global database engine: {e}")
    # Send alarm for engine creation failure
    asyncio.run(send_alarm(
        operator=operator,
        country=country,
        alarm_type='DB_Connection', 
        remarks=f"Global DB engine creation failed: {str(e)}", 
        status='raise'
    ))
    raise

# Create the original session maker for global database
_OriginalGlobalSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=global_engine)

# Override GlobalSessionLocal with retry logic
def GlobalSessionLocal():
    """GlobalSessionLocal with built-in retry logic."""
    max_retries = 3
    delay = 1
    
    for attempt in range(max_retries):
        try:
            # Try to create session
            session = _OriginalGlobalSessionLocal()
            
            # Test the connection by executing a simple query
            session.execute(text("SELECT 1"))
            
            # If we get here, connection succeeded
            if attempt > 0:  # Only log if we had to retry
                logger.info(f"Global database connection succeeded after {attempt + 1} attempts")
            
            return session
            
        except (OperationalError, DisconnectionError, DatabaseError, TimeoutError) as e:
            if attempt < max_retries - 1:
                logger.warning(f"Global database connection failed, attempt {attempt + 1}/{max_retries}. Retrying in {delay * (2 ** attempt)}s...")
                time.sleep(delay * (2 ** attempt))
                continue
            else:
                # All retries failed - log error but don't send alarm yet
                # Let the calling function handle the alarm after all retries
                logger.error(f"Global database connection failed after {max_retries} attempts. Final error: {e}", exc_info=True)
                raise e
        except Exception as e:
            # For non-database errors, don't retry
            logger.error(f"Non-database error in GlobalSessionLocal: {e}", exc_info=True)
            raise e

@contextmanager
def get_global_db():
    """Dependency that provides a global database session with retry logic."""
    db = None
    try:
        db = GlobalSessionLocal()
        yield db  # Provides a session to the caller
    except Exception as e:
        logger.error(f"Global database session error: {e}")
        # Don't send alarm here - let the calling function handle it after retries
        raise
    finally:
        if db:
            db.close()  # Ensures the session is closed after use 

def create_security_properties_table():
    """Create only the security_properties table in global database"""
    try:
        if test_global_database_connection(global_engine):
            # Create only the SecurityProperties table
            SecurityProperties.__table__.create(global_engine, checkfirst=True)
            logger.info("Security properties table created successfully in global DB")
        else:
            logger.error("Cannot create security properties table - global database connection failed after retries")
            raise Exception("Global database connection failed after retries")
    except Exception as e:
        logger.error(f"Error creating security properties table in global database: {e}")
        raise 