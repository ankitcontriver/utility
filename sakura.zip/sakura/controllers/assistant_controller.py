from fastapi import APIRouter

from logger import get_logger
from service.assistant_service import get_assistants_service

logger = get_logger(__name__)

router = APIRouter()


@router.get("/get_assistants", tags=["Assistants Mapping"])
def get_assistants(email: str):
    logger.info(f"get_assistants controller called for email: {email}")
    return get_assistants_service(email)
