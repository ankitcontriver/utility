from response.GenericResponse import GenericResponse


class GetVoiceList:
    def __init__(self, id, language_code, voice_name, language_display_name, gender, sample_text):
        self.id = id
        self.language_code = language_code
        self.voice_name = voice_name
        self.language_display_name = language_display_name
        self.gender = gender
        self.sample_text = sample_text

    def __repr__(self):
        return f"GetVoiceList(id={self.id}, language_code={self.language_code}, voice_name={self.voice_name}, language_display_name={self.language_display_name}, gender={self.gender}, sample_text={self.sample_text})"


class GetVoiceListResponse(GenericResponse):
    def __init__(self, status_code, status, message, data: list[GetVoiceList]):
        super().__init__(status_code=status_code, status=status, message=message)
        self.data = data

    def __repr__(self):
        return f"GetVoiceListResponse(status_code={self.status_code}, status={self.status}, message={self.message}, data={self.data})"
