from sqlalchemy.orm import Session
from models.database_models import Configuration


def get_config_by_key(db: Session, key: str):
    return db.query(Configuration).filter(Configuration.config_key==key).first()
