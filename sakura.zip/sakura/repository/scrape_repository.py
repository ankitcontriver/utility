from sqlalchemy.orm import Session
from models.database_models import ScrapedData
from enums.scrape_status_enum import ScrapeStatus


def get_scraped_data(db: Session, URL: str):
    return db.query(ScrapedData).filter(ScrapedData.base_url == URL).first()


def add_scraped_data(db: Session, data: ScrapedData):
    db.add(data)
    db.commit()


def update_data(db: Session, data: ScrapedData, update: str, status: ScrapeStatus = ScrapeStatus.PROCESSED):
    data.status = status
    data.summary = update
    db.commit()
