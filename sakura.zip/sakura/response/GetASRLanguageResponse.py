from response.GenericResponse import GenericResponse


class GetASRLanguage:
    def __init__(self, id, country_specific_language_id, country_specific_language_name):
        self.id = id
        self.country_specific_language_id = country_specific_language_id
        self.country_specific_language_name = country_specific_language_name

    def __repr__(self):
        return f"id: {self.id}, country_specific_language_id: {self.country_specific_language_id}, country_specific_language_name: {self.country_specific_language_name}"


class GetASRLanguageResponse(GenericResponse):
    def __init__(self, status, status_code, message, data: list[GetASRLanguage]):
        super().__init__(status_code, status, message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, status_code: {self.status_code}, message: {self.message}, data: {self.data}"
