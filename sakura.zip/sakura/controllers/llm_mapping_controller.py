from fastapi import APIRouter
from logger import get_logger
from service.llm_mapping_service import get_llm_model as get_llm_model_service

logger = get_logger(__name__)

router = APIRouter()


@router.get("/get_llm_model", tags=["LLM Mapping"])
def get_llm_model(language: str, avatar_id: str):
    logger.info(f"get_llm_model controller called for language : {language}, avatar_id : {avatar_id}")
    return get_llm_model_service(language, avatar_id)
