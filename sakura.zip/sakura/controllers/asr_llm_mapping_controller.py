from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Dict
from config.database_config import SessionLocal
from repository.asr_llm_mapping_repository import (
    get_all_active_asr_llm_mappings,
    get_asr_llm_mapping_by_op_co,
    create_asr_llm_mapping,
    update_asr_llm_mapping,
    delete_asr_llm_mapping
)
from service.multi_client_config_service import multi_client_manager
from logger import get_logger
from pydantic import BaseModel

logger = get_logger(__name__)
router = APIRouter(prefix="/asr-llm-mapping", tags=["Multi-Client Configuration"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class ASRLLMMappingCreate(BaseModel):
    op_co: str
    stt_provider: str = None
    stt_region: str = None
    stt_key: str = None
    llm_provider: str = None
    llm_api: str = None
    llm_key: str = None
    llm_model: str = None
    tts_provider: str = None
    tts_api: str = None
    tts_key: str = None
    perplexity_api: str = None
    perplexity_key: str = None
    perplexity_model: str = None

@router.get("/stats")
async def get_configuration_stats():
    """Get current configuration statistics and hit counts"""
    try:
        stats = multi_client_manager.get_configuration_stats()
        return {
            "status": "success", 
            "data": stats,
            "total_configurations": len(stats)
        }
    except Exception as e:
        logger.error(f"Error getting stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/reload")
async def reload_configurations():
    """Reload configurations from database"""
    try:
        success = multi_client_manager.load_configurations()
        if success:
            return {"status": "success", "message": "Configurations reloaded successfully"}
        else:
            raise HTTPException(status_code=500, detail="Failed to reload configurations")
    except Exception as e:
        logger.error(f"Error reloading configurations: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/")
async def get_all_mappings(db: Session = Depends(get_db)):
    """Get all ASR/LLM mappings"""
    try:
        mappings = get_all_active_asr_llm_mappings(db)
        return [
            {
                "id": m.id,
                "op_co": m.op_co,
                "llm_provider": m.llm_provider,
                "llm_model": m.llm_model,
                "tts_provider": m.tts_provider,
                "stt_provider": m.stt_provider,
                "perplexity_api": m.perplexity_api,
                "perplexity_model": m.perplexity_model
            }
            for m in mappings
        ]
    except Exception as e:
        logger.error(f"Error getting mappings: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{op_co}")
async def get_mapping(op_co: str, db: Session = Depends(get_db)):
    """Get specific ASR/LLM mapping by operator_country"""
    try:
        mapping = get_asr_llm_mapping_by_op_co(db, op_co)
        if not mapping:
            raise HTTPException(status_code=404, detail=f"Mapping not found for {op_co}")
        
        return {
            "id": mapping.id,
            "op_co": mapping.op_co,
            "stt_provider": mapping.stt_provider,
            "stt_region": mapping.stt_region,
            "stt_key": mapping.stt_key,
            "llm_provider": mapping.llm_provider,
            "llm_api": mapping.llm_api,
            "llm_key": mapping.llm_key,
            "llm_model": mapping.llm_model,
            "tts_provider": mapping.tts_provider,
            "tts_api": mapping.tts_api,
            "tts_key": mapping.tts_key,
            "perplexity_api": mapping.perplexity_api,
            "perplexity_key": mapping.perplexity_key,
            "perplexity_model": mapping.perplexity_model
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting mapping for {op_co}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/")
async def create_mapping(mapping: ASRLLMMappingCreate, db: Session = Depends(get_db)):
    """Create new ASR/LLM mapping"""
    try:
        existing = get_asr_llm_mapping_by_op_co(db, mapping.op_co)
        if existing:
            raise HTTPException(status_code=400, detail=f"Mapping for {mapping.op_co} already exists")
        
        created = create_asr_llm_mapping(db, mapping.dict())
        if created:
            multi_client_manager.load_configurations()
            return {"status": "success", "message": f"Mapping created for {mapping.op_co}"}
        else:
            raise HTTPException(status_code=500, detail="Failed to create mapping")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating mapping: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/{op_co}")
async def update_mapping(op_co: str, mapping: ASRLLMMappingCreate, db: Session = Depends(get_db)):
    """Update existing ASR/LLM mapping"""
    try:
        updated = update_asr_llm_mapping(db, op_co, mapping.dict())
        if updated:
            multi_client_manager.load_configurations()
            return {"status": "success", "message": f"Mapping updated for {op_co}"}
        else:
            raise HTTPException(status_code=404, detail=f"Mapping not found for {op_co}")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating mapping for {op_co}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/{op_co}")
async def delete_mapping(op_co: str, db: Session = Depends(get_db)):
    """Delete ASR/LLM mapping"""
    try:
        deleted = delete_asr_llm_mapping(db, op_co)
        if deleted:
            multi_client_manager.load_configurations()
            return {"status": "success", "message": f"Mapping deleted for {op_co}"}
        else:
            raise HTTPException(status_code=404, detail=f"Mapping not found for {op_co}")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting mapping for {op_co}: {e}")
        raise HTTPException(status_code=500, detail=str(e))
