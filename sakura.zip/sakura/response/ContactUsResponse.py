from response.GenericResponse import GenericResponse


class ContactUsObject:
    def __init__(self, id, name, email, phone, message, query_type, user_id, timestamp):
        self.id = id
        self.name = name
        self.email = email
        self.phone = phone
        self.message = message
        self.query_type = query_type
        self.user_id = user_id
        self.timestamp = timestamp

    def __repr__(self):
        return f"ContactForm({self.id}, {self.name}, {self.email}, {self.phone}, {self.message}, {self.query_type}, {self.user_id}, {self.timestamp})"


class ContactUsResponse(GenericResponse):
    def __init__(self, status_code, status, message, data: ContactUsObject):
        super().__init__(status_code=status_code, status=status, message=message)
        self.data = data

    def __repr__(self):
        return f"ContactUsResponse({self.status_code}, {self.status}, {self.message}, {self.data})"