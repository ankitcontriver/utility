from response.GenericResponse import GenericResponse


class GetAssistants:
    def __init__(self, assistant_id, description, female_picture_url,
                 male_picture_url, role, name):
        self.assistant_id = assistant_id
        self.description = description
        self.female_picture_url = female_picture_url
        self.male_picture_url = male_picture_url
        self.role = role
        self.name = name

    def __repr__(self):
        return f'assistant_id: {self.assistant_id}, description: {self.description}, female_picture_url: {self.female_picture_url}, male_pic : {self.male_picture_url}, role: {self.role}, name: {self.name} '


class GetAssistantsResponse(GenericResponse):
    def __init__(self, status_code, status, message, data: list[GetAssistants]):
        super().__init__(status_code=status_code, status=status, message=message)
        self.data = data

    def __repr__(self):
        return f'status_code: {self.status_code}, status: {self.status}, message: {self.message}'
