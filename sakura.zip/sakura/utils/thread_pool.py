from concurrent.futures import ThreadPoolExecutor
from threading import Lock
from logger import get_logger
import atexit
import os

logger = get_logger(__name__)

_executors = {}
_lock = Lock()

def get_named_thread_pool(pool_name: str, max_workers: int = None):
    """
    Returns a lazily-initialized singleton instance of a named ThreadPoolExecutor.
    Each pool is identified by its name.

    Args:
        pool_name (str): The name of the pool to get or create.
        max_workers (int): The maximum number of threads for the pool if it needs to be created.

    Returns:
        ThreadPoolExecutor: The requested thread pool instance.
    """
    if max_workers is None:
        # Enhanced default for high-concurrency scenarios
        cpu_count = os.cpu_count() or 4
        default_workers = max(20, cpu_count * 4)  # Much higher default for I/O bound operations
        max_workers = int(os.getenv('THREAD_POOL_MAX_WORKERS', default_workers))
    global _executors
    if pool_name not in _executors:
        with _lock:
            # Double-check locking to ensure thread safety
            if pool_name not in _executors:
                logger.info(f"Lazily creating thread pool '{pool_name}' with {max_workers} workers")
                _executors[pool_name] = ThreadPoolExecutor(
                    max_workers=max_workers,
                    thread_name_prefix=f'{pool_name}_pool'
                )
                logger.info(f"Thread pool '{pool_name}' ready for lazy thread creation")
    return _executors[pool_name]

def _shutdown_all_pools():
    """
    Shuts down all created thread pools gracefully.
    This function is intended to be registered with atexit.
    """
    with _lock:
        for pool_name, executor in _executors.items():
            logger.info(f"Shutting down pool: {pool_name}")
            executor.shutdown(wait=True)
        _executors.clear()

# Register the shutdown function to be called upon program exit
atexit.register(_shutdown_all_pools) 