from response.GenericResponse import GenericResponse


class ScrapedDataObject:
    def __init__(self, url, state, summary):
        self.url = url
        self.state = state
        self.summary = summary

    def __repr__(self):
        return f"url: {self.url}, summary: {self.summary}, state: {self.state}"


class ScrapeResponse(GenericResponse):
    def __init__(self, status, status_code, message, data:ScrapedDataObject):
        super().__init__(status_code=status_code,status=status,message=message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, status_code: {self.status_code}, message: {self.message}, data: {self.data}"
