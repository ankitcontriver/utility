faqs = {
    'en': """
    1.	How can I get Somtel new Sim/eSIM, or renew my number?
Visit Somtel nearest branch to get a new sim/eSIM, or a replacement for your old number.
2.	How much does Somtel standard Sim Card cost?
The price of a Somtel standard Sim Card is $1.00, and it does not include any extra services. You have the option to top up your account with voice or data bundles using either your eDahab account or through Somtel POS.
3.	How much does Somtel standard eSIM cost?
The price of a Somtel standard Sim Card is $2.00, and it does not include any extra services. You have the option to top up your account with voice or data bundles using either your eDahab account or through Somtel POS.
4.	How much does Somtel VIP number cost?
Visit Somtel nearest branch for more information about Somtel VIP packs.
5.	How long does the Somtel number remain active?
Maintain your free lifetime validity by regularly recharging your number with Somtel services, making and receiving calls, or sending SMSs.
6.	How can I re-activate my Somtel prepaid account?
To reactivate your Somtel prepaid account, all you need to do is top up your number with Somtel services by dialing *101# from another Somtel number registered with eDahab, using DahabPlus, or visiting the nearest Somtel POS.
7.	How to recharge my number with Somtel prepaid services?
To receive detailed instructions on recharge with Somtel prepaid services, dial *303#, then select option 4 (Additional Info), select option 1 (Other Services). You will then be sent an SMS containing all the details to your Somtel number. Or you can recharge through DahapPlus, or our website page somtelnetwork.net.
8.	What steps should I take to unlock my eDahab Pin (Attempt PIN)?
Dial *303# and select option 1 (eDahab Services). Then, choose option 1 again for Unbar Pin attempt, and proceed by entering your correct eDahab PIN.
9.	What steps should I take to block my eDahab account if my device is lost? 
To suspend your eDahab PIN using another Somtel number, dial *303#, select option 1 for eDahab Services, then choose option 2 to suspend your PIN. Finally, enter your correct eDahab PIN to complete the process.
10.	What steps should I take to unlock or release my PIN/PUK from my device? 
To access your PIN/PUK using a different Somtel number, you can simply dial *303#, and then select option 2 for Somtel Services, then select option 1 to view your PIN/PUK. 
11.	How can I check my voice/data balance?
To check your balance on your Somtel number, you can either dial *999#, or dial *303#, then select the second menu (Somtel Services). From there, select the second option which is (Check Balance). 
12.	How can I unsubscribe from receiving Ads SMS?
Simply send a text message from your Somtel number to (818) with the word (Maya) included in the message. There will be no charge for sending this message.
13.	How can I send money through eDahab?
To receive detailed instructions on sending money via eDahab, dial *303#, then select option 4 (Additional Info), select option 2 (Send Money). You will then be sent an SMS containing all the details to your Somtel number.

14.	How to get more information about Somtel Products and Services?
To get full information, reach us on our Facebook, Instagram, LinkedIn, or website page somtelnetwork.net.
15.	What are your business hours?
Our team is here to assist our customers seven days a week, from 7:00AM until 10:00PM.
16.	How Can recharge my Somtel prepaid account with voice or internet?
If you are registered with eDahab, dial *101#, select the currency with enough balance, pick a service from the menu, and input your eDahab PIN to complete the transaction. Alternatively, you can recharge at the nearest Somtel POS.
17.	What is Dalmar Plus?
Dalmar Plus provides international roaming services that allow you to use your Somtel number for voice/SMS or eDahab while traveling abroad in over 200 countries.
18.	How do I activate Dalmar Plus service for international roaming?
Visit our nearest Somtel POS to activate Dalmar Plus (International Roaming) service.

19. How do I activate Dalmar prepaid roaming on my Somtel Sim card/ eSIM?
Your Somtel number comes with free prepaid roaming (Dalmar) activated in Ethiopia, Kenya, Djibouti, Saudi Arabia, Qatar, UAE, Egypt, and Sudan. Simply recharge your account to start using it.

20. How do I get postpaid roaming packs on Somtel Sim card/ eSIM?
Visit your nearest Somtel Store and get multiple Postpaid Roming packs with affordable prices.

21. In which locations is the Somtel 5G service available?
Somtel 5G is available in Hargeysa, Burco, Borama, and Barbara.
    
    """,

    'so': """
    1.	Sidee baan uheli karaa Lambar cusub ama dib ugu furan karaa lamberkeyga Somtel?
Fadlan booqo laanta Somtel ee kuugu dhow si aad uhesho lambar cusub ama dib ugu furato lambarkaaga Somtel ee kaa lumey.
2.	Waa imisa qiimaha Sim-cardka caadiga ah ee Somtel?
Qiimaha Sim Card-ka caadiga ah ee Somtel waa Hal Dollar oo kaliya, kumana jiraan wax adeegyo dheeraad ah. Waxaad haysataa ikhtiyaarka ah inaad ku shubato akoonkaaga xidhmo ku hadal ah ama internet adoo isticmaalaya eDahab ama Waxaad kaga shuban kartaa laamaha Somtel ee kuugu dhow.
3.	Waa imisa qiimaha Somtel eSIM?
Qiimaha Somtel eSIM waa Laba Dollar oo kaliya, kumana jiraan wax adeegyo dheeraad ah. Waxaad haysataa ikhtiyaarka ah inaad ku shubato akoonkaaga xidhmo ku hadal ah ama internet adoo isticmaalaya eDahab ama kaga shuban kartaa laamaha Somtel.
4.	Waa imisa qiimaha Somtel VIP Lamber?
Booqo Somtel laanteeda kuugu dhow si aad u hesho macluumaad dheeraad ah oo ku saabsan xidhmooyinka VIP-da ee Somtel.
5.	Ilaa intee ayuu lambarka Somtel sii shaqaynayaa?
Waxa kaliya oo aad u baahan tahay in aad si joogto ah ugu shubto lambarkaaga adeegyada Somtel si aanu kaaga xanibmin.



6.	Sideen lambarkeyga Somtel uuga sheqeysiin karaa hadii uu is xanibo?
Si aad dib uga shaqysiisid lambarkaaga Somtel, waxa kaliya ubaahantahay inaad ku shubato adeegyada Somtel adigoo lambar kele ku diiwaangashan eDahab ka garaacaya xidig hal eber hal afargees, ama adoo isticmaalaya DahabPlus, ama booqanaya laanta Somtel ee kuugu dhow.
7.	Sideen uugu shubtaa Adeegyada Somtel?
Si aad u hesho tilmaamo faahfaahsan oo ku saabsan kushubashada adeegyada Somtel, garaac xidig sadex eber sadex afargees ee Adeega Saacid, ka dibna dooro optionka afraad (caawimo dheeraad ah), ka dib dooro optionka koowaad (Adeegyada Shirkada). Ka dib waxa laguu soo diri fariin ka kooban dhammaan faahfaahinta kushubashada adeegyada Somtel. Ama waxaad kaga shuban kartaa Appka DahapPlus ama sidoo kele laanta Somtel ee kuugu dhow.
8.	Sideen iskaga qaadi karaa xayiraada PIN-ka eDahab?
Haddii aad Xasuusato PIN-kaaga, garaac xidig sadex eber sadex afargees oo dooro optionka koowaad (Adeega eDahab). Kadib, dooro optionka koowaad (xayiraada iska qaad), ka dib hal mar si sax ah ugeli PIN-ka eDahab.
9.	Sideen uxaniban karaa akoonka eDahab hadii uu taleefanku iga lumo ama la xado? 
Si aad u hakiso akoon-kaaga eDahab adigoo isticmaalaya lambarka kale oo Somtel ah, garaac xidig sadex eber sadex afargees, dooro optionka koowaad (Adeegyada eDahab), kadib dooro optionka labaad (xayir telephone lumey), ugu dambayn geli PIN-kaaga eDahab ee saxda ah si aad uhakisato akoonkaaga eDahab.

10.	Sim cardka Somtel PIN/PUK baa igaga xidhmey, sideen iskaga qaadaa?
Waxaad kaga qaadi kartaa adoo isticmaalaya simcard kele oo Somtel ah xidig sadex eber sadex afargees, kadib dooranaya optionka labaad (Adeegyada Somtel), kana sii dooranaya optionka koowaad (Itus PIN/PUK), ka dib geli lambaarkaaga si aad u aragto PIN/PUK lambarkaaga. 
11.	Sideen u ogaan karaa hadhaaga ku hadalka ama internetka?
Si aad u ogaato hadhaaga ku hadalka ama internetka, waxaad garaaci kartaa xidig sadex nine afargees, ama garaac xidig sadex eber sadex afargees, ka dibna dooro optionka labaad (Adeegyada Somtel), kana sii dooro optionka labaad (hadhaaga eego). 
12.	Sideen iskaga xidhi karaa fariimaha xayasiiska?
Kaliya fariin qoraal ah ka soo dir lambarkaaga Somtel, kuna dir lambarka gaaban ee sideed hal sideed. Fariinta waxaad ku qoreysaa kilmadda (Maya) ka dib dir. Fariintu waa bilaash.
13.	Sidee eDahab lacagaha looga diraa?
Si aad u hesho tilmaamo faahfaahsan oo ku saabsan diritaanka lacagaha eDahab, garaac xidig sadex eber sadex afargees, ka dibna dooro optionka afraad (Caawimo Dheeraad ah), dooro optionka labaad (Lacag Dirida). Ka dib waxaad heleysaa fariin ka kooban qaabka lacag dirida eDahab.
14.	Sidee lagu heli karaa macluumaad dheeraad ah oo ku saabsan Badeecooyinka iyo Adeegyada Shirkadda Somtel?
Si aad u hesho macluumaad buuxa, nagala soo xidhiidh boggayaga Facebook, Instagram, LinkedIn, ama website-ka somtelnetwork.net
15.	Waa maxay saacadaha shaqada Somtel?
Daryeelka macaamiisha ee Somtel waxay diyaar uyihiin inay caawiyaan macaamiisha Somtel todobada maalmood ee usbuuca, laga bilaabo todobada subaxnimo ilaa iyo tobanka habeenimo.
16.	Sideen uugu shuban karaa adeega ku hadalka ama internetka?
Haddii aad ka diiwaan gashan tahay eDahab, garaac xidig hal eber hal afargees, dooro nooca lacagta kuugu jirta hadhaagaga, ka dib liiska ka dooro adeega aad ubaahantey, ka dib geli PIN-ka eDahab. Sidoo kale waxaad kaga shuban kartaa Appka DahabPlus, ama laanta Somtel ee kuugu dhow.
17.	Muxuu yahay adeegga Dalmar Plus?
Adeegga Dalmar Plus waa international roaming kuu saamaxaya inaad lambarkaaga Somtel ku isticmaashid in ka badan laba boqol oo dal, ku hadal iyo eDahab.
18.	Sideen uheli karaa adeegga Dalmar Plus?
Fadlan booqo laanta Somtel ee kuugu dhow si aad uhesho adeega Dalmar Plus.
19.	Sideen uheli karaa adeegga Dalmar (Prepaid Roaming)?
Lambarkaaga Somtel uu la socdaa adeegga Dalmar (Prepaid Roaming), kana sheqeynaya tusaale ahaan, Ethiopia, Kenya, Djibouti, Saudi Arabia, Qatar, UAE, Egypt, iyo Sudan adoo kaliyaata ku shubanaya ku hadal.
20.	Halkeen ka heli karaa xidhmooyinka Postpaid Roaming?
Fadlan booqo laanta Somtel ee kuugu dhow si aad uhesho dhamaan macluumaadka ku saabsan xidhmooyinka Postpaid Roaming.
21.	Meelehee buu ka sheqeeyaa Somtel 5G?
Somtel 5G waxuu ka sheqeeyaa Hargeysa, Burco, Borama, iyo Barbara.

    
    """
}
