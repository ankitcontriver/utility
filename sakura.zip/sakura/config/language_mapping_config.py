"""
Language mapping configuration for Smart IVR language-based file filtering.
Creates multiple language-specific mappings stored directly in ivr_stt_array field.
"""
import re
import copy
from typing import Dict, Any
from logger.__init__ import get_logger

logger = get_logger(__name__)

def normalize_language_code(lang_code: str) -> str:
    """
    Normalize language codes to standard format.
    Examples:
    - enUS -> en-US
    - frCA -> fr-CA
    - es -> es
    - en-US -> en-US (already normalized)
    """
    if not lang_code or lang_code == "default":
        return lang_code
    
    # If already contains hyphen, return as is
    if '-' in lang_code:
        return lang_code
    
    # If length is 4 or more and contains both letters and numbers, add hyphen
    if len(lang_code) >= 4:
        # Pattern: 2 letters + 2 letters/numbers (e.g., enUS, frCA, en01)
        match = re.match(r'^([a-zA-Z]{2})([a-zA-Z0-9]{2,})$', lang_code)
        if match:
            return f"{match.group(1)}-{match.group(2)}"
    
    # If length is 2, assume it's a language code (e.g., en, fr, es)
    if len(lang_code) == 2:
        return lang_code
    
    # For other cases, return as is
    return lang_code

def detect_language_from_filename(filename: str) -> str:
    """
    Extract language code from filename suffix and normalize it.
    Supports multiple patterns:
    - voiceprompt_{lang_code}.wav
    - {filename}_VOICEPROMPT_{lang_code}.wav
    - {filename}_{lang_code}.wav
    - {filename}_VOICEPROMPT.wav (treated as default)
    Returns normalized language code or "default" if no language code found.
    """
    # Look for pattern: voiceprompt_{lang_code}.wav
    match = re.search(r'voiceprompt_([^_]+)\.wav$', filename, re.IGNORECASE)
    if match:
        return normalize_language_code(match.group(1))
    
    # Look for pattern: {filename}_VOICEPROMPT_{lang_code}.wav
    match = re.search(r'_VOICEPROMPT_([^_]+)\.wav$', filename, re.IGNORECASE)
    if match:
        return normalize_language_code(match.group(1))
    
    # Look for pattern: {filename}_VOICEPROMPT.wav (treat as default)
    if re.search(r'_VOICEPROMPT\.wav$', filename, re.IGNORECASE):
        return "default"
    
    # Look for pattern: {filename}_{lang_code}.wav (generic - anything after last underscore)
    match = re.search(r'_([^_]+)\.wav$', filename, re.IGNORECASE)
    if match:
        return normalize_language_code(match.group(1))
    
    # If no language code found in filename, return "default" instead of assuming en-US
    return "default"

def create_language_mappings_from_ivr_stt_array(ivr_stt_array: Dict[str, Any], lang_selection_via_asr: bool = False) -> Dict[str, Any]:
    """
    Create language mappings with new structure:
    {
        "metadata": {...},
        "language_selection": {...},  // Only if lang_selection_via_asr is True
        "language_mappings": {
            "default": {"nodes": {...}},
            "F": {"nodes": {...}},
            "en-US": {"nodes": {...}}
        }
    }
    """
    # Extract metadata and nodes
    metadata = ivr_stt_array.get("metadata", {})
    nodes = ivr_stt_array.get("nodes", {})
    
    # Extract language codes from original filenames
    language_codes = set()
    
    if "nodes" in ivr_stt_array:
        for node_id, node_data in ivr_stt_array["nodes"].items():
            if "stt" in node_data:
                stt_data = node_data["stt"]
                
                # Check original filenames for language detection
                if "original_filenames" in stt_data:
                    original_filenames = stt_data["original_filenames"]
                    
                    # Check voice files
                    if "voice" in original_filenames and isinstance(original_filenames["voice"], list):
                        for voice_filename in original_filenames["voice"]:
                            if isinstance(voice_filename, str) and ".wav" in voice_filename:
                                lang_code = detect_language_from_filename(voice_filename)
                                language_codes.add(lang_code)
                    
                    # Check dtmf files
                    if "dtmf" in original_filenames and isinstance(original_filenames["dtmf"], list):
                        for dtmf_filename in original_filenames["dtmf"]:
                            if isinstance(dtmf_filename, str) and ".wav" in dtmf_filename:
                                lang_code = detect_language_from_filename(dtmf_filename)
                                language_codes.add(lang_code)
    
    # Create language mappings - ALL nodes included, just filtered by language
    language_mappings = {}
    
    # Add default mapping (contains all nodes)
    language_mappings["default"] = {"nodes": copy.deepcopy(nodes)}
    
    # Add language-specific mappings (filtered by language)
    for lang_code in language_codes:
        if lang_code != "default":
            language_mappings[lang_code] = {
                "nodes": create_language_specific_nodes(nodes, lang_code)
            }
    
    # Create result structure
    result = {
        "metadata": metadata,
        "language_mappings": language_mappings
    }
    
    # Add language selection if it exists in the ivr_stt_array (created by process_xml_string)
    if "language_selection" in ivr_stt_array:
        result["language_selection"] = ivr_stt_array["language_selection"]
    
    logger.info(f"Created language mappings: {list(language_mappings.keys())}")
    return result

def create_language_specific_nodes(nodes: Dict[str, Any], target_lang_code: str) -> Dict[str, Any]:
    """
    Create language-specific nodes by filtering STT content based on original filenames.
    ALL nodes are included, but STT content is filtered by language.
    """
    filtered_nodes = {}
    
    for node_id, node_data in nodes.items():
        # Copy the node as-is
        filtered_node = copy.deepcopy(node_data)
        
        # Filter STT content by language if present
        if "stt" in filtered_node:
            stt_data = filtered_node["stt"]
            
            if "original_filenames" in stt_data:
                original_filenames = stt_data["original_filenames"]
                filtered_voice = []
                filtered_dtmf = []
                
                # Filter voice files
                if "voice" in original_filenames and isinstance(original_filenames["voice"], list):
                    for i, voice_filename in enumerate(original_filenames["voice"]):
                        if isinstance(voice_filename, str) and ".wav" in voice_filename:
                            lang_code = detect_language_from_filename(voice_filename)
                            if lang_code == target_lang_code:
                                if i < len(stt_data.get("voice", [])):
                                    filtered_voice.append(stt_data["voice"][i])
                
                # Filter dtmf files
                if "dtmf" in original_filenames and isinstance(original_filenames["dtmf"], list):
                    for i, dtmf_filename in enumerate(original_filenames["dtmf"]):
                        if isinstance(dtmf_filename, str) and ".wav" in dtmf_filename:
                            lang_code = detect_language_from_filename(dtmf_filename)
                            if lang_code == target_lang_code:
                                if i < len(stt_data.get("dtmf", [])):
                                    filtered_dtmf.append(stt_data["dtmf"][i])
                
                # Update the stt data with filtered results
                stt_data["voice"] = filtered_voice
                stt_data["dtmf"] = filtered_dtmf
                
                # Remove original_filenames as it's not needed in the final structure
                if "original_filenames" in stt_data:
                    del stt_data["original_filenames"]
        
        # Add the filtered node (all nodes included, just STT content filtered)
        filtered_nodes[node_id] = filtered_node
    
    return filtered_nodes

def get_language_specific_ivr_stt_array(
    ivr_stt_array: Dict[str, Any], 
    lang_code: str
) -> Dict[str, Any]:
    """
    Get language-specific ivr_stt_array combining metadata with language-specific nodes.
    Returns: {
        "metadata": {...},
        "language_selection": {...},  // Only if available
        "nodes": {...}  // Language-specific nodes (all nodes, filtered STT content)
    }
    """
    # Normalize the input language code (from call_start/call_message)
    normalized_lang_code = normalize_language_code(lang_code)
    
    metadata = ivr_stt_array.get("metadata", {})
    language_mappings = ivr_stt_array.get("language_mappings", {})
    language_selection = ivr_stt_array.get("language_selection", {})
    
    result = {
        "metadata": metadata
    }
    
    # Add language selection if available
    if language_selection:
        result["language_selection"] = language_selection
    
    # Add language-specific nodes
    if normalized_lang_code in language_mappings:
        result["nodes"] = language_mappings[normalized_lang_code]["nodes"]
    else:
        result["nodes"] = language_mappings.get("default", {}).get("nodes", {})
    
    return result