from response.GenericResponse import GenericResponse


class Questionnaire:
    def __init__(self, questions: str, header: str):
        self.questions = questions
        self.header = header

    def __repr__(self):
        return f"header: {self.header}, questions: {self.questions}"


class QuestionnaireResponse(GenericResponse):
    def __init__(self, status_code: int, status: str, message: str, response: Questionnaire):
        super().__init__(status_code=status_code, status=status, message=message)
        self.response = response

    def __repr__(self):
        return f"status_code: {self.status_code}, status: {self.status}, message: {self.message}, response: {self.response}"
