import os
import threading
from typing import Dict, List, Optional, Union
from dataclasses import dataclass
from openai import AzureOpenAI
from config.database_config import SessionLocal
from repository.asr_llm_mapping_repository import get_all_active_asr_llm_mappings
from logger import get_logger
from utils.function_call_util_functions import disconnect_service

logger = get_logger(__name__)

@dataclass
class ClientConfig:
    """Configuration for a single client"""
    provider: str
    api_url: str
    api_key: str
    model: Optional[str] = None
    client: Optional[Union[AzureOpenAI, object]] = None
    hit_count: int = 0
    is_available: bool = True

@dataclass 
class ProviderConfig:
    """Configuration for all providers of an operator_country"""
    llm_clients: List[ClientConfig]
    tts_clients: List[ClientConfig]
    stt_clients: List[ClientConfig] 
    perplexity_clients: List[ClientConfig]

class MultiClientConfigManager:
    """Manages multiple LLM/TTS/STT/Perplexity clients based on database configuration"""
    
    def __init__(self):
        self.config_cache: Dict[str, ProviderConfig] = {}
        self.lock = threading.RLock()
        self.loaded = False
        
    def load_configurations(self) -> bool:
        """Load all configurations from database into cache"""
        try:
            logger.info("Loading multi-client configurations from database")
            db = SessionLocal()
            try:
                mappings = get_all_active_asr_llm_mappings(db)
                
                with self.lock:
                    self.config_cache.clear()
                    
                    for mapping in mappings:
                        op_co_key = mapping.op_co
                        
                        provider_config = self._parse_mapping_to_config(mapping)
                        
                        if provider_config:
                            self.config_cache[op_co_key] = provider_config
                            logger.info(f"Loaded config for {op_co_key}: "
                                      f"LLM({len(provider_config.llm_clients)}), "
                                      f"TTS({len(provider_config.tts_clients)}), "
                                      f"STT({len(provider_config.stt_clients)}), "
                                      f"Perplexity({len(provider_config.perplexity_clients)})")
                    
                    self.loaded = True
                    logger.info(f"Multi-client configuration loaded for {len(self.config_cache)} operator_country combinations")
                    return True
                    
            finally:
                db.close()
                
        except Exception as e:
            logger.error(f"Failed to load multi-client configurations: {e}", exc_info=True)
            return False
    
    def _parse_mapping_to_config(self, mapping) -> Optional[ProviderConfig]:
        """Parse database mapping to ProviderConfig"""
        try:
            llm_clients = self._parse_llm_clients(
                mapping.llm_provider, mapping.llm_api, mapping.llm_key, mapping.llm_model
            )
            
            tts_clients = self._parse_clients(
                mapping.tts_provider, mapping.tts_api, mapping.tts_key, "TTS"
            )
            
            stt_clients = self._parse_clients(
                mapping.stt_provider, mapping.stt_region, mapping.stt_key, "STT"
            )
            
            perplexity_clients = self._parse_perplexity_clients(
                mapping.perplexity_api, mapping.perplexity_key, mapping.perplexity_model
            )
            
            return ProviderConfig(
                llm_clients=llm_clients,
                tts_clients=tts_clients, 
                stt_clients=stt_clients,
                perplexity_clients=perplexity_clients
            )
            
        except Exception as e:
            logger.error(f"Failed to parse mapping for {mapping.op_co}: {e}")
            return None
    
    def _parse_clients(self, providers: str, apis: str, keys: str, client_type: str) -> List[ClientConfig]:
        """Parse comma-separated provider configurations"""
        clients = []
        
        if not providers or not apis or not keys:
            return clients
            
        try:
            provider_list = [p.strip() for p in providers.split(',')]
            api_list = [a.strip() for a in apis.split(',')]
            key_list = [k.strip() for k in keys.split(',')]
            
            if len(provider_list) == len(api_list) == len(key_list):
                for provider, api, key in zip(provider_list, api_list, key_list):
                    if provider and api and key:
                        client_config = ClientConfig(
                            provider=provider,
                            api_url=api,
                            api_key=key
                        )
                        
                        if client_type == "LLM" and 'azure' in provider.lower():
                            try:
                                azure_client = AzureOpenAI(
                                    azure_endpoint=api,
                                    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
                                    api_key=key,
                                )
                                client_config.client = azure_client
                                clients.append(client_config)
                                logger.debug(f"Initialized {client_type} client for {provider}")
                            except Exception as e:
                                logger.error(f"Failed to initialize {client_type} client for {provider}: {e}")
                        else:
                            clients.append(client_config)
                            logger.debug(f"Configured {client_type} client for {provider}")
            else:
                logger.warning(f"Mismatched {client_type} configuration lengths for providers/apis/keys")
                
        except Exception as e:
            logger.error(f"Error parsing {client_type} clients: {e}")
            
        return clients
    
    def _parse_llm_clients(self, providers: str, apis: str, keys: str, models: str = None) -> List[ClientConfig]:
        """Parse LLM client configurations with model support"""
        clients = []
        
        if not providers or not apis or not keys:
            return clients
            
        try:
            provider_list = [p.strip() for p in providers.split(',')]
            api_list = [a.strip() for a in apis.split(',')]
            key_list = [k.strip() for k in keys.split(',')]
            model_list = []
            
            if models:
                model_list = [m.strip() for m in models.split(',')]
            
            # Ensure all lists have the same length by padding with None/empty values
            max_length = len(provider_list)
            if len(api_list) != max_length or len(key_list) != max_length:
                logger.warning("Mismatched LLM configuration lengths for providers/apis/keys")
                return clients
            
            # Pad model list if shorter or not provided
            while len(model_list) < max_length:
                model_list.append(None)
                
            for provider, api, key, model in zip(provider_list, api_list, key_list, model_list):
                if provider and api and key:
                    client_config = ClientConfig(
                        provider=provider,
                        api_url=api,
                        api_key=key,
                        model=model
                    )
                    
                    if 'azure' in provider.lower():
                        try:
                            azure_client = AzureOpenAI(
                                azure_endpoint=api,
                                api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
                                api_key=key,
                            )
                            client_config.client = azure_client
                            clients.append(client_config)
                            logger.debug(f"Initialized LLM client for {provider} with model: {model}")
                        except Exception as e:
                            logger.error(f"Failed to initialize LLM client for {provider}: {e}")
                    else:
                        clients.append(client_config)
                        logger.debug(f"Configured LLM client for {provider} with model: {model}")
                
        except Exception as e:
            logger.error(f"Error parsing LLM clients: {e}")
            
        return clients
    
    def _parse_perplexity_clients(self, apis: str, keys: str, models: str = None) -> List[ClientConfig]:
        """Parse Perplexity configurations"""
        clients = []
        
        if not apis or not keys:
            return clients
            
        try:
            api_list = [a.strip() for a in apis.split(',')]
            key_list = [k.strip() for k in keys.split(',')]
            model_list = []
            
            if models:
                model_list = [m.strip() for m in models.split(',')]
            
            # Ensure all lists have the same length by padding with None/empty values
            max_length = len(api_list)
            if len(key_list) != max_length:
                logger.warning("Mismatched Perplexity configuration lengths for apis/keys")
                return clients
            
            # Pad model list if shorter or not provided
            while len(model_list) < max_length:
                model_list.append(None)
                
            for i, (api, key, model) in enumerate(zip(api_list, key_list, model_list)):
                if api and key:
                    client_config = ClientConfig(
                        provider=f"perplexity_{i+1}",
                        api_url=api,
                        api_key=key,
                        model=model
                    )
                    clients.append(client_config)
                    logger.debug(f"Configured Perplexity client {i+1} with model: {model}")
                
        except Exception as e:
            logger.error(f"Error parsing Perplexity clients: {e}")
            
        return clients
    
    def get_llm_client(self, op_co: str) -> Optional[ClientConfig]:
        """Get next available LLM client with failover support"""
        with self.lock:
            return self._get_next_client(op_co, "llm")
    
    def get_tts_client(self, op_co: str) -> Optional[ClientConfig]:
        """Get next available TTS client with failover support"""
        with self.lock:
            return self._get_next_client(op_co, "tts")
    
    def get_stt_client(self, op_co: str) -> Optional[ClientConfig]:
        """Get next available STT client with failover support"""
        with self.lock:
            return self._get_next_client(op_co, "stt")
    
    def get_perplexity_client(self, op_co: str) -> Optional[ClientConfig]:
        """Get next available Perplexity client with failover support"""
        with self.lock:
            return self._get_next_client(op_co, "perplexity")
    
    def _get_next_client(self, op_co: str, client_type: str) -> Optional[ClientConfig]:
        """Generic method to get next client with round-robin and failover"""
        if not self.loaded:
            logger.warning("Configuration not loaded yet")
            return None
            
        config = self.config_cache.get(op_co)
        if not config:
            logger.error(f"No configuration found for {op_co}")
            return None
        
        if client_type == "llm":
            clients = config.llm_clients
        elif client_type == "tts":
            clients = config.tts_clients
        elif client_type == "stt":
            clients = config.stt_clients
        elif client_type == "perplexity":
            clients = config.perplexity_clients
        else:
            return None
        
        if not clients:
            logger.error(f"No {client_type.upper()} clients configured for {op_co}")
            return None
        
        available_clients = [c for c in clients if c.is_available]
        
        if not available_clients:
            logger.error(f"No available {client_type.upper()} clients for {op_co}")
            for client in clients:
                client.is_available = True
            available_clients = clients
            logger.info(f"Reset all {client_type.upper()} clients for {op_co}")
        
        selected_client = min(available_clients, key=lambda c: c.hit_count)
        selected_client.hit_count += 1
        
        logger.debug(f"Selected {client_type.upper()} client {selected_client.provider} for {op_co} "
                    f"(hit_count: {selected_client.hit_count})")
        
        return selected_client
    
    def mark_client_failed(self, op_co: str, client_type: str, provider: str):
        """Mark a client as failed for failover"""
        with self.lock:
            config = self.config_cache.get(op_co)
            if not config:
                return
            
            if client_type == "llm":
                clients = config.llm_clients
            elif client_type == "tts":
                clients = config.tts_clients
            elif client_type == "stt":
                clients = config.stt_clients
            elif client_type == "perplexity":
                clients = config.perplexity_clients
            else:
                return
            
            for client in clients:
                if client.provider == provider:
                    client.is_available = False
                    logger.warning(f"Marked {client_type.upper()} client {provider} as failed for {op_co}")
                    break
    
    def validate_op_co(self, op_co: str) -> bool:
        """Check if configuration exists for operator_country combination"""
        with self.lock:
            return op_co in self.config_cache
    
    def get_configuration_stats(self) -> Dict:
        """Get statistics about current configurations and hit counts"""
        with self.lock:
            stats = {}
            for op_co, config in self.config_cache.items():
                llm_stats = [(c.provider, c.hit_count, c.is_available, c.model) for c in config.llm_clients]
                tts_stats = [(c.provider, c.hit_count, c.is_available) for c in config.tts_clients]
                stt_stats = [(c.provider, c.hit_count, c.is_available) for c in config.stt_clients]
                perplexity_stats = [(c.provider, c.hit_count, c.is_available, c.model) for c in config.perplexity_clients]
                
                stats[op_co] = {
                    'llm_clients': llm_stats,
                    'tts_clients': tts_stats,
                    'stt_clients': stt_stats,
                    'perplexity_clients': perplexity_stats,
                    'total_llm_hits': sum(c.hit_count for c in config.llm_clients),
                    'total_tts_hits': sum(c.hit_count for c in config.tts_clients),
                    'total_stt_hits': sum(c.hit_count for c in config.stt_clients),
                    'total_perplexity_hits': sum(c.hit_count for c in config.perplexity_clients)
                }
            return stats

# Global instance
multi_client_manager = MultiClientConfigManager()

def get_op_co_key(operator: str, country: str) -> str:
    """Create operator_country key"""
    return f"{operator}_{country}"

async def handle_configuration_not_found(call_id: str, op_co: str, assistant_id: str) -> dict:
    """Handle case when no configuration is found - return disconnect signal"""
    logger.error(f"No configuration found for {op_co}, disconnecting call {call_id}")
    try:
        return await disconnect_service(
            call_id=call_id,
            assistant_id=assistant_id,
            parameter=f"Service not available for your region. Please try again later."
        )
    except Exception as e:
        logger.error(f"Failed to create disconnect response for call {call_id}: {e}")
        return {"####STOP####": "Service temporarily unavailable"}

def initialize_multi_client_configuration():
    """Initialize multi-client configuration at startup"""
    success = multi_client_manager.load_configurations()
    if success:
        logger.info("Multi-client configuration service initialized successfully")
    else:
        logger.error("Failed to initialize multi-client configuration service")
    return success
