import os
import requests
import uuid

from logger import get_logger
from dotenv import load_dotenv

logger = get_logger(__name__)

load_dotenv()

key_var_name = os.getenv('TRANSLATOR_TEXT_RESOURCE_KEY')
region_var_name = os.getenv('TRANSLATOR_TEXT_REGION')
endpoint_var_name = os.getenv('TRANSLATOR_TEXT_ENDPOINT')

path = '/translate?api-version=3.0'

headers = {
    'Ocp-Apim-Subscription-Key': f"{key_var_name}",
    'Ocp-Apim-Subscription-Region': f"{region_var_name}",
    'Content-type': 'application/json',
    'X-ClientTraceId': str(uuid.uuid4())
}


def translate_transcript(text, from_lang, to_lang="en"):
    try:
        logger.info(f"translate_transcript called for text - {text}, from language - {from_lang}, to language - {to_lang}")
        body = [{
            'text': f'{text}'
        }]
        params = f'&from={from_lang}&to={to_lang}'
        constructed_url = endpoint_var_name + path + params
        request = requests.post(constructed_url, headers=headers, json=body)
        response = request.json()

        translation_text = response[0]['translations'][0]['text']
        logger.info(f"Translated Text {translation_text} in {to_lang}")
        return translation_text
    except Exception as e:
        logger.error(f"Error while translating transcript in language_service.py : {e}")
        return text
