from models.database_models import ContactForms
from sqlalchemy.orm import Session
from models.request_models import ContactForm


def add_contact_form(db: Session, request: ContactForm):
    contact = ContactForms(name=request.name, email=request.email,message=request.message, phone_number=request.phone_number, query_type=request.query_type, user_id=request.user_id)
    db.add(contact)
    db.commit()
    return contact
