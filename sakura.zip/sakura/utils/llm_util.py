import asyncio
import json
import os
import random
import re
import time
import traceback
import uuid

import httpx
from pathlib import Path


from openai import OpenAI, AzureOpenAI

from utils.redis_db_manager import redis_manager
from config.filler_prompt import config_language_response
from controllers.audio_controller import generate_audio_google, generate_audio_azure, generate_audio_eleven_labs, \
    generate_audio_whisper
from enums.call_enums import Event, ServiceType
from logger import get_logger
from models.request_models import MessageResponse
from service.language_service import translate_transcript
from utils.alarm_utils import send_alarm,run_alarm_in_thread
from utils.chat_utils import send_chat_chunk_callback_socket
from utils.prompt_template import call_sentiment_analyser_prompt, \
    call_satisfaction_analyser_prompt, call_emotions_analyser_prompt, call_intent_analyser_prompt
from utils.prompt_template import opening_statement_prompt, sh_opening_statement_prompt
from utils.utils import convert_wav_to_base64, save_audio_to_file, get_current_time_with_milliseconds

logger = get_logger(__name__)
client = OpenAI()
filler_prompt_path = os.getenv("FILLER_AUDIO_PROMPTS_PATH")

call_summary_word_limit=os.getenv("CALL_SUMMARY_WORD_LIMIT", 50)
pa_jericho_call_log_api_endpoint= os.getenv("PA_JERICHO_CALL_LOG_API_ENDPOINT")

random_responses = [
    "Sure, just a sec!!",
    "Sure thing, just a sec!",
    "Okay, give me a moment!",
    "Alright, let me check!",
    "Sure, give me a sec!",
    "Sure, hold on a bit!"
]

pa_random_responses=[
    "Let me check calendar for that.",
    "I'll look into the schedule.",
    "Let me find the best time for you.",
    "Let me check availability for that.",
    "Let me see what works for you."
]

# Removed hardcoded Azure client - now using database-cached configurations
# All LLM operations now use multi-client configuration system

def get_llm_client_for_analysis(assistant_id: str = None, fallback_model: str = "gpt-4"):
    """Get LLM client and model from multi-client configuration for analysis tasks"""
    try:
        if assistant_id:
            from cache.assistant_configuration_cache import get_assistant_details_by_id
            from service.multi_client_config_service import multi_client_manager, get_op_co_key

            assistant_config = get_assistant_details_by_id(int(assistant_id))
            if assistant_config:
                operator = assistant_config.get('operator')
                country = assistant_config.get('country')

                if operator and country:
                    op_co = get_op_co_key(operator, country)
                    client_config = multi_client_manager.get_llm_client(op_co)

                    if client_config and client_config.client:
                        model_name = client_config.model or fallback_model
                        logger.debug(f"Using multi-client for analysis with model {model_name}")
                        return client_config.client, model_name

        logger.warning("No multi-client configuration available for analysis tasks")
        return None, None
    except Exception as e:
        logger.error(f"Error getting LLM client for analysis: {e}")
        return None, None


def generate_dynamic_message_id(base_message_id: str = None, suffix: str = "Avatar") -> str:
    """
    Generate dynamic message ID in format: <messageId>_<uuid>
    
    Args:
        base_message_id: The base message ID (e.g., "123" from "123_Avatar")
        suffix: The suffix to append (default: "Avatar")
    
    Returns:
        Formatted message ID like "123_Avatar_550e8400-e29b-41d4-a716-446655440000"
    """
    if not base_message_id:
        base_message_id = "0"
    
    # Extract the base part if it contains underscore
    if "_" in base_message_id:
        base_message_id = base_message_id.split("_")[0]
    
    unique_uuid = str(uuid.uuid4())
    return f"{base_message_id}_{suffix}_{unique_uuid}"


def call_openai_based_on_model_and_systemmessage(model_name, message_array, assistant_id=None, user_obj=None):
    try:
        gpt_obj = {
            "model": model_name,
            "messages": message_array
        }
        try:
            response = client.chat.completions.create(**gpt_obj)
            run_alarm_in_thread(send_alarm(alarm_type='Azure_OpenAI_API', remarks='Azure OpenAI API working fine', status='clear', assistant_id=assistant_id))
        except Exception as api_exc:
            run_alarm_in_thread(send_alarm(operator=None, country=None, alarm_type='Azure_OpenAI_API', remarks=str(api_exc), status='raise', assistant_id=assistant_id))
            raise
        logger.debug(f"Response - {response}")
        data = response.json()
        logger.debug(f"Data - {data}")
        parsed_data = json.loads(data)
        content = parsed_data["choices"][0]["message"]["content"]
        logger.info(f"response content from openai ---> {content}")
        return content
    except Exception as e:
        logger.error(f"Error  in call_openai_based_on_model_and_system message() -> {e}",exc_info=True)


def remove_emojis(text):
    try:
        emoji_pattern = re.compile(
            "["
            "\U0001F600-\U0001F64F"  # emoticons
            "\U0001F300-\U0001F5FF"  # symbols & pictographs
            "\U0001F680-\U0001F6FF"  # transport & map symbols
            "\U0001F700-\U0001F77F"  # alchemical symbols
            "\U0001F780-\U0001F7FF"  # Geometric Shapes Extended
            "\U0001F800-\U0001F8FF"  # Supplemental Arrows-C
            "\U0001F900-\U0001F9FF"  # Supplemental Symbols and Pictographs
            "\U0001FA00-\U0001FA6F"  # Chess Symbols
            "\U0001FA70-\U0001FAFF"  # Symbols and Pictographs Extended-A
            "\U00002702-\U000027B0"  # Dingbats
            "\U000024C2-\U0001F251"
            "]+",
            flags=re.UNICODE
        )

        emojis_present = bool(emoji_pattern.search(text))
        cleaned_text = emoji_pattern.sub(r'', text)
        return cleaned_text, emojis_present
    except Exception as e:
        logger.error(f"Error in remove_emojis: {e}",exc_info=True)


def remove_asterisks(text):
    return text.replace('**', '')


def convert_chunk_to_transcript_based_on_voice_code(voice_code, chunk, call_id, event_type, tts_style, provider, gender,
                                                    is_translate=False, assistant_id=None):
    try:
        logger.info(f"{call_id} tts for chunk -> {chunk}")
        transcript_time = time.time()

        # Get assistant_id from user call record if not provided
        if assistant_id is None:
            try:
                from utils.memory_cache_manager import get_user_call_record
                user_call_record = get_user_call_record(str(call_id))
                if user_call_record:
                    assistant_id = user_call_record.get("assistantId")
                    logger.debug(f"Retrieved assistant_id {assistant_id} from call record for TTS")
            except Exception as e:
                logger.warning(f"Could not get assistant_id from call record for {call_id}: {e}")

        language_code = '-'.join(voice_code.split('-')[:2])

        if chunk == "":
            return "", chunk

        language = language_code.split("-")[0]
        logger.debug(f"{call_id} Sending chunk in en -> {chunk}")

        if is_translate:
            logger.info(f"{call_id} - Language is {language}, Translating")
            translated_text = translate_transcript(chunk, "en", language)
            chunk = translated_text

        logger.info(
            f"{call_id} -> provider -> {provider}, speech_lang_code -> {language_code}, voice_code -> {voice_code}")
        chunk = remove_asterisks(chunk)
        chunk = re.sub(r'\brs\.?\b', 'Rupees', chunk, flags=re.IGNORECASE)
        tts_chunk = chunk
        tts_chunk, emojis_present = remove_emojis(tts_chunk)
        tts_chunk = tts_chunk.replace("&", " and ")

        words_in_chunk = len(tts_chunk.split())
        logger.debug(f"{call_id} tts for tts chunk -> {tts_chunk}, length -> {len(tts_chunk)}, emojis_present - {emojis_present}, words_in_chunk -> {words_in_chunk}")
        if emojis_present and len(tts_chunk) == 1:
            logger.info(f"only Emoji present in chunk, returning")
            return "", chunk
        if event_type == Event.CALL.value:
            transcript = generate_transcript_based_on_provider(provider, gender, tts_chunk, voice_code, call_id,
                                                               tts_style, language_code, assistant_id)
            
            
            logger.info(
                f"call_id {call_id} - time taken to transcript------> {(time.time() - transcript_time) * 1000:.2f} ms")
        else:
            transcript = ""

        return transcript, chunk
    except Exception as e:
        logger.error(f"Error while converting chunk to transcript in llm_wrapper_controller.py : {e}",exc_info=True)


def set_buildup_prompt(call_id: str, prompt_category: str):
    try:
        from utils.memory_cache_manager import get_user_call_record, set_user_call_record
        user_obj = get_user_call_record(call_id)
        if user_obj is None:
            return
        logger.debug(f"{call_id} logging user_obj in set_buildup_prompt -----> {user_obj}")
        user_obj["prompt_category"] = prompt_category
        set_user_call_record(call_id, user_obj)
        logger.info(f"{call_id} buildup_prompt_category set to {prompt_category} in set_buildup_prompt")
    except Exception as e:
        logger.error(f"Exception occurred in set_buildup_prompt for call_id {call_id}: {e}",exc_info=True)
        raise


async def get_buildup_prompt(prompt_category: str, call_id: str, language: str, event_type: str, voice_code: str,
                             sid: str, current_message_id: str, tts_style: str, is_translate: bool, provider: str,
                             function_name, gender, service_type=None):
    logger.secure(f"{call_id} -- getting filler prompt based on category")
    try:
        if prompt_category is not None and (
                function_name == "web_search" or function_name == "get_time" or function_name == "get_weather"):
            logger.info(f"prompt_category not none ----> {prompt_category}")
            random_number = random.randint(1, 5)
            filler_prompt_file_name = f"{prompt_category}_{random_number}"
            final_audio_path = f"{filler_prompt_path}/{voice_code}/{prompt_category}/{filler_prompt_file_name}.wav"
            final_audio_path_exists = Path(final_audio_path).exists()
            logger.debug(f"{call_id} -- filler_prompt_file_name ----> {filler_prompt_file_name},final audio path ----> {final_audio_path},final audio path exists ----> {final_audio_path_exists}")
            filler_chunk = ""
            filler_chunk_exists = False
            try:
                filler_chunk = config_language_response.get(f"{language}_responses").get(prompt_category)[
                    random_number - 1]
                filler_chunk_exists = True
            except (KeyError, IndexError, TypeError) as e:
                logger.error(f"{call_id} -- error getting filler_chunk: {e}",exc_info=True)

            if final_audio_path_exists and filler_chunk_exists:
                logger.info(f"{call_id} -- final audio path for the category ----> {final_audio_path},filler_prompt_chunk - {filler_chunk}")
                # Use WAV file path directly instead of converting to base64
                filler_prompt = final_audio_path

                message_id = generate_dynamic_message_id(current_message_id, "Avatar")

                await send_socket_message(call_id, filler_chunk, filler_prompt, event_type, message_id, sid)
            elif not final_audio_path_exists and filler_chunk_exists:
                logger.info(f"{call_id} -- final_audio_path does not exist, generating new audio for filler_chunk - {filler_chunk}")
                base64_transcript = generate_transcript_based_on_provider(provider, gender, filler_chunk,
                                                                              voice_code, call_id, tts_style, language)
                
                # Convert to WAV file using TTS manager
                try:
                    from service.pa_tts_manager import get_tts_manager
                    import time
                    tts_manager = get_tts_manager()
                    if tts_manager:
                        response_id = f"filler_{int(time.time() * 1000)}"
                        wav_path = await tts_manager.convert_chunk_to_wav(
                            base64_chunk=base64_transcript,
                            call_id=call_id,
                            response_id=response_id
                        )
                        new_filler_transcript = wav_path
                        logger.info(f"Converted filler TTS to WAV: {wav_path}")
                    else:
                        logger.warning("TTS manager not available, using base64 transcript")
                        new_filler_transcript = base64_transcript
                except Exception as e:
                    logger.error(f"Failed to convert filler TTS to WAV: {e}")
                    new_filler_transcript = base64_transcript
                
                message_id = generate_dynamic_message_id(current_message_id, "Avatar")
                await send_socket_message(call_id, filler_chunk, new_filler_transcript, event_type, message_id, sid)
                save_audio_to_file(base64_transcript, final_audio_path)  # Save base64 for future use
            else:
                logger.info(f"{call_id} -- either final_audio_path does not exist or filler_chunk retrieval failed")
                await filler_chunk_based_on_random_array(call_id, language, voice_code, event_type, current_message_id,
                                                         sid, tts_style, is_translate, provider, gender, service_type)
        else:
            logger.info(f"{call_id} -- no prompt_id received from get_buildup_prompt_id")
            if function_name!='disconnect_service':
                await filler_chunk_based_on_random_array(call_id, language, voice_code, event_type, current_message_id, sid,
                                                     tts_style, is_translate, provider, gender, service_type)
            
    except Exception as e:
        logger.error(f"Error in get_buildup_prompt: {e}",exc_info=True)


async def filler_chunk_based_on_random_array(call_id, language, voice_code, event_type, current_message_id, sid,
                                             tts_style, is_translate, provider, gender, service_type=None):
    logger.info(f"playing random notify prompt")

    if service_type == ServiceType.PA.value and pa_random_responses:
        function_calling_chunk = random.choice(pa_random_responses)
    else:
        function_calling_chunk = random.choice(random_responses)
    
    # translated_chunk = translate_transcript(function_calling_chunk, "en", language)
    transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(voice_code,
                                                                                function_calling_chunk,
                                                                                call_id,
                                                                                event_type,
                                                                                tts_style, provider, gender,
                                                                                is_translate)
    message_id = generate_dynamic_message_id(current_message_id, "Avatar")
    sending_chunk = current_chunk + " "
    await send_socket_message(call_id, sending_chunk, transcript, event_type, message_id, sid)


async def send_socket_message(call_id, chunk_text, chunk_transcript, event_type, message_id, sid, is_end_chunk=False):
    message_response = MessageResponse(callId=call_id, chunk=chunk_text,
                                       isEndChunk=is_end_chunk, transcript=chunk_transcript,
                                       messageId=message_id,
                                       eventType=event_type)
    logger.info(f"{call_id} Sending message response -> {message_response.__repr__()}")
    await send_chat_chunk_callback_socket(sid=sid,
                                          data=message_response.dict())


def generate_transcript_based_on_provider(provider, gender, chunk_text, voice_code, call_id, tts_style, language, assistant_id=None):
    logger.info(f"{call_id} generating transcript based on provider {provider} and text {chunk_text}")

    provider = provider.lower()
    try:
        if provider == "google":
            audio_msg = generate_audio_google(message=chunk_text, language_code=language, voice_name=voice_code,
                                              gender=gender)
        elif provider == "eleven-labs":
            audio_msg = generate_audio_eleven_labs(message=chunk_text, voice_name=voice_code)
        elif provider == "whisper" or provider == "openai":
            audio_msg = generate_audio_whisper(message=chunk_text, voice_name=voice_code)
        elif provider == "azure":
            audio_msg = generate_audio_azure(text=chunk_text, lang=language, voice_name=voice_code, tts_style=tts_style, assistant_id=assistant_id)
        else:
            audio_msg = generate_audio_azure(text=chunk_text, lang=language, voice_name=voice_code, tts_style=tts_style, assistant_id=assistant_id)

        return audio_msg
    except Exception as e:
        logger.error(f"Exception in generate_transcript_based_on_provider: {e}",exc_info=True)


def generate_avatar_message_after_silence(call_id, messages):
    try:
        logger.info(f"{call_id} generating avatar message after silence")
        message = call_openai_based_on_model_and_systemmessage("text-embedding-3-small", messages, assistant_id=None)
        return message
    except Exception as e:
        logger.error(f"Error in generate_avatar_message_after_silence: {e}",exc_info=True)
        raise


def create_opening_prompt_vini(vini_system_prompt, assistant_id=None):
    try:
        logger.info("Creating opening prompt for Vini")

        # Get client and model from multi-client configuration
        client, model_name = get_llm_client_for_analysis(assistant_id, "gpt-4")

        if not client:
            logger.warning("No LLM client available for Vini opening prompt, using default message")
            return "Hello! How can I assist you today?"

        completion = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": vini_system_prompt},
                {"role": "system", "content": opening_statement_prompt},
            ],
        )
        # Extract and return the model's response
        opening_message_response = completion.choices[0].message.content

        run_alarm_in_thread(send_alarm(alarm_type='Azure_OpenAI_API', remarks="Azure_OpenAI_API working fine", status='clear'))
        logger.info(f"Generated Vini opening prompt using model {model_name}")
        return opening_message_response
    except Exception as e:
        logger.error(f"Error in create_opening_prompt_vini: {e}",exc_info=True)
        run_alarm_in_thread(send_alarm(alarm_type='Azure_OpenAI_API', remarks=str(e), status='raise'))
        return "Hello! How can I assist you today?"


def tts_and_send_response(voice_code, chunk, call_id, event_type, tts_style, provider, gender, is_translate,
                          currentMessageId, socket_id):
    try:
        tts_start_time = time.time()
        logger.info(f"call_id - {call_id} Chunk Representation for chunk - {chunk} repr -  {repr(chunk)}")
        chunk = chunk.replace('\\n', '')
        transcript, current_chunk = convert_chunk_to_transcript_based_on_voice_code(
            voice_code,
            chunk,
            call_id, event_type, tts_style, provider, gender, is_translate
        )
        logger.info(
            f"Time taken for TTS for Call Id - {call_id} for chunk - {current_chunk} -  {time.time() - tts_start_time}")

        message_id = generate_dynamic_message_id(currentMessageId, "Avatar")
        message_response = MessageResponse(callId=call_id, chunk=current_chunk,
                                           isEndChunk=False, transcript=transcript,
                                           messageId=message_id, eventType=event_type)
        logger.info(
            f"{call_id} Sending message response -> {message_response.__repr__()} for chunk {current_chunk} at time {get_current_time_with_milliseconds()}")

        # Send response using asyncio to ensure thread safety
        asyncio.run(send_chat_chunk_callback_socket(sid=socket_id, data=message_response.dict()))

    except Exception as e:
        logger.error(f"Exception in TTS and Send Response for Call Id {call_id}: {e}",exc_info=True)


def get_call_sentiments(call_id, call_messages,assistant_id=None):
    try:
        logger.secure(f"Getting call sentiments for call_id {call_id}")

        # Get client and model from multi-client configuration
        client, model_name = get_llm_client_for_analysis(assistant_id,"gpt-4")

        if not client:
            logger.warning("No LLM client available for sentiment analysis, returning neutral")
            return "neutral"

        conversation_text = "\n".join([list(message.values())[0] for message in call_messages])
        call_sentiment_analyser_final_prompt = call_sentiment_analyser_prompt + conversation_text
        message_array = [{"role": "system", "content": call_sentiment_analyser_final_prompt}]
        completion = client.chat.completions.create(
            model=model_name,
            messages=message_array,
        )
        call_sentiments = completion.choices[0].message.content
        logger.info(f"Generated sentiment analysis using model {model_name}")
        return call_sentiments
    except Exception as e:
        logger.error(f"Error in get_call_sentiments: {e}",exc_info=True)
        run_alarm_in_thread(send_alarm(alarm_type='Azure_OpenAI_API', remarks=str(e), status='raise'))
        return "neutral"


def get_call_emotions(call_id, call_messages, assistant_id=None):
    try:
        logger.secure(f"Getting call emotions for call_id {call_id}")

        # Get client and model from multi-client configuration
        client, model_name = get_llm_client_for_analysis(assistant_id, "gpt-4")

        if not client:
            logger.warning("No LLM client available for emotion analysis, returning neutral")
            return "neutral"

        conversation_text = "\n".join([list(message.values())[0] for message in call_messages])
        call_emotions_analyser_final_prompt = call_emotions_analyser_prompt + conversation_text
        message_array = [{"role": "system", "content": call_emotions_analyser_final_prompt}]
        completion = client.chat.completions.create(
            model=model_name,
            messages=message_array,
        )
        call_emotions = completion.choices[0].message.content
        logger.info(f"Generated emotion analysis using model {model_name}")
        return call_emotions
    except Exception as e:
        logger.error(f"Error in get_call_emotions: {e}",exc_info=True)
        run_alarm_in_thread(send_alarm(alarm_type='Azure_OpenAI_API', remarks=str(e), status='raise'))
        return "neutral"


def get_call_intent(call_id, call_messages, assistant_id=None):
    try:
        logger.secure(f"Getting call intent for call_id {call_id}")

        # Get client and model from multi-client configuration
        client, model_name = get_llm_client_for_analysis(assistant_id, "gpt-4")

        if not client:
            logger.warning("No LLM client available for intent analysis, returning general_inquiry")
            return "general_inquiry"

        conversation_text = "\n".join([list(message.values())[0] for message in call_messages])
        call_intent_analyser_final_prompt = call_intent_analyser_prompt + conversation_text
        message_array = [{"role": "system", "content": call_intent_analyser_final_prompt}]
        completion = client.chat.completions.create(
            model=model_name,
            messages=message_array,
        )
        call_intent = completion.choices[0].message.content
        logger.info(f"Generated intent analysis using model {model_name}")
        return call_intent
    except Exception as e:
        logger.error(f"Error in get_call_intent: {e}")
        run_alarm_in_thread(send_alarm(alarm_type='Azure_OpenAI_API', remarks=str(e), status='raise'))
        return "general_inquiry"


def get_call_satisfaction_score(call_id, call_messages, assistant_id=None):
    try:
        logger.secure(f"Getting call satisfaction score for call_id {call_id}")

        # Get client and model from multi-client configuration
        client, model_name = get_llm_client_for_analysis(assistant_id, "gpt-4")

        if not client:
            logger.warning("No LLM client available for satisfaction score analysis, returning neutral score")
            return "3"

        conversation_text = "\n".join([list(message.values())[0] for message in call_messages])
        call_satisfaction_analyser_final_prompt = call_satisfaction_analyser_prompt + conversation_text
        message_array = [{"role": "system", "content": call_satisfaction_analyser_final_prompt}]
        completion = client.chat.completions.create(
            model=model_name,
            messages=message_array,
        )
        call_satisfaction_score = completion.choices[0].message.content
        logger.info(f"Generated satisfaction score analysis using model {model_name}")
        return call_satisfaction_score
    except Exception as e:
        logger.error(f"Error in get_call_satisfaction_score: {e}")
        run_alarm_in_thread(send_alarm(alarm_type='Azure_OpenAI_API', remarks=str(e), status='raise'))
        return "3"


def create_opening_prompt_sh(sh_system_prompt, previous_complains, assistant_id=None):
    try:
        logger.info("Creating opening prompt for Sh")

        # Get client and model from multi-client configuration
        client, model_name = get_llm_client_for_analysis(assistant_id, "gpt-4")

        if not client:
            logger.warning("No LLM client available for Sh opening prompt, using default message")
            return "Hello! I'm here to help you with your service requests. How can I assist you today?"

        completion = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": sh_system_prompt},
                {"role": "system", "content": sh_opening_statement_prompt},
                {"role": "system", "content": str(previous_complains)}
            ],
        )
        opening_message_response = completion.choices[0].message.content
        logger.info(f"Generated Sh opening prompt using model {model_name}")
        return opening_message_response
    except Exception as e:
        logger.error(f"Error in create_opening_prompt_sh: {e}",exc_info=True)
        run_alarm_in_thread(send_alarm(alarm_type='Azure_OpenAI_API', remarks=str(e), status='raise'))
        return "Hello! I'm here to help you with your service requests. How can I assist you today?"


def generate_random_pin():
    # Generate a unique pin
    base_pin = random.randint(10000, 99999)
    pin_digits = [int(d) for d in str(base_pin)]
    xor_digit = random.randint(0, 9)
    pin_digits[-1] = pin_digits[-1] ^ xor_digit
    unique_pin = int(''.join(str(d) for d in pin_digits))
    return unique_pin

async def send_call_record_to_jericho(aParty,bParty,llmMessages,callFilePath,callStartTime,callEndTime,call_summary_prompt, assistant_id=None):
    try:
        # Filter messages once for both summary and conversation
        filtered_messages = [
            msg for msg in llmMessages
            if msg.get("role") in ("user", "assistant") and msg.get("content")
        ]

        uniquePin=generate_random_pin()

        # Prepare conversation text for summary
        conversation_text = "\n".join(msg["content"] for msg in filtered_messages)

        call_summary_prompt = call_summary_prompt.replace("<<conversation_text>>", conversation_text)
        call_summary_prompt = call_summary_prompt.replace("<<call_summary_word_limit>>", call_summary_word_limit)
        call_summary_prompt = call_summary_prompt.replace("<<reference_current_datetime>>",callEndTime)

        message_array = [{"role": "system", "content": call_summary_prompt}]

        # Generate call summary using multi-client configuration
        client, model_name = get_llm_client_for_analysis(assistant_id, "gpt-4")

        if not client:
            logger.warning("No LLM client available for call summary generation, using default values")
            call_summary = "Call completed successfully"
            isCalenderBlock = False
            calenderBlockStartTime = None
            calenderBlockEndTime = None
            subject = f"Call with {aParty}"
            callerName = aParty
        else:
            completion = client.chat.completions.create(
                model=model_name,
                messages=message_array,
            )

            response_text = completion.choices[0].message.content
            logger.info(f"Generated call summary using model {model_name}")

            # Parse the JSON response
            try:
                response_json = json.loads(response_text)
                call_summary = response_json.get("call_summary")
                call_summary = call_summary.replace("<<aParty>>", aParty)
                isCalenderBlock = response_json.get("isCalenderBlock")
                calenderBlockStartTime = response_json.get("calenderBlockStartTime")
                calenderBlockEndTime = response_json.get("calenderBlockEndTime")
                subject = response_json.get("subject")
                subject = subject.replace("<<aParty>>", aParty)
                callerName = response_json.get("callerName")
                callerName = callerName.replace("<<aParty>>", aParty)
            except Exception as e:
                logger.error(f"Failed to parse response {response_text} from call summary generation:{e}",exc_info=True)
                call_summary = "Call completed successfully"
                subject = f"Call with {aParty}"
                callerName = aParty
                isCalenderBlock = False
                calenderBlockStartTime = None
                calenderBlockEndTime = None

        # Prepare payload
        payload = {
            "msisdn": bParty,
            "aparty": aParty,
            "summaryConversation": call_summary,
            "fullConversation": json.dumps(filtered_messages, ensure_ascii=True),
            "callFilePath": callFilePath,
            "pin": str(uniquePin),
            "subject": subject,
            "callerName": callerName,
            "isCalenderBlock": isCalenderBlock,
            "calenderBlockStartTime": calenderBlockStartTime,
            "calenderBlockEndTime": calenderBlockEndTime,
            "startTimeStamp": callStartTime,
            "endTimeStamp": callEndTime
        }

        # Check if Jericho endpoint is configured
        if not pa_jericho_call_log_api_endpoint:
            logger.warning("PA_JERICHO_CALL_LOG_API_ENDPOINT not configured, skipping Jericho call record")
            return
        
        logger.info(f"Sending call record to Jericho - URL: {pa_jericho_call_log_api_endpoint}, Payload: {payload}")

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.post(pa_jericho_call_log_api_endpoint, json=payload)
                logger.info(f"Received response from Jericho: {response.status_code} {response.text}")
        except Exception as e:
            logger.error(f"Error in send_call_record_to_jericho: {e}", exc_info=True)
            run_alarm_in_thread(send_alarm(alarm_type='Jericho_Call_Log', remarks=str(e), status='raise', assistant_id=assistant_id))
            raise
        # Clear alarm on success
        run_alarm_in_thread(send_alarm(alarm_type='Jericho_Call_Log', remarks="Jericho API working fine", status='clear', assistant_id=assistant_id))
    except Exception as e:
        logger.error(f"Error in send_call_record_to_jericho: {e}", exc_info=True)
        raise

