"""
CDR API Controller
Handles CDR push requests via REST API
"""
from fastapi import APIRouter, Query, HTTPException
from logger import get_logger
from service.cdr_api_service import get_cdr_api_pusher
import time

logger = get_logger(__name__)

# Create FastAPI router for CDR API routes
router = APIRouter(tags=["CDR API"])

@router.get("/push")
def push_cdr(
    country: str = Query(..., description="Country code"),
    operator: str = Query(..., description="Operator name"),
    call_status: str = Query("completed", description="Call status")
):
    """
    Push CDR to external API with provided parameters
    
    Args:
        country: Country code
        operator: Operator name  
        call_status: Call status
        
    Returns:
        200 OK with success message
    """
    try:
        logger.info(f"CDR push request received - country: {country}, operator: {operator}, status: {call_status}")
        
        # Get CDR API pusher
        pusher = get_cdr_api_pusher()
        
        # Create CDR with default values
        cdr_data = pusher.create_cdr_from_params(country, operator, call_status)
        
        # Generate unique call ID for this API request
        call_id = cdr_data['call_id']
        
        # Push CDR asynchronously
        pusher.push_cdr_async(call_id, cdr_data)
        
        # Return immediate response
        return {
            'status': 'success',
            'message': 'CDR push request submitted successfully',
            'call_id': call_id,
            'country': country,
            'operator': operator,
            'call_status': call_status,
            'timestamp': int(time.time())
        }
        
    except Exception as e:
        logger.error(f"Error in CDR push API: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to process CDR push request: {str(e)}")


