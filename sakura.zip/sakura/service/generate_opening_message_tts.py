from controllers.audio_controller import generate_audio_azure
from config import assistant_config
from logger import get_logger

logger = get_logger(__name__)

def generate_opening_msg_for_assistant_tts(assist_id: str):
    try:
        output_file = f"tts_outputs_{assist_id}.txt"
        logger.info("generate_opening_msg_for_assistant_tts called")
        assistant = assistant_config.assistants[assist_id]
        opening_msg = assistant["opening_message"]
        audio = generate_audio_azure(opening_msg)
        logger.debug(f"opening_msg: {opening_msg} and audio: {audio}")
        with open(output_file, "w") as f:
            f.write(audio)
    except Exception as e:
        logger.error(f"Error while generating opening message in generate_opening_message_tts.py : {e}",exc_info=True)

