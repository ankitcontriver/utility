import gzip
import logging
import os
import shutil
import time
from logging import Logger
from logging.handlers import TimedRotatingFileHandler

# Add custom SECURE log level (value 25, between INFO=20 and WARNING=30)
SECURE_LEVEL = 25
logging.addLevelName(SECURE_LEVEL, "SECURE")

def secure(self, message, *args, **kwargs):
    """Log a message with severity 'SECURE'."""
    if self.isEnabledFor(SECURE_LEVEL):
        self._log(SECURE_LEVEL, message, args, **kwargs)

# Add the secure method to Logger class - THIS IS THE KEY LINE
logging.Logger.secure = secure

def suppress_loggers():
    """
    Suppress noisy loggers such as Werkzeug.
    """
    logging.getLogger("werkzeug").setLevel(logging.ERROR)


class GzipTimedRotatingFileHandler(TimedRotatingFileHandler):
    def doRollover(self):
        """
        Perform log rotation and compress the old log file.
        """
        # Perform the regular rotation
        super().doRollover()

        # The filename of the rotated log file
        rotated_log = self.baseFilename + "." + time.strftime("%Y%m%d-%H%M%S")
        
        # Compress the rotated log file
        gz_filename = rotated_log + ".gz"

        if os.path.exists(rotated_log):
            with open(rotated_log, 'rb') as f_in:
                with gzip.open(gz_filename, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
        else:
            pass            

        # Remove the original uncompressed log file
        if os.path.exists(rotated_log):
            os.remove(rotated_log)

        print(f"Compressed {rotated_log} to {gz_filename}")


def init_logger():
    """
    Initializes the logger with the specified configurations.
    Reads log file path, level, and format from environment variables.
    Configures log rotation every hour and GZIP compression for old logs.
    """
    print("Logger initializing...")
    log_file_path = _get_log_file_path()
    log_level = _get_log_level()
    log_format = _get_log_format()

    print(f"Initializing logger with configurations: \n"
                f"Log file path: {log_file_path} \n"
                f"Log level: {log_level} \n"
                f"Log format: {log_format}")

    # Create the GZIP Timed Rotating File Handler (rotates every hour)
    handler = GzipTimedRotatingFileHandler(
        filename=log_file_path,
        when="H",        # Set rotation to occur every hour
        interval=1,      # Rotate every 1 hour
        backupCount=5,   # Keep up to 5 old log files
        encoding="utf-8" # Ensure encoding is UTF-8
    )
    
    # Set the suffix to include the timestamp and use GZIP compression
    handler.suffix = "%Y-%m-%d_%H-%M-%S.gz"
    
    handler.setFormatter(logging.Formatter(log_format))

    # Configure the root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)

    # Clear any existing handlers to avoid duplication
    if root_logger.hasHandlers():
        root_logger.handlers.clear()

    # Add file handler and optionally a console handler
    root_logger.addHandler(handler)

    # Optionally, add a console handler to see logs on the terminal
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter(log_format))
    root_logger.addHandler(console_handler)

    suppress_loggers()
    print(f"Logger initialized. Logs will be written to {log_file_path}")


def get_logger(name: str) -> Logger:
    """
    Returns a logger instance with the specified name.
    """
    return logging.getLogger(name)


def _get_log_file_path() -> str:
    """
    Returns the log file path, creating the directory if necessary.
    """
    default_log_path = "logs/sakura.log"  # Changed to 'sakura.log'
    log_file_path = os.environ.get("LOG_FILE_PATH", default_log_path)

    if not log_file_path:
        log_file_path = default_log_path

    # Ensure the directory exists
    log_dir = os.path.dirname(log_file_path)
    if not os.path.exists(log_dir):
        print(f"Creating directory: {log_dir}")
        os.makedirs(log_dir, exist_ok=True)

    return log_file_path


def _get_log_level() -> int:
    """
    Returns the logging level based on the LOG_LEVEL environment variable.
    Defaults to INFO if not specified or invalid.
    """
    log_level = os.environ.get("LOG_LEVEL", "INFO").upper()
    
    # Handle custom SECURE level
    if log_level == "SECURE":
        return SECURE_LEVEL
    
    # Check if it's a valid logging level name
    if hasattr(logging, log_level):
        return getattr(logging, log_level)
    
    # Fallback to INFO if invalid
    return logging.INFO


def _get_log_format() -> str:
    """
    Returns the log format based on the LOG_FORMAT environment variable.
    Defaults to a standard format if not specified.
    """
    default_log_format = "%(asctime)s %(levelname)s %(name)s %(threadName)s : %(message)s"
    log_format = os.environ.get("LOG_FORMAT", default_log_format)
    return log_format or default_log_format
