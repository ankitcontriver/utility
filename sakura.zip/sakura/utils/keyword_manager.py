import json
import os
import threading
from typing import Dict, List, Any

class KeywordManager:
    """
    Manages all dynamic keywords and dictionaries (person names, urgency, formality, intent, etc.)
    in a single persistent JSON file. Thread-safe for concurrent access.
    """
    def __init__(self, json_path: str = "dynamic_keywords.json"):
        self.json_path = json_path
        self.lock = threading.Lock()
        self.keywords = self._load_keywords()

    def _load_keywords(self) -> Dict[str, List[str]]:
        if os.path.exists(self.json_path):
            with open(self.json_path, "r") as f:
                return json.load(f)
        # Default structure if file does not exist
        return {
            "person_names": [],
            "urgency_keywords": [],
            "formality_keywords": [],
            "intent_keywords": [],
            "sentiment_keywords": [],
            "other_keywords": []
        }

    def save_keywords(self):
        with self.lock:
            with open(self.json_path, "w") as f:
                json.dump(self.keywords, f, indent=2)

    def add_keyword(self, category: str, keyword: str):
        with self.lock:
            if keyword not in self.keywords.get(category, []):
                self.keywords.setdefault(category, []).append(keyword)

    def prune_keywords(self, category: str, used_keywords: List[str]):
        with self.lock:
            self.keywords[category] = [k for k in self.keywords.get(category, []) if k in used_keywords]

    def get_keywords(self, category: str) -> List[str]:
        return self.keywords.get(category, [])

    def get_all(self) -> Dict[str, List[str]]:
        return self.keywords

    def update_from_llm(self, learning_data: Dict[str, List[str]]):
        """
        Update all keyword categories from LLM learning_data (expects dict with keys matching categories)
        """
        with self.lock:
            for category, words in learning_data.items():
                for word in words:
                    if word not in self.keywords.get(category, []):
                        self.keywords.setdefault(category, []).append(word)

    def shutdown(self):
        self.save_keywords()
