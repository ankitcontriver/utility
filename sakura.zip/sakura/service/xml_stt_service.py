import os
import json
import time
import html
import re
from typing import Dict, Any, List, Optional
import subprocess
import xml.etree.ElementTree as ET
from logger.__init__ import get_logger

logger = get_logger(__name__)  # Use your project's logger

PROMPTS_WAV_DIR = os.getenv('PROMPTS_WAV_DIR')
STT_API_KEY = os.getenv('STT_API_KEY')
STT_API_REGION = os.getenv('STT_API_REGION')

class XMLSTTProcessor:
    def __init__(self):
        """
        Initialize the STT processor using global environment variables for API key, region, and wav directory.
        """
        self.api_key = STT_API_KEY
        self.region = STT_API_REGION
        self.stt_url = f"https://{self.region}.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?format=detailed&language=en-US"
        self.wav_directory = PROMPTS_WAV_DIR
        

    def transcribe_wav(self, wav_file_path: str) -> Dict[str, Any]:
        """
        Transcribe WAV file using STT API (no caching).
        """
        if not os.path.exists(wav_file_path):
            return {
                'status': 'error',
                'error': f'File not found: {wav_file_path}',
                'transcription': '',
                'confidence': 0
            }
        return self.transcribe_wav_with_curl(wav_file_path)

    def transcribe_wav_with_curl(self, wav_file_path: str) -> Dict[str, Any]:
        if not os.path.exists(wav_file_path):
            return {
                'status': 'error',
                'error': f'File not found: {wav_file_path}',
                'transcription': '',
                'confidence': 0
            }
        try:
            curl_cmd = [
                'curl', '-s', '-w', '%{http_code}',
                '-X', 'POST', self.stt_url,
                '-H', 'Content-Type: audio/wav; codecs=audio/pcm; samplerate=16000',
                '-H', f'Ocp-Apim-Subscription-Key: {self.api_key}',
                '-H', f'Ocp-Apim-Subscription-Region: {self.region}',
                '-H', 'Accept: application/json',
                '--data-binary', f'@{wav_file_path}'
            ]
            debug_cmd = curl_cmd.copy()
            debug_cmd[7] = 'Ocp-Apim-Subscription-Key: [HIDDEN]'
            logger.debug(f"Curl command: {' '.join(debug_cmd)}")
            result = subprocess.run(curl_cmd, capture_output=True, text=True)
            response_text = result.stdout.strip()
            status_code = response_text[-3:] if response_text[-3:].isdigit() else 'unknown'
            json_response = response_text[:-3] if status_code != 'unknown' else response_text
            if status_code == '200' and json_response:
                try:
                    stt_result = json.loads(json_response)
                    if stt_result.get('RecognitionStatus') == 'Success':
                        return {
                            'status': 'success',
                            'transcription': stt_result.get('DisplayText', ''),
                            'confidence': stt_result.get('NBest', [{}])[0].get('Confidence', 0) if stt_result.get('NBest') else 0,
                            'raw_response': stt_result
                        }
                    else:
                        return {
                            'status': 'error',
                            'error': f'Recognition failed: {stt_result.get("RecognitionStatus", "Unknown")}',
                            'transcription': '',
                            'confidence': 0
                        }
                except json.JSONDecodeError as e:
                    return {
                        'status': 'error',
                        'error': f'Invalid JSON response: {str(e)}',
                        'transcription': '',
                        'confidence': 0
                    }
            elif status_code != '200':
                return {
                    'status': 'error',
                    'error': f'HTTP {status_code}: {json_response}',
                    'transcription': '',
                    'confidence': 0
                }
            else:
                return {
                    'status': 'error',
                    'error': 'Empty JSON response',
                    'transcription': '',
                    'confidence': 0
                }
        except Exception as e:
            return {
                'status': 'error',
                'error': str(e),
                'transcription': '',
                'confidence': 0
            }

    def process_xml_string(self, xml_string: str, lang_selection_via_asr: bool = False) -> Dict[str, Any]:
        logger.info(f"Processing XML from string input")
        try:
            # Unescape HTML entities (e.g., &lt;, &gt;)
            xml_string = html.unescape(xml_string)
            # Replace unicode escapes (e.g., \u003c, \u003e, \u0022)
            xml_string = re.sub(r'\\u003c', '<', xml_string)
            xml_string = re.sub(r'\\u003e', '>', xml_string)
            xml_string = re.sub(r'\\u0022', '"', xml_string)

            # Try decoding unicode escapes
            try:
                xml_string = xml_string.encode('utf-8').decode('unicode_escape')
            except Exception as e:
                logger.error(f"Unicode escape decode failed: {e}")

            xml_string = xml_string.strip()
            root = ET.fromstring(xml_string)
        except Exception as e:
            logger.error(f"Failed to parse XML string: {e}")
            return {
                "metadata": {"error": f"Failed to parse XML: {e}"},
                "nodes": {}
            }
        
        # Find choose language and setlanguage nodes if lang_selection_via_asr is true
        choose_language_node = None
        setlanguage_nodes = {}
        if lang_selection_via_asr:
            choose_language_node = self.find_choose_language_node(xml_string)
            setlanguage_nodes = self.get_setlanguage_nodes(xml_string)
            logger.info(f"Found choose_language_node: {choose_language_node}")
            logger.info(f"Found setlanguage_nodes: {setlanguage_nodes}")
        
        wav_directory = self.wav_directory
        root_element = root.find('root')
        all_nodes = {}
        connections = {}
        if root_element is not None:
            for mx_cell in root_element.findall('mxCell'):
                cell_id = mx_cell.get('id')
                cell_type = mx_cell.get('type')
                source = mx_cell.get('source')
                target = mx_cell.get('target')
                if cell_id:
                    all_nodes[cell_id] = {
                        'id': cell_id,
                        'type': cell_type,
                        'value': mx_cell.get('value', ''),
                        'children': []
                    }
                if cell_type in ['DTMF', 'Normal'] and source and target:
                    if source not in connections:
                        connections[source] = []
                    connections[source].append(target)
        navigation_nodes = {}
        if root_element is not None:
            for mx_cell in root_element.findall('mxCell'):
                cell_id = mx_cell.get('id')
                cell_type = mx_cell.get('type')
                if cell_type == 'Navigation':
                    mx_params = mx_cell.find('mxParams')
                    if mx_params is not None:
                        wav_files = []
                        for mx_param in mx_params.findall('mxParam'):
                            promptfile = mx_param.get('promptfile')
                            if promptfile and promptfile.endswith('.wav'):
                                clean_path = promptfile
                                if '-' in promptfile and promptfile[0].isdigit():
                                    clean_path = promptfile.split('-', 1)[1] if '-' in promptfile else promptfile
                                wav_file_info = {
                                    'original_path': clean_path,
                                    'filename': clean_path.split('/')[-1] if '/' in clean_path else clean_path,
                                    'is_voice_prompt': '_VOICEPROMPT' in promptfile
                                }
                                wav_files.append(wav_file_info)
                        if wav_files:
                            navigation_nodes[cell_id] = {
                                'id': cell_id,
                                'type': cell_type,
                                'value': mx_cell.get('value', ''),
                                'wav_files': wav_files,
                                'stt_results': {},
                                'children': connections.get(cell_id, [])
                            }
        logger.debug(f"Found {len(navigation_nodes)} Navigation nodes with WAV files")
        processed_nodes = {}
        successful_transcriptions = 0
        failed_transcriptions = 0
        for node_id, node_data in navigation_nodes.items():
            logger.debug(f"Processing node {node_id}: {node_data['value']}")
            node_stt_results = {'voice': [], 'dtmf': []}
            node_success_count = 0
            node_total_count = 0
            has_question_prompt = False
            for wav_file in node_data['wav_files']:
                wav_path = None
                if wav_directory:
                    potential_path = os.path.join(wav_directory, wav_file['filename'])
                    if os.path.exists(potential_path):
                        wav_path = potential_path
                if not wav_path:
                    if os.path.exists(wav_file['original_path']):
                        wav_path = wav_file['original_path']
                if wav_path and os.path.exists(wav_path):
                    node_total_count += 1
                    stt_result = self.transcribe_wav(wav_path)
                    if stt_result['status'] == 'success':
                        transcription = stt_result['transcription']
                        successful_transcriptions += 1
                        node_success_count += 1
                        has_question_prompt = True
                    else:
                        transcription = wav_path
                        failed_transcriptions += 1
                    if wav_file['is_voice_prompt']:
                        node_stt_results['voice'].append(transcription)
                        # Store original filename for language mapping
                        if 'original_filenames' not in node_stt_results:
                            node_stt_results['original_filenames'] = {'voice': [], 'dtmf': []}
                        node_stt_results['original_filenames']['voice'].append(wav_file['filename'])
                    else:
                        node_stt_results['dtmf'].append(transcription)
                        # Store original filename for language mapping
                        if 'original_filenames' not in node_stt_results:
                            node_stt_results['original_filenames'] = {'voice': [], 'dtmf': []}
                        node_stt_results['original_filenames']['dtmf'].append(wav_file['filename'])
                    time.sleep(0.5)
                else:
                    node_total_count += 1
                    failed_transcriptions += 1
                    fallback_path = wav_file['original_path']
                    if wav_file['is_voice_prompt']:
                        node_stt_results['voice'].append(fallback_path)
                        # Store original filename for language mapping
                        if 'original_filenames' not in node_stt_results:
                            node_stt_results['original_filenames'] = {'voice': [], 'dtmf': []}
                        node_stt_results['original_filenames']['voice'].append(wav_file['filename'])
                    else:
                        node_stt_results['dtmf'].append(fallback_path)
                        # Store original filename for language mapping
                        if 'original_filenames' not in node_stt_results:
                            node_stt_results['original_filenames'] = {'voice': [], 'dtmf': []}
                        node_stt_results['original_filenames']['dtmf'].append(wav_file['filename'])
            node_output = {'stt': node_stt_results}
            if has_question_prompt and node_data['children']:
                node_output['children'] = node_data['children']
            processed_nodes[node_id] = node_output
        
        # Create the base result structure
        result = {
            'metadata': {
                'source_xml': 'xml.xml',
                'total_nodes': len(processed_nodes),
                'root_nodes': len([n for n in processed_nodes.values() if n.get('parent') is None]),
                'total_connections': sum(len(n.get('children', [])) for n in processed_nodes.values()),
                'node_types': {}
            },
            'nodes': processed_nodes
        }
        
        # Count node types
        for node_data in processed_nodes.values():
            node_type = node_data.get('type', 'Unknown')
            result['metadata']['node_types'][node_type] = result['metadata']['node_types'].get(node_type, 0) + 1
        
        # Add language selection block if lang_selection_via_asr is true
        if lang_selection_via_asr and choose_language_node and setlanguage_nodes:
            # Create setlanguage_children
            setlanguage_children = []
            for setlang_id, setlang_data in setlanguage_nodes.items():
                setlanguage_children.append({
                    'id': setlang_id,
                    'type': 'processing',
                    'value': 'setlanguage',
                    'mxParams': setlang_data.get('mxParam', '_E')
                })
            
            result['language_selection'] = {
                'choose_language': choose_language_node,
                'setlanguage_children': setlanguage_children
            }
        
        return result

    def process_xml_file(self, xml_file_path: str, lang_selection_via_asr: bool = False) -> Dict[str, Any]:
        with open(xml_file_path, 'r', encoding='utf-8') as f:
            xml_string = f.read()
        return self.process_xml_string(xml_string, lang_selection_via_asr)

    def analyze_results(self, result: Dict[str, Any]) -> Dict[str, Any]:
        metadata = result.get('metadata', {})
        nodes = result.get('nodes', {})
        summary = {
            'total_navigation_nodes': metadata.get('total_navigation_nodes', 0),
            'included_nodes': metadata.get('included_nodes', 0),
            'successful_transcriptions': metadata.get('successful_transcriptions', 0),
            'failed_transcriptions': metadata.get('failed_transcriptions', 0),
            'sample_nodes': []
        }
        for node_id, node_data in list(nodes.items())[:5]:
            stt_data = node_data.get('stt', {})
            summary['sample_nodes'].append({
                'node_id': node_id,
                'voice': stt_data.get('voice', []),
                'dtmf': stt_data.get('dtmf', []),
                'children': node_data.get('children', [])
            })
        return summary 

    def find_choose_language_node(self, xml_string: str) -> Optional[str]:
        """Find navigation node with 'choose language' value"""
        try:
            root = ET.fromstring(xml_string)
            root_element = root.find('root')
            if root_element is not None:
                for mx_cell in root_element.findall('mxCell'):
                    if (mx_cell.get('type') == 'Navigation' and 
                        'choose langauge' in mx_cell.get('value', '').lower()):
                        node_id = mx_cell.get('id')
                        return node_id
        except Exception as e:
            logger.error(f"Error finding choose language node: {e}")
        return None

    def get_setlanguage_nodes(self, xml_string: str) -> Dict[str, Any]:
        """Find all processing nodes with 'setlanguage' value"""
        setlanguage_nodes = {}
        try:
            root = ET.fromstring(xml_string)
            root_element = root.find('root')
            if root_element is not None:
                for mx_cell in root_element.findall('mxCell'):
                    if (mx_cell.get('type') == 'Processing' and 
                        mx_cell.get('value') == 'setlanguage'):
                        node_id = mx_cell.get('id')
                        mx_params = mx_cell.find('mxParams')
                        # Get the mxParam value from mxParams
                        mx_param_value = '_E'  # Default value
                        if mx_params is not None:
                            for mx_param in mx_params.findall('mxParam'):
                                param_value = mx_param.get('value', '')
                                if param_value:
                                    mx_param_value = param_value
                                    break
                        
                        setlanguage_nodes[node_id] = {
                            'id': node_id,
                            'value': mx_cell.get('value'),
                            'mxParam': mx_param_value
                        }
        except Exception as e:
            logger.error(f"Error finding setlanguage nodes: {e}")
        return setlanguage_nodes