from response.GenericResponse import GenericResponse


class Menu:
    def __init__(self, id, title, path):
        self.id = id
        self.title = title
        self.path = path

    def __repr__(self):
        return f"id: {self.id}, title: {self.title}, path: {self.path}"


class GetMenuResponse(GenericResponse):
    def __init__(self, status, status_code, message, data: list[Menu]):
        super().__init__(status=status,status_code=status_code,message=message)
        self.data = data

    def __repr__(self):
        return f"status: {self.status}, status_code: {self.status_code}, message: {self.message}, data: {self.data}"
